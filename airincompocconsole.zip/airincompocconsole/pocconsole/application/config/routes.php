<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['tenant/add']['post'] = 'tenant/add_action';
$route['tenant/edit/(:num)']['post'] = 'tenant/edit_action/$1';
$route['pocaccount/add/(:num)']['post'] = 'pocaccount/add_action/$1';
$route['pocaccount/add_batch/(:num)']['post'] = 'pocaccount/add_batch_action/$1';
$route['pocaccount/edit/(:num)/(:num)']['post'] = 'pocaccount/edit_action/$1/$2';
$route['pocaccount/handy_edit/(:num)/(:num)']['post'] = 'pocaccount/handy_edit_action/$1/$2';
$route['devicesetting/edit/(:num)']['post'] = 'devicesetting/edit_action/$1';
$route['dialplan/edit/(:num)']['post'] = 'dialplan/edit_action/$1';
$route['handy_device/edit/(:num)']['post'] = 'handy_device/edit_action/$1';
$route['handy_tenant/edit/(:num)']['post'] = 'handy_tenant/edit_action/$1';
$route['handy_factory/edit']['post'] = 'handy_factory/edit_action';
$route['group/add/(:num)']['post'] = 'group/add_action/$1';
$route['group/add_batch/(:num)']['post'] = 'group/add_batch_action/$1';
$route['group/edit/(:num)/(:num)']['post'] = 'group/edit_action/$1/$2';
$route['group/plan/(:num)/(:num)']['post'] = 'group/plan_post_action/$1/$2';
$route['webaccount/add']['post'] = 'webaccount/add_action';
$route['webaccount/edit/(:num)']['post'] = 'webaccount/edit_action/$1';
$route['firmup_handy/add']['post'] = 'firmup_handy/add_action';
$route['firmup_handy/edit/(:num)']['post'] = 'firmup_handy/edit_action/$1';
$route['firmup_handy/macaddr_edit/(:num)']['post'] = 'firmup_handy/macaddr_edit_action/$1';
$route['default_controller'] = 'login';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
