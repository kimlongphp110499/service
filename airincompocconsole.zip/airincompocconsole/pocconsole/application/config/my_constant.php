<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$config['my_constant.php'] = '';

// webaccount type names
global $global_web_account_type_names;
$global_web_account_type_names =array(
	'admin'=> '保守',
	'tenant' => 'テナント',
	'tenant_api' => 'API'
);

// poc/group account enable/disable status names
global $global_account_status_names;
$global_account_status_names =array(
	'0'=> '無効',
	'1' => '有効'
);

// standard Industry-Type names
global $global_industry_names;
$global_industry_names = array(
	'(01) 農業,林業' => '農業,林業',
	'(02) 漁業' => '漁業',
	'(03) 鉱業,採石業,砂利採取業' => '鉱業,採石業,砂利採取業',
	'(04) 建設業' => '建設業',
	'(05) 製造業' => '製造業',
	'(06) 電気・ガス・熱供給・水道業' => '電気・ガス・熱供給・水道業',
	'(07) 情報通信業' => '情報通信業',
	'(08) 運輸業,郵便業' => '運輸業,郵便業',
	'(09) 卸売業,小売業' => '卸売業,小売業',
	'(10) 金融業,保険業' => '金融業,保険業',
	'(11) 不動産業,物品賃貸業' => '不動産業,物品賃貸業',
	'(12) 学術研究,専門・技術サービス業' => '学術研究,専門・技術サービス業',
	'(13) 宿泊業,飲食サービス業' => '宿泊業,飲食サービス業',
	'(14) 生活関連サービス業,娯楽業' => '生活関連サービス業,娯楽業',
	'(15) 教育,学習支援業' => '教育,学習支援業',
	'(16) 医療,福祉' => '医療,福祉',
	'(17) 複合サービス事業' => '複合サービス事業',
	'(18) その他のサービス業' => 'その他のサービス業',
	'(19) その他の公務' => 'その他の公務',
	'(99) その他(自由入力)' => ''
);

// standard Industry-Type numbers
global $global_industry_numbers;
$global_industry_numbers = array(
	'1' => '農業,林業',
	'2' => '漁業',
	'3' => '鉱業,採石業,砂利採取業',
	'4' => '建設業',
	'5' => '製造業',
	'6' => '電気・ガス・熱供給・水道業',
	'7' => '情報通信業',
	'8' => '運輸業,郵便業',
	'9' => '卸売業,小売業',
	'10' => '金融業,保険業',
	'11' => '不動産業,物品賃貸業',
	'12' => '学術研究,専門・技術サービス業',
	'13' => '宿泊業,飲食サービス業',
	'14' => '生活関連サービス業,娯楽業',
	'15' => '教育,学習支援業',
	'16' => '医療,福祉',
	'17' => '複合サービス事業',
	'18' => 'その他のサービス業',
	'19' => 'その他の公務',
	'99' => ''
);

