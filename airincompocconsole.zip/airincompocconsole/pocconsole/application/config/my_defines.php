<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/* デバイス種別 */
define('DEVICE_SPT', '1');  // SPTアプリ
define('DEVICE_ISM', '2');  // ISM-101(車載機)
define('DEVICE_IPP', '3');  // 固定電話
define('DEVICE_HDY', '4');  // 新型ハンディ機

/* サイト共通設定 */
define('DEFAULT_SIP_PORT', '5060');
define('SPTAPI_SERVER_HOST', 'localhost');
define('SPTAPI_PATH', '/spt_api2');
define('XMPP_SERVER_HOST', 'localhost:9090');
define('XMPP_API_PATH', '/plugins/restapi/v1/');
define('XMPP_ADMIN_USER', 'admin');
define('XMPP_ADMIN_PASS', 'iforce8880');
define('USE_BREADCRUMB_IN_HEADER', true);

/* サイト別設定 : AWS用 */
// define('PUBLIC_IP_ADDRESS', '52.196.218.153');
// define('PRIVATE_IP_ADDRESS', '10.0.0.202');
// define('DEFAULT_SIP_SERVER_DOMAIN', '52.196.218.153');
// define('SIP_CONF_TEMPLATE', 'sip_conf_template_aws');

/* サイト別設定 : KCPS2用 */
define('PUBLIC_IP_ADDRESS', '27.93.149.218');
define('PRIVATE_IP_ADDRESS', '192.168.141.2');
define('PUBLIC_SIP_SERVER_DOMAIN', '27.93.149.218');
define('PRIVATE_SIP_SERVER_DOMAIN', '192.168.141.2');
define('SIP_CONF_TEMPLATE', 'sip_conf_template_kcps2');

/* サイト別設定 : IIJ GIO用 */
// define('PUBLIC_IP_ADDRESS', '150.31.253.17');
// define('PRIVATE_IP_ADDRESS', false);
// define('DEFAULT_SIP_SERVER_DOMAIN', '150.31.253.17');
// define('SIP_CONF_TEMPLATE', 'sip_conf_template_iijgio');

/* サイト別設定 : AZURE用 */
// define('PUBLIC_IP_ADDRESS', 'centos.japanwest.cloudapp.azure.com');
// define('PRIVATE_IP_ADDRESS', '10.0.2.4');
// define('DEFAULT_SIP_SERVER_DOMAIN', 'centos.japanwest.cloudapp.azure.com');
// define('SIP_CONF_TEMPLATE', 'sip_conf_template_azure');

/* 画像転送用ディレクトリ */
define('IMAGE_TRANSFER_DIR', '/mnt/pocdata/images/');  // SPTアプリ

/* 通話記録ディレクトリ */
define('ASTERISK_MONITOR_DIR', '/mnt/pocdata/records/');
define('AUDIO_OUTPUT_DIR', '/mnt/pocdata/audio/');

/* ffmpeg実行パス */
define('FFMPEG_CMD', '/usr/bin/ffmpeg');

// 新型ハンディ端末API Digest認証Realm
define('DIGEST_API_REALM', 'HANDY CONFIG API');

// テナント内の最大グループ数
define('MAX_GROUPS_IN_TENANT', 9999);

// FWファイル配置フォルダ
define('FW_FOLDER', './firmware/');
//define('FW_FOLDER', '.\\firmware\\');
