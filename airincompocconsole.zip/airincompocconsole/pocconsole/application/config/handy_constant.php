<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$config['handy_constant.php'] = '';

//
// display string for handy device config
//

global $global_handy_off_on_names;
$global_handy_off_on_names = array(
	'0'=> 'OFF',
	'1'=> 'ON'
);


global $global_handy_battery_saver_names;
$global_handy_battery_saver_names = array(
	'0'=> 'OFF',
	'1'=> '短い',
	'2'=> '中間',
	'3'=> '長い'
);

global $global_handy_clock_type_names;
$global_handy_clock_type_names = array(
	'0'=> '24H',
	'1'=> '12H',
);

global $global_handy_call_notice_names;
$global_handy_call_notice_names = array(
	'0'=> 'OFF',
	'1'=> '音',
	'2'=> '振動',
	'3'=> '両方'
);

global $global_handy_mic_type_names;
$global_handy_mic_type_names = array(
	'0'=> 'なし',
	'1'=> 'マイク１',
	'2'=> 'マイク２',
	'3'=> 'マイク３'
);

global $global_handy_mic_gain_names;
$global_handy_mic_gain_names = array(
	'6'=> '6dB',
	'4'=> '4dB',
	'2'=> '2dB',
	'0'=> '0dB',
	'-2'=> '-2dB',
	'-4'=> '-4dB',
	'-6'=> '-6dB',
	'-8'=> '-8dB',
	'-10'=> '-10dB',
	'-12'=> '-12dB',
	'-14'=> '-14dB',
	'-16'=> '-16dB',
	'-18'=> '-18dB',
	'-20'=> '-20dB'
);

global $global_handy_rx_agc_names;
$global_handy_rx_agc_names = array(
	'0'=> 'OFF',
	'1'=> '弱',
	'2'=> '強'
);

global $global_handy_auto_keylock_timer_names;
$global_handy_auto_keylock_timer_names = array(
	'0'=> 'OFF',
	'15'=> '15 秒',
	'30'=> '30 秒'
);

global $global_handy_backlight_names;
$global_handy_backlight_names = array(
	'0'=> '常時消灯',
	'1'=> '操作時点灯',
	'2'=> '常時点灯'
);

global $global_handy_backlight_timer_names;
$global_handy_backlight_timer_names = array(
	'5'=> '5 秒',
	'10'=> '10 秒',
	'15'=> '15 秒',
	'30'=> '30 秒',
	'60'=> '60 秒'
);

global $global_handy_simcard_types;
$global_handy_simcard_types = array(
	'0'=> 'カードSIM',
	'1'=> 'eSIM'
);

global $global_handy_ping_interval;
$global_handy_ping_interval = array(
	'30'=> '30 秒',
	'60'=> '60 秒',
	'600'=> '600 秒',
	'1800'=> '1800 秒',
	'3600'=> '3600 秒',
	'7200'=> '7200 秒',
	'21600'=> '21600 秒',
	'86400'=> '86400 秒'
);

global $global_handy_register_interval;
$global_handy_register_interval = array(
	'30'=> '30 秒',
	'60'=> '60 秒',
	'600'=> '600 秒',
	'1800'=> '1800 秒',
	'3600'=> '3600 秒',
	'7200'=> '7200 秒',
	'21600'=> '21600 秒',
	'86400'=> '86400 秒'
);

global $global_handy_pri_ap_mode;
$global_handy_pri_ap_mode = array(
	'0'=> 'Client',
	'1'=> 'AP'
);

global $global_handy_pri_wifi_nw_mode;
$global_handy_pri_wifi_nw_mode = array(
	'0'=> '802.11b',
	'1'=> '802.11g',
	'2'=> 'Auto'
);

global $global_handy_gps_mode;
$global_handy_gps_mode = array(
	'0'=> 'KDDI',
	'1'=> 'RMC'
);

global $global_handy_alarm_type;
$global_handy_alarm_type = array(
	'1'=> '通知音1',
	'2'=> '通知音2',
	'3'=> '通知音3',
	'4'=> '通知音4',
	'5'=> '通知音5',
	'6'=> '通知音6',
	'7'=> '通知音7',
	'8'=> '通知音8'
);

global $global_handy_income_alermtime;
$global_handy_income_alermtime = array(
	'1'=> '1',
	'3'=> '3',
	'5'=> '5',
	'10'=> '10'
);

global $global_handy_key_setting_info;
$global_handy_key_setting_info = array(
	'1'=> '(1)なし',
	'2'=> '(2)エマージェンシーの検知',
	'3'=> '(3)エマージェンシー遅延のリセット',
	'4'=> '(4)バックライト',
	'5'=> '(5)Mode No. Down',
	'6'=> '(6)Mode No. Down (連続)',
	'7'=> '(7)Mode No. Up',
	'8'=> '(8)Mode No. Up (連続)',
	'9'=> '(9)ダイレクト Mode No.１～５',
	'10'=> '(10)ダイレクト Mode No.１～５設定',
	'11'=> '(11)表示形式',
	'12'=> '(12)エマージェンシー',
	'13'=> '(13)固定音量',
	'14'=> '(14)ダブル・ファンクション',
	'15'=> '(15)無線機の位置表示',
	'16'=> '(16)ホームMode No.',
	'17'=> '(17)ホームMode No.に設定',
	'18'=> '(18)キーロック',
	'19'=> '(19)個別・グループ切換え',
	'20'=> '(20)ローン・ワーカー',
	'21'=> '(21)メンテナンス',
	'22'=> '(22)本体メニューモード',
	'23'=> '(23)送受信履歴モード',
	'24'=> '(24)メッセージ送信モード',
	'25'=> '(25)Mode No.ダウン',
	'26'=> '(26)Mode No.ダウン(連続)',
	'27'=> '(27)Mode No.アップ',
	'28'=> '(28)Mode No.アップ(連続)',
	'29'=> '(29)モニター',
	'30'=> '(30)モニター・モーメンタリー',
	'31'=> '(31)録音再生',
	'32'=> '(32)秘話',
	'33'=> '(33)秘話番号/秘話鍵リスト番号',
	'34'=> '(34)GPS データ送出',
	'35'=> '(35)サイレント・アラーム',
	'36'=> '(36)音量アッテネート',
	'37'=> '(37)バイブレータ'
);

global $global_handy_display_power_on_mode;
$global_handy_display_power_on_mode = array(
	'0'=> '個別',
	'1'=> 'グループ',
	'2'=> '会議室'
);

global $global_handy_display_battery_flag;
$global_handy_display_battery_flag = array(
	'0'=> 'While Transmitting',
	'1'=> 'Always',
	'2'=> 'Always - Late Warning'
);

global $global_handy_emergency_mode_number;
$global_handy_emergency_mode_number = array(
	'0'=> 'ノーマル',
	'1'=> 'モニター',
	'2'=> 'グループ',
	'3'=> 'ジオフェンス'
);

global $global_handy_emergency_mode_type;
$global_handy_emergency_mode_type = array(
	'0'=> 'Silent',
	'1'=> 'Audible'
);

global $global_handy_emergency_display;
$global_handy_emergency_display = array(
	'0'=> 'Selected',
	'1'=> 'Emergency Mode No.'
);

global $global_handy_emergency_key_delay_time;
$global_handy_emergency_key_delay_time = array(
	'0'=> 'Off',
	'0.1'=> '0.1s',
	'0.2'=> '0.2s',
	'0.3'=> '0.3s',
	'0.4'=> '0.4s',
	'0.5'=> '0.5s',
	'0.6'=> '0.6s',
	'0.7'=> '0.7s',
	'0.8'=> '0.8s',
	'0.9'=> '0.9s',
	'1.0'=> '1.0s',
	'1.1'=> '1.1s',
	'1.2'=> '1.2s',
	'1.3'=> '1.3s',
	'1.4'=> '1.4s',
	'1.5'=> '1.5s',
	'1.6'=> '1.6s',
	'1.7'=> '1.7s',
	'1.8'=> '1.8s',
	'1.9'=> '1.9s',
	'2.0'=> '2.0s',
	'2.1'=> '2.1s',
	'2.2'=> '2.2s',
	'2.3'=> '2.3s',
	'2.4'=> '2.4s',
	'2.5'=> '2.5s',
	'2.6'=> '2.6s',
	'2.7'=> '2.7s',
	'2.8'=> '2.8s',
	'2.9'=> '2.9s',
	'3.0'=> '3.0s',
	'3.1'=> '3.1s',
	'3.2'=> '3.2s',
	'3.3'=> '3.3s',
	'3.4'=> '3.4s',
	'3.5'=> '3.5s',
	'3.6'=> '3.6s',
	'3.7'=> '3.7s',
	'3.8'=> '3.8s',
	'3.9'=> '3.9s',
	'4.0'=> '4.0s',
	'4.1'=> '4.1s',
	'4.2'=> '4.2s',
	'4.3'=> '4.3s',
	'4.4'=> '4.4s',
	'4.5'=> '4.5s',
	'4.6'=> '4.6s',
	'4.7'=> '4.7s',
	'4.8'=> '4.8s',
	'4.9'=> '4.9s',
	'5.0'=> '5.0s',
);

global $global_handy_emergency_man_angle;
$global_handy_emergency_man_angle = array(
	'45'=> '45 度',
	'60'=> '60 度',
	'75'=> '75 度'
);

global $global_handy_history_timestamp;
$global_handy_history_timestamp = array(
	'0'=> '付加しない',
	'1'=> '付加する'
);

global $global_handy_history_info_settings;
$global_handy_history_info_settings = array(
	'0'=> '取得しない',
	'1'=> '取得する'
);

global $global_handy_history_custom_settings;
$global_handy_history_custom_settings = array(
	b'0'=> 'OFF',
	b'1'=> 'ON'
);

global $global_handy_auto_mic_gain;
$global_handy_auto_mic_gain = array(
	'0' => '-15dB',
	'1' => '-12dB',
	'2' => '-9dB',
	'3' => '-6dB',
	'4' => '-3dB',
	'5' => '0dB',
	'6'	=> '3dB',
	'7' => '6dB',
	'8' => '9dB',
	'9' => '12dB'
);

global $global_handy_time_out_timer;
$global_handy_time_out_timer = array(
	'0'=> 'OFF',
	'1'=> '30 秒',
	'2'=> '60 秒',
	'3'=> '90 秒',
	'4'=> '120 秒',
	'5'=> '150 秒',
	'6'=> '180 秒',
	'7'=> '210 秒',
	'8'=> '240 秒',
	'9'=> '270 秒',
	'10'=> '300 秒'
);

global $global_handy_ptt_call;
$global_handy_ptt_call = array(
	'0'=> '全員',
	'1'=> 'グループ',
	'2'=> '会議室',
	'3'=> '個別'
);

global $global_handy_direct_call;
$global_handy_direct_call = array(
	'0'=> '全員',
	'1'=> 'グループ',
	'2'=> '個別'
);

global $global_handy_tx_block;
$global_handy_tx_block = array(
	'0'=> 'OFF（送信許可）',
	'1'=> 'ON（送信禁止）',
	'2'=> 'OFF（送信許可）',
	'3'=> 'ON（送信禁止）'
);

global $global_handy_callback_timer;
$global_handy_callback_timer = array(
	'0'=> 'OFF',
	'1'=> '5 秒',
	'2'=> '10 秒',
	'3'=> '30 秒',
	'4'=> '60 秒',
	'5'=> '完全切替'
);

global $global_handy_audio_alc;
$global_handy_audio_alc = array(
	'0'=> 'OFF',
	'1'=> '大音抑制',
	'2'=> '小音増幅弱',
	'3'=> '小音増幅強'
);

global $global_handy_audio_reduce;
$global_handy_audio_reduce = array(
	'0'=> 'OFF',
	'1'=> '抑制レベル弱',
	'2'=> '抑制レベル強'
);

global $global_handy_record_mode;
$global_handy_record_mode = array(
	'0'=> 'OFF', 
	'1'=> '全員通話',
	'2'=> 'グループ通話',
	'3'=> '全員＋グループ',
	'4'=> '個別通話',
	'5'=> '全員+個別',
	'6'=> 'グループ+個別',
	'7'=> 'すべて'
);

global $global_handy_message_block;
$global_handy_message_block = array(
	'0'=> '許可', 
	'1'=> '禁止'
);

global $global_handy_speaker_beep_vol;
$global_handy_speaker_beep_vol = array(
	'0'=> 'OFF',
	'1'=> 'レベル1',
	'2'=> 'レベル2',
	'3'=> 'レベル3',
	'4'=> 'レベル4',
	'5'=> 'ボリューム連動'
);

global $global_handy_bell_mode;
$global_handy_bell_mode = array(
	'1'=> 'ピロリロリロリ♪',
	'2'=> 'プルルップルルッ♪',
	'3'=> 'ピピッピピッ♪'
);

global $global_handy_voice_guide;
$global_handy_voice_guide = array(
	'0'=> 'OFF',
	'1'=> '音量ガイド',
	'2'=> '操作ガイド',
	'3'=> '音量・操作両方'
);

global $global_handy_voice_guide_vol;
$global_handy_voice_guide_vol = array(
	'1'=> 'レベル1',
	'2'=> 'レベル2',
	'3'=> 'レベル3',
	'4'=> 'レベル4',
	'5'=> 'ボリューム連動'
);

global $global_handy_alarm_low_battery;
$global_handy_alarm_low_battery = array(
	'0'=> 'OFF',
	'1'=> '1回のみ',
	'2'=> '30秒毎',
	'3'=> '1分毎',
	'4'=> '2分毎',
	'5'=> '5分毎',
	'6'=> '10分毎'
);

global $global_handy_shortcut_key;
$global_handy_shortcut_key = array(
	'0'=> 'OFF',
	'1'=> '緊急呼出',
	'2'=> '直通PTT',
	'3'=> '音量固定・連動切替',
	'4'=> '最終録音再生',
	'5'=> 'ミュート'
);

global $global_handy_speaker_extnl_vol;
$global_handy_speaker_extnl_vol = array(
	'0'=> '小',
	'1'=> '中',
	'2'=> '大'
);

global $global_handy_speaker_vol_mode;
$global_handy_speaker_vol_mode = array(
	'0'=> 'ボリューム連動',
	'1'=> '設定値に固定'
);

global $global_handy_earphone_sekkyaku_mode;
$global_handy_earphone_sekkyaku_mode = array(
	'0'=> 'OFF',
	'1'=> 'ハンド',
	'2'=> 'タッチ',
	'3'=> 'ボイス'
);

global $global_handy_sekkyaku_touch;
$global_handy_sekkyaku_touch = array(
	'0'=> '低い',
	'1'=> '標準',
	'2'=> '高い',
);

global $global_handy_sekkyaku_release_timer;
$global_handy_sekkyaku_release_timer = array(
	'0'=> '5 秒',
	'1'=> '10 秒',
	'2'=> '15 秒',
	'3'=> '30 秒',
	'4'=> '60 秒'
);

global $global_handy_emergency_vol;
$global_handy_emergency_vol = array(
	'0'=> 'ボリューム連動',
	'1'=> 'レベル1',
	'2'=> 'レベル2',
	'3'=> 'レベル3',
	'4'=> 'レベル4',
	'5'=> 'BEEP音量',
	'6'=> '最大'
);

global $global_handy_backlight_timer;
$global_handy_backlight_timer = array(
	'0'=> '消灯',
	'1'=> '5秒',
	'2'=> '10秒',
	'3'=> '30秒',
	'4'=> '60秒',
	'5'=> '常灯'
);

global $global_handy_audio_codec;
$global_handy_audio_codec = array(
	'0'=> 'SPEEX WIDEBAND',
	'1'=> 'SPEEX',
	'2'=> 'G.729A',
);


global $global_handy_vox;
$global_handy_vox = array(
	'0'=> 'OFF',
	'1'=> '送信終了時PTTキー',
	'2'=> '送信開始時PTTキー',
	'3'=> '通常VOX動作'
);

global $global_handy_set_mode;
$global_handy_set_mode = array(
	'0'=> '簡易セットモード',
	'1'=> '標準セットモード',
	'2'=> '簡易セットモード',
	'3'=> '標準セットモード',
	'4'=> 'セットモード禁止'
);

global $global_handy_power_off_timer;
$global_handy_power_off_timer = array(
	'0'=> 'OFF',
	'1'=> '30 分',
	'2'=> '1時間',
	'3'=> '2時間',
	'4'=> '3時間',
	'5'=> '4時間',
	'6'=> '5時間',
	'7'=> '6時間'
);
