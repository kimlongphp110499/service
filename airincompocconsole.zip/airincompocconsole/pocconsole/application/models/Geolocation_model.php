<?php
class Geolocation_model extends CI_Model
{
    /**
     * DBに登録されている位置情報履歴のレコードを取得する。
     *
     * @param id $tenant_id 検索するテナントのID。
     * @return object クエリ結果の配列。
     */
    public function get_tenant($tenant_id)
    {
        $this->db->select('geolocation_log.*, pocaccounts.username, pocaccounts.display_name');
        $this->db->from('geolocation_log');
        $this->db->join('pocaccounts', 'geolocation_log.poc_id = pocaccounts.poc_id');
        $this->db->where('geolocation_log.company_id', $tenant_id);
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return false;
        }
    }
}
