<?php
class Group_model extends CI_Model
{
    /**
     * 全グループの情報を返す。
     *
     * @param string $sortkey ソートキー。
     * @param string $order 順序('asc'or'desc')
     * @return array|false クエリ結果のオブジェクト。失敗した場合はFALSEを返す。
     */
    public function get_all($sortkey = false, $order = false)
    {
        $this->db->select('*');
        $this->db->from('groups');
        if ($sortkey) {
            $this->db->order_by($sortkey, $order);
        }
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return false;
        }
    }
    
    /**
     * DBに登録されているテナント別グループのレコードを取得する。
     *
     * @param int $tenant_id 検索するテナントのID。
     * @param string $sortkey ソートキー。
     * @param string $order 順序('asc'or'desc')
     * @return object クエリ結果のオブジェクト。
     */
    public function get_tenant($tenant_id, $sortkey = false, $order = false)
    {
        $this->db->select('groups.*, tenants.company_name');
        $this->db->from('groups');
        $this->db->join('tenants', 'tenants.company_id = groups.company_id');
        $this->db->where('groups.company_id', $tenant_id);
        if ($sortkey) {
            $this->db->order_by($sortkey, $order);
        }
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return false;
        }
    }
 
    /**
     * 回線計画用にテナントに登録されている有効なグループのリストを取得する。
     *
     * @param id $tenant_id 検索するテナントのID。
     * @return object クエリ結果の配列。
     */
    public function get_tenant_groups($tenant_id)
    {
        $this->db->select('group_id,  group_name, sip_number, conf_sip_number');
        $this->db->where('company_id', $tenant_id);
        $this->db->where('status !=', 0);
        $this->db->from('groups');
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return false;
        }
    }

    /**
     * グループ内を検索
     *
     * @param string $select_str フィールド選択
     * @param array $cond_array 検索条件のarray
     * @return object クエリ結果のオブジェクト（複数行の場合あり）
     */
    public function select_one_group($select_str, $cond_array)
    {
        if ($select_str) {
            $this->db->select($select_str);
        }
        $this->db->from('groups');
        $this->db->where($cond_array);
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            return $query->row();   // return only one row, even when multiple found
        } else {
            return false;
        }
    }

    /**
     * 指定されたグループのレコードを取得する。
     *
     * @param int $id グループのID。
     * @return object クエリ結果のオブジェクト。
     */
    public function get($id)
    {
        $this->db->select('groups.*, tenants.company_name');
        $this->db->from('groups');
        $this->db->join('tenants', 'tenants.company_id = groups.company_id');
        $this->db->where('group_id', $id);
        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->row();
        } else {
            return false;
        }
    }

   /**
     * sip番号で指定されたグループの情報を取得する。
     *
     * @param int $sip_number グループのID。
     *
     * @param int $tid テナントID (オプション、検索時にテナントを限定する)
     *
     * @return object クエリ結果のグループオブジェクト、見つからないときは false
     */
    public function get_group_sip($sip_number, $tid = false)
    {
        $this->db->select('*');
        $this->db->from('groups');
        if ($tid) {
            $this->db->where('company_id', $tid);
        }
        $this->db->where('status !=', 0);
        $this->db->group_start();
            $this->db->where('sip_number', $sip_number);
            $this->db->or_where('conf_sip_number', $sip_number);
        $this->db->group_end();
        
        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->row();
        } else {
            return false;
        }
    }

    /**
     * 指定されたグループに含まれるメンバーを返す。
     *
     * @param int $id グループのID。
     * @param string $sortkey ソートキー。
     * @param string $order 順序('asc'or'desc')
     * @return object メンバーの配列。
     */
    public function get_members($id, $sortkey = false, $order = false)
    {
        $this->db->select('group_members.poc_id, username, display_name, sip_number, device_name');
        $this->db->from('group_members');
        $this->db->join('pocaccounts', 'pocaccounts.poc_id = group_members.poc_id');
        $this->db->join('devices', 'pocaccounts.device_id = devices.device_id');
        $this->db->where('group_id', $id);
        if ($sortkey) {
            $this->db->order_by($sortkey, $order);
        }
        $query = $this->db->get();

        return $query->result();
    }

    /**
     * 指定されたグループに含まれるメンバーを返す。
     *
     * @param int $id グループのID。
     * @return object メンバーの配列。
     */
    public function get_member_ids($id)
    {
        $this->db->select('poc_id');
        $this->db->from('group_members');
        $this->db->where('group_id', $id);
        $query = $this->db->get();

        $array = [];
        foreach ($query->result() as $row) {
            $array[] = $row->poc_id;
        }

        return $array;
    }

    /**
     * 回線計画用に指定されたグループに含まれる有効なメンバー情報を返す。
     *
     * @param int $id (有効な)グループのID。
     * @return object メンバー情報の配列。
     */
    public function get_member_accounts($id, $prop_names = false)
    {
        // set defaut props
        if (!$prop_names) {
            // in case test/debug
            //$prop_names = 'group_members.poc_id, username, display_name, sip_number, pocaccounts.status';
            $prop_names = 'username, display_name, sip_number';
        }

        $this->db->select($prop_names);
        $this->db->from('group_members');
        $this->db->join('pocaccounts', 'pocaccounts.poc_id = group_members.poc_id');
        $this->db->where('group_id', $id);
        $this->db->where('pocaccounts.status !=', 0);
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return false;
        }
    }

    /**
     * テナント内で重複するグループ名があるか調べる。
     *
     * @param int $tid 対象のテナントID。
     * 
     * @param int $group_name 調べるグループ名。
     *      * 
     * @return 利用可能な場合はTRUEを返す。
     */
    public function is_available_in_tenant($tid, $group_name)
    {
        $this->db->where('company_id', $tid);
        $this->db->where('group_name', $group_name);
        $query = $this->db->get('groups');

        return ($query->num_rows() == 0) ? true : false;
    }

    /**
     * テナントに所属するグループの数を返す。(有効および無効の両方)
     *
     * @param id $tenant_id 検索するテナントのID。
     * @return int テナント内の有効および無効のグループ数。
     * 
     * 無効な $tid と　有効な $tid だがグループ数が 0 の場合を区別できないので注意
     * (事前に $tidが有効かチェックすること)
     */
    public function number_of_groups($tid)
    {
        $this->db->from('groups');
        $this->db->where('company_id', $tid);

        return $this->db->count_all_results();
    }

    /**
     * グループを追加する。
     */
    public function add()
    {
        $data = array(
            'sip_number' => $this->input->post('sip_number'),
            'group_name' => $this->input->post('group_name'),
            'status' => $this->input->post('status'),
            'company_id' => $this->input->post('company_id'),
            'register_date' => date('Y-m-d H:i:s'),
            'update_date' => date('Y-m-d H:i:s'),
        );

        $this->db->insert('groups', $data);
    }

    /**
     * 指定されたグループのレコード内容を更新する。
     *
     * @param int $id グループのID。
     * @return boolan 失敗した場合はfalseを返す。
     */
    public function edit($id)
    {
        $data = array(
            //'sip_number' => $this->input->post('sip_number'),
            'group_name' => $this->input->post('group_name'),
            'status' => $this->input->post('status'),
            'update_date' => date('Y-m-d H:i:s'),
        );

        $this->db->where('group_id', $id);

        return $this->db->update('groups', $data);
    }

    /**
     * グループを削除する。グループメンバーも削除する。
     *
     * @param int $id グループのID。
     * @return boolan 失敗した場合はfalseを返す。
     */
    public function delete($id)
    {
        $this->db->where('group_id', $id);
        $this->db->delete('group_members');

        $this->db->where('group_id', $id);

        return $this->db->delete('groups');
    }

    /**
     * テナントに所属するグループを全て削除する。
     *
     * @param int $tenant_id 検索するテナントのID。
     * @return boolan 失敗した場合はfalseを返す。
     */
    public function delete_tenant($tenant_id)
    {
        $this->db->trans_start();

        $this->db->where('company_id', $tenant_id);
        $query = $this->db->get('groups');
        foreach ($query->result() as $row) {
            $this->delete($row->group_id);
        }
        
        $this->db->trans_complete();
        if ($this->db->trans_status() === false) {
            return false;
        }
        return true;
    }
    
    /**
     * グループに所属するメンバーを設定する。
     *
     * @param int $id グループのID。
     * @param array $array_poc_id 追加するPOC IDの配列
     * (メンバが一つも選択されていない場合実際には null になる。この時メンバーは全削除)
     * 
     * @return boolan 失敗した場合はfalseを返す。
     */
    public function plan($id, $array_poc_id)
    {
        $this->db->trans_start();

        // 既存のメンバーを全削除
        $this->db->where('group_id', $id);
        $this->db->delete('group_members');

        // 選択されたメンバーを追加 (nullの場合count(null) == 0 となりOK)
        if (is_array($array_poc_id)) {
            if (count($array_poc_id) > 0) {
                foreach ($array_poc_id as $row) {
                    $data = array('group_id' => $id,
                                'poc_id' => $row
                                );
                    $this->db->insert('group_members', $data);
                }
            }
        }
        
        $this->db->trans_complete();
        if ($this->db->trans_status() === false) {
            return false;
        }
        return true;
    }

    /**
     * 複数グループを一括して追加する。
     *
     * @param int $tid テナントID。
     * 
     * @param array $groups グループの配列。'group_name'(必須) 'sip_number' 'conf_sip_number' 'status'
     *              group_nameの重複チェックはこの関数の呼び出し側で行うこと
     * 
     * @param int $sip_last_id 開始するSIP番号
     * 
     * @return boolan 失敗した場合はfalseを返す。
     */
    public function add_batch($tid, &$groups, $sip_start_id)
    {
        $sip_prefix = sprintf('70%04d', $tid);
        $conf_sip_prefix = sprintf('80%04d', $tid);

        foreach ($groups as $row) {
            
            // グループ名が設定されているかチェック
            if (!array_key_exists('group_name', $row)) {
                return false;
            }
        }

        $count = $sip_start_id;
        if ($count == 10000) {
            $count = 1;
        }
        $last_id = $count;
        $this->db->trans_start();
        
        foreach ($groups as &$row) {

            // グループ名(必須)
            $group_name = $row['group_name'];
            
            // グループSIP番号 が設定されている?
            if (array_key_exists('sip_number', $row)) {
                $sip_number = $row['sip_number'];
            }
            else {
                $sip_number = $sip_prefix.sprintf('%04d', $count);
                while ($this->isSipNumberInUse($sip_number)) {
                    $count++;
                    if ($count == 10000) {
                        $count = 1;
                    }
                    $sip_number = $sip_prefix.sprintf('%04d', $count);
                }
                $last_id = $count;
            }

            // 会議室SIP番号 が設定されている?
            if (array_key_exists('conf_sip_number', $row)) {
                $conf_sip_number = $row['conf_sip_number'];
            }
            else {
                $conf_sip_number = $conf_sip_prefix.sprintf('%04d', $count);
            }

            // status が設定されている?
            if (array_key_exists('status', $row)) {
                $status = $row['status'];
            }
            else {
                $status = '1';
            }

            $data = array('group_name' => $group_name,
                          'sip_number' => $sip_number,
                          'conf_sip_number' => $conf_sip_number,
                          'status' => $status,
                          'company_id' => $tid,
                          'register_date' => date('Y-m-d H:i:s'),
                          'update_date' => date('Y-m-d H:i:s'),
                          );
            $this->db->insert('groups', $data);

            // return sip_number by reference
            $row['sip_number'] = $data['sip_number'];
            $row['conf_sip_number'] = $data['conf_sip_number'];
            $count++;
            if ($count == 10000) {
                $count = 1;
            }
        }
        
        $this->db->trans_complete();
        if ($this->db->trans_status() === false) {
            return -1;
        }
        return $last_id;
    }

    private function isSipNumberInUse($sip_number)
    {
        $this->db->from('groups');
        $this->db->where('sip_number', $sip_number);

        return $this->db->count_all_results() != 0;
    }
}
