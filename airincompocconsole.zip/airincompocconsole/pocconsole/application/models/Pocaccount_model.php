<?php
class PocAccount_model extends CI_Model
{
    private $enc_key = 'SC9MjPrX&x$aWQ5/~wyyyA!eUoPJ&EBy';
        
    /**
     * 全アカウントの情報を返す。
     *
     * @return array|false クエリ結果のオブジェクト。失敗した場合はFALSEを返す。
     */
    public function get_all()
    {
        $this->db->select('*');
        $query = $this->db->get('pocaccounts');

        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return false;
        }
    }
    
    /**
     * DBに登録されているPoCアカウントのレコードを取得する。
     *
     * @param id $tenant_id 検索するテナントのID。
     * @param string $sortkey ソートキー。
     * @param string $order 順序('asc'or'desc')
     * @return object クエリ結果の配列。
     */
    public function get_tenant($tenant_id, $sortkey = false, $order = false)
    {
        $this->db->select('pocaccounts.*, tenants.company_name, devices.device_name, spt_configs.*, ism_configs.*');
        $this->db->from('pocaccounts');
        $this->db->join('tenants', 'tenants.company_id = pocaccounts.company_id');
        $this->db->join('devices', 'devices.device_id = pocaccounts.device_id');
        $this->db->join('spt_configs', 'spt_configs.id = pocaccounts.spt_config_id');
        $this->db->join('ism_configs', 'ism_configs.id = pocaccounts.ism_config_id');
        $this->db->where('pocaccounts.company_id', $tenant_id);
        if ($sortkey) {
            $this->db->order_by($sortkey, $order);
        }
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return false;
        }
    }

    /**
     * 回線計画用にテナントに登録されている有効なPoCアカウントのリストを取得する。
     *
     * @param id $tenant_id 検索するテナントのID。
     * @return object クエリ結果の配列。
     */
    public function get_tenant_accounts($tenant_id)
    {
        $this->db->select('username, display_name, device_id, sip_number, mac_address, app_version');
        $this->db->where('company_id', $tenant_id);
        $this->db->where('status !=', 0);
        $this->db->from('pocaccounts');
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return false;
        }
    }
    
    /**
     * groupplansと結合した全PoCアカウントの取得する。
     *
     * @param id $tenant_id 検索するテナントのID。
     * @return object クエリ結果の配列。
     */
    public function get_tenant_with_group($tenant_id)
    {
        $this->db->select('*');
        $this->db->from('pocaccounts');
        $this->db->join('group_members', 'group_members.poc_id = pocaccounts.poc_id', 'left');
        $this->db->where('pocaccounts.company_id', $tenant_id);
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return false;
        }
    }
    
    /**
     * テナントに所属するアカウントの数を返す。
     *
     * @param id $tenant_id 検索するテナントのID。
     * @return int アカウント数。
     */
    public function count_tenant($tenant_id, $dev_type)
    {
        $this->db->from('pocaccounts');
        $this->db->where('company_id', $tenant_id);
        $this->db->where('device_id', $dev_type);

        return $this->db->count_all_results();
    }
    
    /**
     * 指定されたPoCアカウントのレコードを取得する。
     *
     * @param int $id PoCアカウントのID。
     * @return object クエリ結果のオブジェクト。
     */
    public function get($id)
    {
        $this->db->select('pocaccounts.*, tenants.company_name, devices.device_name, spt_configs.*, ism_configs.*');
        $this->db->from('pocaccounts');
        $this->db->join('tenants', 'tenants.company_id = pocaccounts.company_id');
        $this->db->join('devices', 'devices.device_id = pocaccounts.device_id');
        $this->db->join('spt_configs', 'spt_configs.id = pocaccounts.spt_config_id');
        $this->db->join('ism_configs', 'ism_configs.id = pocaccounts.ism_config_id');
        $this->db->where('poc_id', $id);
        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->row();
        } else {
            return false;
        }
    }

    public function get_from_token($token)
    {
        $this->db->select('pocaccounts.*, tenants.company_name, devices.device_name, spt_configs.*');
        $this->db->from('pocaccounts');
        $this->db->join('tenants', 'tenants.company_id = pocaccounts.company_id');
        $this->db->join('devices', 'devices.device_id = pocaccounts.device_id');
        $this->db->join('spt_configs', 'spt_configs.id = pocaccounts.spt_config_id');
        $this->db->where('spt_configs.token', $token);
        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->row();
        } else {
            return false;
        }
    }
    
    /**
     * PoCアカウントid から各種コンフィグid を取得する。
     *
     * @param int $id PoCアカウントのID。
     * @return object クエリ結果のオブジェクト。
     */
     public function get_config_ids($id)
     {
        $this->db->select('hdy_config_id, spt_config_id, ism_config_id');
        $this->db->where('poc_id', $id);
        $query = $this->db->get('pocaccounts');

        if ($query->num_rows() == 1) {
            return $query->row();
        } else {
            return false;
        }
     }
     
     
    /**
     * PoCアカウント名からPoCアカウントのレコードを取得する。
     *
     * @param int $poc_account PoCアカウント名。
     * @return object クエリ結果のオブジェクト。
     */
     public function get_account($poc_account)
     {
         $this->db->select('*');
         $this->db->from('pocaccounts');
         $this->db->where('username', $poc_account);
         $query = $this->db->get();
 
         if ($query->num_rows() == 1) {
             return $query->row();
         } else {
             return false;
         }
     }

         /**
     * SIP番号からPoCアカウントのレコードを取得する。
     *
     * @param int $sip_number sip番号。
     * @return object クエリ結果のオブジェクト。
     */
    public function get_account_sip($sip_number, $tid=false)
    {
        $this->db->select('*');
        $this->db->from('pocaccounts');
        if($tid){
            $this->db->where('company_id', $tid);
        }
        $this->db->where('status !=', 0);
        $this->db->where('sip_number', $sip_number);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->row();
        } else {
            return false;
        }
    }

    /**
     * 指定されたPoCアカウントのレコード内容を更新する。
     *
     * @param int $id PoCアカウントのID。
     * @param int $device_id デバイスID。
     * @return boolean 更新に失敗した場合はFALSEを返す。
     */
    public function edit($id, $device_id)
    {
        $this->db->select('spt_config_id,ism_config_id');
        $this->db->from('pocaccounts');
        $this->db->where('poc_id', $id);
        $query = $this->db->get();
        $spt_conf_id = $query->row()->spt_config_id;
        $ism_conf_id = $query->row()->ism_config_id;

        $this->db->trans_start();

        // 基本設定
        $data = array(
            'username' => $this->input->post('username'),
            'display_name' => $this->input->post('display_name'),
            //'password' => MD5($this->input->post('password')),
            //'sip_server_domain' => $this->input->post('sip_server_domain'),
            //'sip_port' => $this->input->post('sip_port'),
            'sip_number' => $this->input->post('sip_number'),
            'mac_address' => strtolower($this->input->post('mac_address')),
            'imei' => strtolower($this->input->post('imei')),
            'use_srtp' => $this->input->post('use_srtp'),
            'status' => $this->input->post('status'),
            'update_date' => date('Y-m-d H:i:s'),
        );

        $password = $this->input->post('password');
        if (!empty($password)) {
            $data['password'] = MD5($password);
            $data['enc_password'] = openssl_encrypt($password, 'AES-128-ECB', $this->enc_key);
        }

        $this->db->where('poc_id', $id);
        $this->db->update('pocaccounts', $data);

        // SPTアプリ設定
        if ($device_id == DEVICE_SPT) {
            $data = array(
                          'gps_interval' => $this->input->post('gps_interval'),
                          //'bluetooth_interval' => $this->input->post('bluetooth_interval'),
                          //'bluetooth_rssi_threshold' => $this->input->post('bluetooth_rssi_threshold'),
                          'xmpp_server_domain' => $this->input->post('xmpp_server_domain'),
                          'xmpp_service_name' => $this->input->post('xmpp_service_name'),
                          'xmpp_port' => $this->input->post('xmpp_port'),
                          'xmpp_username' => $this->input->post('xmpp_username'),
                          'xmpp_password' => $this->input->post('xmpp_password'),
                          'send_image_interval' => $this->input->post('send_image_interval'),
                          'send_image_quality' => $this->input->post('send_image_quality'),
                          'image_folder' => $this->input->post('username')
                          );

            if ($this->input->post('status') == '0') {
                $data['token'] = '';
            }
            
            $this->db->where('id', $spt_conf_id);
            $this->db->update('spt_configs', $data);
        }

        // ISM-101設定
        if ($device_id == DEVICE_ISM) {
            $data = array(
                          'call1' => $this->input->post('call1'),
                          'call2' => $this->input->post('call2'),
                          'call3' => $this->input->post('call3'),
                          //'geomode' => $this->input->post('geomode'),
                          'geointerval' => $this->input->post('geointerval'),
                          'geodistance' => $this->input->post('geodistance'),
                          //'callbacktimer' => $this->input->post('callbacktimer'),
                          'newvoicemail' => $this->input->post('newvoicemail'),
                          'novoicemail' => $this->input->post('novoicemail'),
                          //'mic' => $this->input->post('mic'),
                          //'speaker' => $this->input->post('speaker'),
                          'gpsurl' => $this->input->post('gpsurl'),
                          'fw_update' => $this->input->post('fw_update'),
                          'appversion' => $this->input->post('appversion'),
                          'apppath' => $this->input->post('apppath'),
                          'kernelversion' => $this->input->post('kernelversion'),
                          'kernelpath' => $this->input->post('kernelpath'),
                          );

            $this->db->where('id', $ism_conf_id);
            $this->db->update('ism_configs', $data);
        }

        $this->db->trans_complete();
        if ($this->db->trans_status() === false) {
            return false;
        }
        return true;
    }

    /**
     * 指定されたアカウントのレコードを削除する。
     *
     * @param int $id アカウントのID。
     * @return boolean 更新に失敗した場合はFALSEを返す。
     *
     * 注: 新型ハンディ機用コンフィグはhdy_config_id を保存しておいて、コントローラーから削除する
     *
     */
    public function delete($id)
    {
        // アカウント削除前にコンフィグIDを取得
        $row = $this->get_config_ids($id);

        // トランザクション開始
        $this->db->trans_start();

        /* group_memberから削除 */
        $this->db->where('poc_id', $id);
        $this->db->delete('group_members');

        /* pocaccountsから削除 */
        $this->db->where('poc_id', $id);
        $this->db->delete('pocaccounts');

        // 新型ハンディ機用コンフィグはこの関数の外で削除
        // (現時点で一か所のみ)

        /* spt_configs, ism_configsから削除 */
        if ($row->spt_config_id) {
            $this->db->select('type');
            $this->db->where('id', $row->spt_config_id);
            $query = $this->db->get('spt_configs');
            $row2 = $query->row();
            if ($row2->type == 'specific') {
                $this->db->where('id', $row->spt_config_id);
                $this->db->delete('spt_configs');
            }
        }

        if ($row->ism_config_id) {
            $this->db->select('type');
            $this->db->where('id', $row->ism_config_id);
            $query = $this->db->get('ism_configs');
            $row3 = $query->row();
            if ($row3->type == 'specific') {
                $this->db->where('id', $row->ism_config_id);
                $this->db->delete('ism_configs');
            }
        }

        $this->db->trans_complete();
        if ($this->db->trans_status() === false) {
            return false;
        }
        return true;
    }

    /**
     * テナントに所属するグループを全て削除する。
     *
     * @param int $tid 削除するテナントのID。
     */
    public function delete_tenant($tid)
    {
        $this->db->where('company_id', $tid);
        $query = $this->db->get('pocaccounts');
        foreach ($query->result() as $row) {
            $this->delete($row->poc_id);
        }
    }
    
    /**
     * 利用可能なアカウントIDか調べる。
     *
     * @param int $id 調べるID。(アカウント名)
     * 
     * @param int $exclude_tid チェックから除外するTID (オプション)
     * システム全体で重複があってはけないが、これから削除するテナント内に同じIDがあっても気にしない)
     * 
     * @return 利用可能な場合はTRUEを返す。
     */
    public function is_available_id($id, $exclude_tid = false)
    {
        $this->db->select('username');
        $this->db->where('username', $id);
        if ($exclude_tid) {
            $this->db->where('company_id !=', $exclude_tid);
        }
        $query = $this->db->get('pocaccounts');

        return ($query->num_rows() == 0) ? true : false;
    }

    /**
     * 利用可能なIPアドレスか調べる。
     *
     * @param int $addr 調べるIPアドレス。
     * 
     * @param int $exclude_tid チェックから除外するTID (オプション)
     * システム全体で重複があってはけないが、これから削除するテナント内に同じIPアドレスがあっても気にしない)
     * 
     * @return 利用可能な場合はTRUEを返す。
     */
    public function is_available_ipaddr($addr, $exclude_tid = false)
    {
        $this->db->where('ip_address', $addr);
        if ($exclude_tid) {
            $this->db->where('company_id !=', $exclude_tid);
        }
        $query = $this->db->get('pocaccounts');

        return ($query->num_rows() == 0) ? true : false;
    }

    /**
     * 利用可能なMACアドレスか調べる。
     *
     * @param int $addr 調べるMACアドレス。
     * 
     * @param int $exclude_tid チェックから除外するTID (オプション)
     * システム全体で重複があってはけないが、これから削除するテナント内に同じMACアドレスがあっても気にしない)
     * 
     * @return 利用可能な場合はTRUEを返す。
     */
    public function is_available_macaddr($addr, $exclude_tid = false)
    {
        $this->db->where('mac_address', $addr);
        if ($exclude_tid) {
            $this->db->where('company_id !=', $exclude_tid);
        }
        $query = $this->db->get('pocaccounts');

        return ($query->num_rows() == 0) ? true : false;
    }

    /**
     * 利用可能なIMEIか調べる。
     *
     * @param int $imei 調べるIMEI。
     * 
     * @param int $exclude_tid チェックから除外するTID (オプション)
     * システム全体で重複があってはけないが、これから削除するテナント内に同じMACアドレスがあっても気にしない)
     * 
     * @return 利用可能な場合はTRUEを返す。
     */
    public function is_available_imei($imei, $exclude_tid = false)
    {
        $this->db->where('imei', $imei);
        if ($exclude_tid) {
            $this->db->where('company_id !=', $exclude_tid);
        }
        $query = $this->db->get('pocaccounts');

        return ($query->num_rows() == 0) ? true : false;
    }

    /**
     * 利用可能なSIP番号か調べる。
     *
     * @param int $sip_number 調べるSIP番号
     * @return 利用可能な場合はTRUEを返す。
     */
    public function is_available_sip_number($sip_number)
    {
        $this->db->where('sip_number', $sip_number);
        $query = $this->db->get('pocaccounts');
        if ($query->num_rows() > 0)    return false;

        $this->db->where('sip_number', $sip_number);
        $query = $this->db->get('groups');

        return ($query->num_rows() == 0) ? true : false;
    }
    
    /**
     * テナント内で重複するアカウント表示名があるか調べる。
     *
     * @param int $tid 対象のテナントID。
     * 
     * @param int $display_name 調べる表示名。
     *      * 
     * @return 利用可能な場合はTRUEを返す。
     */
    public function is_available_in_tenant($tid, $display_name)
    {
        $this->db->where('company_id', $tid);
        $this->db->where('display_name', $display_name);
        $query = $this->db->get('pocaccounts');

        return ($query->num_rows() == 0) ? true : false;
    }

    /**
     * 複数アカウントを一括して追加する。
     *
     * @param int $tid テナントID。
     * @param array $accounts アカウント名の配列。
     *  各々の要素は以下をサポート 'username'(必須) 'password' (必須)
     *  'display_name'(オプション) 'sip_number'(オプション) 'status'(オプション)
     *  'ip_address' (オプション、ISM時にsip_numberを決定するために利用)
     *  'mac_address' (オプション、主にISMのみ利用)
     * @param int $dev_id デバイス種別。
     * @param int $sip_start_id SIP番号
     * 
     * この関数はPocaccount.phpの add_batch_actionおよびimportから呼ばれる
     * add_batch_actionの場合仕組み上同一テナントでのアカウント名と表示名の重複は発生しない。
     * import時のusername/display_nameの重複チェックは呼び出し側で行うこと
     */
    public function add_batch($tid, &$accounts, $dev_id, $sip_start_id)
    {
        $sip_prefix = '';
        if ($dev_id == DEVICE_HDY) {
            $sip_prefix = sprintf('20%04d', $tid);
        } elseif ($dev_id == DEVICE_SPT) {
            $sip_prefix = sprintf('60%04d', $tid);
        } elseif ($dev_id == DEVICE_ISM) {
            $sip_prefix = sprintf('50%04d', $tid);
        } else {// DEVICE_IPP
            $sip_prefix = sprintf('30%04d', $tid);
        }

        /* テナント毎のPoCアカウントテンプレートを取得(HDY用) */
        $this->db->select('*');
        $this->db->where('company_id', $tid);
        $this->db->where('type', 'device_tenant');
        $query = $this->db->get('hdy_configs_new');
		if ($query->num_rows() < 1) {
			// no tenant template exist????
			log_message('error', 'pocconsole#add_batch() : no tenant template for ID='.$tid.' exist.');
			$hdy_row = array();	// empty array object
		}
		else {
			log_message('debug', 'pocconsole#add_batch() : '.$query->num_rows().'template entry exist for tenant ID='.$tid);
        	$hdy_row = $query->row();
            unset($hdy_row->id, $hdy_row->comment);	// clear 'id' and 'comment' but keep 'last_update'
		}

        /* テナント毎のPoCアカウント初期設定インデックスを取得(SPT/ISM用) */
        $this->db->select('spt_config_id, ism_config_id');
        $this->db->where('company_id', $tid);
        $query = $this->db->get('tenants');
        $ids = $query->row();

        /* テナントのSPT設定 */
        $this->db->where('id', $ids->spt_config_id);
        $query = $this->db->get('spt_configs');
        $spt_row = $query->row();

        /* テナントのISM設定 */
        $this->db->where('id', $ids->ism_config_id);
        $query = $this->db->get('ism_configs');
        $ism_row = $query->row();

        $count = $sip_start_id;
        if ($count == 10000) {
            $count = 1;
        }
        $last_id = $count;

        /* DB更新 */
        foreach ($accounts as &$row) {
            // sip_number が設定されている?
            if (array_key_exists('sip_number', $row)) {
                $sip_number = $row['sip_number'];
            }
            else {
                if ($dev_id == DEVICE_ISM) {
                    if (array_key_exists('ip_address', $row)) {
                        $ipaddr = $row['ip_address'];
                        $sip_number = sprintf(
                            '5%03d%03d%03d',
                            ($ipaddr >> 16) & 0xff,
                            ($ipaddr >> 8) & 0xff,
                            $ipaddr & 0xff
                        );
                    } else {
                        $sip_number = $sip_prefix.sprintf('%04d', $count);
                    }
                } else {
                    $sip_number = $sip_prefix.sprintf('%04d', $count);
                    while ($this->isSipNumberInUse($sip_number)) {
                        $count++;
                        if ($count == 10000) {
                            $count = 1;
                        }
                        $sip_number = $sip_prefix.sprintf('%04d', $count);
                    }
                    $last_id = $count;
                }
            }

            // display_name が設定されている?(import時)
            if (array_key_exists('display_name', $row)) {
                $display_name = $row['display_name'];
            }
            else {
                // usernameを利用(add_batch_action時)
                $display_name = $row['username'];
            }

            // status が設定されている?
            if (array_key_exists('status', $row)) {
                $status = $row['status'];
            }
            else {
                $status = '1';
            }

            /* HDY設定 */
            if ($dev_id == DEVICE_HDY && !empty($hdy_row)) {
                $hdy_row->type = 'device';
                $this->db->insert('hdy_configs_new', $hdy_row);
                $hdy_config_id = $this->db->insert_id();
            } else {
                $hdy_config_id = '0'; // not used but for safety
            }

            /* SPT設定 */
            if ($dev_id == DEVICE_SPT) {
                $pw_str = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
                $spt_row->id = '';
                $spt_row->type = 'specific';
                $spt_row->xmpp_username = 'iforce'.$sip_number.'@'.$spt_row->xmpp_service_name;
                $spt_row->xmpp_password = substr(str_shuffle(str_repeat($pw_str, 8)), 0, 8);
                $spt_row->image_folder = $row['username'];
                $this->db->insert('spt_configs', $spt_row);
                $spt_config_id = $this->db->insert_id();

                $row['xmpp_username'] = 'iforce'.$sip_number;
                $row['xmpp_password'] = $spt_row->xmpp_password;
            } else {
                $spt_config_id = $ids->spt_config_id;
            }

            /* ISM設定 */
            if ($dev_id == DEVICE_ISM) {
                $ism_row->id = '';
                $ism_row->type = 'specific';
                //$ism_row->ip_address = //TODO
                //$ism_row->call1 = //TODO
                //$ism_row->call2 = //TODO
                //$ism_row->call3 = //TODO
                $this->db->insert('ism_configs', $ism_row);
                $ism_config_id = $this->db->insert_id();
            } else {
                $ism_config_id = $ids->ism_config_id;
            }

            /* pocaccountsにレコード追加 */
            $data = array(
                          'username' => $row['username'],
                          'display_name' => $display_name,
                          'password' => MD5($row['password']),
                          'enc_password' => openssl_encrypt($row['password'], 'AES-128-ECB', $this->enc_key),
                          'device_id' => $dev_id,
                          'sip_server_domain' => $dev_id == DEVICE_SPT ? PUBLIC_SIP_SERVER_DOMAIN : PRIVATE_SIP_SERVER_DOMAIN,
                          'sip_port' => DEFAULT_SIP_PORT,
                          'sip_number' => $sip_number,
                          'sip_password' => 'iforce'.$sip_number,
                          'mac_address' => array_key_exists('mac_address', $row) ? $row['mac_address'] : '',
                          'imei' => array_key_exists('imei', $row) ? $row['imei'] : '',
                          'use_srtp' => 0,
                          'status' => $status,
                          'company_id' => $tid,
                          'register_date' => date('Y-m-d H:i:s'),
                          'update_date' => date('Y-m-d H:i:s'),
                          'hdy_config_id' => $hdy_config_id,
                          'spt_config_id' => $spt_config_id,
                          'ism_config_id' => $ism_config_id,
                          );
            $this->db->insert('pocaccounts', $data);
            
            $row['poc_id'] = $this->db->insert_id();
            $row['sip_number'] = $data['sip_number'];
            $row['sip_password'] = $data['sip_password'];
            $count++;
            if ($count == 10000) {
                $count = 1;
            }
        }

        return $last_id;
    }

    /**
     * ISM設定データを取得する。
     *
     * @param int $poc_id PocアカウントのID。
     * @return array|false ISM設定データ。
     */
    public function get_ism_conf($poc_id)
    {
        $this->db->select('ism_config_id');
        $this->db->where('poc_id', $poc_id);
        $query = $this->db->get('pocaccounts');
        $row = $query->row();
        if (!$row) {
            return false;
        }

        /* テナントのISM設定 */
        $this->db->select('*');
        $this->db->where('id', $row->ism_config_id);
        $query = $this->db->get('ism_configs');

        return $query->row();
    }

    /**
     * ISMの発信先の表示名を取得する。
     *
     * @param int $poc_id PoCアカウントのID。
     * @return array|false 表示名の配列(call1～call3)。
     */
    public function get_ism_call_display_name($poc_id)
    {
        $row = $this->get_ism_conf($poc_id);
        if (!$row) {
            return false;
        }

        $array = array();
        for ($i = 1; $i <= 3; $i++) {
            $this->db->select('pocaccounts.display_name as display_name, groups.group_name as group_name');
            $this->db->from('ism_configs');
            $this->db->join('pocaccounts', 'pocaccounts.sip_number = ism_configs.call'.$i, 'left');
            $this->db->join('groups', 'groups.sip_number = ism_configs.call'.$i, 'left');
            $this->db->where('id', $row->id);
            $query = $this->db->get();
            $row2 = $query->row();
            if (!$row2) {
                return false;
            }
            $array[] = $row2->display_name ? $row2->display_name : $row2->group_name;
        }

        return $array;
    }

    /**
     * 指定されたPoCアカウントのユーザー名とパスワードを更新する。
     *
     * @param int $id PoCアカウントのID。
     * @param string $poc_new_dispname PoC新アカウント名(表示名)。
     * @param string $poc_new_password PoC新パスワード。
     * @return boolean 更新に失敗した場合はFALSEを返す。
     */
     public function edit_account_passwd($id, $poc_new_dispname, $poc_new_password)
     {
         $this->db->trans_start();
 
         $data['display_name'] = $poc_new_dispname;
         $data['password'] = MD5($poc_new_password);
 
         $this->db->where('poc_id', $id);
         $this->db->update('pocaccounts', $data);
  
         $this->db->trans_complete();
         if ($this->db->trans_status() === false) {
             return false;
         }
         return true;
     }
 
    /**
     * 指定されたPoCアカウントのレコード内容を指定されたデータで更新する。
     *
     * @param int $id PoCアカウントのID。
     * @param array $data 更新するコンフィグ情報
     * @return boolean 更新に失敗した場合はFALSEを返す。
     */
    public function edit_handy_config($id, $data)
    {
        $this->db->trans_start();
        
        $this->db->where('poc_id', $id);
        $this->db->update('pocaccounts', $data);

        $this->db->trans_complete();
        if ($this->db->trans_status() === false) {
            return false;
        }
        return true;
    }

    /**
     * スタッフの現在位置の配列を返す。
     * @param int $tenant_id テナントID。
     */
    public function getStaffLocations($tenant_id)
    {
        $this->db->select('poc_id, display_name, X(geo_location) as lon, Y(geo_location) as lat');
        $this->db->from('pocaccounts');
        $this->db->join('spt_configs', 'pocaccounts.spt_config_id = spt_configs.id');
        $this->db->where('pocaccounts.company_id', $tenant_id);
        //$this->db->where('pocaccounts.update_date >', date('Y-m-d H:i:s', time() - 60 * 60));
        $this->db->where('spt_configs.token !=', '');

        $query = $this->db->get();

        return $query->result_array();
    }

    private function isSipNumberInUse($sip_number)
    {
        $this->db->from('pocaccounts');
        $this->db->where('sip_number', $sip_number);

        return $this->db->count_all_results() != 0;
    }
}
