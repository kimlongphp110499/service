<?php
class Device_model extends CI_Model
{
    /**
     * DBに登録されている全デバイスのレコードを取得する。
     * @return クエリ結果の配列。
     */
    public function get_all()
    {
        $this->db->select('*');
        $this->db->from('devices');
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return false;
        }
    }
    
    /**
     * 指定されたデバイスのレコードを取得する。
     * @param id デバイスのID。
     * @return クエリ結果のオブジェクト。またはデバイスが見つからないときは false
     */
    public function get($id)
    {
        $query = $this->db->get_where('devices', array('device_id' => $id));

        if ($query->num_rows() == 1) {
            return $query->row();
        } else {
            return false;
        }
    }

    /**
     * デバイス名からデバイスのレコードを取得する。
     * @param device_name デバイス名の文字列
     * @return クエリ結果のオブジェクト。またはデバイスが見つからないときは false 
     */
    public function get_device($device_name)
    {
        $query = $this->db->get_where('devices', array('device_name' => $device_name));

        if ($query->num_rows() == 1) {
            return $query->row();
        } else {
            return false;
        }
    }


    /**
     * デバイスを追加する。
     */
    public function add()
    {
        $data = array(
            'name' => $this->input->post('name'),
            'model' => $this->input->post('model'),
        );

        $this->db->insert('devices', $data);
    }

    /**
     * 指定されたデバイスのレコード内容を更新する。
     * @param id デバイスのID。
     */
    public function edit($id)
    {
        $data = array(
            'name' => $this->input->post('name'),
            'model' => $this->input->post('model'),
        );

        $this->db->where('device_id', $id);
        $this->db->update('devices', $data);
    }

    /**
     * 指定されたデバイスのレコードを削除する。
     * @param id デバイスのID。
     */
    public function delete($id)
    {
        $this->db->where('device_id', $id);
        $this->db->delete('devices');
    }
}
