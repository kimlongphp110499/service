<?php
class CallRecord_model extends CI_Model
{
    /**
     * DBに登録されている通話記録のレコードを取得する。
     *
     * @param int $tenant_id 検索するテナントのID。
     * @param int $page ページ番号。-1を指定すると全てのレコードを取得する。
     * @param string $sortkey ソートキー。
     * @param string $order 順序('asc'or'desc')
     * @return object クエリ結果の配列。
     */
    public function get_tenant($tenant_id, $page = 0, $sortkey = false, $order = false)
    {
        $str = "SELECT "
            ."message_all.id as id, "
            ."message_all.date_time as date_time, "
            ."T1.display_name as send_from, "
            ."T2.display_name as send_to, "
            ."T3.group_name as group_name, "
            ."message_all.duration as duration, "
            ."message_all.type as type "
            ."FROM message_all "
            ."LEFT JOIN pocaccounts AS T1 ON message_all.send_from = T1.sip_number "
            ."LEFT JOIN pocaccounts AS T2 ON message_all.send_to = T2.sip_number "
            ."LEFT JOIN groups AS T3 ON message_all.send_to = (CASE WHEN message_all.type = 13 THEN T3.conf_sip_number ELSE T3.sip_number END) "
            ."WHERE message_all.company_id=".$tenant_id." AND "
            ."message_all.type IN('5','6','7','8','13') ";
        if ($sortkey) {
            $str .= "ORDER BY ".$sortkey." ".$order." ";
            if ($sortkey == 'send_to') {
                $str .= ", group_name ".$order." ";
            }
        } else {
            $str .= "ORDER BY id desc ";
	}
        if ($page != -1) {
            $str .= "LIMIT ".($page * 50).", 50";
        }

        $query = $this->db->query($str);
        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return false;
        }
    }

    public function get_tenant_num($tenant_id)
    {
        $this->db->from('message_all');
        $this->db->where('company_id', $tenant_id);
        $this->db->where_in('type', array('5','6','7','8','13'));

        return $this->db->count_all_results();
    }

    /**
     * DBに登録されている通話記録のレコードを取得する。
     *
     * @param id $tid 検索するテナントのID。
     * @param id $id 通話記録のID。
     * @return object クエリ結果の配列。
     */
    public function get_filepath($tid, $id)
    {
        $this->db->select('filepath');
        $this->db->where('company_id', $tid);
        $this->db->where('id', $id);
        $query = $this->db->get('message_all');

        if ($query->num_rows() > 0) {
            return $query->row()->filepath;
        }
        return false;
    }

    public function get_call_num_from_date($tid = false, $timestamp = false)
    {
        if ($timestamp) {
            $this->db->where('date_time >=', $timestamp * 1000);
        }
        if ($tid) {
            $this->db->where('company_id', $tid);
        }
        $this->db->where_in('type', array('5','6','7','8'));
        $this->db->from('message_all');

        return $this->db->count_all_results();
    }

    public function get_file_size_from_date($tid = false, $timestamp = false)
    {
        $this->db->select('filepath');
        if ($timestamp) {
            $this->db->where('date_time >=', $timestamp * 1000);
        }
        if ($tid) {
            $this->db->where('company_id', $tid);
        }
        $this->db->where_in('type', array('5','6','7','8'));
        $this->db->from('message_all');

        $query = $this->db->get();
        if (!$query) {
            return 0;
        }

        $size = 0;
        foreach ($query->result() as $row) {
            if (file_exists(ASTERISK_MONITOR_DIR.$row->filepath.'.wav')) {
                $size += filesize(ASTERISK_MONITOR_DIR.$row->filepath.'.wav');
            }
        }
        return $size;
    }
}
