<?php
class Image_model extends CI_Model
{
    /**
     * 画像の総ファイルサイズを取得。
     *
     * @param int $tid テナントID。
     * @return int ファイルサイズ(バイト)。
     */
    public function get_file_size($tid)
    {
        $size = 0;

        $this->db->select('username');
        $this->db->where('company_id', $tid);
        $query = $this->db->get('pocaccounts');
        
        foreach ($query->result() as $row) {
            $dir = IMAGE_TRANSFER_DIR.$row->username;
            if (is_dir($dir)) {
                $files = scandir($dir);
                if ($files !== false) {
                    $files = array_diff($files, array('.', '..'));
                    foreach ($files as $file) {
                        $size += filesize($dir.'/'.$file);
                    }
                }
            }
            $dir = IMAGE_TRANSFER_DIR.$row->username.'_s';
            if (is_dir($dir)) {
                $files = scandir($dir);
                if ($files !== false) {
                    $files = array_diff($files, array('.', '..'));
                    foreach ($files as $file) {
                        $size += filesize($dir.'/'.$file);
                    }
                }
            }
        }

        return $size;
    }
}
