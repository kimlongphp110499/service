<?php
class WebAccount_model extends CI_Model
{
    
    /**
     * Web UIログイン処理。
     *
     * @param string $login_id ログインID。
     * @param string $password_パスワード。
     * @return object クエリ結果のオブジェクト。
     */
    public function login($login_id, $password)
    {
		$valid_type = array('admin', 'tenant');
		
        // status == 0 でも良い (戻った後チェック)
        $this->db->select('*');
        $this->db->from('webaccounts');
        $this->db->where('login_id', $login_id);
        $this->db->where('password', MD5($password));
        $this->db->where_in('type', $valid_type);
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query -> num_rows() == 1) {
            return $query->result();
        } else {
            return false;
        }
    }
    
    /**
     * APIログイン処理。
     *
     * @param string $login_id APIログインID。
     * @param string $password_パスワード。
     * @return object クエリ結果のオブジェクト。
     */
    public function api_login($login_id, $password)
    {
		$valid_type = array('tenant_api');
		
        // status == 0 でも良い (戻った後チェック)
        $this->db->select('*');
        $this->db->from('webaccounts');
        $this->db->where('login_id', $login_id);
        $this->db->where('password', MD5($password));
        $this->db->where_in('type', $valid_type);
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query -> num_rows() == 1) {
            return $query->row();
        } else {
            return false;
        }
    }

    /**
     * Baisc認証用ログイン処理
     *
     * @param string $login_id APIログインID。
     * @param string $password パスワード。
     *
     * @return object ture if authentication success
     */
    public function basic_login($login_id, $password)
    {
        return !empty($this->api_login($login_id, $password));
    }

   /**
     * Digest認証用ログイン処理(hash取得)
     *
     * @param string $login_id APIログインID。
     * @param string $password パスワード。(digest認証では使用しない)
     *
     * @return object md5(username:restrealm:password) string or FALSE if not valid login id
     */
     public function digest_login($login_id, $password)
     {
         // あらかじめ保存された digest_hashを取得
         // $password は利用しない
         $valid_type = array('tenant_api');
         $not_valid_status = array('0');
         
         $this->db->select('*');
         $this->db->from('webaccounts');
         $this->db->where('login_id', $login_id);
         // password field is not checked
         //$this->db->where('password', MD5($password));
         $this->db->where_in('type', $valid_type);
         $this->db->where_not_in('status', $not_valid_status);  // 'status' != 0
         $this->db->limit(1);
 
         $query = $this->db->get();
 
         if ($query -> num_rows() == 1) {
             $row = $query->row();
             return $row->digest_hash;
         } else {
             return false;
         }
     }
 

    /**
     * DBに登録されている全アカウントのレコードを取得する。
     *
     * @param string $sortkey ソートキー。
     * @param string $order 順序('asc'or'desc')
     * @return object クエリ結果のオブジェクト。
     */
    public function get_all($sortkey = false, $order = false)
    {
        $this->db->select('webaccounts.*, tenants.company_name');
        $this->db->from('webaccounts');
        $this->db->join('tenants', 'tenants.company_id = webaccounts.company_id');
        if ($sortkey) {
            $this->db->order_by($sortkey, $order);
        }
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return false;
        }
    }
    
    /**
     * テナントに所属する全アカウントのレコードを取得する。
     *
     * @param int $tid テナントID。
     * @param string $sortkey ソートキー。
     * @param string $order 順序('asc'or'desc')
     * @return object クエリ結果のオブジェクト。
     */
    public function get_tenant($tid, $sortkey = false, $order = false)
    {
        $this->db->select('*');
        $this->db->from('webaccounts');
        $this->db->where('company_id', $tid);
        if ($sortkey) {
            $this->db->order_by($sortkey, $order);
        }
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return false;
        }
    }
    
    /**
     * 指定されたWebアカウントのレコードを取得する。
     *
     * @param int $id WebアカウントのID。
     * @return object クエリ結果のオブジェクト。
     */
    public function get($id)
    {
        $this->db->select('webaccounts.*, tenants.company_name');
        $this->db->from('webaccounts');
        $this->db->join('tenants', 'tenants.company_id = webaccounts.company_id');
        $this->db->where('account_id', $id);
        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->row();
        } else {
            return false;
        }
    }

    /**
     * Webアカウントを追加する。
     *
     * @return boolean 失敗した場合はFALSEを返す。
     */
    public function add()
    {
        $account_type = $this->input->post('type');
        $password = $this->input->post('password');

        $data = array(
            'login_id' => $this->input->post('login_id'),   // account ID
            'password' => MD5($password),                   // account password
            'username' => $this->input->post('username'),   // display name
            'type' => $account_type,
            'status' => $this->input->post('status'),
            'company_id' => $this->input->post('company_id'),
            'register_date' => date('Y-m-d H:i:s'),
            'update_date' => date('Y-m-d H:i:s'),
        );

        // if this is 'tenant_api' account, generate api_key and digest_hash
        // api_key is used for protection from NULL password
        if ($account_type == 'tenant_api') {
            
            // generate 128bit API key and store in 32char HEX string
            $blob = openssl_random_pseudo_bytes(16);
            $api_key = bin2hex($blob);

            // generate 128bit hash created by login_id/realm/password
            $digest_hash = MD5($data['login_id'].':'.DIGEST_API_REALM.':'.$password);

            $data += array(
                'api_key' => $api_key,
                'digest_hash' => $digest_hash,
            );
        }

        return $this->db->insert('webaccounts', $data);
    }

    /**
     * 指定されたWebアカウントのレコード内容を更新する。
     *
     * @param int $id WebアカウントのID番号 (1- )
     *
     * @param int $login_id WebアカウントのログインID。
     *
     * @return boolean 失敗した場合はFALSEを返す。
     */
    public function edit($id, $login_id)
    {
        // check login_id (for safety)
        if (empty($login_id)) {
            log_message('error', 'empty login_id fir ID='.$id);
            return false;
        }
 
        $data = array(
            'username' => $this->input->post('username'),
            'type' => $this->input->post('type'),
            'status' => $this->input->post('status'),
            'update_date' => date('Y-m-d H:i:s'),
        );

        // password change???
        $password = $this->input->post('password');
        if (!empty($password)) {

            // re-generate 128bit API key and store in 32char HEX string
            $blob = openssl_random_pseudo_bytes(16);
            $api_key = bin2hex($blob);

            // re-generate 128bit hash created by login_id/realm/password
            $digest_hash = MD5($login_id.':'.DIGEST_API_REALM.':'.$password);
                                    
            $data += array(
                'password' => MD5($password),
                'api_key' => $api_key,
                'digest_hash' => $digest_hash,
            );
        }

        $this->db->where('account_id', $id);

        return $this->db->update('webaccounts', $data);
    }

    /**
     * 指定されたアカウントのレコードを削除する。
     *
     * @param int $id アカウントのID。
     * @return boolean 失敗した場合はFALSEを返す。
     */
    public function delete($id)
    {
        $this->db->where('account_id', $id);

        return $this->db->delete('webaccounts');
    }

    /**
     * 指定されたテナントのレコードを削除する。
     *
     * @param int $tid テナントのID。
     * @return boolean 失敗した場合はFALSEを返す。
     */
    public function delete_tenant($tid)
    {
        $this->db->where('company_id', $tid);

        return $this->db->delete('webaccounts');
    }

    /**
     * 指定されたログインIDが登録されているかを確認する。
     *
     * @param string $login_id 調べるログインID。
     * @return 登録されている場合はTRUEを返す。それ以外はFALSEを返す。
     */
    public function check_login_id($login_id)
    {
        $this->db->select('login_id');
        $this->db->from('webaccounts');
        $this->db->where('login_id', $login_id);
        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * ログイントークンを設定する。
     *
     * @param string $account_id アカウントID。
     * @param string $token トークン。
     */
    public function set_token($account_id, $token)
    {
        $data = array(
                      'token' => $token
                      );
        $this->db->where('account_id', $account_id);
        $this->db->update('webaccounts', $data);
    }

    /**
     * いずれかのテナントユーザーの最終ログイン日時を設定する。
     *
     * @param string $account_id アカウントID。
     * @param string $date 最終ログイン日時。
     */
    public function set_last_login($account_id, $date)
    {
        $data = array(
                      'last_login' => date('Y-m-d H:i:s', $date)
                      );
        $this->db->where('account_id', $account_id);
        $this->db->update('webaccounts', $data);
    }
}
