<?php
class Tenant_model extends CI_Model
{
    /**
     * DBに登録されている全テナントのレコードを取得する。
     *
     * @param string $sortkey ソートキー。
     * @param string $order 順序('asc'or'desc')
     * @return object クエリ結果のオブジェクト。
     */
    public function get_all($sortkey = false, $order = false, $search = false)
    {
        $this->db->select('*');
        $this->db->from('tenants');
        if ($search) {
            $this->db->like('company_name', $search);
            $this->db->or_like('sip_context_name', $search);
        }
        if ($sortkey) {
            $this->db->order_by($sortkey, $order);
        }
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return false;
        }
    }
    
    /**
     * 指定されたテナントのレコードを取得する。
     *
     * @param int $id テナントのID。
     * @return object クエリ結果のオブジェクト。
     */
    public function get($id)
    {
        $query = $this->db->get_where('tenants', array('company_id' => $id));

        if ($query->num_rows() == 1) {
            return $query->row();
        } else {
            return false;
        }
    }

    /**
     * パラメータで指定された条件にあうレコードを取得する。
     *
     * @param array $param パラメータ。
     * @return object クエリ結果のオブジェクト。
     */
    public function get_where($param)
    {
        $query = $this->db->get_where('tenants', $param);

        if ($query->num_rows() == 1) {
            return $query->row();
        } else {
            return false;
        }
    }

    /**
     * テナントを追加する。
     * テナントが追加成功したら、テナントIDを自動生成する
     *
     * @return int 追加したテナントID (または失敗の場合はFALSEを返す)
     */
    public function add()
    {
        /* システム設定をコピー */
        $this->db->where('id', 1);
        $query = $this->db->get('spt_configs');
        $row = $query->row();
        $row->id = '';
        $row->type = 'tenant';
        $this->db->insert('spt_configs', $row);
        $spt_config_id = $this->db->insert_id();

        $this->db->where('id', 1);
        $query = $this->db->get('ism_configs');
        $row = $query->row();
        $row->id = '';
        $row->type = 'tenant';
        $this->db->insert('ism_configs', $row);
        $ism_config_id = $this->db->insert_id();

        // 新型ハンディ機用はテナントidが必要なので、別関数で処理

		// pre-process 'company_industry_etc'
		global $global_industry_names;
		global $global_industry_numbers;
        
		$company_industry=$this->input->post('company_industry');
		$company_industry_etc=$this->input->post('company_industry_etc');
		if (!empty($company_industry) && in_array($company_industry, $global_industry_names, TRUE)) { 
            // pre-defined industy. use it!
		} else if (!empty($company_industry_etc)) {
			// undefined industry
			$company_industry=$company_industry_etc;
		} else {
			// empty
			$company_industry='';
		}

        $company_industry_code = $this->input->post('company_industry');
		if (!empty($company_industry_code) && in_array($company_industry_code, $global_industry_numbers, TRUE)) {
            $company_industry_code = array_search($company_industry_code, $global_industry_numbers, TRUE);   // 01 - 19
        }
        else {
            // empty or not predefeined industry
            $company_industry_code = 99;
        }

        $data = array(
            'company_name' => $this->input->post('company_name'),
            'company_kana' => $this->input->post('company_kana'),
            'sip_context_name' => $this->input->post('sip_context_name'),
            'contact_name' => $this->input->post('contact_name'),
            'contact_kana' => $this->input->post('contact_kana'),
            'contact_department' => $this->input->post('contact_department'),
            'contact_title' => $this->input->post('contact_title'),
            'contact_zip' => $this->input->post('contact_zip'),
            'contact_address' => $this->input->post('contact_address'),
            'contact_tel' => $this->input->post('contact_tel'),
            'contact_email' => $this->input->post('contact_email'),
            'sales_staff_name' => $this->input->post('sales_staff_name'),
            'sales_staff_tel' => $this->input->post('sales_staff_tel'),
            'sales_staff_email' => $this->input->post('sales_staff_email'),
            'company_industry' => $company_industry,
            'agent_company' => $this->input->post('agent_company'),
            'agent_name' => $this->input->post('agent_name'),
            'agent_tel' => $this->input->post('agent_tel'),
            'agent_email' => $this->input->post('agent_email'),
            'spt_config_id' => $spt_config_id,
            'ism_config_id' => $ism_config_id,
            'register_date' => date('Y-m-d H:i:s'),
            'update_date' => date('Y-m-d H:i:s'),
        );

        if ($this->db->insert('tenants', $data)) {
            // 書き込み成功
            $id = $this->db->insert_id();  // テナントID
            $company_code = sprintf('JP%02d001%04d', $company_industry_code, ($id % 10000));

            // company_code レコード更新
            $data = array('company_code' => $company_code);
            $this->db->where('company_id', $id);
            $this->db->update('tenants', $data);
            
            return $id;
        }
        else {
            return false;
        }
    }

    /**
     * テナントをインポートする。
     * テナントが追加成功したら、テナントIDを自動生成する
     *
     * @return int 追加したテナントID (または失敗の場合はFALSEを返す)
     */
    public function import($tenant_data)
    {
        /* システム設定をコピー */
        $this->db->where('id', 1);
        $query = $this->db->get('spt_configs');
        $row = $query->row();
        $row->id = '';
        $row->type = 'tenant';
        $this->db->insert('spt_configs', $row);
        $spt_config_id = $this->db->insert_id();

        $this->db->where('id', 1);
        $query = $this->db->get('ism_configs');
        $row = $query->row();
        $row->id = '';
        $row->type = 'tenant';
        $this->db->insert('ism_configs', $row);
        $ism_config_id = $this->db->insert_id();

        // 新型ハンディ機用はテナントidが必要なので、別関数で処理

		// pre-process 'company_industry_etc'
		global $global_industry_names;
		global $global_industry_numbers;
        
		$company_industry=$tenant_data['company_industry'];
        $company_industry_code = $tenant_data['company_industry'];
		if (!empty($company_industry_code) && in_array($company_industry_code, $global_industry_numbers, TRUE)) {
            $company_industry_code = array_search($company_industry_code, $global_industry_numbers, TRUE);   // 01 - 19
        }
        else {
            // empty or not predefeined industry
            $company_industry_code = 99;
        }

        $data = array(
            'company_name' => $tenant_data['company_name'],
            'company_kana' => $tenant_data['company_kana'],
            'sip_context_name' => $tenant_data['sip_context_name'],
            'contact_name' => $tenant_data['contact_name'],
            'contact_kana' => $tenant_data['contact_kana'],
            'contact_department' => $tenant_data['contact_department'],
            'contact_title' => $tenant_data['contact_title'],
            'contact_zip' => $tenant_data['contact_zip'],
            'contact_address' => $tenant_data['contact_address'],
            'contact_tel' => $tenant_data['contact_tel'],
            'contact_email' => $tenant_data['contact_email'],
            'sales_staff_name' => $tenant_data['sales_staff_name'],
            'sales_staff_tel' => $tenant_data['sales_staff_tel'],
            'sales_staff_email' => $tenant_data['sales_staff_email'],
            'company_industry' => $company_industry,
            'agent_company' => $tenant_data['agent_company'],
            'agent_name' => $tenant_data['agent_name'],
            'agent_tel' => $tenant_data['agent_tel'],
            'agent_email' => $tenant_data['agent_email'],
            'spt_config_id' => $spt_config_id,
            'ism_config_id' => $ism_config_id,
            'register_date' => date('Y-m-d H:i:s'),
            'update_date' => date('Y-m-d H:i:s'),
        );

        if ($this->db->insert('tenants', $data)) {
            // 書き込み成功
            $id = $this->db->insert_id();  // テナントID
            $company_code = sprintf('JP%02d001%04d', $company_industry_code, ($id % 10000));

            // company_code レコード更新
            $data = array('company_code' => $company_code);
            $this->db->where('company_id', $id);
            $this->db->update('tenants', $data);
            
            return $id;
        }
        else {
            return false;
        }
    }

    /**
     * 指定されたテナントのレコード内容を更新する。
     *
     * @param int $id テナントのID。
     * @return boolean 失敗の場合はFALSEを返す。
     */
    public function edit($id)
    {
		// pre-process 'company_industry_etc'
		global $global_industry_names;
		
		$company_industry=$this->input->post('company_industry');
		$company_industry_etc=$this->input->post('company_industry_etc');
		if (!empty($company_industry) && in_array($company_industry, $global_industry_names, TRUE)) { 
			// pre-defined industy. use it!
		} else if (!empty($company_industry_etc)) {
			// undefined industry
			$company_industry=$company_industry_etc;
		} else {
			// empty
			$company_industry='';
		}

        $data = array(
            'company_code' => $this->input->post('company_code'),
            'company_name' => $this->input->post('company_name'),
            'company_kana' => $this->input->post('company_kana'),
            'sip_context_name' => $this->input->post('sip_context_name'),
            'contact_name' => $this->input->post('contact_name'),
            'contact_kana' => $this->input->post('contact_kana'),
            'contact_department' => $this->input->post('contact_department'),
            'contact_title' => $this->input->post('contact_title'),
            'contact_zip' => $this->input->post('contact_zip'),
            'contact_address' => $this->input->post('contact_address'),
            'contact_tel' => $this->input->post('contact_tel'),
            'contact_email' => $this->input->post('contact_email'),
            'sales_staff_name' => $this->input->post('sales_staff_name'),
            'sales_staff_tel' => $this->input->post('sales_staff_tel'),
            'sales_staff_email' => $this->input->post('sales_staff_email'),
            'company_industry' => $company_industry,
            'agent_company' => $this->input->post('agent_company'),
            'agent_name' => $this->input->post('agent_name'),
            'agent_tel' => $this->input->post('agent_tel'),
            'agent_email' => $this->input->post('agent_email'),
            'update_date' => date('Y-m-d H:i:s'),
        );

        $this->db->where('company_id', $id);

        return $this->db->update('tenants', $data);
    }

    /**
     * 回線計画用に指定されたテナントの緊急情報内容を更新する。
     *
     * @param int $tid テナントのID。
     * 
     * @param int $data アップデートするフィールド配列。
     * 
     * @return boolean 失敗の場合はFALSEを返す。
     */
    public function edit_emergency($tid, $data)
    {
        $this->db->where('company_id', $tid);

        return $this->db->update('tenants', $data);
    }
    
    /**
     * 指定されたテナントのレコードを削除する。
     *
     * @param int $id テナントのID。
     * @return boolean 失敗の場合はFALSEを返す。
     */
    public function delete($id)
    {
        $this->db->select('spt_config_id, ism_config_id');
        $this->db->where('company_id', $id);
        $query = $this->db->get('tenants');
        $row = $query->row();

        $this->db->where('company_id', $id);
        $this->db->delete('tenants');

        $this->db->where('id', $row->spt_config_id);
        $this->db->delete('spt_configs');

        $this->db->where('id', $row->ism_config_id);

        return $this->db->delete('ism_configs');
    }

    /**
     * 指定されたテナントのSPTアカウントの最後のIDを返す。
     *
     * @param int $id テナントのID。
     * @return object クエリ結果のオブジェクト。
     */
    public function get_last_device_ids($id)
    {
        $this->db->select('hdy_last_id, spt_last_id, ism_last_id, ipp_last_id');
        $this->db->where('company_id', $id);
        $query = $this->db->get('tenants');

        if ($query->num_rows() == 1) {
            return $query->row();
        }
        
        return false;
    }

    /**
     * 最終IDを更新する。
     *
     * @param int $tid テナントID
     * @param int $spt SPT通し番号
     * @param int $ism ISM通し番号
     * @param int $ipp IPP通し番号
     * @return boolean 失敗の場合はFALSEを返す。
     */
    public function update_last_ids($tid, $hdy, $spt, $ism, $ipp)
    {
        $data =     array(
                        'hdy_last_id' => $hdy,
                        'spt_last_id' => $spt,
                        'ism_last_id' => $ism,
                        'ipp_last_id' => $ipp
                        );
        $this->db->where('company_id', $tid);

        return $this->db->update('tenants', $data);
    }
        
    /**
     * 指定されたテナントのグループの最後のIDを返す。
     *
     * @param int $id テナントのID。
     * @return int|false 最後のID。
     */
    public function get_last_group_id($id)
    {
        $this->db->select('group_last_id');
        $this->db->where('company_id', $id);
        $query = $this->db->get('tenants');

        if ($query->num_rows() == 1) {
            return $query->row()->group_last_id;
        }
        
        return false;
    }

    /**
     * 使用した最終グループIDを更新する。
     *
     * @param int $tid テナントID
     * @param int $last 通し番号 (初期状態 = 0, 3つグループを作成すると3を保存)
     * 
     * @return boolean 失敗の場合はFALSEを返す。
     */
    public function update_last_group_id($tid, $last)
    {
        $data =     array('group_last_id' => $last);

        $this->db->where('company_id', $tid);

        return $this->db->update('tenants', $data);
    }

    /**
     * テナントテーブルで会社名の重複があるか調べる。
     *
     * @param int $company_name 調べる会社名。
     * 
     * @return 利用可能な場合はTRUEを返す。
     */
    public function is_available_company_name($company_name)
    {
        $this->db->where('company_name', $company_name);
        $query = $this->db->get('tenants');

        return ($query->num_rows() == 0) ? true : false;
    }

    /**
     * テナントテーブルでSIPコンテキスト名の重複があるか調べる。
     *
     * @param int $sip_context_name 調べるSIPコンテキスト名。
     * 
     * @param int $exclude_tid 除外するTID (オプション)
     * システム全体で重複があってはけないが、編集中のテナント内に同じSIPコンテキスト名があっても気にしない
     * 
     * @return 利用可能な場合はTRUEを返す。
     */
    public function is_available_sip_context($sip_context_name, $exclude_tid = false)
    {
        $this->db->where('sip_context_name', $sip_context_name);
        if ($exclude_tid) {
            $this->db->where('company_id !=', $exclude_tid);
        }
        $query = $this->db->get('tenants');

        return ($query->num_rows() == 0) ? true : false;
    }

}
