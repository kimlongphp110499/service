<?php
class HandyDevice_model extends CI_Model
{
    /**
     * DBに登録されているデバイステンプレート設定を返す。
     *
     * @param int $tid 検索するテナントのID。0 = 保守アカウント用
	 *
     * @return object|false クエリ結果のオブジェクト。
     */
    public function get_device_template($tid = 0)
    {
		if ($tid) {
			// テナントアカウント用
        	$this->db->where('type', 'device_tenant');
        	$this->db->where('company_id', $tid);
        	$query = $this->db->get('hdy_configs_new');
		}
		else {
			// 保守アカウント用
        	$this->db->where('type', 'device_admin');  // singleton
        	$query = $this->db->get('hdy_configs_new');
		}

        if ($query->num_rows() != 1) {
            return false;
        }

        return $query->row();
    }

    /**
     * DBに登録されているテナント設定、またはテナント用テンプレートを返す。
     *
     * @param int $tid 検索するテナントのID。0 = テナント用テンプレートを取得(保守アカウント用)
	 *
     * @return object|false クエリ結果のオブジェクト。
     */
    public function get_tenant_template($tid = 0)
    {
		if ($tid) {
			// テナントアカウント設定
			// this is not templete though...
        	$this->db->where('type', 'tenant');
        	$this->db->where('company_id', $tid);
        	$query = $this->db->get('hdy_configs_new');
		}
		else {
			// テナント用テンプレート(保守アカウント用)
        	$this->db->where('type', 'tenant_admin');  // singleton
        	$query = $this->db->get('hdy_configs_new');
		}

        if ($query->num_rows() != 1) {
            return false;
        }

        return $query->row();
    }

    /**
     * DBに登録されている工場出荷マスターデータを返す。
     *
     * @return object|false クエリ結果のオブジェクト。
     */
    public function get_factory_template()
    {
		// 工場出荷マスターデータ(保守アカウント用)
		// this is not templete though...
       	$this->db->where('type', 'factory');  // singleton
       	$query = $this->db->get('hdy_configs_new');

        if ($query->num_rows() != 1) {
            return false;
        }

        return $query->row();
    }

    /**
     * DBに登録されているPOCアカウントごとのデバイス設定を返す。
     *
     * @param int $tid 検索するテナントのID (0 = テナントidをチェックしない)
     * 
     * @param int $index 検索するデバイスのindex値 (POCアカウントidではない)
	 *
     * @return object|false クエリ結果のオブジェクト。
     */
     public function get_device_config($tid, $index)
     {
         if ($tid) {
             // テナントチェックあり
             $this->db->where('type', 'device');
             $this->db->where('company_id', $tid);
             $this->db->where('id', $index);
             $query = $this->db->get('hdy_configs_new');
         }
         else {
             // テナントチェックなし
             // 保守アカウント用
             $this->db->where('type', 'device');
             $this->db->where('id', $index);
             $query = $this->db->get('hdy_configs_new');
         }
 
         if ($query->num_rows() != 1) {
             return false;
         }
 
         return $query->row();
     }

     /**
     * DBに登録されているデバイス設定を更新(プライベート関数)。
     *
     * @param int $handy_config_id 更新するレコード番号
	 *
     * @param array $record 編集するレコード(1行分のデータ)
     *
     * @return true|false 成功または失敗
     */
    private function _edit_device($handy_config_id, $record)
    {
		$this->db->trans_start();

        $this->db->where('id', $handy_config_id);
        $this->db->update('hdy_configs_new', $record);

		$this->db->trans_complete();

        if ($this->db->trans_status() === false) {
            return false;
        }
        return true;
    }

    /**
     * DBに登録されているデバイステンプレート設定を編集。
     *
     * @param int $tid 編集するテナントのID。0 = 保守アカウント用
	 *
     * @param array $record 編集するデバイステンプレート
     *
     * @return true|false 成功または失敗
     */
    public function edit_device_template($tid, $record)
	{
        // check if specified template record exist
        $hdy_config = $this->get_device_template($tid);
        if (!$hdy_config) {
            // no record found.
            log_message('error', 'edit_device_template: no target record found.');
            return false;
        }

        // update record using record number
		return $this->_edit_device($hdy_config->id, $record);
	}

    /**
     * DBに登録されているテナント設定、またはテナント用テンプレートを編集。
     *
     * @param int $tid 編集するテナントのID。0 = テナント用テンプレートを編集(保守アカウント用)
	 *
     * @param array $record 編集するテナント設定またはテナントテンプレート
	 *
     * @return true|false 成功または失敗
     */
    public function edit_tenant_template($tid, $record)
	{
        // check if specified template record exist
        $hdy_config = $this->get_tenant_template($tid);
        if (!$hdy_config) {
            // no record found.
            log_message('error', 'edit_tenant_template: no target record found.');
            return false;
        }


        // update record using record number
        return $this->_edit_device($hdy_config->id, $record);
	}

    /**
     * DBに登録されている工場出荷マスターデータを編集。
     *
     * @return true|false 成功または失敗
     */
    public function edit_factory_template($record)
	{
        // check if factory initial record exist
        $hdy_config = $this->get_factory_template();
        if (!$hdy_config) {
            // no record found.
            log_message('error', 'edit_factory_template: no target record found.');
            return false;
        }
        

        // update record using record number
        return $this->_edit_device($hdy_config->id, $record);
	}

    /**
     * DBに登録されているデバイスコンフィグ設定を編集。
     *
     * @param int $tid 検索するテナントのID (0 = テナントidをチェックしない : オプション)
     * 
     * @param int $index 編集するデバイスのindex値 (POCアカウントidではない : 必須)
     *
     * @param array $record 保存するデバイスコンフィグ (必須)
     *
     * @return true|false 成功または失敗
     */
     public function edit_device_config($tid, $index, $record)
     {
         // check POC account record exist
         $hdy_config = $this->get_device_config($tid, $index);
         if (!$hdy_config) {
            // no record found.
            log_message('error', 'edit_device_config: no target record found.');
            return false;
        }

        // update record using record number
        return $this->_edit_device($index, $record);
    }

    /**
    * DBに登録されているテナント設定テンプレートとデバイス設定テンプレートを新規テナント用にコピー。
    *
    * @param int $tid 新規テナントのID。( 0 は無効)
    *
    * @return true|false 成功または失敗
    */
    public function copy_tenant_config($tid)
    {
        if (!$tid) {
            log_message('error', 'copy_tenant_config: invalid tenant id 0.');
            return false;
        }

        // check if specified 'tenant' record exist
        $hdy_config = $this->get_tenant_template($tid);
        if ($hdy_config) {
            // 'tenant' record already exist
            log_message('error', 'copy_tenant_config: tenant record for TID='.$tid.' already exist.');
            return false;
        }

        // check if specified 'device_tenant' record exist
        $hdy_config2 = $this->get_device_template($tid);
        if ($hdy_config2) {
            // 'device_tenant' record already exist
            log_message('error', 'copy_tenant_config: device_tenant record for TID='.$tid.' already exist.');
            return false;
        }

        // get 'tenant_admin' record and copy to 'tenant' with company_id = $tid
        $hdy_config = $this->get_tenant_template(0);
        if (!$hdy_config) {
            log_message('error', 'copy_tenant_config: no tenant_admin record found in hdy_configs table.');
            return false;
        }

        unset($hdy_config->id, $hdy_config->last_login, $hdy_config->comment);   // clear these fields
        $hdy_config->type = 'tenant';    // テナント設定
        $hdy_config->company_id = $tid;     // テナントID
        // 更新日はそのまま引き継ぐ

        // get 'device_admin' record and copy to 'device_tenant' with company_id = $tid
        $hdy_config2 = $this->get_device_template(0);
        if (!$hdy_config2) {
            log_message('error', 'copy_tenant_config: no device_admin record found in hdy_configs table.');
            return false;
        }

        unset($hdy_config2->id, $hdy_config2->last_login, $hdy_config2->comment);   // clear these fields
        $hdy_config2->type = 'device_tenant';   // デバイステンプレート
        $hdy_config2->company_id = $tid;        // テナントID
        // 更新日はそのまま引き継ぐ

        // insert 2 records
        $this->db->trans_start();
        $this->db->insert('hdy_configs_new', $hdy_config);
        $this->db->insert('hdy_configs_new', $hdy_config2);
        $this->db->trans_complete();

        // return result
        return $this->db->trans_status();
    }    

    /**
    * DBに登録されているテナント設定とテナント用デバイステンプレートを削除。
    *
    * @param int $tid 削除するテナントのID。( 0 は無効)
    */
    public function delete_tenant_config($tid)
    {
         if (!$tid) {
            log_message('error', 'delete_tenant_config: invalid tenant id 0.');
            return;
         }

        // check if specified 'tenant' record exist
        $hdy_config = $this->get_tenant_template($tid);
        if (!$hdy_config) {
            // no record found.
            log_message('error', 'delete_tenant_config: no tenant record for TID='.$tid.' found.');
            return;
        }

        // check if specified 'device_tenant' record exist
        $hdy_config2 = $this->get_device_template($tid);
        if (!$hdy_config2) {
            // no record found.
            log_message('error', 'delete_tenant_config: no device_tenant record for TID='.$tid.' found.');
            return;
        }

        // delete 2 records
        $this->db->where('id', $hdy_config->id);
        $this->db->or_where('id', $hdy_config2->id);
        $this->db->delete('hdy_configs_new');

        // テナントに所属する個別のデバイス設定は要別途削除
    }

 
    /**
     * DBに登録されているデバイスコンフィグ設定を削除。
     *
     * @param int $tid 削除するテナントのID (0 = テナントidをチェックしない : オプション)
     * 
     * @param int $index 削除するデバイスのindex値 (POCアカウントidではない : 必須)
     */
     public function delete_device_config($tid, $index)
     {
         // check POC account record exist
         $hdy_config = $this->get_device_config($tid, $index);
         if (!$hdy_config) {
            // no record found.
            log_message('error', 'delete_device_config: no target record found.'); 
            return;
        }

        $this->db->where('id', $hdy_config->id);
        $this->db->delete('hdy_configs_new');
    }
    
}
