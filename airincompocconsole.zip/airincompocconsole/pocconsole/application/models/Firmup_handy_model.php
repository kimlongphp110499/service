<?php
class Firmup_handy_model extends CI_Model
{
    /**
     * ファームアップ管理一覧情報を取得する。
     *
     * @param string $sortkey ソートキー。
     * @param string $order 順序('asc'or'desc')
     */
    public function getFirm($sortkey = false, $order = false)
    {
        $this->db->select('firmup_file.*, tenants.company_name,');
        $this->db->from('firmup_file');
        $this->db->join('tenants', 'tenants.company_id = firmup_file.company_id');
        if ($sortkey) {
            $this->db->order_by($sortkey, $order);
        }
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return false;
        }
    }

    /**
     * 登録端末情報を取得する。
     *
     * @param int $id Index
     * @param string $sortkey ソートキー。
     * @param string $order 順序('asc'or'desc')
     */
    public function getMacaddr_reg($id, $sortkey = false, $order = false)
    {
        $this->db->select('firmup_macaddr.*, tenants.company_name, firmup_file.device_name');
        $this->db->from('firmup_macaddr');
        $this->db->join('firmup_file', 'firmup_file.id = firmup_macaddr.firmup_file_id');
        $this->db->join('tenants', 'tenants.company_id = firmup_file.company_id');
        $this->db->where('firmup_file_id',$id);
        if ($sortkey) {
            $this->db->order_by($sortkey, $order);
        }
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return false;
        }
        
    }

    /**
     * 更新済み端末情報を取得する。
     *
     * @param int $id Index
     * @param string $firm_version 登録中バージョン
     * @param string $sortkey ソートキー。
     * @param string $order 順序('asc'or'desc')
     */
    public function getMacaddr_updated($id, $firm_version, $sortkey = false, $order = false)
    {
        $this->db->select('firmup_macaddr.*, tenants.company_name, firmup_file.device_name');
        $this->db->from('firmup_macaddr');
        $this->db->join('firmup_file', 'firmup_file.id = firmup_macaddr.firmup_file_id');
        $this->db->join('tenants', 'tenants.company_id = firmup_file.company_id');
        $this->db->where('firmup_file_id',$id);
        $this->db->where('firmup_macaddr.firm_version',$firm_version);
        if ($sortkey) {
            $this->db->order_by($sortkey, $order);
        }
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return false;
        }
        
    }

    /**
     * 更新済み端末情報を取得する。
     *
     * @param int $id Index
     * @param string $firm_version 登録中バージョン
     * @param string $sortkey ソートキー。
     * @param string $order 順序('asc'or'desc')
     */
    public function getMacaddr_noupd($id, $firm_version, $sortkey = false, $order = false)
    {
        $this->db->select('firmup_macaddr.*, tenants.company_name, firmup_file.device_name');
        $this->db->from('firmup_macaddr');
        $this->db->join('firmup_file', 'firmup_file.id = firmup_macaddr.firmup_file_id');
        $this->db->join('tenants', 'tenants.company_id = firmup_file.company_id');
        $this->db->where('firmup_file_id',$id);
        $this->db->where('firmup_macaddr.firm_version !=',$firm_version);
        if ($sortkey) {
            $this->db->order_by($sortkey, $order);
        }
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return false;
        }
        
    }

    /**
     * ファームアップ用ファイルテーブルから指定したidの情報を取得する。
     *
     * @param int $id インデックス (必須)
     */
    public function getFirmupfile($id)
    {
        $this->db->select('firmup_file.*, tenants.company_name');
        $this->db->join('tenants', 'tenants.company_id = firmup_file.company_id');
        $this->db->from('firmup_file');
        $this->db->where('id', $id);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->row();
        } else {
            return false;
        }
    }

    /**
     * ファームウェア情報を追加する。
     *
     * @return boolean 失敗した場合はFALSEを返す。
     */
    public function addFirm($file_name = false)
    {
        if ($file_name)
        {
            $firm_version = $this->input->post('firm_version');
            if(!$firm_version){
                $firm_version = "";
            }

            $register_date = new DateTime();
            $validity_from = new DateTime($this->input->post('validity_from'));
            $validity_to = new DateTime($this->input->post('validity_to'));

            $firm_info = array(
                'company_id' => intval($this->input->post('company_id'), 10),
                'firm_name' => $file_name,
                'device_name' => $this->input->post('device_name'),
                'firm_version' => $firm_version,
                'flag' => intval($this->input->post('flag'), 10),
                'register_date' => $register_date->format('Y-m-d H:i:s'),
                'validity_from' => $validity_from->format('Y-m-d H:i:s'),
                'validity_to' => $validity_to->format('Y-m-d H:i:s')
            );
    
            return $this->db->insert('firmup_file', $firm_info);
        }

        return false;
    }

    public function editFirm($file_name, $id){

        if ($file_name){
            $firm_version = $this->input->post('firm_version');
            if(!$firm_version){
                $firm_version = "";
            }

            $register_date = new DateTime();
            $validity_from = new DateTime($this->input->post('validity_from'));
            $validity_to = new DateTime($this->input->post('validity_to'));      

            $firm_info = array(
                'company_id' => $this->input->post('company_id'),
                'firm_name' => $file_name,
                'device_name' => $this->input->post('device_name'),
                'firm_version' => $firm_version,
                'flag' => $this->input->post('flag'),
                'register_date' => date('Y-m-d H:i:s'),
                'validity_from' => $this->input->post('validity_from'),
                'validity_to' => $this->input->post('validity_to'),
            );

            $this->db->where('id', $id);

            return $this->db->update('firmup_file', $firm_info);
        }

        return false;
    }

    /**
     * IMEIテーブルからマッチするレコードを取得。
     *
     * @param string $macaddr 検索するIMEI (必須)
     * 
     * @return int 該当するIMEIテーブル行 または false
     */
    public function getmac_from_address($macaddr)
    {
        $macaddr = strtoupper($macaddr);    // 大文字には変換するが、16進数かどうか等はチェックしない

        $this->db->from('firmup_macaddr');
        $this->db->where('macaddr',$macaddr);
        $query = $this->db->get();

        if ($query->num_rows() == 1) {  // 1行見つかった
            return $query->row();
        } else {
            return false;
        }

    }


    public function delete($id){
        $this->db->where('firmup_file_id', $id);
        $this->db->delete('firmup_macaddr');

        $this->db->where('id', $id);
        return $this->db->delete('firmup_file');
    }
    public function getMacaddr(){

    }

    /**
     * IMEIテーブルに複数レコードを追加
     *
     * @param array $records 追加するレコードのオブジェクト配列 (必須)
     * テーブルに同じIMEI行が存在しないことを事前にチェック
     * 
     * @return 失敗した場合はfalseを返す。
     */
    public function addMacaddr($records){

        // 複数レコードのinsertを実行
        $this->db->trans_start();
        $this->db->insert_batch('firmup_macaddr', $records);
        $this->db->trans_complete();

        return $this->db->trans_status();   // true if SUCCESS
    }

    /**
     * IMEIテーブルの複数の該当レコードを編集
     *
     * @param array $records 編集するレコードのオブジェクト配列 (必須)
     * テーブルに同じIMEI行が存在することを事前にチェックする
     * 
     * @param $string マッチングを行うカラム名 (必須)
     * 
     * @return 失敗した場合はfalseを返す。
     */
    public function editMacaddr($records, $match){

        // $match カラムの一致するレコードを編集
        $this->db->trans_start();
        $this->db->update_batch('firmup_macaddr', $records, $match);
        $this->db->trans_complete();

        return $this->db->trans_status();   // true if SUCCESS
    }

    /**
     * IMEIテーブルのうち、firmup_file_id が合致するレコードを全削除
     *
     * @param $int $firmup_file_id 検索するfirmip_file_id (必須)
     * 
     * @return 失敗した場合はfalseを返す。
     */
    public function deleteMacaddr($firmup_file_id){

        // 'firmup_file_id' カラムが指定値と同じレコードを全削除
        $this->db->trans_start();
        $this->db->delete('firmup_macaddr', array('firmup_file_id' => $firmup_file_id));
        $this->db->trans_complete();

        return $this->db->trans_status();   // true if SUCCESS
    }
}
