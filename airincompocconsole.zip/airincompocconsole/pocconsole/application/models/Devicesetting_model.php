<?php
class DeviceSetting_model extends CI_Model
{
    /**
     * DBに登録されているSPT設定を返す。
     *
     * @param int $tenant_id 検索するテナントのID。
     * @return object|false クエリ結果のオブジェクト。
     */
    public function get_spt_config($tenant_id)
    {
        $this->db->select('spt_config_id');
        $this->db->where('company_id', $tenant_id);
        $query = $this->db->get('tenants');

        if ($query->num_rows() != 1) {
            return false;
        }

        $this->db->where('id', $query->row()->spt_config_id);
        $query = $this->db->get('spt_configs');

        if ($query->num_rows() != 1) {
            return false;
        }

        return $query->row();
    }
    
    /**
     * DBに登録されているISM設定を返す。
     *
     * @param int $tenant_id 検索するテナントのID。
     * @return object|false クエリ結果のオブジェクト。
     */
    public function get_ism_config($tenant_id)
    {
        $this->db->select('ism_config_id');
        $this->db->where('company_id', $tenant_id);
        $query = $this->db->get('tenants');

        if ($query->num_rows() != 1) {
            return false;
        }

        $this->db->where('id', $query->row()->ism_config_id);
        $query = $this->db->get('ism_configs');

        if ($query->num_rows() != 1) {
            return false;
        }

        return $query->row();
    }

    /**
     * レコード内容を更新する。
     *
     * @param int $tid テナントID。
     */
    public function edit($tid)
    {
        $spt_config = $this->get_spt_config($tid);
        $ism_config = $this->get_ism_config($tid);

        $this->db->trans_start();

        $data = array(
            'gps_interval' => $this->input->post('gps_interval'),
            //'bluetooth_address' => $this->input->post('bluetooth_address'),
            //'bluetooth_interval' => $this->input->post('bluetooth_interval'),
            //'bluetooth_rssi_threshold' => $this->input->post('bluetooth_rssi_threshold'),
            'xmpp_server_domain' => $this->input->post('xmpp_server_domain'),
            'xmpp_service_name' => $this->input->post('xmpp_service_name'),
            'xmpp_port' => $this->input->post('xmpp_port'),
            'send_image_interval' =>  $this->input->post('send_image_interval'),
            'send_image_quality' =>  $this->input->post('send_image_quality'),
        );

        $this->db->where('id', $spt_config->id);
        $this->db->update('spt_configs', $data);

        $data = array(
            'call1' => $this->input->post('call1'),
            'call2' => $this->input->post('call2'),
            'call3' => $this->input->post('call3'),
            //'geomode' => $this->input->post('geomode'),
            'geointerval' => $this->input->post('geointerval'),
            'geodistance' => $this->input->post('geodistance'),
            'callbacktimer' => $this->input->post('callbacktimer'),
            'newvoicemail' => $this->input->post('newvoicemail'),
            'novoicemail' => $this->input->post('novoicemail'),
            'mic' => $this->input->post('mic'),
            'speaker' => $this->input->post('speaker'),
            'gpsurl' => $this->input->post('gpsurl'),
            'appversion' => $this->input->post('appversion'),
            'apppath' => $this->input->post('apppath'),
            'kernelversion' => $this->input->post('kernelversion'),
            'kernelpath' => $this->input->post('kernelpath'),
        );

        $this->db->where('id', $ism_config->id);
        $this->db->update('ism_configs', $data);

        $this->db->trans_complete();
        if ($this->db->trans_status() === false) {
            return false;
        }
        return true;
    }
}
