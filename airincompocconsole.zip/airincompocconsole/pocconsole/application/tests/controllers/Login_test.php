<?php
class Login_test extends TestCase
{
	public function test_index()
	{
		$output = $this->request('GET', ['Login', 'index']);
		$this->assertContains('<title>PoCコンソール</title>', $output);
	}
}
