<?php
class Home_test extends TestCase
{
	public function test_index()
	{
		MonkeyPatch::patchMethod(
								 'Home',
								 ['getSessionData' =>
								  ['id' => 1,
								   'username' => 'システム管理者',
								   'tenant' => 1,
								   'usermode' => 'admin',
								   'token' => 'aaaaaaaa'
								   ]
								  ]);
		$output = $this->request('GET', ['Home', 'index']);
		$this->assertContains('システム管理者', $output);
	}
}
