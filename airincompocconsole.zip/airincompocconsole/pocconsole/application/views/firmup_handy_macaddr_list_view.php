<?php
$data['username'] = $username;
$data['usermode'] = $usermode;
$data['css'] = 'dummy.css';
$data['menu'] = 'firmup_handy';

// setup breadcrumb
$breadcrumb = array(
	'ホーム' => 	base_url('home'),
    'ファームアップ管理' => base_url('firmup_handy/view_list'),
    '端末リスト' => false,
);

$data['breadcrumb'] = $breadcrumb;

$this->load->view('templates/header', $data);
$this->load->view('templates/sidemenu', $data);

// global $global_web_account_type_names;

?>

<?php if (!USE_BREADCRUMB_IN_HEADER && isset($breadcrumb)): ?>
	<ol class="breadcrumb"> <!-- パンくず対応済み -->
<?php
		foreach ($breadcrumb as $_title => $_url) {
			if ($_url) { echo '<li><a href="'.$_url.'">'.$_title.'</a></li>'; }
			else { echo '<li class="active">'.$_title.'</li>'; }
		}
?>
	</ol>
<?php endif ?>

<h2 class="page-header"><?php echo $page_title ?></h2>

<?php
     if (!empty($firmup_macaddr)) {
         $sorticon = '<span class="glyphicon glyphicon-triangle-'
		     .($order == 'asc' ? 'top' : 'bottom').' poc-icon"></span>';

		 echo '機種数: '.count($firmup_macaddr);
         echo '<table class="table table-striped table-condensed table-hover poc-table">';
		 echo '<thead>';
		 echo '<tr>';

      if ($page_title == "登録端末一覧")  {
        $view_list = 'mac_view_list_1';
      } elseif ($page_title == "更新済み端末リスト") {
        $view_list = 'mac_view_list_2';
      } elseif ($page_title == "未更新端末一覧") {
        $view_list = 'mac_view_list_3';
      }

		 // IMEI
     $dir = ($sortkey == 'macaddr' && $order == 'asc') ? 'desc' : 'asc';
     $param = 'macaddr/'.$dir;
      echo '<th><a href="'.base_url('firmup_handy/'.$view_list.'/'.$id.'/'.$param).'">IMEI ';
      if ($sortkey == 'macaddr') {
        echo $sorticon;
      }
		 echo '</a></th>';

		 // 登録中バージョン
         $dir = ($sortkey == 'firm_version' && $order == 'asc') ? 'desc' : 'asc';
		 $param = 'firm_version/'.$dir;
         echo '<th><a href="'.base_url('firmup_handy/'.$view_list.'/'.$id.'/'.$param).'">登録中バージョン ';
		 if ($sortkey == 'firm_version') {
			 echo $sorticon;
		 }
		 echo '</a></th>';

		 // API接続日時
         $dir = ($sortkey == 'last_connect' && $order == 'asc') ? 'desc' : 'asc';
		 $param = 'last_connect/'.$dir;
         echo '<th><a href="'.base_url('firmup_handy/'.$view_list.'/'.$id.'/'.$param).'">API接続日時 ';
		 if ($sortkey == 'last_connect') {
			 echo $sorticon;
		 }
		 echo '</a></th>';

         

         // 削除
         /*
         $dir = ($sortkey == 'device_name' && $order == 'asc') ? 'desc' : 'asc';
		 $param = 'device_name/'.$dir;
         echo '<th><a href="'.base_url('firmup_handy/view_list/'.$param).'">種別 ';
		 if ($sortkey == 'device_name') {
			 echo $sorticon;
		 }
         echo '</a></th>';
         */
		 
		 
		 echo '</tr>';
		 echo '</thead>';
		 echo '<tbody>';

         foreach ($firmup_macaddr as $row) {
			 echo '<tr>';
			 echo '<td>'.$row['macaddr'].'</td>';
             echo '<td>'.$row['firm_version'].'</td>';	
             echo '<td>'.$row['last_connect'].'</td>';				 
             echo '</tr>';
         }
		 /*
         echo '</tbody></table>';
		 echo '<div class="text-right">';
		 echo '<a href="'.base_url('firmup_handy/export').'" class="btn btn-sm btn-default"><span class="glyphicon glyphicon-save"></span> CSVエクスポート</a>';
		 echo '</div>';
		 */
     }
     else {
         echo "登録された機種はありません。";
     }
?>

<!-- modal for deleting PoC Account -->
<!--
<div class="modal fade" id="modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">確認</h4>
      </div>
      <div class="modal-body">
        ファイルを削除しますか？
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <a href="<?php echo base_url('firumup_handy/delete/'.$row->id); ?>" class="btn btn-primary">削除</a>
      </div>
    </div>
  </div>
</div>
-->
<?php
$this->load->view('templates/footer', $data);
?>
