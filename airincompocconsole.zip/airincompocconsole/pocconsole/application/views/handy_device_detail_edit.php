<?php
$data['username'] = $username;
$data['usermode'] = $usermode;
$data['css'] = 'dummy.css';
if ($config_type == 'device_admin'):
	$data['menu'] = 'devicesetting';
elseif ($config_type == 'device_tenant'):
	$data['menu'] = 'devicesetting';
else:
	$data['menu'] = 'pocaccount';
endif;

// setup breadcrumb
if ($config_type == 'device_admin'){
  $breadcrumb = array(
    'ホーム' => 	base_url('home'),
    'デバイス設定' => base_url('devicesetting/view'),
    'アカウントマスターデータ' => false,
  );
}elseif ($config_type == 'device_tenant'){
  $breadcrumb = array(
    'ホーム' => 	base_url('home'),
    'デバイス設定' => base_url('devicesetting/view'),
    'アカウント基本データ' => false,
  );
}else{
  $breadcrumb = array(
    'ホーム' => 	base_url('home'),
    'デバイス設定' => base_url('pocaccount/view_list/'.$tenant->company_id),
    'アカウント詳細' => base_url('pocaccount/view/'.$tenant->company_id.'/'.$account->poc_id),
    'アカウント個別設定' => false,
  );
}

$data['breadcrumb'] = $breadcrumb;

$this->load->view('templates/header', $data);
$this->load->view('templates/sidemenu', $data);

global $global_handy_off_on_names;
global $global_handy_battery_saver_names;
global $global_handy_clock_type_names;
global $global_handy_call_notice_names;
global $global_handy_mic_type_names;
global $global_handy_mic_gain_names;
global $global_handy_rx_agc_names;
global $global_handy_auto_keylock_timer_names;
global $global_handy_backlight_names;
global $global_handy_backlight_timer_names;
global $global_handy_auto_mic_gain;
global $global_handy_time_out_timer;
global $global_handy_ptt_call;
global $global_handy_direct_call;
global $global_handy_tx_block;
global $global_handy_callback_timer;
global $global_handy_audio_alc;
global $global_handy_audio_reduce;
global $global_handy_record_mode;
global $global_handy_message_block;
global $global_handy_speaker_beep_vol;
global $global_handy_bell_mode;
global $global_handy_voice_guide;
global $global_handy_voice_guide_vol;
global $global_handy_alarm_low_battery;
global $global_handy_shortcut_key;
global $global_handy_speaker_extnl_vol;
global $global_handy_speaker_vol_mode;
global $global_handy_earphone_sekkyaku_mode;
global $global_handy_sekkyaku_touch;
global $global_handy_sekkyaku_release_timer;
global $global_handy_emergency_vol;
global $global_handy_backlight_timer;
global $global_handy_audio_codec;
global $global_handy_vox;
global $global_handy_set_mode;
global $global_handy_power_off_timer;

?>

<?php if (!USE_BREADCRUMB_IN_HEADER && isset($breadcrumb)): ?>
	<ol class="breadcrumb"> <!-- パンくず対応済み -->
<?php
		foreach ($breadcrumb as $_title => $_url) {
			if ($_url) { echo '<li><a href="'.$_url.'">'.$_title.'</a></li>'; }
			else { echo '<li class="active">'.$_title.'</li>'; }
		}
?>
	</ol>
<?php endif ?>


<?php if ($config_type == 'device_admin'): ?>
  <h2 class="page-header">DJCP100　アカウントマスターデータ</h2>
  <div class="poc-message-box">
テナント作成時にテナントアカウントへコピーされるアカウント初期設定です。
  </div>
<?php elseif ($config_type == 'device_tenant'): ?>
  <h2 class="page-header">DJCP100　アカウント基本データ</h2>
  <h3>テナント: <?php echo $tenant->company_name; ?></h3>
  <div class="poc-message-box">
テナント向けにDJCP100端末の新規アカウント作成時にコピーされるアカウント初期設定です。
  </div>
<?php else: ?>
  <h2 class="page-header">DJCP100　アカウント個別設定</h2>
  <h3>テナント: <?php echo $tenant->company_name; ?></h3>
  <h3>アカウント: <?php echo $account->username; ?> （ <?php echo $account->display_name; ?> ）</h3>
  <div class="poc-message-box">
デバイスのアカウントごとの設定です。
  </div>
<?php endif; ?>

<?php
  if ($config_type == 'device_admin'):
    echo form_open('handy_device/edit/0');
  elseif ($config_type == 'device_tenant'):
    echo form_open('handy_device/edit/'.$tenant->company_id);
  else:
    echo form_open('pocaccount/handy_edit/'.$tenant->company_id.'/'.$account->poc_id);
  endif;
?>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">システム設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">
    <div class="row">
        <div class="col-md-4 poc-list-title">時刻表示設定</div>
        <div class="col-md-8">
          <select name="clock" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_clock_type_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->clock == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('clock'); ?>
    		</div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">Private Wi-Fi</div>
        <div class="col-md-8">
          <select name="pri_wifi" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_off_on_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->pri_wifi == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('pri_wifi'); ?>
        </div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">音声ガイダンス</div>
        <div class="col-md-8">
          <select name="voice_info" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_off_on_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->voice_info == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('voice_info'); ?>
        </div>
      </div>
    </div>
  </div>
</div>

<?php if ($config_type != "device") : ?>
<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">アカウント情報</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">

    <div class="row">
        <div class="col-md-4 poc-list-title">表示名</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="disp_name"
              name="disp_name" value="<?php echo set_value('disp_name', $hdy_config->disp_name); ?>"/>
          <span>文字列(128桁)</span>
          <?php echo form_error('disp_name'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">SIP番号</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="sip_id"
              name="sip_id" value="<?php echo set_value('sip_id', $hdy_config->sip_id); ?>"/>
          <span>文字列(128桁)</span>
          <?php echo form_error('sip_id'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">SIPパスワード</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="password" id="sip_password"
              name="sip_password" value="<?php echo set_value('sip_password', $hdy_config->sip_password); ?>"/>
          <span>文字列(128桁)</span>
          <?php echo form_error('sip_password'); ?>
        </div>
      </div>

    </div>
  </div>
</div>
<?php endif ?>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">受信通知設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">
      <div class="row">
        <div class="col-md-4 poc-list-title">LTE音声受信通知</div>
        <div class="col-md-8">
          <select name="speaker_lte_vib" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_call_notice_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->speaker_lte_vib == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('speaker_lte_vib'); ?>
        </div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">Wi-Fi音声受信通知</div>
        <div class="col-md-8">
          <select name="speaker_pri_wifi_vib" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_call_notice_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->speaker_pri_wifi_vib == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('speaker_pri_wifi_vib'); ?>
        </div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">LTEデータ受信通知</div>
        <div class="col-md-8">
          <select name="speaker_lte_data" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_call_notice_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->speaker_lte_data == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('speaker_lte_data'); ?>
        </div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">Wi-Fiデータ受信通知</div>
        <div class="col-md-8">
          <select name="speaker_pri_wifi_data" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_call_notice_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->speaker_pri_wifi_data == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('speaker_pri_wifi_data'); ?>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">マイク設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">
      <div class="row">
        <div class="col-md-4 poc-list-title">マイク種別</div>
        <div class="col-md-8">
          <select name="audio_mic_type" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_mic_type_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->audio_mic_type == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('audio_mic_type'); ?>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">送信設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">

      <div class="row">
        <div class="col-md-4 poc-list-title">内部マイク感度</div>
        <div class="col-md-8">
          <select name="audio_intnl_mic_gain" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_auto_mic_gain as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->audio_intnl_mic_gain == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('audio_intnl_mic_gain'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">外部マイク感度</div>
        <div class="col-md-8">
          <select name="audio_extnl_mic_gain" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_auto_mic_gain as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->audio_extnl_mic_gain == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('audio_extnl_mic_gain'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">緊急時マイク感度</div>
        <div class="col-md-8">
          <select name="audio_emergency_mic_gain" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_auto_mic_gain as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->audio_emergency_mic_gain == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('audio_emergency_mic_gain'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">PTTホールド</div>
        <div class="col-md-8">
          <select name="key_ptt_hold" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_off_on_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->key_ptt_hold == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('key_ptt_hold'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">コールバック</div>
        <div class="col-md-8">
          <select name="audio_earphone_callback" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_off_on_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->audio_earphone_callback == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('audio_earphone_callback'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">VOX動作設定</div>
        <div class="col-md-8">
          <select name="vox" style="width: 150px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_vox as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->vox == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('vox'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">VOX動作レベル</div>
        <div class="col-md-8">
          <input style="width: 100px; padding: 0 5px;" class="form-control input-sm" type="text" id="vox_thresh" 
            name="vox_thresh" value="<?php echo set_value('vox_thresh', $hdy_config->vox_thresh); ?>"/>
          <span>1～7（Step 1）　1=感度低/7=感度高</span>
          <?php echo form_error('vox_thresh'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">ノイズキャンセラー</div>
        <div class="col-md-8">
          <select name="audio_noise_can" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_off_on_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->audio_noise_can == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('audio_noise_can'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">エコーキャンセラー</div>
        <div class="col-md-8">
          <select name="audio_echo_can" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_off_on_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->audio_echo_can == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('audio_echo_can'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">連続送信制限時間</div>
        <div class="col-md-8">
          <select name="time_out_timer" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_time_out_timer as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->time_out_timer == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('time_out_timer'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">PTT通信相手選択</div>
        <div class="col-md-8">
          <select name="ptt_call" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_ptt_call as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->ptt_call == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('ptt_call'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">PTT通信グループ</div>
        <div class="col-md-8">
         <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="ptt_group"
              name="ptt_group" value="<?php echo set_value('ptt_group', $hdy_config->ptt_group); ?>"/>
          <span>グループSIP番号</span>
          <?php echo form_error('ptt_group'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">PTT通信会議室</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="ptt_conference"
              name="ptt_conference" value="<?php echo set_value('ptt_conference', $hdy_config->ptt_conference); ?>"/>
          <span>会議室SIP番号</span>
          <?php echo form_error('ptt_conference'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">PTT通信個別端末</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="ptt_individual"
              name="ptt_individual" value="<?php echo set_value('ptt_individual', $hdy_config->ptt_individual); ?>"/>
          <span>端末SIP番号</span>
          <?php echo form_error('ptt_individual'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">直通相手選択</div>
        <div class="col-md-8">
          <select name="direct_call" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_direct_call as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->direct_call == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('direct_call'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">直接通信グループ</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="direct_group"
              name="direct_group" value="<?php echo set_value('direct_group', $hdy_config->direct_group); ?>"/>
          <span>グループSIP番号</span>
          <?php echo form_error('direct_group'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">直接通信個別端末</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="direct_individual"
              name="direct_individual" value="<?php echo set_value('direct_individual', $hdy_config->direct_individual); ?>"/>
          <span>端末SIP番号</span>
          <?php echo form_error('direct_individual'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">送信禁止</div>
        <div class="col-md-8">
          <select name="tx_block" style="width: 150px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_tx_block as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->tx_block == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('tx_block'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">個別呼出切替</div>
        <div class="col-md-8">
          <select name="ind_callback_timer" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_callback_timer as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->ind_callback_timer == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('ind_callback_timer'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">グループ呼出切替</div>
        <div class="col-md-8">
          <select name="group_callback_timer" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_callback_timer as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->group_callback_timer == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('group_callback_timer'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">全員呼出切替</div>
        <div class="col-md-8">
          <select name="all_callback_timer" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_callback_timer as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->all_callback_timer == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('all_callback_timer'); ?>
        </div>
      </div>

    </div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">受信設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">

      <div class="row">
        <div class="col-md-4 poc-list-title">音量一定化</div>
        <div class="col-md-8">
          <select name="audio_alc" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_audio_alc as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->audio_alc == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('audio_alc'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">低音域抑制</div>
        <div class="col-md-8">
          <select name="audio_bass_reduce" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_audio_reduce as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->audio_bass_reduce == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('audio_bass_reduce'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">高音域抑制</div>
        <div class="col-md-8">
          <select name="audio_treble_reduce" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_audio_reduce as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->audio_treble_reduce == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('audio_treble_reduce'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">録音動作設定</div>
        <div class="col-md-8">
          <select name="record_mode" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_record_mode as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->record_mode == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('record_mode'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ受信禁止</div>
        <div class="col-md-8">
          <select name="message_block" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_message_block as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->message_block == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('message_block'); ?>
        </div>
      </div>

    </div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">通知/警告設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">

      <div class="row">
        <div class="col-md-4 poc-list-title">ビープ音量</div>
        <div class="col-md-8">
          <select name="speaker_beep_vol" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_speaker_beep_vol as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->speaker_beep_vol == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('speaker_beep_vol'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">ベル機能</div>
        <div class="col-md-8">
          <select name="alarm_bell" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_off_on_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->alarm_bell == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('alarm_bell'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">ベルの音色</div>
        <div class="col-md-8">
          <select name="bell_mode" style="width: 150px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_bell_mode as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->bell_mode == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('bell_mode'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">音声ガイド</div>
        <div class="col-md-8">
          <select name="voice_guide" style="width: 150px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_voice_guide as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->voice_guide == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('voice_guide'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">音声ガイド音量</div>
        <div class="col-md-8">
          <select name="voice_guide_vol" style="width: 150px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_voice_guide_vol as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->voice_guide_vol == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('voice_guide_vol'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">減電池警告</div>
        <div class="col-md-8">
          <select name="alarm_low_battery" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_alarm_low_battery as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->alarm_low_battery == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('alarm_low_battery'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">イヤホン断線検知</div>
        <div class="col-md-8">
          <select name="alarm_earphone_broken" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_off_on_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->alarm_earphone_broken == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('alarm_earphone_broken'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">接続通知</div>
        <div class="col-md-8">
          <select name="alarm_ind_call_ok" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_off_on_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->alarm_ind_call_ok == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('alarm_ind_call_ok'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">失敗通知</div>
        <div class="col-md-8">
          <select name="alarm_ind_call_ng" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_off_on_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->alarm_ind_call_ng == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('alarm_ind_call_ng'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">PTTビープ</div>
        <div class="col-md-8">
          <select name="audio_ptt_beep" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_off_on_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->audio_ptt_beep == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('audio_ptt_beep'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">エンドピー</div>
        <div class="col-md-8">
          <select name="audio_end_beep" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_off_on_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->audio_end_beep == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('audio_end_beep'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">通信圏外警告</div>
        <div class="col-md-8">
          <select name="alarm_connect" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_off_on_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->alarm_connect == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('alarm_connect'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">圏外時コールバック停止</div>
        <div class="col-md-8">
          <select name="alarm_stop_callback" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_off_on_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->alarm_stop_callback == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('alarm_stop_callback'); ?>
        </div>
      </div>

    </div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">各種動作設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">

      <div class="row">
        <div class="col-md-4 poc-list-title">短縮キー動作</div>
        <div class="col-md-8">
          <select name="shortcut_key" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_shortcut_key as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->shortcut_key == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('shortcut_key'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">外部音量設定</div>
        <div class="col-md-8">
          <select name="speaker_extnl_vol" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_speaker_extnl_vol as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->speaker_extnl_vol == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('speaker_extnl_vol'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">音量の調整方法</div>
        <div class="col-md-8">
          <select name="speaker_vol_mode" style="width: 150px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_speaker_vol_mode as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->speaker_vol_mode == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('speaker_vol_mode'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">固定音量レベル</div>
        <div class="col-md-8">
          <input style="width: 100px; padding: 0 5px;" class="form-control input-sm" type="text" id="speaker_fixed_vol" 
            name="speaker_fixed_vol" value="<?php echo set_value('speaker_fixed_vol', $hdy_config->speaker_fixed_vol); ?>"/>
          <span>0 ～ 32 (step 1)</span>
          <?php echo form_error('speaker_fixed_vol'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">最大音量レベル</div>
        <div class="col-md-8">
          <input style="width: 100px; padding: 0 5px;" class="form-control input-sm" type="text" id="speaker_max_vol" 
            name="speaker_max_vol" value="<?php echo set_value('speaker_max_vol', $hdy_config->speaker_max_vol); ?>"/>
          <span>0 ～ 32 (step 1)</span>
          <?php echo form_error('speaker_max_vol'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">最小音量レベル</div>
        <div class="col-md-8">
          <input style="width: 100px; padding: 0 5px;" class="form-control input-sm" type="text" id="speaker_min_vol" 
            name="speaker_min_vol" value="<?php echo set_value('speaker_min_vol', $hdy_config->speaker_min_vol); ?>"/>
          <span>0 ～ 32 (step 1)</span>
          <?php echo form_error('speaker_min_vol'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">接客モード</div>
        <div class="col-md-8">
          <select name="earphone_sekkyaku_mode" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_earphone_sekkyaku_mode as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->earphone_sekkyaku_mode == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('earphone_sekkyaku_mode'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">接客ボイス感度</div>
        <div class="col-md-8">
          <input style="width: 100px; padding: 0 5px;" class="form-control input-sm" type="text" id="sekkyaku_voice" 
            name="sekkyaku_voice" value="<?php echo set_value('sekkyaku_voice', $hdy_config->sekkyaku_voice); ?>"/>
          <span>1～7（Step 1）　1=感度低/7=感度高</span>
          <?php echo form_error('sekkyaku_voice'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">接客タッチ感度</div>
        <div class="col-md-8">
          <select name="sekkyaku_touch" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_sekkyaku_touch as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->sekkyaku_touch == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('sekkyaku_touch'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">接客復帰時間</div>
        <div class="col-md-8">
          <select name="sekkyaku_release_timer" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_sekkyaku_release_timer as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->sekkyaku_release_timer == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('sekkyaku_release_timer'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">接客ボイス保持</div>
        <div class="col-md-8">
          <input style="width: 100px; padding: 0 5px;" class="form-control input-sm" type="text" id="sekkyaku_voice_timer" 
            name="sekkyaku_voice_timer" value="<?php echo set_value('sekkyaku_voice_timer', $hdy_config->sekkyaku_voice_timer); ?>"/>
          <span>1～5（秒）</span>
          <?php echo form_error('sekkyaku_voice_timer'); ?>
        </div>
      </div>

    </div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">緊急動作設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">

      <div class="row">
        <div class="col-md-4 poc-list-title">緊急動作　受信禁止</div>
        <div class="col-md-8">
          <select name="emergency_receive" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_message_block as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->emergency_receive == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('emergency_receive'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">緊急動作　警報音のみ</div>
        <div class="col-md-8">
          <input style="width: 100px; padding: 0 5px;" class="form-control input-sm" type="text" id="emergency_alarm_duration" 
            name="emergency_alarm_duration" value="<?php echo set_value('emergency_alarm_duration', $hdy_config->emergency_alarm_duration); ?>"/>
          <span>0=OFF/1～60（秒）</span>
          <?php echo form_error('emergency_alarm_duration'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">緊急動作　警報音+発報</div>
        <div class="col-md-8">
          <input style="width: 100px; padding: 0 5px;" class="form-control input-sm" type="text" id="emergency_alarm_ptt_duration" 
            name="emergency_alarm_ptt_duration" value="<?php echo set_value('emergency_alarm_ptt_duration', $hdy_config->emergency_alarm_ptt_duration); ?>"/>
          <span>0=OFF/1～60（秒）</span>
          <?php echo form_error('emergency_alarm_ptt_duration'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">緊急動作　発報のみ</div>
        <div class="col-md-8">
          <input style="width: 100px; padding: 0 5px;" class="form-control input-sm" type="text" id="emergency_silent_ptt_duration" 
            name="emergency_silent_ptt_duration" value="<?php echo set_value('emergency_silent_ptt_duration', $hdy_config->emergency_silent_ptt_duration); ?>"/>
          <span>0=OFF/1～60（秒）</span>
          <?php echo form_error('emergency_silent_ptt_duration'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">緊急動作　音声送信</div>
        <div class="col-md-8">
          <input style="width: 100px; padding: 0 5px;" class="form-control input-sm" type="text" id="emergency_live_ptt_duration" 
            name="emergency_live_ptt_duration" value="<?php echo set_value('emergency_live_ptt_duration', $hdy_config->emergency_live_ptt_duration); ?>"/>
          <span>0=OFF/1～60（秒）</span>
          <?php echo form_error('emergency_live_ptt_duration'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">緊急動作　警報音量（内部）</div>
        <div class="col-md-8">
          <select name="emergency_intnl_vol" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_emergency_vol as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->emergency_intnl_vol == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('emergency_intnl_vol'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">緊急動作　警報音量（外部）</div>
        <div class="col-md-8">
          <select name="emergency_extnl_vol" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_emergency_vol as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->emergency_extnl_vol == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('emergency_extnl_vol'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">緊急速報機能</div>
        <div class="col-md-8">
          <select name="kinkyu_sokuho" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_off_on_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->kinkyu_sokuho == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('kinkyu_sokuho'); ?>
        </div>
      </div>

    </div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">端末システム設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">

      <div class="row">
        <div class="col-md-4 poc-list-title">バックライトタイマー</div>
        <div class="col-md-8">
          <select name="backlight_timer" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_backlight_timer as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->backlight_timer == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('backlight_timer'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">コントラスト</div>
        <div class="col-md-8">
        <input style="width: 100px; padding: 0 5px;" class="form-control input-sm" type="text" id="display_lcd_contrast" 
            name="display_lcd_contrast" value="<?php echo set_value('display_lcd_contrast', $hdy_config->display_lcd_contrast); ?>"/>
          <span>1～10</span>
          <?php echo form_error('display_lcd_contrast'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">バッテリーセーブ</div>
        <div class="col-md-8">
          <select name="battery_save" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_off_on_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->battery_save == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('battery_save'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">オートパワーオフ</div>
        <div class="col-md-8">
          <select name="power_off_timer" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_power_off_timer as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->power_off_timer == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('power_off_timer'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">音声コーデック設定</div>
        <div class="col-md-8">
          <select name="audio_codec" style="width: 150px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_audio_codec as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->audio_codec == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('audio_codec'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">セットモード切り替え</div>
        <div class="col-md-8">
          <select name="set_mode" style="width: 150px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_set_mode as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->set_mode == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('set_mode'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">リセット動作禁止</div>
        <div class="col-md-8">
          <select name="reset_disable" style="width: 150px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_message_block as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->reset_disable == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('reset_disable'); ?>
        </div>
      </div>

    </div>
  </div>
</div>

<div class="text-right poc-control-panel">
  <button type="submit" class="btn btn-primary">保存</button>
  <?php if ($config_type == 'device_admin'): ?>
    <a href="<?php echo base_url('handy_device/view/'); ?>" class="btn btn-default">キャンセル</a>
  <?php elseif ($config_type == 'device_tenant'): ?>
    <a href="<?php echo base_url('handy_device/view/'.$tenant->company_id); ?>" class="btn btn-default">キャンセル</a>
  <?php else: ?>
    <a href="<?php echo base_url('pocaccount/handy_view/'.$tenant->company_id.'/'.$account->poc_id); ?>" class="btn btn-default">キャンセル</a>
  <?php endif; ?>
</div>

<?php echo form_close(); ?>

<?php
$this->load->view('templates/footer', $data);
?>
