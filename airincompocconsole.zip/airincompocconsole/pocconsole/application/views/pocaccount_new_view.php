<ol class="breadcrumb">
  <li><a href="<?php echo base_url('home'); ?>">ホーム</a></li>
  <li><a href="<?php echo base_url('pocaccount/view_list/'.$tenant->company_id); ?>">アカウント一覧</a></li>
  <li class="active">新規アカウント追加</li>
</ol>

<h2 class="page-header">新規アカウント追加</h2>
<h3>テナント: <?php echo $tenant->company_name; ?></h3>
<?php echo form_open('pocaccount/add/'.$tenant->company_id); ?>

<table class="table table-bordered table-condensed poc-table">
  <thead>
    <tr>
      <th class="bg-primary" colspan="2">基本設定</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td class="poc-td-right">アカウント名</td>
      <td>
        <input class="form-control input-sm" type="text" name="username" value="<?php echo set_value('username'); ?>"/>
        <?php echo form_error('username'); ?>
      </td>
    </tr>
    <tr>
      <td class="poc-td-right">表示名</td>
      <td>
        <input class="form-control input-sm" type="text" name="display_name" value="<?php echo set_value('display_name'); ?>"/>
        <?php echo form_error('display_name'); ?>
      </td>
    </tr>
    <tr>
      <td class="poc-td-right">パスワード</td>
      <td>
        <input class="form-control input-sm" type="password" name="password"/>
        <?php echo form_error('password'); ?>
      </td>
    </tr>
    <tr>
      <td class="poc-td-right">パスワード(確認)</td>
      <td>
        <input class="form-control input-sm" type="password" name="confirm"/>
        <?php echo form_error('confirm'); ?>
      </td>
    </tr>
    <tr>
      <td class="poc-td-right">使用機種</td>
      <td>
        <select name="device_id" class="form-control input-sm">
         <?php
         foreach ($devices as $row) {
             echo '<option value="'.$row->device_id.'">'.$row->device_name.'</option>';
         }
         ?>
        </select>
        <?php echo form_error('device_id'); ?>
      </td>
    </tr>
    <tr>
      <td class="poc-td-right">SIP番号</td>
      <td>
        <input class="form-control input-sm" type="text" name="sip_number" value="<?php echo set_value('sip_number'); ?>"/>
        <?php echo form_error('sip_number'); ?>
      </td>
    </tr>
    <tr>
      <td class="poc-td-right">回線番号</td>
      <td>
        <input class="form-control input-sm" type="text" name="line_number" value="<?php echo set_value('line_number'); ?>"/>
        <?php echo form_error('line_number'); ?>
      </td>
    </tr>
    <tr>
      <td class="poc-td-right">IPアドレス</td>
      <td>
        <input class="form-control input-sm" type="text" name="ip_address" value="<?php echo set_value('ip_address'); ?>"/>
        <?php echo form_error('ip_address'); ?>
      </td>
    </tr>
    <tr>
      <td class="poc-td-right">状態</td>
      <td>
        <label calss="radio-inline">
          <input type="radio" name="status" value="1" <?php echo set_radio('status', '1'); ?> /> 有効
        </label>
        <label calss="radio-inline">
          <input type="radio" name="status" value="0"  <?php echo set_radio('status', '0'); ?> /> 無効
        </label>
        <?php echo form_error('status'); ?>
      </td>
    </tr>
  </tbody>
</table>

<table class="table table-bordered table-condensed poc-table">
  <thead>
    <tr>
      <th class="bg-primary" colspan="2">Air-InCom.設定</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td class="poc-td-right">GPSデータ送信間隔</td>
      <td>
        <input class="form-control input-sm" type="text" name="gps_interval" value="<?php echo set_value('gps_interval'); ?>"/>
        <?php echo form_error('gps_interval'); ?>
      </td>
    </tr>
    <tr>
      <td class="poc-td-right">Bluetooth間隔</td>
      <td>
        <input class="form-control input-sm" type="text" name="bluetooth_interval" value="<?php echo set_value('bluetooth_interval'); ?>"/>
        <?php echo form_error('bluetooth_interval'); ?>
      </td>
    </tr>
    <tr>
      <td class="poc-td-right">Bluetooth RSSI閾値</td>
      <td>
        <input class="form-control input-sm" type="text" name="bluetooth_rssi_threshold" value="<?php echo set_value('bluetooth_rssi_threshold'); ?>"/>
        <?php echo form_error('bluetooth_rssi_threshold'); ?>
      </td>
    </tr>
    <tr>
      <td class="poc-td-right">XMPPサーバーホスト名</td>
      <td>
        <input class="form-control input-sm" type="text" name="xmpp_server_domain" value="<?php echo set_value('xmpp_server_domain'); ?>"/>
        <?php echo form_error('xmpp_server_domain'); ?>
      </td>
    </tr>
    <tr>
      <td class="poc-td-right">XMPPサーバーポート名</td>
      <td>
        <input class="form-control input-sm" type="text" name="xmpp_port" value="<?php echo set_value('xmpp_port'); ?>"/>
        <?php echo form_error('xmpp_port'); ?>
      </td>
    </tr>
    <tr>
      <td class="poc-td-right">XMPPサービス名</td>
      <td>
        <input class="form-control input-sm" type="text" name="xmpp_service_name" value="<?php echo set_value('xmpp_service_name'); ?>"/>
        <?php echo form_error('xmpp_service_name'); ?>
      </td>
    </tr>
    <tr>
      <td class="poc-td-right">XMPPユーザー名</td>
      <td>
        <input class="form-control input-sm" type="text" name="xmpp_username" value="<?php echo set_value('xmpp_username'); ?>"/>
        <?php echo form_error('xmpp_username'); ?>
      </td>
    </tr>
    <tr>
      <td class="poc-td-right">XMPPパスワード</td>
      <td>
        <input class="form-control input-sm" type="text" name="xmpp_password" value="<?php echo set_value('xmpp_password'); ?>"/>
        <?php echo form_error('xmpp_password'); ?>
      </td>
    </tr>
    <tr>
      <td class="poc-td-right">画像送信間隔</td>
      <td>
        <input class="form-control input-sm" type="text" name="send_image_interval" value="<?php echo set_value('send_image_interval'); ?>"/>
        <?php echo form_error('send_image_interval'); ?>
      </td>
    </tr>
    <tr>
      <td class="poc-td-right">画像品質</td>
      <td>
        <input class="form-control input-sm" type="text" name="send_image_quality" value="<?php echo set_value('send_image_quality'); ?>"/>
        <?php echo form_error('send_image_quality'); ?>
      </td>
    </tr>
  </tbody>
</table>

<table class="table table-bordered table-condensed poc-table">
  <thead>
    <tr>
      <th class="bg-primary" colspan="2">ISM-101設定</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td class="poc-td-right">MODE1発信先番号</td>
      <td>
        <input class="form-control input-sm" type="text" name="call1" value="<?php echo set_value('call1'); ?>"/>
        <?php echo form_error('call1'); ?>
      </td>
    </tr>
    <tr>
      <td class="poc-td-right">MODE2発信先番号</td>
      <td>
        <input class="form-control input-sm" type="text" name="call2" value="<?php echo set_value('call2'); ?>"/>
        <?php echo form_error('call2'); ?>
      </td>
    </tr>
    <tr>
      <td class="poc-td-right">MODE3発信先番号</td>
      <td>
        <input class="form-control input-sm" type="text" name="call3" value="<?php echo set_value('call3'); ?>"/>
        <?php echo form_error('call3'); ?>
      </td>
    </tr>
    <tr>
      <td class="poc-td-right">GPS測位間隔時間</td>
      <td>
        <input class="form-control input-sm" type="text" name="geointerval" value="<?php echo set_value('geointerval'); ?>"/>
        <?php echo form_error('geointerval'); ?>
      </td>
    </tr>
    <tr>
      <td class="poc-td-right">GPS測位間隔距離</td>
      <td>
        <input class="form-control input-sm" type="text" name="geodistance" value="<?php echo set_value('geodistance'); ?>"/>
        <?php echo form_error('geodistance'); ?>
      </td>
    </tr>
    <tr>
      <td class="poc-td-right">コールバックタイマー</td>
      <td>
        <input class="form-control input-sm" type="text" name="callbacktimer" value="<?php echo set_value('callbacktimer'); ?>"/>
        <?php echo form_error('callbacktimer'); ?>
      </td>
    </tr>
    <tr>
      <td class="poc-td-right">不在伝言再生番号</td>
      <td>
        <input class="form-control input-sm" type="text" name="newvoicemail" value="<?php echo set_value('newvoicemail'); ?>"/>
        <?php echo form_error('newvoicemail'); ?>
      </td>
    </tr>
    <tr>
      <td class="poc-td-right">ラストコール再生番号</td>
      <td>
        <input class="form-control input-sm" type="text" name="novoicemail" value="<?php echo set_value('novoicemail'); ?>"/>
        <?php echo form_error('novoicemail'); ?>
      </td>
    </tr>
    <tr>
      <td class="poc-td-right">マイク音量</td>
      <td>
        <input class="form-control input-sm" type="text" name="mic" value="<?php echo set_value('mic'); ?>"/>
        <?php echo form_error('mic'); ?>
      </td>
    </tr>
    <tr>
      <td class="poc-td-right">スピーカー音量</td>
      <td>
        <input class="form-control input-sm" type="text" name="speaker" value="<?php echo set_value('speaker'); ?>"/>
        <?php echo form_error('speaker'); ?>
      </td>
    </tr>
    <tr>
      <td class="poc-td-right">GPSデータ送信先URL</td>
      <td>
        <input class="form-control input-sm" type="text" name="gpsurl" value="<?php echo set_value('gpsurl'); ?>"/>
        <?php echo form_error('gpsurl'); ?>
      </td>
    </tr>
    <tr>
      <td class="poc-td-right">アプリバージョン</td>
      <td>
        <input class="form-control input-sm" type="text" name="appversion" value="<?php echo set_value('appversion'); ?>"/>
        <?php echo form_error('appversion'); ?>
      </td>
    </tr>
    <tr>
      <td class="poc-td-right">アプリパス</td>
      <td>
        <input class="form-control input-sm" type="text" name="apppath" value="<?php echo set_value('apppath'); ?>"/>
        <?php echo form_error('apppath'); ?>
      </td>
    </tr>
    <tr>
      <td class="poc-td-right">カーネルバージョン</td>
      <td>
        <input class="form-control input-sm" type="text" name="kernelversion" value="<?php echo set_value('kernelversion'); ?>"/>
        <?php echo form_error('kernelversion'); ?>
      </td>
    </tr>
    <tr>
      <td class="poc-td-right">カーネルパス</td>
      <td>
        <input class="form-control input-sm" type="text" name="kernelpath" value="<?php echo set_value('kernelpath'); ?>"/>
        <?php echo form_error('kernelpath'); ?>
      </td>
    </tr>
  </tbody>
</table>

  <input type="hidden" name="company_id" value="<?php echo $tenant->company_id; ?>" />
  <div class="text-right">
    <button type="submit" class="btn btn-primary">追加</button>
    <a href="<?php echo base_url('pocaccount/view_list/'.$tenant->company_id); ?>" class="btn btn-default">キャンセル</a>
  </div>

</form>
