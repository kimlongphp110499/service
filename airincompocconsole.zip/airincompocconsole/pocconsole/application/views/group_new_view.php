<ol class="breadcrumb">
  <li><a href="<?php echo base_url('home'); ?>">ホーム</a></li>
  <li><a href="<?php echo base_url('group/view_list/'.$tenant->company_id); ?>">グループ一覧</a></li>
  <li class="active">新規グループ追加</li>
</ol>

<h2 class="page-header">新規グループ追加</h2>
<h3>テナント: <?php echo $tenant->company_name; ?></h3>
<?php echo form_open('group/add/'.$tenant->company_id); ?>

<table class="table table-bordered table-condensed poc-table">
  <tbody>
    <tr>
      <td class="poc-td-right">SIP番号</td>
      <td>
        <input class="form-control input-sm" type="text" name="sip_number" value="<?php echo set_value('sip_number'); ?>"/>
        <?php echo form_error('sip_number'); ?>
      </td>
    </tr>
    <tr>
      <td class="poc-td-right">グループ名</td>
      <td>
        <input class="form-control input-sm" type="text" name="group_name" value="<?php echo set_value('group_name'); ?>"/>
        <?php echo form_error('group_name'); ?>
      </td>
    </tr>
    <tr>
      <td class="poc-td-right">状態</td>
      <td>
        <label calss="radio-inline">
          <input type="radio" name="status" value="1" <?php echo set_radio('status', '1'); ?> /> 有効
        </label>
        <label calss="radio-inline">
          <input type="radio" name="status" value="0"  <?php echo set_radio('status', '0'); ?> /> 無効
        </label>
        <?php echo form_error('status'); ?>
      </td>
    </tr>
  </tbody>
</table>
  <input type="hidden" name="company_id" value="<?php echo $tenant->company_id; ?>" />
  <div class="text-right">
    <button type="submit" class="btn btn-primary">追加</button>
    <a href="<?php echo base_url('group/view_list/'.$tenant->company_id); ?>" class="btn btn-default">キャンセル</a>
  </div>

</form>