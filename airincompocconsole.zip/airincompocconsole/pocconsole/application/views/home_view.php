<?php
$data['username'] = $username;
$data['usermode'] = $usermode;
$data['css'] = 'dummy.css';
$data['menu'] = 'home';

// setup breadcrumb
$breadcrumb = array(
	'ホーム' => 	false,
);

$data['breadcrumb'] = $breadcrumb;

$this->load->view('templates/header', $data);
$this->load->view('templates/sidemenu', $data);
?>

<?php if (!USE_BREADCRUMB_IN_HEADER && isset($breadcrumb)): ?>
	<ol class="breadcrumb"> <!-- パンくず対応済み -->
<?php
		foreach ($breadcrumb as $_title => $_url) {
			if ($_url) { echo '<li><a href="'.$_url.'">'.$_title.'</a></li>'; }
			else { echo '<li class="active">'.$_title.'</li>'; }
		}
?>
	</ol>
<?php endif ?>

<?php if ($usermode != 'admin') : ?>
<div class="panel panel-info">
  <div class="panel-heading">
    <h2 class="panel-title">お知らせ</h2>
  </div>
  <div class="panel-body">
    <ul style="list-style-type: square; color:#d9edf7">
      <li><a href="#">メンテナンスのお知らせ</a></li>
    </ul>
  </div>
</div>
<?php endif ?>

<div class="panel panel-info">
<div class="panel-heading">
<h2 class="panel-title">PoCクラウド使用状況</h2>
</div>
<?php if ($usermode == 'admin') : ?>
<div class="panel-body"></div>
<table class="table table-striped table-hover table-condensed">
  <thead>
    <!--1/11・右寄せに修正-->
    <tr>
      <th rowspan="2" style="width:30%">テナント名</th>
      <th colspan="2" style="width:25%">本日</th>
      <th colspan="2" style="width:25%">直近7日間</th>
      <th rowspan="2" colspan="2" style="width:20%; text-align:right">総ストレージ使用量</th>
    </tr>
    <tr>
      <th style="width:12.5%; text-align:right">通話数</th>
	  <th style="width:12.5%; text-align:right">ストレージ(KB)</th>
      <th style="width:12.5%; text-align:right">通話数</th>
	  <th style="width:12.5%; text-align:right">ストレージ(KB)</th>
    </tr>
  </thead>
  <tbody>
<?php
	$total_today = 0;
	$total_week = 0;
	$size_today = 0;
	$size_week = 0;
	$size_total = 0;
    foreach ($call_list as $row) {
		echo '<tr>';
		echo '<td>'.$row['company_name'].'</td>';
		echo '<td style="text-align:right">'.number_format($row['call_today_num']).'</td>';
		echo '<td style="text-align:right">'.number_format($row['file_today_size'] / 1024).'</td>';
		echo '<td style="text-align:right">'.number_format($row['call_weekly_num']).'</td>';
		echo '<td style="text-align:right">'.number_format($row['file_weekly_size'] / 1024).'</td>';
		echo '<td style="text-align:right">'.number_format($row['file_total_size'] / 1024).'</td>';
		echo '<td style="text-align:right">('.number_format($row['file_total_size'] / (1024 * 1024 * 1024), 2).'%)</td>';
		echo '</tr>';
		$total_today += $row['call_today_num'];
		$total_week += $row['call_weekly_num'];
		$size_today += $row['file_today_size'] / 1024;
		$size_week += $row['file_weekly_size'] / 1024;
		$size_total += $row['file_total_size'] / 1024;
	}
?>
  </tbody>
  <tfoot>
    <tr>
      <td>合計</td>
      <td style="text-align:right"><?php echo number_format($total_today); ?></td>
      <td style="text-align:right"><?php echo number_format($size_today); ?></td>
	  <td style="text-align:right"><?php echo number_format($total_week); ?></td>
	  <td style="text-align:right"><?php echo number_format($size_week); ?></td>
	  <td style="text-align:right"><?php echo number_format($size_total); ?></td>
	  <td></td>
	</tr>
  </tfoot>
</table>
<?php else : ?>
<div class="panel-body">
  総ストレージ使用量:
  <?php echo number_format($call_list[0]['file_total_size'] / 1024); ?>KB
  (<?php echo number_format($call_list[0]['file_total_size'] / (1024 * 1024 * 1024), 2); ?>%使用)
</div>
<table class="table table-striped table-hover table-condensed">
  <thead>
    <tr>
      <th>期間</th>
      <th style="text-align:right">通話数</th>
	  <th style="text-align:right">ストレージ(KB)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>本日</td>
      <td style="text-align:right"><?php echo number_format($call_list[0]['call_today_num']); ?></td>
      <td style="text-align:right"><?php echo number_format($call_list[0]['file_today_size'] / 1024); ?></td>
	</tr>
    <tr>
      <td>7日間</td>
      <td style="text-align:right"><?php echo number_format($call_list[0]['call_weekly_num']); ?></td>
      <td style="text-align:right"><?php echo number_format($call_list[0]['file_weekly_size'] / 1024); ?></td>
	</tr>
  </tbody>
</table>
<?php endif ?>
</div>

<!--
<?php if ($usermode == 'admin') : ?>
<div class="panel panel-info">
<div class="panel-heading">
<h2 class="panel-title">アラート一覧</h2>
</div>
<div class="panel-body">
<p>
未対処のアラートがxx件あります。
</p>
<table class="table table-striped table-hover table-condensed">
  <thead>
    <tr>
      <th>発生日時</th>
      <th>テナント名</th>
      <th>アラート識別</th>
      <th>対処</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>YYYY-MM-DD HH:MM:SS</td>
      <td>○○○○○○</td>
      <td>長期無通話</td>
      <td class="text-center"><buttton class="btn btn-warning btn-sm">対処実行</button></td>
    </tr>
    <tr>
      <td>YYYY-MM-DD HH:MM:SS</td>
      <td>○○○○○○</td>
      <td>長期無通話</td>
      <td class="text-center"><buttton class="btn btn-warning btn-sm">対処実行</button></td>
    </tr>
    <tr>
      <td>YYYY-MM-DD HH:MM:SS</td>
      <td>○○○○○○</td>
      <td>長期無通話</td>
      <td class="text-center"><buttton class="btn btn-warning btn-sm">対処実行</button></td>
    </tr>
  </tobdy>
</table>
</div>
</div>

<div class="panel panel-info">
<div class="panel-heading">
<h2 class="panel-title">問い合わせ一覧</h2>
</div>
<div class="panel-body">
<p>
未回答の問い合わせがxx件あります。
</p>
<table class="table table-striped table-hover table-condensed">
  <thead>
    <tr>
      <th>登録日時</th>
      <th>テナント名</th>
      <th>タイトル</th>
      <th>対処</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>YYYY-MM-DD HH:MM:SS</td>
      <td>○○○○○○</td>
      <td>発信できない</td>
      <td class="text-center"><buttton class="btn btn-warning btn-sm">回答</button></td>
    </tr>
    <tr>
      <td>YYYY-MM-DD HH:MM:SS</td>
      <td>○○○○○○</td>
      <td>着信できない</td>
      <td class="text-center"><buttton class="btn btn-warning btn-sm">回答</button></td>
    </tr>
    <tr>
      <td>YYYY-MM-DD HH:MM:SS</td>
      <td>○○○○○○</td>
      <td>最大グループ数について</td>
      <td class="text-center"><buttton class="btn btn-warning btn-sm">回答</button></td>
    </tr>
  </tobdy>
</table>
</div>
</div>
<?php endif ?>
-->

<?php
$this->load->view('templates/footer', $data);
?>