<?php
// setup breadcrumb
$breadcrumb = array(
  'ホーム' => 	base_url('home'),
  'ログ一覧' => false,
);

$data['breadcrumb'] = $breadcrumb;
?>

<?php if (!USE_BREADCRUMB_IN_HEADER && isset($breadcrumb)): ?>
	<ol class="breadcrumb"> <!-- パンくず対応済み -->
<?php
		foreach ($breadcrumb as $_title => $_url) {
			if ($_url) { echo '<li><a href="'.$_url.'">'.$_title.'</a></li>'; }
			else { echo '<li class="active">'.$_title.'</li>'; }
		}
?>
	</ol>
<?php endif ?>

<h2 class="page-header">ログ一覧</h2>

<!-- Nav tabs -->
<ul class="nav nav-pills" role="tablist">
  <li role="presentation" class="active"><a href="#call" role="tab" data-toggle="tab">端末通話ログ</a></li>
  <li role="presentation"><a href="#operation" role="tab" data-toggle="tab">操作ログ</a></li>
  <li role="presentation"><a href="#access" role="tab" data-toggle="tab">アクセスログ</a></li>
</ul>

<!-- Tab panes -->
<div class="tab-content">
         
  <!-- Call tab -->
  <div role="tabpanel" class="tab-pane active" id="call">
    <br/>

      <div class="panel panel-info">
        <div class="panel-heading">
          <h4 class="panel-title">本日の総通話数</h4>
        </div>
        <div class="panel-body">
          <table class="table table-sriped table-condensed">
            <thead>
              <tr>
                <th>テナント名</th>
                <th>通話数</th>
              </tr>
            </thead>
            <tbody>
<?php
	$total = 0;
    foreach ($call_list as $row) {
	 echo '<tr>';
	 echo '<td>'.$row['company_name'].'</td>';
	 echo '<td>'.number_format($row['call_today_num']).'</td>';
	 echo '</tr>';
	 $total += $row['call_today_num'];
    }
?>
            </tbody>
            <tfoot>
              <tr>
                <td>合計</td>
			    <td><?php echo number_format($total); ?></td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    
      <div class="panel panel-info">
        <div class="panel-heading">
          <h4 class="panel-title">直近7日間の総通話数</h4>
        </div>
        <div class="panel-body">
          <table class="table table-sriped table-condensed">
            <thead>
              <tr>
                <th>テナント名</th>
                <th>通話数</th>
              </tr>
            </thead>
            <tbody>
<?php
	$total = 0;
    foreach ($call_list as $row) {
	 echo '<tr>';
	 echo '<td>'.$row['company_name'].'</td>';
	 echo '<td>'.number_format($row['call_weekly_num']).'</td>';
	 echo '</tr>';
	 $total += $row['call_weekly_num'];
    }
?>
            </tbody>
            <tfoot>
              <tr>
                <td>合計</td>
			    <td><?php echo number_format($total); ?></td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    
    <table class="table table-striped table-condensed table-hover">
      <thead>
        <tr>
          <th>発信番号</th>
          <th>着信番号</th>
          <th>開始日時</th>
          <th>通話時間</th>
          <th>操作</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
        </tr>
        <tr>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
        </tr>
        <tr>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
        </tr>
      </tbody>
    </table>
  </div>

  <!-- Operation tab -->
  <div role="tabpanel" class="tab-pane" id="operation">
    <br/>
    <table class="table table-striped table-condensed table-hover">
      <thead>
        <tr>
          <th>時間</th>
          <th>操作</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>2015-12-10 10:00:00</td>
          <td>xxxがユーザーアカウントxxxを追加</td>
        </tr>
        <tr>
          <td>2015-12-10 11:00:00</td>
          <td>xxxがユーザーアカウントxxxを編集</td>
        </tr>
        <tr>
          <td>...</td>
          <td>...</td>
        </tr>
      </tbody>
    </table>
  </div>
         
  <!-- Access tab -->
  <div role="tabpanel" class="tab-pane" id="access">
    <br/>
    <table class="table table-striped table-condensed table-hover">
      <thead>
        <tr>
          <th>テナント</th>
          <th>時間</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>...</td>
          <td>...</td>
        </tr>
        <tr>
          <td>...</td>
          <td>...</td>
        </tr>
        <tr>
          <td>...</td>
          <td>...</td>
        </tr>
      </tbody>
    </table>
  </div>
         
</div>