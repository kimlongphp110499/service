<?php
$data['username'] = $username;
$data['usermode'] = $usermode;
$data['css'] = 'dummy.css';
$data['menu'] = 'devicesetting';

// setup breadcrumb
$breadcrumb = array(
	'ホーム' => 	base_url('home'),
  'デバイス設定詳細' => false,
);

$data['breadcrumb'] = $breadcrumb;

$this->load->view('templates/header', $data);
$this->load->view('templates/sidemenu', $data);
?>

<?php if (!USE_BREADCRUMB_IN_HEADER && isset($breadcrumb)): ?>
	<ol class="breadcrumb"> <!-- パンくず対応済み -->
<?php
		foreach ($breadcrumb as $_title => $_url) {
			if ($_url) { echo '<li><a href="'.$_url.'">'.$_title.'</a></li>'; }
			else { echo '<li class="active">'.$_title.'</li>'; }
		}
?>
	</ol>
<?php endif ?>

<h2 class="page-header">デバイス設定</h2>

<?php if ($usermode == 'admin'): ?>
<h3>テナント: <?php echo $tenant->company_name; ?></h3>
<?php endif ?>

<div class="poc-message-box">
全デバイスで共通する設定項目です。
</div>

<div class="panel panel-info">
	<div class="panel-heading">
		<h3 class="panel-title">DJCP100設定</h3>
	</div>
	<div class="panel-body poc-panel-body">
		<div class="container-fluid poc-list">
			<a href="<?php echo base_url('handy_device/view/'.$tenant->company_id); ?>" class="btn btn-default">アカウント基本データ</a>
			<a href="<?php echo base_url('handy_tenant/view/'.$tenant->company_id); ?>" class="btn btn-default">テナントデータ</a>
		</div>
      <p />
	  <p>デバイス個別の設定は「アカウント」から行います。</p>
	</div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">Air-InCom.設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">
      <div class="row">
        <div class="col-md-4 poc-list-title">GPSデータ送信間隔</div>
        <div class="col-md-8"><?php echo number_format($spt_config->gps_interval); ?>ミリ秒</div>
      </div>
      <!--<div class="row">
        <div class="col-md-4 poc-list-title">Bluetoothアドレス</div>
        <div class="col-md-8"><?php echo $spt_config->bluetooth_address; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">Bluetooth間隔</div>
        <div class="col-md-8"><?php echo number_format($spt_config->bluetooth_interval); ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">Bluetooth RSSI閾値</div>
        <div class="col-md-8"><?php echo number_format($spt_config->bluetooth_rssi_threshold); ?></div>
      </div>-->
<?php if ($usermode == 'admin') : ?>
      <div class="row">
        <div class="col-md-4 poc-list-title">XMPPサーバーホスト名</div>
        <div class="col-md-8"><?php echo $spt_config->xmpp_server_domain; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">XMPPサーバーポート名</div>
        <div class="col-md-8"><?php echo $spt_config->xmpp_port; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">XMPPサービス名</div>
        <div class="col-md-8"><?php echo $spt_config->xmpp_service_name; ?></div>
      </div>
<?php endif ?>
      <div class="row">
        <div class="col-md-4 poc-list-title">画像送信間隔</div>
        <div class="col-md-8"><?php echo number_format($spt_config->send_image_interval); ?>ミリ秒</div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">画像品質</div>
        <div class="col-md-8"><?php echo $spt_config->send_image_quality; ?></div>
      </div>
    </div>
  </div>
</div>

<!--
<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">ISM-101設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">
      <div class="row">
        <div class="col-md-4 poc-list-title">MODE1発信先番号</div>
        <div class="col-md-8"><?php echo ($ism_config->call1); ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">MODE2発信先番号</div>
        <div class="col-md-8"><?php echo ($ism_config->call2); ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">MODE3発信先番号</div>
        <div class="col-md-8"><?php echo ($ism_config->call3); ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">GPS測位モード</div>
        <div class="col-md-8">
          <?php
	switch ($ism_config->geomode) {
	case 1:
		echo 'Auto方式';
		break;
	case 2:
		echo 'Set-Assisted方式';
		break;
	case 3:
		echo 'Standalone方式';
		break;
	default:
		echo 'Set-Based方式';
		break;
	}
          ?>
        </div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">GPS測位間隔時間</div>
        <div class="col-md-8"><?php echo ($ism_config->geointerval); ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">GPS測位間隔距離</div>
        <div class="col-md-8"><?php echo ($ism_config->geodistance); ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">コールバックタイマー</div>
        <div class="col-md-8"><?php echo ($ism_config->callbacktimer); ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">不在伝言再生番号</div>
        <div class="col-md-8"><?php echo ($ism_config->newvoicemail); ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">ラストコール再生番号</div>
        <div class="col-md-8"><?php echo ($ism_config->novoicemail); ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">マイク音量</div>
        <div class="col-md-8"><?php echo ($ism_config->mic); ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">スピーカー音量</div>
        <div class="col-md-8"><?php echo ($ism_config->speaker); ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">GPSデータ送信先URL</div>
        <div class="col-md-8"><?php echo ($ism_config->gpsurl); ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">アプリバージョン</div>
        <div class="col-md-8"><?php echo ($ism_config->appversion); ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">アプリパス</div>
        <div class="col-md-8"><?php echo ($ism_config->apppath); ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">カーネルバージョン</div>
        <div class="col-md-8"><?php echo ($ism_config->kernelversion); ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">カーネルパス</div>
        <div class="col-md-8"><?php echo ($ism_config->kernelpath); ?></div>
      </div>
    </div>
  </div>
</div>
-->

<div class="text-right poc-control-panel">
  <a href="<?php echo base_url('devicesetting/edit/'.$tenant->company_id); ?>" class="btn btn-primary">編集</a>
<?php if ($usermode == 'admin') : ?>
  <a href="<?php echo base_url('devicesetting/view'); ?>" class="btn btn-default">戻る</a>
<?php endif ?>
</div>

<?php
$this->load->view('templates/footer', $data);
?>
