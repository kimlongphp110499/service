<?php
$data['username'] = $username;
$data['usermode'] = $usermode;
$data['css'] = 'dummy.css';
$data['menu'] = 'pocaccount';

// setup breadcrumb
$breadcrumb = array(
	'ホーム' => 	base_url('home'),
  'アカウント一覧' => base_url('pocaccount/view_list/'.$tenant->company_id),
  'アカウント詳細' => false,
);

$data['breadcrumb'] = $breadcrumb;

$this->load->view('templates/header', $data);
$this->load->view('templates/sidemenu', $data);
?>

<?php if (!USE_BREADCRUMB_IN_HEADER && isset($breadcrumb)): ?>
	<ol class="breadcrumb"> <!-- パンくず対応済み -->
<?php
		foreach ($breadcrumb as $_title => $_url) {
			if ($_url) { echo '<li><a href="'.$_url.'">'.$_title.'</a></li>'; }
			else { echo '<li class="active">'.$_title.'</li>'; }
		}
?>
	</ol>
<?php endif ?>

<h2 class="page-header">アカウント詳細：<?php echo $account->username; ?></h2>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">基本設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">
      <div class="row">
        <div class="col-md-4 poc-list-title">アカウント名</div>
        <div class="col-md-8"><?php echo $account->username; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">表示名</div>
        <div class="col-md-8"><?php echo $account->display_name; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">使用機種</div>
        <div class="col-md-8"><?php echo $account->device_name; ?></div>
      </div>
<!--1/12・SIPサーバードメイン・SIPサーバーポート番号を非表示に変更-->
<!--
<?php if ($usermode == 'admin') : ?>
      <div class="row">
        <div class="col-md-4 poc-list-title">SIPサーバードメイン</div>
        <div class="col-md-8"><?php echo $account->sip_server_domain; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">SIPサーバーポート番号</div>
        <div class="col-md-8"><?php echo $account->sip_port; ?></div>
      </div>
<?php endif ?>
-->
      <div class="row">
        <div class="col-md-4 poc-list-title">SIP番号</div>
        <div class="col-md-8"><?php echo $account->sip_number; ?></div>
      </div>
<?php if ($account->device_id == DEVICE_ISM) : ?>
      <div class="row">
        <div class="col-md-4 poc-list-title">MACアドレス</div>
        <div class="col-md-8">
<?php
		   echo !empty($account->mac_address) ? $account->mac_address : 'N/A';
?>
		</div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">アプリバージョン</div>
        <div class="col-md-8">
<?php
		   echo !empty($account->app_version) ? $account->app_version : 'N/A';
?>
		</div>
      </div>
<?php endif ?>
<?php if ($account->device_id == DEVICE_HDY) : ?>
      <div class="row">
        <div class="col-md-4 poc-list-title">IMEI</div>
        <div class="col-md-8"><?php echo $account->imei; ?></div>
      </div>
<?php endif ?>
      <div class="row">
        <div class="col-md-4 poc-list-title">音声通話暗号化(TLS+SRTP)</div>
        <div class="col-md-8">
	      <?php echo $account->use_srtp
                    ? '<span class="glyphicon glyphicon-ok poc-icon-ok"></span> 有効'
	                : '<span class="glyphicon glyphicon-remove poc-icon-ng"></span> 無効'; ?>
        </div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">状態</div>
        <div class="col-md-8">
	      <?php echo $account->status
                    ? '<span class="glyphicon glyphicon-ok poc-icon-ok"></span> 有効'
	                : '<span class="glyphicon glyphicon-remove poc-icon-ng"></span> 無効'; ?>
        </div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">登録日</div>
        <div class="col-md-8"><?php echo $account->register_date; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">更新日</div>
        <div class="col-md-8"><?php echo $account->update_date; ?></div>
      </div>
    </div>
  </div>
</div>

<?php if ($account->device_id == DEVICE_HDY) : ?>
<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">DJCP100設定</h3>
  </div>
	<div class="panel-body poc-panel-body">
		<div class="container-fluid poc-list">
			<a href="<?php echo base_url('pocaccount/handy_view/'.$tenant->company_id.'/'.$account->poc_id); ?>" class="btn btn-default">アカウント別設定</a>
		</div>
      <p />
	  <p>テナント共通の設定は「デバイス設定」メニューから行います。</p>
	</div>
</div>
<?php endif ?>

<?php if ($account->device_id == DEVICE_SPT) : ?>
<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">Air-InCom.設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">
      <div class="row">
        <div class="col-md-4 poc-list-title">GPSデータ送信間隔</div>
        <div class="col-md-8"><?php echo number_format($account->gps_interval); ?> ミリ秒</div>
      </div>
      <!--<div class="row">
        <div class="col-md-4 poc-list-title">Bluetooth間隔</div>
        <div class="col-md-8"><?php echo number_format($account->bluetooth_interval); ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">Bluetooth RSSI閾値</div>
        <div class="col-md-8"><?php echo $account->bluetooth_rssi_threshold; ?></div>
      </div>-->
<?php if ($usermode == 'admin') : ?>
      <div class="row">
        <div class="col-md-4 poc-list-title">XMPPサーバーホスト名</div>
        <div class="col-md-8"><?php echo $account->xmpp_server_domain; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">XMPPサーバーポート番号</div>
        <div class="col-md-8"><?php echo $account->xmpp_port; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">XMPPサービス名</div>
        <div class="col-md-8"><?php echo $account->xmpp_service_name; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">XMPPユーザー名</div>
        <div class="col-md-8"><?php echo $account->xmpp_username; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">XMPPパスワード</div>
        <div class="col-md-8"><?php echo $account->xmpp_password; ?></div>
      </div>
<?php endif ?>
      <div class="row">
        <div class="col-md-4 poc-list-title">画像送信間隔</div>
        <div class="col-md-8"><?php echo number_format($account->send_image_interval); ?> ミリ秒</div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">画像品質</div>
        <div class="col-md-8"><?php echo $account->send_image_quality; ?></div>
      </div>
    </div>
  </div>
</div>
<?php endif ?>

<?php if ($account->device_id == DEVICE_ISM) : ?>
<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">ISM-101設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">
      <div class="row">
        <div class="col-md-4 poc-list-title">MODE1発信先番号</div>
        <div class="col-md-8"><?php if (empty($calls[0])): echo "(設定なし)"; else: echo $calls[0]; endif ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">MODE2発信先番号</div>
        <div class="col-md-8"><?php if (empty($calls[1])): echo "(設定なし)"; else: echo $calls[1]; endif ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">MODE3発信先番号</div>
        <div class="col-md-8"><?php if (empty($calls[2])): echo "(設定なし)"; else: echo $calls[2]; endif ?></div>
      </div>
<!--
      <div class="row">
        <div class="col-md-4 poc-list-title">GPS測位モード</div>
        <div class="col-md-8">
        <?php
	switch ($account->geomode) {
	case 1:
		echo 'Auto方式';
		break;
	case 2:
		echo 'Set-Assisted方式';
		break;
	case 3:
		echo 'Standalone方式';
		break;
	default:
		echo 'Set-Based方式';
		break;
	}
        ?>
        </div>
      </div>
-->
      <div class="row">
        <div class="col-md-4 poc-list-title">GPS測位間隔時間</div>
        <div class="col-md-8"><?php echo $account->geointerval; ?> 秒</div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">GPS測位間隔距離</div>
        <div class="col-md-8"><?php echo $account->geodistance; ?> m</div>
      </div>
	  <!--
      <div class="row">
        <div class="col-md-4 poc-list-title">コールバックタイマー</div>
        <div class="col-md-8"><?php echo $account->callbacktimer; ?> 秒</div>
      </div>
      -->
      <div class="row">
        <div class="col-md-4 poc-list-title">不在伝言再生番号</div>
        <div class="col-md-8"><?php echo $account->newvoicemail; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">ラストコール再生番号</div>
        <div class="col-md-8"><?php echo $account->novoicemail; ?></div>
      </div>
	  <!--
      <div class="row">
        <div class="col-md-4 poc-list-title">マイク音量</div>
        <div class="col-md-8"><?php echo $account->mic; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">スピーカー音量</div>
        <div class="col-md-8"><?php echo $account->speaker; ?></div>
      </div>
      -->
      <div class="row">
        <div class="col-md-4 poc-list-title">GPSデータ送信先URL</div>
        <div class="col-md-8"><?php echo $account->gpsurl; ?></div>
      </div>
      <!--
      <div class="row">
        <div class="col-md-4 poc-list-title">ファーム更新</div>
        <div class="col-md-8"><?php echo ($account->fw_update ? 'する': 'しない'); ?></div>
      </div>
      --> 
      <div class="row">
        <div class="col-md-4 poc-list-title">アプリバージョン</div>
        <div class="col-md-8"><?php echo $account->appversion; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">アプリパス</div>
        <div class="col-md-8"><?php echo $account->apppath; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">カーネルバージョン</div>
        <div class="col-md-8"><?php echo $account->kernelversion; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">カーネルパス</div>
        <div class="col-md-8"><?php echo $account->kernelpath; ?></div>
      </div>
    </div>
  </div>
</div>
<?php endif ?>

  <div class="text-right poc-control-panel">
    <a href="<?php echo base_url('pocaccount/edit/'.$tenant->company_id.'/'.$account->poc_id); ?>" class="btn btn-primary">編集</a>
	<?php if ($usermode == 'admin') : ?>
    <button type="button" class="btn btn-default" data-toggle="modal" data-target="#modal">削除</button>
	<?php endif ?>
    <a href="<?php echo base_url('pocaccount/view_list/'.$tenant->company_id); ?>" class="btn btn-default">キャンセル</a>
  </div>

<!-- modal for deleting PoC Account -->
<div class="modal fade" id="modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">確認</h4>
      </div>
      <div class="modal-body">
        アカウントを削除しますか？
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <a href="<?php echo base_url('pocaccount/delete/'.$tenant->company_id.'/'.$account->poc_id); ?>" class="btn btn-primary">削除</a>
      </div>
    </div>
  </div>
</div>

<?php
$this->load->view('templates/footer', $data);
?>
     
