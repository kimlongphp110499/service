<?php
$data['username'] = $username;
$data['usermode'] = $usermode;
$data['css'] = 'dummy.css';
$data['menu'] = 'pocaccount';

// setup breadcrumb
$breadcrumb = array(
	'ホーム' => 	base_url('home'),
  'アカウント一覧' => base_url('pocaccount/view_list/'.$tenant->company_id),
  '新規アカウント一括追加' => false,
);

$data['breadcrumb'] = $breadcrumb;

$this->load->view('templates/header', $data);
$this->load->view('templates/sidemenu', $data);
?>

<?php if (!USE_BREADCRUMB_IN_HEADER && isset($breadcrumb)): ?>
	<ol class="breadcrumb"> <!-- パンくず対応済み -->
<?php
		foreach ($breadcrumb as $_title => $_url) {
			if ($_url) { echo '<li><a href="'.$_url.'">'.$_title.'</a></li>'; }
			else { echo '<li class="active">'.$_title.'</li>'; }
		}
?>
	</ol>
<?php endif ?>

<h2 class="page-header">新規アカウント一括追加</h2>
<h3>テナント: <?php echo $tenant->company_name; ?></h3>
<div class="bg-info">
	 <?php echo count($accounts); ?>件のアカウントを追加しました。
</div>

  <table class="table table-striped table-condensed poc-table">
    <thead>
      <tr>
        <th>No.</th>
        <th>アカウント名</th>
        <th>パスワード</th>
        <th>SIP番号</th>
        <th>SIPパスワード</th>
      </tr>
    </thead>
    <tbody>
	 <?php
	 $count = 1;
	 foreach ($accounts as $row) {
	 echo '<tr>';
	 echo '<td>'.$count.'</td>';
	 echo '<td>'.$row['username'].'</td>';
	 echo '<td>'.$row['password'].'</td>';
	 echo '<td>'.$row['sip_number'].'</td>';
	 echo '<td>'.$row['sip_password'].'</td>';
	 echo '</tr>';
	 $count++;
     }
	 ?>
    </tbody>
  </table>

  <div class="text-right">
    <a href="<?php echo base_url('pocaccount/download_csv/'.$tenant->company_id.'/'.$cacheid); ?>" class="btn btn-primary">CSVダウンロード</a>
    <!--<a href="<?php echo base_url('pocaccount/download_sipconf/'.$tenant->company_id.'/'.$cacheid); ?>" class="btn btn-primary">sip.confダウンロード</a>-->
    <a href="<?php echo base_url('pocaccount/view_list/'.$tenant->company_id); ?>" class="btn btn-default">OK</a>
  </div>

</form>

<?php
$this->load->view('templates/footer', $data);
?>
