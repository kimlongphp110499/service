<?php
$data['username'] = $username;
$data['usermode'] = $usermode;
$data['css'] = 'dashboard.css';
$data['menu'] = 'tenant';

// setup breadcrumb
$breadcrumb = array(
	'ホーム' => 	base_url('home'),
  'テナント一覧' => base_url('tenant/view_list'),
  '新規テナント追加' => false,
);

$data['breadcrumb'] = $breadcrumb;

$this->load->view('templates/header', $data);
$this->load->view('templates/sidemenu', $data);

// use global industry type names defined in config/my_constant.php
global $global_industry_names;

$company_industry_val=$this->input->post('company_industry');
$company_industry = !empty($company_industry_val)?$this->input->post('company_industry'):'';
$company_industry_etc_val=$this->input->post('company_industry_etc');
$company_industry_etc = !empty($company_industry_etc_val)?$this->input->post('company_industry_etc'):'';

// check if predefined industry type value exist or not
if (!empty($company_industry) && in_array($company_industry, $global_industry_names, TRUE)) {
	// clear optional industry name when it is predefined
	$company_industry_etc = '';
}

?>


<?php if (!USE_BREADCRUMB_IN_HEADER && isset($breadcrumb)): ?>
	<ol class="breadcrumb"> <!-- パンくず対応済み -->
<?php
		foreach ($breadcrumb as $_title => $_url) {
			if ($_url) { echo '<li><a href="'.$_url.'">'.$_title.'</a></li>'; }
			else { echo '<li class="active">'.$_title.'</li>'; }
		}
?>
	</ol>
<?php endif ?>

<h2 class="page-header">新規テナント追加</h2>
<?php echo form_open('tenant/add'); ?>

  <div class="poc-message-box">
    <span class="glyphicon glyphicon-asterisk poc-icon-required"></span>がついた項目は入力が必須です。
  </div>
  <div class="form-horizontal">

    <!-- <div class="form-group has-feedback">
      <label class="control-label col-md-3" for="company_code">お客様コード</label>
      <div class="col-md-9">
        <input class="form-control input-sm" type="text" id="company_code" name="company_code" value="<?php echo set_value('company_code'); ?>"/>
        <span class="glyphicon glyphicon-asterisk form-control-feedback poc-icon-required"></span>
	    <?php echo form_error('company_code'); ?>
      </div>
    </div> -->

    <div class="form-group has-feedback">
      <label class="control-label col-md-3" for="company_name">会社名</label>
      <div class="col-md-9">
        <input class="form-control input-sm" type="text" id="company_name" name="company_name" value="<?php echo set_value('company_name'); ?>"/>
        <span class="glyphicon glyphicon-asterisk form-control-feedback poc-icon-required"></span>
	    <?php echo form_error('company_name'); ?>
      </div>
    </div>

    <div class="form-group has-feedback">
      <label class="control-label col-md-3" for="company_kana">会社名カナ</label>
      <div class="col-md-9">
        <input class="form-control input-sm" type="text" name="company_kana" value="<?php echo set_value('company_kana'); ?>"/>
        <?php echo form_error('company_kana'); ?>
      </div>
    </div>

    <div class="form-group has-feedback">
      <label class="control-label col-md-3" for="sip_context_name">SIPコンテキスト名</label>
      <div class="col-md-9">
        <input class="form-control input-sm" type="text" id="sip_context_name" name="sip_context_name" value="<?php echo set_value('sip_context_name'); ?>"/>
        <span class="glyphicon glyphicon-asterisk form-control-feedback poc-icon-required"></span>
        <?php echo form_error('sip_context_name'); ?>
      </div>
    </div>

    <div class="form-group has-feedback">
      <label class="control-label col-md-3" for="contact_name">窓口担当者名</label>
      <div class="col-md-9">
        <input class="form-control input-sm" type="text" id="contact_name" name="contact_name" value="<?php echo set_value('contact_name'); ?>"/>
        <span class="glyphicon glyphicon-asterisk form-control-feedback poc-icon-required"></span>
        <?php echo form_error('contact_name'); ?>
      </div>
    </div>

    <div class="form-group has-feedback">
      <label class="control-label col-md-3" for="contact_kana">窓口担当者名カナ</label>
      <div class="col-md-9">
        <input class="form-control input-sm" type="text" id="contact_kana" name="contact_kana" value="<?php echo set_value('contact_kana'); ?>"/>
        <?php echo form_error('contact_kana'); ?>
      </div>
    </div>

    <div class="form-group has-feedback">
      <label class="control-label col-md-3" for="contact_department">所属部署</label>
      <div class="col-md-9">
        <input class="form-control input-sm" type="text" id="contact_department" name="contact_department" value="<?php echo set_value('contact_department'); ?>"/>
        <?php echo form_error('contact_department'); ?>
      </div>
    </div>

    <div class="form-group has-feedback">
      <label class="control-label col-md-3" for="contact_title">役職</label>
      <div class="col-md-9">
        <input class="form-control input-sm" type="text" id="contact_title" name="contact_title" value="<?php echo set_value('contact_title'); ?>"/>
        <?php echo form_error('contact_title'); ?>
      </div>
    </div>

    <div class="form-group has-feedback">
      <label class="control-label col-md-3" for="contact_zip">郵便番号</label>
      <div class="col-md-9">
        <input class="form-control input-sm" type="text" id="contact_zip" name="contact_zip" value="<?php echo set_value('contact_zip'); ?>"/>
        <?php echo form_error('contact_zip'); ?>
      </div>
    </div>

    <div class="form-group has-feedback">
      <label class="control-label col-md-3" for="contact_address">住所</label>
      <div class="col-md-9">
        <input class="form-control input-sm" type="text" id="contact_address" name="contact_address" value="<?php echo set_value('contact_address'); ?>"/>
        <?php echo form_error('contact_address'); ?>
      </div>
    </div>

    <div class="form-group has-feedback">
      <label class="control-label col-md-3" for="contact_tel">電話番号</label>
      <div class="col-md-9">
        <input class="form-control input-sm" type="text" id="contact_tel" name="contact_tel" value="<?php echo set_value('contact_tel'); ?>"/>
        <?php echo form_error('contact_tel'); ?>
      </div>
    </div>

    <div class="form-group has-feedback">
      <label class="control-label col-md-3" for="contact_email">担当者E-mail</label>
      <div class="col-md-9">
        <input class="form-control input-sm" type="text" id="contact_email" name="contact_email" value="<?php echo set_value('contact_email'); ?>"/>
        <span class="glyphicon glyphicon-asterisk form-control-feedback poc-icon-required"></span>
        <?php echo form_error('contact_email'); ?>
      </div>
    </div>

    <div class="form-group has-feedback">
      <label class="control-label col-md-3" for="sales_staff_name">営業担当者名</label>
      <div class="col-md-9">
        <input class="form-control input-sm" type="text" id="sales_staff_name" name="sales_staff_name" value="<?php echo set_value('sales_staff_name'); ?>"/>
        <?php echo form_error('sales_staff_name'); ?>
      </div>
    </div>

    <div class="form-group has-feedback">
      <label class="control-label col-md-3" for="sales_staff_tel">営業担当者TEL</label>
      <div class="col-md-9">
        <input class="form-control input-sm" type="text" id="sales_staff_tel" name="sales_staff_tel" value="<?php echo set_value('sales_staff_tel'); ?>"/>
        <?php echo form_error('sales_staff_tel'); ?>
      </div>
    </div>

    <div class="form-group has-feedback">
      <label class="control-label col-md-3" for="sales_staff_email">営業担当者E-mail</label>
      <div class="col-md-9">
        <input class="form-control input-sm" type="text" id="sales_staff_email" name="sales_staff_email" value="<?php echo set_value('sales_staff_email'); ?>"/>
        <?php echo form_error('sales_staff_email'); ?>
      </div>
    </div>

    <div class="form-group has-feedback">
      <label class="control-label col-md-3" for="company_industry">
        <!--<span class="glyphicon glyphicon-asterisk form-control-feedback poc-icon-required"></span>-->
	  利用者の業種</label>
      <div class="col-md-9">
		<select id="company_industry" name="company_industry" style="width: 250px; padding: 0 5px;" class="form-control input-sm">
			<?php foreach ($global_industry_names as $key => $value) { ?>
				<option value="<?php echo htmlentities($value) ?>" <?php if ($company_industry == $value) echo 'selected="selected"' ?> ><?php echo htmlentities($key).' *' ?></option>
			<?php } ?>
			<?php form_error('company_industry'); ?>
		</select>
		<p style="float: right;"> <span>「その他(自由入力)」の場合 業種名を入力</span>
			<input type="text" name="company_industry_etc" class="form-control input-sm" value="<?php echo htmlentities(set_value('company_industry_etc', $company_industry_etc))?>" maxlength="48" />
			<?php form_error('company_industry_etc'); ?>
		</p>
      </div>
    </div>

    <div class="form-group has-feedback">
      <label class="control-label col-md-3" for="agent_company">代理店名</label>
      <div class="col-md-9">
        <input class="form-control input-sm" type="text" id="agent_company" name="agent_company" value="<?php echo set_value('agent_company'); ?>"/>
        <?php echo form_error('agent_company'); ?>
      </div>
    </div>

    <div class="form-group has-feedback">
      <label class="control-label col-md-3" for="agent_name">代理店担当者名</label>
      <div class="col-md-9">
        <input class="form-control input-sm" type="text" id="agent_name" name="agent_name" value="<?php echo set_value('agent_name'); ?>"/>
        <?php echo form_error('agent_name'); ?>
      </div>
    </div>

    <div class="form-group has-feedback">
      <label class="control-label col-md-3" for="agent_tel">代理店担当者TEL</label>
      <div class="col-md-9">
        <input class="form-control input-sm" type="text" id="agent_tel" name="agent_tel" value="<?php echo set_value('agent_tel'); ?>"/>
        <?php echo form_error('agent_tel'); ?>
      </div>
    </div>

    <div class="form-group has-feedback">
      <label class="control-label col-md-3" for="agent_email">代理店担当者E-mail</label>
      <div class="col-md-9">
        <input class="form-control input-sm" type="text" id="agent_email" name="agent_email" value="<?php echo set_value('agent_email'); ?>"/>
        <?php echo form_error('agent_email'); ?>
      </div>
    </div>

  </div>

  <!-- 操作ボタン -->
  <div class="text-right poc-control-panel">
    <button type="submit" class="btn btn-primary">追加</button>
    <a href="<?php echo base_url('tenant/view_list'); ?>" class="btn btn-default">キャンセル</a>
  </div>
</form>

<?php
$this->load->view('templates/footer', $data);
?>
