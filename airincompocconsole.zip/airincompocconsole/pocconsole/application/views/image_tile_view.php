<?php
$data['username'] = $username;
$data['usermode'] = $usermode;
$data['css'] = 'dummy.css';
$data['menu'] = 'image';

// setup breadcrumb
$breadcrumb = array(
	'ホーム' => base_url('home'),
	'転送画像一覧' => false,
);

$data['breadcrumb'] = $breadcrumb;

$this->load->view('templates/header', $data);
$this->load->view('templates/sidemenu', $data);
?>

<?php if (!USE_BREADCRUMB_IN_HEADER && isset($breadcrumb)): ?>
	<ol class="breadcrumb"> <!-- パンくず対応済み -->
<?php
		foreach ($breadcrumb as $_title => $_url) {
			if ($_url) { echo '<li><a href="'.$_url.'">'.$_title.'</a></li>'; }
			else { echo '<li class="active">'.$_title.'</li>'; }
		}
?>
	</ol>
<?php endif ?>

<h2 class="page-header">転送画像一覧</h2>

<?php if (empty($accounts)) : ?>
<div class="poc-message-box">
SPTアカウントがありません。
</div>
<?php else : ?>
<table>
<tbody>
<?php for ($i = 0; $i < count($accounts); $i++): ?>

<?php if ($i % 8 == 0) : ?>
<tr>
<?php endif ?>

    <td id="img<?php echo $accounts[$i]['poc_id']; ?>">
      <div class="poc-image-box">
        <a href="<?php echo base_url('image/detail/'.$tenant->company_id.'/'.$accounts[$i]['poc_id']); ?>">
          <img class="poc-image" src="<?php echo $accounts[$i]['image_path']; ?> " />
          <span class="date"><?php echo $accounts[$i]['date']; ?><br>
          <?php echo $accounts[$i]['time']; ?></span>
		</a>
		<a href="<?php echo base_url('image/detail/'.$tenant->company_id.'/'.$accounts[$i]['poc_id']); ?>">
          <div class="user"><?php echo $accounts[$i]['display_name']; ?></div>
		</a>
      </div>
    </td>
	 
<?php if ($i % 8 == 7) : ?>
</tr>
<?php endif ?>

<?php endfor ?>
</tbody>
</table>

<script>
$(function() {
	setInterval(function () {
		$.getJSON("<?php echo base_url('image/reload_image/'.$tenant->company_id); ?>", function (data) {
			if (data != null && data.length > 0) {
				for (var $i = 0 ; $i < data.length ; $i++){
					if (data[$i]["image_path"] != null) {
						$('#img' + data[$i]["poc_id"] + " img.poc-image").attr("src",data[$i]["image_path"]); //画像更新
						$('#img' + data[$i]["poc_id"] + " span.date").text(data[$i]["date"] + "\n" + data[$i]["time"]);
					}
				}
			}
		});
	}, 5000);
});
</script>
<?php endif ?>

<?php
$this->load->view('templates/footer', $data);
?>

