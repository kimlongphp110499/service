<?php
$data['username'] = $username;
$data['usermode'] = $usermode;
$data['css'] = 'dummy.css';
$data['menu'] = 'firmup_handy';

// setup breadcrumb
$breadcrumb = array(
    'ホーム' => 	base_url('home'),
    'ファームアップ管理' => base_url('firmup_handy/view_list'),
    'ファームアップファイル編集' => false,
);

$data['breadcrumb'] = $breadcrumb;

$this->load->view('templates/header', $data);
$this->load->view('templates/sidemenu', $data);

global $global_web_account_type_names;

?>

<?php if (!USE_BREADCRUMB_IN_HEADER && isset($breadcrumb)): ?>
	<ol class="breadcrumb"> <!-- パンくず対応済み -->
<?php
		foreach ($breadcrumb as $_title => $_url) {
			if ($_url) { echo '<li><a href="'.$_url.'">'.$_title.'</a></li>'; }
			else { echo '<li class="active">'.$_title.'</li>'; }
		} 
?>
	</ol>
<?php endif ?>

<h2 class="page-header">ファームアップファイル編集</h2>
<?php echo form_open_multipart('firmup_handy/edit/'.$firmup_file ->id); ?>
  <div class="form-horizontal">

    <div class="form-group">
      <label class="control-label col-md-3">テナント番号</label>
      <div class="col-md-9">
        <div class="form-control-static"><?php echo $firmup_file ->company_id; ?></div>
        <input type="hidden" name="company_id" value="<?php echo $firmup_file ->company_id; ?>"/>
      </div>
    </div>

    <div class="form-group">
      <label class="control-label col-md-3">テナント名</label>
      <div class="col-md-9">
        <div class="form-control-static"><?php echo $firmup_file ->company_name; ?></div>
        <input type="hidden" name="company_name" value="<?php echo $firmup_file ->company_name; ?>"/>
      </div>
    </div>

    <div class="form-group has-feedback">
      <label class="control-label col-md-3" for="firm_version"></label>
      <div class="col-md-9">
      <a href="<?php echo base_url('firmup_handy/macaddr_edit/'.$firmup_file ->id); ?>" class="btn btn-default">IMEI登録</a>
      </div>
    </div>

    <div class="form-group">
        <label for="firm_name" class="control-label col-md-3">ファームアップファイル選択</label>
        <div class="col-md-6">
        <div class="input-group">
            <input type="file" id="firm_name" name="firm_name" style="display: none"/>
            <a class="input-group-addon input-sm" onclick="$('#firm_name').click();"><i class="glyphicon glyphicon-folder-open"></i></a>
            <input id="cover" type="text" class="form-control input-sm" placeholder="ファイルを選択" disabled="disabled" />
        </div>
        <?php echo form_error('firm_name'); ?>
        
        </div>
        <script>
  $('#firm_name').change(function() {
      $('#cover').val($(this).val());
    });
        </script>
    </div>

    <div class="form-group has-feedback">
      <label class="control-label col-md-3" for="device_name">機種名</label>
      <div class="col-md-9">
        <input class="form-control input-sm" type="text" id="device_name" name="device_name" value="<?php echo set_value('device_name', $firmup_file->device_name); ?>"/>
	    <?php echo form_error('device_name'); ?>
      </div>
    </div>

    <div class="form-group has-feedback">
      <label class="control-label col-md-3" for="firm_version">バージョン名</label>
      <div class="col-md-9">
      <input class="form-control input-sm" type="text" id="firm_version" name="firm_version" value="<?php echo set_value('firm_version', $firmup_file->firm_version); ?>"/>
	    <?php echo form_error('firm_version'); ?>
      </div>
    </div>

    <div class="form-group has-feedback">
      <label class="control-label col-md-3">有効フラグ</label>
      <div class="col-md-9">
        <label calss="radio-inline">
          <input type="radio" name="flag" value="1" <?php echo set_radio('flag', '1', $firmup_file->flag == 1 ? TRUE : FALSE); ?> /> 有効
        </label>
        <label calss="radio-inline">
          <input type="radio" name="flag" value="0" <?php echo set_radio('flag', '0', $firmup_file->flag == 0 ? TRUE : FALSE); ?> /> 無効
        </label>
        <?php echo form_error('flag'); ?>
      </div>
    </div>

    <div class="form-group has-feedback">
      <label class="control-label col-md-3" for="firm_version">有効期限_FROM</label>
      <div class="col-md-9">
        <input class="form-control input-sm" type="datetime-local" id="validity_from" name="validity_from" style="width: 250px; padding: 0 5px;" value="<?php echo set_value('validity_from', $firmup_file->validity_from); ?>"/>
	    <?php echo form_error('validity_from'); ?>
      </div>
    </div>

    <div class="form-group has-feedback">
      <label class="control-label col-md-3" for="firm_version">有効期限_TO</label>
      <div class="col-md-9">
        <input class="form-control input-sm" type="datetime-local" id="validity_to" name="validity_to" style="width: 250px; padding: 0 5px;" value="<?php echo set_value('validity_to', $firmup_file->validity_to); ?>"/>
	    <?php echo form_error('validity_to'); ?>
      </div>
    </div>

  </div>

  <div class="text-right poc-control-panel">
    <button type="submit" class="btn btn-primary" value="upload">登録</button>
    <a href="<?php echo base_url('firmup_handy/view_list'); ?>" class="btn btn-default">キャンセル</a>
  </div>

</form>

<?php
$this->load->view('templates/footer', $data);
?>
