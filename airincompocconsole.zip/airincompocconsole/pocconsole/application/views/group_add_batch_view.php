<?php
$data['username'] = $username;
$data['usermode'] = $usermode;
$data['css'] = 'dummy.css';
$data['menu'] = 'group';

// setup breadcrumb
$breadcrumb = array(
	'ホーム' => 	base_url('home'),
  'グループ一覧' => base_url('group/view_list/'.$tenant->company_id),
  '新規グループ追加' => false,
);

$data['breadcrumb'] = $breadcrumb;

$this->load->view('templates/header', $data);
$this->load->view('templates/sidemenu', $data);
?>

<?php if (!USE_BREADCRUMB_IN_HEADER && isset($breadcrumb)): ?>
	<ol class="breadcrumb"> <!-- パンくず対応済み -->
<?php
		foreach ($breadcrumb as $_title => $_url) {
			if ($_url) { echo '<li><a href="'.$_url.'">'.$_title.'</a></li>'; }
			else { echo '<li class="active">'.$_title.'</li>'; }
		}
?>
	</ol>
<?php endif ?>

<h2 class="page-header">新規グループ追加</h2>
<h3>テナント: <?php echo $tenant->company_name; ?></h3>
<?php echo form_open('group/add_batch/'.$tenant->company_id); ?>

  <div class="poc-message-box">
    作成するグループ数を指定してください。
  </div>

  <div class="form-horizontal">
    <div class="form-group">
      <label class="control-label col-md-2" for="group_num">グループ数</label>
      <div class="col-md-4">
        <input class="form-control input-sm" type="text" id="group_num" name="group_num" value="<?php echo set_value('group_num', '0'); ?>"/>
        <?php echo form_error('group_num'); ?>
      </div>
    </div>
  </div>

  <input type="hidden" name="company_id" value="<?php echo $tenant->company_id; ?>" />
  <div class="text-right poc-control-panel">
    <button type="submit" class="btn btn-primary">追加</button>
    <a href="<?php echo base_url('group/view_list/'.$tenant->company_id); ?>" class="btn btn-default">キャンセル</a>
  </div>

</form>

<?php
$this->load->view('templates/footer', $data);
?>
