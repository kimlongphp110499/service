<?php
$data['username'] = $username;
$data['usermode'] = $usermode;
$data['css'] = 'dummy.css';
$data['menu'] = 'dialplan';

// setup breadcrumb
$breadcrumb = array(
	'ホーム' => 	base_url('home'),
	'緊急呼出' => false,
);

$data['breadcrumb'] = $breadcrumb;

$this->load->view('templates/header', $data);
$this->load->view('templates/sidemenu', $data);
?>

<?php if (!USE_BREADCRUMB_IN_HEADER && isset($breadcrumb)): ?>
	<ol class="breadcrumb"> <!-- パンくず対応済み -->
<?php
		foreach ($breadcrumb as $_title => $_url) {
			if ($_url) { echo '<li><a href="'.$_url.'">'.$_title.'</a></li>'; }
			else { echo '<li class="active">'.$_title.'</li>'; }
		}
?>
	</ol>
<?php endif ?>

<h2 class="page-header">緊急呼出</h2>


<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">テナント別緊急呼出一覧</h3>
  </div>
  <div class="panel-body">
    テナントを選択してください。
  </div>
     
    <table class="table table-striped table-condensed table-hover">
      <thead>
        <tr>
          <th>テナント名</th>
        </tr>
      </thead>
      <tbody>
<?php
     foreach ($tenants as $row) {
         echo '<tr>';
         echo '<td><a href="'.base_url('dialplan/view/'.$row->company_id).'">'.$row->company_name.'</a></td>';
         echo '</tr>';
     }
?>
      </tobdy>
    </table>

</div>

<?php
$this->load->view('templates/footer', $data);
?>
