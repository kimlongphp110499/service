<?php
$data['username'] = $username;
$data['usermode'] = $usermode;
$data['css'] = 'dummy.css';
$data['menu'] = 'tenant';

// setup breadcrumb
if ($usermode == 'admin'){
  $breadcrumb = array(
    'ホーム' => 	base_url('home'),
    'テナント一覧' => base_url('tenant/view_list'),
    'テナント詳細' => false,
  );
}else{
  $breadcrumb = array(
    'ホーム' => 	base_url('home'),
    '会社情報' => false,
  );
}

$data['breadcrumb'] = $breadcrumb;

$this->load->view('templates/header', $data);
$this->load->view('templates/sidemenu', $data);
?>

<?php if (!USE_BREADCRUMB_IN_HEADER && isset($breadcrumb)): ?>
	<ol class="breadcrumb"> <!-- パンくず対応済み -->
<?php
		foreach ($breadcrumb as $_title => $_url) {
			if ($_url) { echo '<li><a href="'.$_url.'">'.$_title.'</a></li>'; }
			else { echo '<li class="active">'.$_title.'</li>'; }
		}
?>
	</ol>
<?php endif ?>

<?php if ($usermode == 'admin') : ?>
<h2 class="page-header">テナント詳細：<?php echo $tenant->company_name; ?></h2>
<?php endif ?>

<div class="container-fluid poc-list">
  <div class="row">
    <div class="col-md-3 poc-list-title">お客様コード</div>
    <div class="col-md-9"><?php echo $tenant->company_code; ?></div>
  </div>
  <div class="row">
    <div class="col-md-3 poc-list-title">会社名</div>
    <div class="col-md-9"><?php echo $tenant->company_name; ?></div>
  </div>
  <div class="row">
    <div class="col-md-3 poc-list-title">会社名カナ</div>
    <div class="col-md-9"><?php echo $tenant->company_kana; ?></div>
  </div>
<?php if ($usermode == 'admin') : ?>
  <div class="row">
    <div class="col-md-3 poc-list-title">SIPコンテキスト名</div>
    <div class="col-md-9"><?php echo $tenant->sip_context_name; ?></div>
  </div>
<?php endif ?>
  <div class="row">
    <div class="col-md-3 poc-list-title">窓口担当者名</div>
    <div class="col-md-9"><?php echo $tenant->contact_name; ?></div>
  </div>
  <div class="row">
    <div class="col-md-3 poc-list-title">窓口担当者名カナ</div>
    <div class="col-md-9"><?php echo $tenant->contact_kana; ?></div>
  </div>
  <div class="row">
    <div class="col-md-3 poc-list-title">所属部署</div>
    <div class="col-md-9"><?php echo $tenant->contact_department; ?></div>
  </div>
  <div class="row">
    <div class="col-md-3 poc-list-title">役職</div>
    <div class="col-md-9"><?php echo $tenant->contact_title; ?></div>
  </div>
  <div class="row">
    <div class="col-md-3 poc-list-title">郵便番号</div>
    <div class="col-md-9"><?php echo $tenant->contact_zip; ?></div>
  </div>
  <div class="row">
    <div class="col-md-3 poc-list-title">住所</div>
    <div class="col-md-9"><?php echo $tenant->contact_address; ?></div>
  </div>
  <div class="row">
    <div class="col-md-3 poc-list-title">電話番号</div>
    <div class="col-md-9"><?php echo $tenant->contact_tel; ?></div>
  </div>
  <div class="row">
    <div class="col-md-3 poc-list-title">担当者E-mail</div>
    <div class="col-md-9">
	  <a href="mailto:<?php echo $tenant->contact_email; ?>"><?php echo $tenant->contact_email; ?></a>
    </div>
  </div>
  <div class="row">
    <div class="col-md-3 poc-list-title">営業担当者名</div>
    <div class="col-md-9"><?php echo $tenant->sales_staff_name; ?></div>
  </div>
  <div class="row">
    <div class="col-md-3 poc-list-title">営業担当者電話番号</div>
    <div class="col-md-9"><?php echo $tenant->sales_staff_tel; ?></div>
  </div>
  <div class="row">
    <div class="col-md-3 poc-list-title">営業担当者E-mail</div>
    <div class="col-md-9">
	  <a href="mailto:<?php echo $tenant->sales_staff_email; ?>"><?php echo $tenant->sales_staff_email; ?></a>
    </div>
  </div>
  <div class="row">
    <div class="col-md-3 poc-list-title">利用者の業種</div>
    <div class="col-md-9"><?php echo $tenant->company_industry; ?></div>
  </div>
  <div class="row">
    <div class="col-md-3 poc-list-title">代理店名</div>
    <div class="col-md-9"><?php echo $tenant->agent_company; ?></div>
  </div>
  <div class="row">
    <div class="col-md-3 poc-list-title">代理店担当者名</div>
    <div class="col-md-9"><?php echo $tenant->agent_name; ?></div>
  </div>
  <div class="row">
    <div class="col-md-3 poc-list-title">代理店担当者TEL</div>
    <div class="col-md-9"><?php echo $tenant->agent_tel; ?></div>
  </div>
  <div class="row">
    <div class="col-md-3 poc-list-title">代理店担当者E-mail</div>
    <div class="col-md-9">
	  <a href="mailto:<?php echo $tenant->agent_email; ?>"><?php echo $tenant->agent_email; ?></a>
	</div>
  </div>
  <div class="row">
    <div class="col-md-3 poc-list-title">登録日</div>
    <div class="col-md-9"><?php echo $tenant->register_date; ?></div>
  </div>
  <div class="row">
    <div class="col-md-3 poc-list-title">更新日</div>
    <div class="col-md-9"><?php echo $tenant->update_date; ?></div>
  </div>
</div>

  <div class="text-right poc-control-panel">
    <a href="<?php echo base_url('tenant/edit/'.$tenant->company_id); ?>" class="btn btn-primary">編集</a>
    <?php if ($usermode == 'admin'): ?>
    <button type="button" class="btn btn-default" data-toggle="modal" data-target="#modal">削除</button>
    <a href="<?php echo base_url('tenant/view_list'); ?>" class="btn btn-default">キャンセル</a>
    <?php endif ?>
  </div>
        
<!-- modal for deleting tenant -->
<div class="modal fade" id="modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">確認</h4>
      </div>
      <div class="modal-body">
        テナントを削除しますか？
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <a href="<?php echo base_url('tenant/delete/'.$tenant->company_id); ?>" class="btn btn-primary">削除</a>
      </div>
    </div>
  </div>
</div>

</p>

<?php
$this->load->view('templates/footer', $data);
?>
