<?php
$data['username'] = $username;
$data['usermode'] = $usermode;
$data['css'] = 'dummy.css';
$data['menu'] = 'devicesetting';

// setup breadcrumb
if ($config_type == 'tenant_admin'){
  $breadcrumb = array(
    'ホーム' => 	base_url('home'),
    'デバイス設定' => base_url('devicesetting/view'),
    'テナント専用コンフィグ設定のマスターデータ' => false,
  );
}else{
  $breadcrumb = array(
    'ホーム' => 	base_url('home'),
    'デバイス設定' => base_url('devicesetting/view'),
    'テナント専用コンフィグデータ設定' => false,
  );
}

$data['breadcrumb'] = $breadcrumb;

$this->load->view('templates/header', $data);
$this->load->view('templates/sidemenu', $data);

global $global_handy_off_on_names;
global $global_handy_battery_saver_names;
global $global_handy_clock_type_names;
global $global_handy_call_notice_names;
global $global_handy_mic_type_names;
global $global_handy_simcard_types;
global $global_handy_ping_interval;
global $global_handy_register_interval;
global $global_handy_pri_ap_mode;
global $global_handy_pri_wifi_nw_mode;
global $global_handy_gps_mode;
global $global_handy_history_timestamp;
global $global_handy_history_info_settings;
global $global_handy_history_custom_settings;
global $global_handy_auto_mic_gain;
global $global_handy_time_out_timer;
global $global_handy_ptt_call;
global $global_handy_direct_call;
global $global_handy_tx_block;
global $global_handy_callback_timer;
global $global_handy_audio_alc;
global $global_handy_audio_reduce;
global $global_handy_record_mode;
global $global_handy_message_block;
global $global_handy_speaker_beep_vol;
global $global_handy_bell_mode;
global $global_handy_voice_guide;
global $global_handy_voice_guide_vol;
global $global_handy_alarm_low_battery;
global $global_handy_shortcut_key;
global $global_handy_speaker_extnl_vol;
global $global_handy_speaker_vol_mode;
global $global_handy_earphone_sekkyaku_mode;
global $global_handy_sekkyaku_touch;
global $global_handy_sekkyaku_release_timer;
global $global_handy_emergency_vol;
global $global_handy_backlight_timer;
global $global_handy_audio_codec;
global $global_handy_vox;
global $global_handy_set_mode;
global $global_handy_power_off_timer;

?>

<?php if (!USE_BREADCRUMB_IN_HEADER && isset($breadcrumb)): ?>
	<ol class="breadcrumb"> <!-- パンくず対応済み -->
<?php
		foreach ($breadcrumb as $_title => $_url) {
			if ($_url) { echo '<li><a href="'.$_url.'">'.$_title.'</a></li>'; }
			else { echo '<li class="active">'.$_title.'</li>'; }
		}
?>
	</ol>
<?php endif ?>

<?php if ($config_type == 'tenant_admin'): ?>
	<h2 class="page-header">DJCP100　テナントマスターデータ</h2>
	<div class="poc-message-box">
テナント作成時にテナントアカウントへコピーされるテナント専用コンフィグデータの初期設定です。
	</div>
<?php else: ?>
	<h2 class="page-header">DJCP100　テナントデータ</h2>
	<h3>テナント: <?php echo $tenant->company_name; ?></h3>
	<div class="poc-message-box">
Power On時にダウンロードされるテナント専用コンフィグデータです。
	</div>
<?php endif ?>

<?php if ($config_type == 'tenant_admin'): ?>
	<?php echo form_open('handy_tenant/edit/0'); ?>
<?php else: ?>
	<?php echo form_open('handy_tenant/edit/'.$tenant->company_id); ?>
<?php endif ?>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">システム情報</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">

      <div class="row">
        <div class="col-md-4 poc-list-title">ファーム更新フラグ</div>
        <div class="col-md-8">
          <select name="FW_flag" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_off_on_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->FW_flag == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('FW_flag'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">アプリケーションバージョン</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="App_ver"
              name="App_ver" value="<?php echo set_value('App_ver', $hdy_config->App_ver); ?>" />
          <span>文字列(128桁)</span>
          <?php echo form_error('App_ver'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">アプリケーションパス（URL）</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="App_path"
              name="App_path" value="<?php echo set_value('App_path', $hdy_config->App_path); ?>"/>
          <span>文字列(256桁)</span>
          <?php echo form_error('App_path'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">カーネルバージョン</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="Kernel_ver"
              name="Kernel_ver" value="<?php echo set_value('Kernel_ver', $hdy_config->Kernel_ver); ?>"/>
          <span>文字列(128桁)</span>
          <?php echo form_error('Kernel_ver'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">カーネルパス（URL）</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="Kernel_path"
              name="Kernel_path" value="<?php echo set_value('Kernel_path', $hdy_config->Kernel_path); ?>"/>
          <span>文字列(256桁)</span>
          <?php echo form_error('Kernel_path'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">モジュールファーム更新フラグ</div>
        <div class="col-md-8">
          <select name="mod_flag" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_off_on_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->mod_flag == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('mod_flag'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">モジュールファームバージョン</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="mod_ver"
              name="mod_ver" value="<?php echo set_value('mod_ver', $hdy_config->mod_ver); ?>"/>
          <span>文字列(128桁)</span>
          <?php echo form_error('mod_ver'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">モジュールファームパス（URL）</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="mod_path"
              name="mod_path" value="<?php echo set_value('mod_path', $hdy_config->mod_path); ?>"/>
          <span>文字列(256桁)</span>
          <?php echo form_error('mod_path'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">SIMカード種別</div>
        <div class="col-md-8">
          <select name="sim" style="width: 150px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_simcard_types as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->sim == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('sim'); ?>
        </div>
      </div>

    </div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">システム設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">

      <div class="row">
        <div class="col-md-4 poc-list-title">暗号鍵情報</div>
        <div class="col-md-8">
          <select name="key_info" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_off_on_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->key_info == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('key_info'); ?>
        </div>
      </div>

    </div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">SIP設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">

      <div class="row">
        <div class="col-md-4 poc-list-title">LTE優先度</div>
        <div class="col-md-8">
          <input style="width: 100px; padding: 0 5px;" class="form-control input-sm" type="text" id="prefix_lte" 
            name="prefix_lte" value="<?php echo set_value('prefix_lte', $hdy_config->prefix_lte); ?>"/>
          <span>1～9（Step 1）　1=Highest Priority/9=Lowest Priority</span>
          <?php echo form_error('prefix_lte'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">RTPパケット破棄</div>
        <div class="col-md-8">
          <input style="width: 100px; padding: 0 5px;" class="form-control input-sm" type="text" id="rtp_discard" 
            name="rtp_discard" value="<?php echo set_value('rtp_discard', $hdy_config->rtp_discard); ?>"/>
          <span>0～10 (Step 1)</span>
          <?php echo form_error('rtp_discard'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">RTP delay</div>
        <div class="col-md-8">
          <input style="width: 100px; padding: 0 5px;" class="form-control input-sm" type="text" id="rtp_delay" 
            name="rtp_delay" value="<?php echo set_value('rtp_delay', $hdy_config->rtp_delay); ?>"/>
          <span>0～5000 (Step 1) ミリ秒</span>
          <?php echo form_error('rtp_delay'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">PING interval（Keep Alive）</div>
        <div class="col-md-8">
          <select name="ping_interval" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_ping_interval as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->ping_interval == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('ping_interval'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">REGISTER interval</div>
        <div class="col-md-8">
          <select name="registar_interval" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_register_interval as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->registar_interval == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('registar_interval'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">Wi-Fi優先度</div>
        <div class="col-md-8">
          <input style="width: 100px; padding: 0 5px;" class="form-control input-sm" type="text" id="prefix_wifi" 
            name="prefix_wifi" value="<?php echo set_value('prefix_wifi', $hdy_config->prefix_wifi); ?>"/>
          <span>1～9（Step 1）　1=Highest Priority/9=Lowest Priority</span>
          <?php echo form_error('prefix_wifi'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">Wi-Fi REGISTER Interval</div>
        <div class="col-md-8">
          <select name="register_interval_pri_wifi" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_register_interval as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->register_interval_pri_wifi == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('register_interval_pri_wifi'); ?>
        </div>
      </div>

    </div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">アカウント情報</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">

      <div class="row">
        <div class="col-md-4 poc-list-title">SIPサーバードメイン（URL）</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="sip_server_domain"
              name="sip_server_domain" value="<?php echo set_value('sip_server_domain', $hdy_config->sip_server_domain); ?>"/>
          <span>文字列(256桁)</span>
          <?php echo form_error('sip_server_domain'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">SIPサーバーポート番号</div>
        <div class="col-md-8">
          <input style="width: 100px; padding: 0 5px;" class="form-control input-sm" type="text" id="sip_server_port" 
            name="sip_server_port" value="<?php echo set_value('sip_server_port', $hdy_config->sip_server_port); ?>"/>
          <span>0 ～ 65535</span>
          <?php echo form_error('sip_server_port'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">SIPサーバーIPアドレス（CRG用）</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="sip_server_ip_crg"
              name="sip_server_ip_crg" value="<?php echo set_value('sip_server_ip_crg', $hdy_config->sip_server_ip_crg); ?>"/>
          <span>文字列(256桁)</span>
          <?php echo form_error('sip_server_ip_crg'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">SIPサーバーポート番号（CRG用）</div>
        <div class="col-md-8">
          <input style="width: 100px; padding: 0 5px;" class="form-control input-sm" type="text" id="sip_server_port_crg" 
            name="sip_server_port_crg" value="<?php echo set_value('sip_server_port_crg', $hdy_config->sip_server_port_crg); ?>"/>
          <span>0 ～ 65535</span>
          <?php echo form_error('sip_server_port_crg'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">XMPPサーバーホスト名</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="xmpp_server_host"
              name="xmpp_server_host" value="<?php echo set_value('xmpp_server_host', $hdy_config->xmpp_server_host); ?>"/>
          <span>文字列(128桁)</span>
          <?php echo form_error('xmpp_server_host'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">XMPPサーバーポート番号</div>
        <div class="col-md-8">
          <input style="width: 100px; padding: 0 5px;" class="form-control input-sm" type="text" id="xmpp_server_port" 
            name="xmpp_server_port" value="<?php echo set_value('xmpp_server_port', $hdy_config->xmpp_server_port); ?>"/>
          <span>0 ～ 65535</span>
          <?php echo form_error('xmpp_server_port'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">XMPPサービス名</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="xmpp_service"
              name="xmpp_service" value="<?php echo set_value('xmpp_service', $hdy_config->xmpp_service); ?>"/>
          <span>文字列(128桁)</span>
          <?php echo form_error('xmpp_service'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">XMPPユーザー名</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="xmpp_user_name"
              name="xmpp_user_name" value="<?php echo set_value('xmpp_user_name', $hdy_config->xmpp_user_name); ?>"/>
          <span>文字列(128桁)</span>
          <?php echo form_error('xmpp_user_name'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">XMPPパスワード</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="password" id="xmpp_password"
              name="xmpp_password" value="<?php echo set_value('xmpp_password', $hdy_config->xmpp_password); ?>"/>
          <span>文字列(128桁)</span>
          <?php echo form_error('xmpp_password'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">不在伝言再生番号</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="unattended_rec_id"
              name="unattended_rec_id" value="<?php echo set_value('unattended_rec_id', $hdy_config->unattended_rec_id); ?>"/>
          <span>文字列(128桁)</span>
          <?php echo form_error('unattended_rec_id'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">ラストコール再生番号</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="lastcall_id"
              name="lastcall_id" value="<?php echo set_value('lastcall_id', $hdy_config->lastcall_id); ?>"/>
          <span>文字列(128桁)</span>
          <?php echo form_error('lastcall_id'); ?>
        </div>
      </div>

    </div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">Webアカウント情報</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">

      <div class="row">
        <div class="col-md-4 poc-list-title">WebサーバーログインID</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="web_account_login_id"
              name="web_account_login_id" value="<?php echo set_value('web_account_login_id', $hdy_config->web_account_login_id); ?>"/>
          <span>文字列(128桁)</span>
          <?php echo form_error('web_account_login_id'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">Webサーバーログインパスワード</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="password" id="web_account_login_password"
              name="web_account_login_password" value="<?php echo set_value('web_account_login_password', $hdy_config->web_account_login_password); ?>"/>
          <span>文字列(128桁)</span>
          <?php echo form_error('web_account_login_password'); ?>
        </div>
      </div>

    </div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">Wi-Fi設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">

      <div class="row">
        <div class="col-md-4 poc-list-title">Private Wi-Fi Mode</div>
        <div class="col-md-8">
          <select name="pri_ap_mode" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_pri_ap_mode as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->pri_ap_mode == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('pri_ap_mode'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">Private Wi-Fiネットワークモード</div>
        <div class="col-md-8">
          <select name="pri_wifi_nw_mode" style="width: 150px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_pri_wifi_nw_mode as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->pri_wifi_nw_mode == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('pri_wifi_nw_mode'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">Private Wi-Fi SSID</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="pri_wifi_ssid"
              name="pri_wifi_ssid" value="<?php echo set_value('pri_wifi_ssid', $hdy_config->pri_wifi_ssid); ?>"/>
          <span>文字列(128桁)</span>
          <?php echo form_error('pri_wifi_ssid'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">Private Wi-Fi Password</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="password" id="pri_wifi_password"
              name="pri_wifi_password" value="<?php echo set_value('pri_wifi_password', $hdy_config->pri_wifi_password); ?>"/>
          <span>文字列(128桁)</span>
          <?php echo form_error('pri_wifi_password'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">Transparent（テザリング）許可</div>
        <div class="col-md-8">
          <select name="pri_wifi_transparent" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_off_on_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->pri_wifi_transparent == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('pri_wifi_transparent'); ?>
        </div>
      </div>

    </div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">GPS設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">

      <div class="row">
        <div class="col-md-4 poc-list-title">GPS測位間隔時間</div>
        <div class="col-md-8">
          <input style="width: 100px; padding: 0 5px;" class="form-control input-sm" type="text" id="gps_conf_interval" 
            name="gps_conf_interval" value="<?php echo set_value('gps_conf_interval', $hdy_config->gps_conf_interval); ?>"/>
          <span>0 ～ 60 (秒)</span>
          <?php echo form_error('gps_conf_interval'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">GPSデータ送信先URL</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="gps_server_url"
              name="gps_server_url" value="<?php echo set_value('gps_server_url', $hdy_config->gps_server_url); ?>"/>
          <span>文字列(128桁)</span>
          <?php echo form_error('gps_server_url'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">GPS測位方式</div>
        <div class="col-md-8">
          <select name="gps_mode" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_gps_mode as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->gps_mode == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('gps_mode'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">GPSデータ送信間隔</div>
        <div class="col-md-8">
          <input style="width: 100px; padding: 0 5px;" class="form-control input-sm" type="text" id="gps_server_interval" 
            name="gps_server_interval" value="<?php echo set_value('gps_server_interval', $hdy_config->gps_server_interval); ?>"/>
          <span>0 ～ 3600 (秒)</span>
          <?php echo form_error('gps_server_interval'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">GPSデータ送信距離間隔</div>
        <div class="col-md-8">
          <input style="width: 100px; padding: 0 5px;" class="form-control input-sm" type="text" id="gps_distance" 
            name="gps_distance" value="<?php echo set_value('gps_distance', $hdy_config->gps_distance); ?>"/>
          <span>0 ～ 10,000 (メートル)</span>
          <?php echo form_error('gps_distance'); ?>
        </div>
      </div>

    </div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">通話設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">

      <div class="row">
        <div class="col-md-4 poc-list-title">LTE Callback Timer</div>
        <div class="col-md-8">
          <input style="width: 100px; padding: 0 5px;" class="form-control input-sm" type="text" id="lte_callback_timer" 
            name="lte_callback_timer" value="<?php echo set_value('lte_callback_timer', $hdy_config->lte_callback_timer); ?>"/>
          <span>0 ～ 60 (秒)</span>
          <?php echo form_error('lte_callback_timer'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">LTE Time out Timer</div>
        <div class="col-md-8">
          <input style="width: 100px; padding: 0 5px;" class="form-control input-sm" type="text" id="lte_time_out_timer" 
            name="lte_time_out_timer" value="<?php echo set_value('lte_time_out_timer', $hdy_config->lte_time_out_timer); ?>"/>
          <span>0 ～ 3,600 (秒)</span>
          <?php echo form_error('lte_time_out_timer'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">LTE Time out Rekey Time</div>
        <div class="col-md-8">
          <input style="width: 100px; padding: 0 5px;" class="form-control input-sm" type="text" id="lte_time_out_time_rekey" 
            name="lte_time_out_time_rekey" value="<?php echo set_value('lte_time_out_time_rekey', $hdy_config->lte_time_out_time_rekey); ?>"/>
          <span>0 ～ 60 (秒)</span>
          <?php echo form_error('lte_time_out_time_rekey'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">Wi-Fi Callback Timer</div>
        <div class="col-md-8">
          <input style="width: 100px; padding: 0 5px;" class="form-control input-sm" type="text" id="wifi_callback_timer" 
            name="wifi_callback_timer" value="<?php echo set_value('wifi_callback_timer', $hdy_config->wifi_callback_timer); ?>"/>
          <span>0 ～ 60 (秒)</span>
          <?php echo form_error('wifi_callback_timer'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">Wi-Fi Time out Timer</div>
        <div class="col-md-8">
          <input style="width: 100px; padding: 0 5px;" class="form-control input-sm" type="text" id="wifi_time_out_timer" 
            name="wifi_time_out_timer" value="<?php echo set_value('wifi_time_out_timer', $hdy_config->wifi_time_out_timer); ?>"/>
          <span>0 ～ 3,600 (秒)</span>
          <?php echo form_error('wifi_time_out_timer'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">Wi-Fi Time out Rekey Time</div>
        <div class="col-md-8">
          <input style="width: 100px; padding: 0 5px;" class="form-control input-sm" type="text" id="wifi_time_out_time_rekey" 
            name="wifi_time_out_time_rekey" value="<?php echo set_value('wifi_time_out_time_rekey', $hdy_config->wifi_time_out_time_rekey); ?>"/>
          <span>0 ～ 60 (秒)</span>
          <?php echo form_error('wifi_time_out_time_rekey'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">LTEジッターバッファ</div>
        <div class="col-md-8">
          <input style="width: 100px; padding: 0 5px;" class="form-control input-sm" type="text" id="lte_jitter_buff" 
            name="lte_jitter_buff" value="<?php echo set_value('lte_jitter_buff', $hdy_config->lte_jitter_buff); ?>"/>
          <span>0 ～ 2,000 (msec)</span>
          <?php echo form_error('lte_jitter_buff'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">Wi-Fiジッターバッファi</div>
        <div class="col-md-8">
          <input style="width: 100px; padding: 0 5px;" class="form-control input-sm" type="text" id="wifi_jitter_buff" 
            name="wifi_jitter_buff" value="<?php echo set_value('wifi_jitter_buff', $hdy_config->wifi_jitter_buff); ?>"/>
          <span>0 ～ 2,000 (msec)</span>
          <?php echo form_error('wifi_jitter_buff'); ?>
        </div>
      </div>

    </div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">受信通知設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">
      <div class="row">
        <div class="col-md-4 poc-list-title">LTE音声受信通知</div>
        <div class="col-md-8">
          <select name="speaker_lte_vib" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_call_notice_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->speaker_lte_vib == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('speaker_lte_vib'); ?>
        </div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">Wi-Fi音声受信通知</div>
        <div class="col-md-8">
          <select name="speaker_pri_wifi_vib" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_call_notice_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->speaker_pri_wifi_vib == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('speaker_pri_wifi_vib'); ?>
        </div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">LTEデータ受信通知</div>
        <div class="col-md-8">
          <select name="speaker_lte_data" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_call_notice_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->speaker_lte_data == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('speaker_lte_data'); ?>
        </div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">Wi-Fiデータ受信通知</div>
        <div class="col-md-8">
          <select name="speaker_pri_wifi_data" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_call_notice_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->speaker_pri_wifi_data == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('speaker_pri_wifi_data'); ?>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">マイク設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">
      <div class="row">
        <div class="col-md-4 poc-list-title">マイク種別</div>
        <div class="col-md-8">
          <select name="audio_mic_type" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_mic_type_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->audio_mic_type == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('audio_mic_type'); ?>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">定型メッセージリスト</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">

      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ１</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="message_list_m1"
              name="message_list_m1" value="<?php echo set_value('message_list_m1', $hdy_config->message_list_m1); ?>"/>
          <span>文字列(128桁)</span>
          <?php echo form_error('message_list_m1'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ２</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="message_list_m2"
              name="message_list_m2" value="<?php echo set_value('message_list_m2', $hdy_config->message_list_m2); ?>"/>
          <span>文字列(128桁)</span>
          <?php echo form_error('message_list_m2'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ３</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="message_list_m3"
              name="message_list_m3" value="<?php echo set_value('message_list_m3', $hdy_config->message_list_m3); ?>"/>
          <span>文字列(128桁)</span>
          <?php echo form_error('message_list_m3'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ４</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="message_list_m4"
              name="message_list_m4" value="<?php echo set_value('message_list_m4', $hdy_config->message_list_m4); ?>"/>
          <span>文字列(128桁)</span>
          <?php echo form_error('message_list_m4'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ５</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="message_list_m5"
              name="message_list_m5" value="<?php echo set_value('message_list_m5', $hdy_config->message_list_m5); ?>"/>
          <span>文字列(128桁)</span>
          <?php echo form_error('message_list_m5'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ６</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="message_list_m6"
              name="message_list_m6" value="<?php echo set_value('message_list_m6', $hdy_config->message_list_m6); ?>"/>
          <span>文字列(128桁)</span>
          <?php echo form_error('message_list_m6'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ７</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="message_list_m7"
              name="message_list_m7" value="<?php echo set_value('message_list_m7', $hdy_config->message_list_m7); ?>"/>
          <span>文字列(128桁)</span>
          <?php echo form_error('message_list_m7'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ８</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="message_list_m8"
              name="message_list_m8" value="<?php echo set_value('message_list_m8', $hdy_config->message_list_m8); ?>"/>
          <span>文字列(128桁)</span>
          <?php echo form_error('message_list_m8'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ９</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="message_list_m9"
              name="message_list_m9" value="<?php echo set_value('message_list_m9', $hdy_config->message_list_m9); ?>"/>
          <span>文字列(128桁)</span>
          <?php echo form_error('message_list_m9'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ１０</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="message_list_m10"
              name="message_list_m10" value="<?php echo set_value('message_list_m10', $hdy_config->message_list_m10); ?>"/>
          <span>文字列(128桁)</span>
          <?php echo form_error('message_list_m10'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ１１</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="message_list_m11"
              name="message_list_m11" value="<?php echo set_value('message_list_m11', $hdy_config->message_list_m11); ?>"/>
          <span>文字列(128桁)</span>
          <?php echo form_error('message_list_m11'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ１２</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="message_list_m12"
              name="message_list_m12" value="<?php echo set_value('message_list_m12', $hdy_config->message_list_m12); ?>"/>
          <span>文字列(128桁)</span>
          <?php echo form_error('message_list_m12'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ１３</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="message_list_m13"
              name="message_list_m13" value="<?php echo set_value('message_list_m13', $hdy_config->message_list_m13); ?>"/>
          <span>文字列(128桁)</span>
          <?php echo form_error('message_list_m13'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ１４</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="message_list_m14"
              name="message_list_m14" value="<?php echo set_value('message_list_m14', $hdy_config->message_list_m14); ?>"/>
          <span>文字列(128桁)</span>
          <?php echo form_error('message_list_m14'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ１５</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="message_list_m15"
              name="message_list_m15" value="<?php echo set_value('message_list_m15', $hdy_config->message_list_m15); ?>"/>
          <span>文字列(128桁)</span>
          <?php echo form_error('message_list_m15'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ１６</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="message_list_m16"
              name="message_list_m16" value="<?php echo set_value('message_list_m16', $hdy_config->message_list_m16); ?>"/>
          <span>文字列(128桁)</span>
          <?php echo form_error('message_list_m16'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ１７</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="message_list_m17"
              name="message_list_m17" value="<?php echo set_value('message_list_m17', $hdy_config->message_list_m17); ?>"/>
          <span>文字列(128桁)</span>
          <?php echo form_error('message_list_m17'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ１８</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="message_list_m18"
              name="message_list_m18" value="<?php echo set_value('message_list_m18', $hdy_config->message_list_m18); ?>"/>
          <span>文字列(128桁)</span>
          <?php echo form_error('message_list_m18'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ１９</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="message_list_m19"
              name="message_list_m19" value="<?php echo set_value('message_list_m19', $hdy_config->message_list_m19); ?>"/>
          <span>文字列(128桁)</span>
          <?php echo form_error('message_list_m19'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ２０</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="message_list_m20"
              name="message_list_m20" value="<?php echo set_value('message_list_m20', $hdy_config->message_list_m20); ?>"/>
          <span>文字列(128桁)</span>
          <?php echo form_error('message_list_m20'); ?>
        </div>
      </div>

    </div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">履歴設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">

      <div class="row">
        <div class="col-md-4 poc-list-title">時刻情報付加設定</div>
        <div class="col-md-8">
          <select name="history_timestamp" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_history_timestamp as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->history_timestamp == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('history_timestamp'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">発着信履歴情報</div>
        <div class="col-md-8">
          <select name="history_call" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_history_info_settings as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->history_call == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('history_call'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">着信履歴</div>
        <div class="col-md-8">
          <select name="history_income" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_history_info_settings as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->history_income == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('history_income'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">発信履歴</div>
        <div class="col-md-8">
          <select name="history_outcome" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_history_info_settings as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->history_outcome == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('history_outcome'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ着信履歴</div>
        <div class="col-md-8">
          <select name="history_message_in" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_history_info_settings as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->history_message_in == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('history_message_in'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ発信履歴</div>
        <div class="col-md-8">
          <select name="history_message_out" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_history_info_settings as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->history_message_out == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('history_message_out'); ?>
        </div>
      </div>

    </div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">カスタム設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">

      <div class="row">
        <div class="col-md-4 poc-list-title">カスタム１</div>
        <div class="col-md-8">
          <select name="custom1" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_history_custom_settings as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->custom1 == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('custom1'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">カスタム２</div>
        <div class="col-md-8">
          <select name="custom2" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_history_custom_settings as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->custom2 == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('custom2'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">カスタム３</div>
        <div class="col-md-8">
          <select name="custom3" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_history_custom_settings as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->custom3 == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('custom3'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">カスタム４</div>
        <div class="col-md-8">
          <select name="custom4" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_history_custom_settings as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->custom4 == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('custom4'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">カスタム５</div>
        <div class="col-md-8">
          <select name="custom5" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_history_custom_settings as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->custom5 == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('custom5'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">カスタム６</div>
        <div class="col-md-8">
          <select name="custom6" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_history_custom_settings as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->custom6 == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('custom6'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">カスタム７</div>
        <div class="col-md-8">
          <select name="custom7" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_history_custom_settings as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->custom7 == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('custom7'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">カスタム８</div>
        <div class="col-md-8">
          <select name="custom8" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_history_custom_settings as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->custom8 == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('custom8'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">カスタム９</div>
        <div class="col-md-8">
          <select name="custom9" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_history_custom_settings as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->custom9 == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('custom9'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">カスタム１０</div>
        <div class="col-md-8">
          <select name="custom10" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_history_custom_settings as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->custom10 == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('custom10'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">カスタム１１</div>
        <div class="col-md-8">
          <select name="custom11" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_history_custom_settings as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->custom11 == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('custom11'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">カスタム１２</div>
        <div class="col-md-8">
          <select name="custom12" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_history_custom_settings as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->custom12 == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('custom12'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">カスタム１３</div>
        <div class="col-md-8">
          <select name="custom13" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_history_custom_settings as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->custom13 == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('custom13'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">カスタム１４</div>
        <div class="col-md-8">
          <select name="custom14" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_history_custom_settings as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->custom14 == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('custom14'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">カスタム１５</div>
        <div class="col-md-8">
          <select name="custom15" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_history_custom_settings as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->custom15 == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('custom15'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">カスタム１６</div>
        <div class="col-md-8">
          <select name="custom16" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_history_custom_settings as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->custom16 == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('custom16'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">カスタム１７</div>
        <div class="col-md-8">
          <select name="custom17" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_history_custom_settings as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->custom17 == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('custom17'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">カスタム１８</div>
        <div class="col-md-8">
          <select name="custom18" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_history_custom_settings as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->custom18 == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('custom18'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">カスタム１９</div>
        <div class="col-md-8">
          <select name="custom19" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_history_custom_settings as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->custom19 == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('custom19'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">カスタム２０</div>
        <div class="col-md-8">
          <select name="custom20" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_history_custom_settings as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->custom20 == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('custom20'); ?>
        </div>
      </div>

    </div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">送信設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">

      <div class="row">
        <div class="col-md-4 poc-list-title">内部マイク感度</div>
        <div class="col-md-8">
          <select name="audio_intnl_mic_gain" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_auto_mic_gain as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->audio_intnl_mic_gain == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('audio_intnl_mic_gain'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">外部マイク感度</div>
        <div class="col-md-8">
          <select name="audio_extnl_mic_gain" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_auto_mic_gain as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->audio_extnl_mic_gain == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('audio_extnl_mic_gain'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">緊急時マイク感度</div>
        <div class="col-md-8">
          <select name="audio_emergency_mic_gain" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_auto_mic_gain as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->audio_emergency_mic_gain == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('audio_emergency_mic_gain'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">PTTホールド</div>
        <div class="col-md-8">
          <select name="key_ptt_hold" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_off_on_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->key_ptt_hold == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('key_ptt_hold'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">コールバック</div>
        <div class="col-md-8">
          <select name="audio_earphone_callback" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_off_on_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->audio_earphone_callback == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('audio_earphone_callback'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">VOX動作設定</div>
        <div class="col-md-8">
          <select name="vox" style="width: 150px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_vox as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->vox == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('vox'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">VOX動作レベル</div>
        <div class="col-md-8">
          <input style="width: 100px; padding: 0 5px;" class="form-control input-sm" type="text" id="vox_thresh" 
            name="vox_thresh" value="<?php echo set_value('vox_thresh', $hdy_config->vox_thresh); ?>"/>
          <span>1～7（Step 1）　1=感度低/7=感度高</span>
          <?php echo form_error('vox_thresh'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">ノイズキャンセラー</div>
        <div class="col-md-8">
          <select name="audio_noise_can" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_off_on_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->audio_noise_can == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('audio_noise_can'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">エコーキャンセラー</div>
        <div class="col-md-8">
          <select name="audio_echo_can" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_off_on_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->audio_echo_can == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('audio_echo_can'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">連続送信制限時間</div>
        <div class="col-md-8">
          <select name="time_out_timer" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_time_out_timer as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->time_out_timer == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('time_out_timer'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">PTT通信相手選択</div>
        <div class="col-md-8">
          <select name="ptt_call" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_ptt_call as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->ptt_call == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('ptt_call'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">PTT通信グループ</div>
        <div class="col-md-8">
         <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="ptt_group"
              name="ptt_group" value="<?php echo set_value('ptt_group', $hdy_config->ptt_group); ?>"/>
          <span>グループSIP番号</span>
          <?php echo form_error('ptt_group'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">PTT通信会議室</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="ptt_conference"
              name="ptt_conference" value="<?php echo set_value('ptt_conference', $hdy_config->ptt_conference); ?>"/>
          <span>会議室SIP番号</span>
          <?php echo form_error('ptt_conference'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">直通相手選択</div>
        <div class="col-md-8">
          <select name="direct_call" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_direct_call as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->direct_call == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('direct_call'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">直接通信グループ</div>
        <div class="col-md-8">
          <input style="width: 400px; padding: 0 5px;" class="form-control input-sm" type="text" id="direct_group"
              name="direct_group" value="<?php echo set_value('direct_group', $hdy_config->direct_group); ?>"/>
          <span>グループSIP番号</span>
          <?php echo form_error('direct_group'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">送信禁止</div>
        <div class="col-md-8">
          <select name="tx_block" style="width: 150px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_tx_block as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->tx_block == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('tx_block'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">個別呼出切替</div>
        <div class="col-md-8">
          <select name="ind_callback_timer" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_callback_timer as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->ind_callback_timer == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('ind_callback_timer'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">グループ呼出切替</div>
        <div class="col-md-8">
          <select name="group_callback_timer" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_callback_timer as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->group_callback_timer == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('group_callback_timer'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">全員呼出切替</div>
        <div class="col-md-8">
          <select name="all_callback_timer" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_callback_timer as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->all_callback_timer == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('all_callback_timer'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">個別通話禁止</div>
        <div class="col-md-8">
          <select name="individual_call_disable" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_message_block as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->individual_call_disable == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('individual_call_disable'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">個別メッセージ禁止</div>
        <div class="col-md-8">
          <select name="individual_message_disable" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_message_block as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->individual_message_disable == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('individual_message_disable'); ?>
        </div>
      </div>

    </div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">受信設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">

      <div class="row">
        <div class="col-md-4 poc-list-title">音量一定化</div>
        <div class="col-md-8">
          <select name="audio_alc" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_audio_alc as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->audio_alc == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('audio_alc'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">低音域抑制</div>
        <div class="col-md-8">
          <select name="audio_bass_reduce" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_audio_reduce as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->audio_bass_reduce == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('audio_bass_reduce'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">高音域抑制</div>
        <div class="col-md-8">
          <select name="audio_treble_reduce" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_audio_reduce as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->audio_treble_reduce == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('audio_treble_reduce'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">録音動作設定</div>
        <div class="col-md-8">
          <select name="record_mode" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_record_mode as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->record_mode == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('record_mode'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ受信禁止</div>
        <div class="col-md-8">
          <select name="message_block" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_message_block as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->message_block == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('message_block'); ?>
        </div>
      </div>

    </div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">通知/警告設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">

      <div class="row">
        <div class="col-md-4 poc-list-title">ビープ音量</div>
        <div class="col-md-8">
          <select name="speaker_beep_vol" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_speaker_beep_vol as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->speaker_beep_vol == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('speaker_beep_vol'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">ベル機能</div>
        <div class="col-md-8">
          <select name="alarm_bell" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_off_on_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->alarm_bell == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('alarm_bell'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">ベルの音色</div>
        <div class="col-md-8">
          <select name="bell_mode" style="width: 150px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_bell_mode as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->bell_mode == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('bell_mode'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">音声ガイド</div>
        <div class="col-md-8">
          <select name="voice_guide" style="width: 150px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_voice_guide as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->voice_guide == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('voice_guide'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">音声ガイド音量</div>
        <div class="col-md-8">
          <select name="voice_guide_vol" style="width: 150px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_voice_guide_vol as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->voice_guide_vol == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('voice_guide_vol'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">減電池警告</div>
        <div class="col-md-8">
          <select name="alarm_low_battery" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_alarm_low_battery as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->alarm_low_battery == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('alarm_low_battery'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">イヤホン断線検知</div>
        <div class="col-md-8">
          <select name="alarm_earphone_broken" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_off_on_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->alarm_earphone_broken == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('alarm_earphone_broken'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">接続通知</div>
        <div class="col-md-8">
          <select name="alarm_ind_call_ok" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_off_on_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->alarm_ind_call_ok == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('alarm_ind_call_ok'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">失敗通知</div>
        <div class="col-md-8">
          <select name="alarm_ind_call_ng" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_off_on_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->alarm_ind_call_ng == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('alarm_ind_call_ng'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">PTTビープ</div>
        <div class="col-md-8">
          <select name="audio_ptt_beep" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_off_on_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->audio_ptt_beep == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('audio_ptt_beep'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">エンドピー</div>
        <div class="col-md-8">
          <select name="audio_end_beep" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_off_on_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->audio_end_beep == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('audio_end_beep'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">通信圏外警告</div>
        <div class="col-md-8">
          <select name="alarm_connect" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_off_on_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->alarm_connect == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('alarm_connect'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">圏外時コールバック停止</div>
        <div class="col-md-8">
          <select name="alarm_stop_callback" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_off_on_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->alarm_stop_callback == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('alarm_stop_callback'); ?>
        </div>
      </div>

    </div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">各種動作設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">

      <div class="row">
        <div class="col-md-4 poc-list-title">短縮キー動作</div>
        <div class="col-md-8">
          <select name="shortcut_key" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_shortcut_key as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->shortcut_key == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('shortcut_key'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">外部音量設定</div>
        <div class="col-md-8">
          <select name="speaker_extnl_vol" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_speaker_extnl_vol as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->speaker_extnl_vol == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('speaker_extnl_vol'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">音量の調整方法</div>
        <div class="col-md-8">
          <select name="speaker_vol_mode" style="width: 150px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_speaker_vol_mode as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->speaker_vol_mode == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('speaker_vol_mode'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">固定音量レベル</div>
        <div class="col-md-8">
          <input style="width: 100px; padding: 0 5px;" class="form-control input-sm" type="text" id="speaker_fixed_vol" 
            name="speaker_fixed_vol" value="<?php echo set_value('speaker_fixed_vol', $hdy_config->speaker_fixed_vol); ?>"/>
          <span>0 ～ 32 (step 1)</span>
          <?php echo form_error('speaker_fixed_vol'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">最大音量レベル</div>
        <div class="col-md-8">
          <input style="width: 100px; padding: 0 5px;" class="form-control input-sm" type="text" id="speaker_max_vol" 
            name="speaker_max_vol" value="<?php echo set_value('speaker_max_vol', $hdy_config->speaker_max_vol); ?>"/>
          <span>0 ～ 32 (step 1)</span>
          <?php echo form_error('speaker_max_vol'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">最小音量レベル</div>
        <div class="col-md-8">
          <input style="width: 100px; padding: 0 5px;" class="form-control input-sm" type="text" id="speaker_min_vol" 
            name="speaker_min_vol" value="<?php echo set_value('speaker_min_vol', $hdy_config->speaker_min_vol); ?>"/>
          <span>0 ～ 32 (step 1)</span>
          <?php echo form_error('speaker_min_vol'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">接客モード</div>
        <div class="col-md-8">
          <select name="earphone_sekkyaku_mode" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_earphone_sekkyaku_mode as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->earphone_sekkyaku_mode == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('earphone_sekkyaku_mode'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">接客ボイス感度</div>
        <div class="col-md-8">
          <input style="width: 100px; padding: 0 5px;" class="form-control input-sm" type="text" id="sekkyaku_voice" 
            name="sekkyaku_voice" value="<?php echo set_value('sekkyaku_voice', $hdy_config->sekkyaku_voice); ?>"/>
          <span>1～7（Step 1）　1=感度低/7=感度高</span>
          <?php echo form_error('sekkyaku_voice'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">接客タッチ感度</div>
        <div class="col-md-8">
          <select name="sekkyaku_touch" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_sekkyaku_touch as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->sekkyaku_touch == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('sekkyaku_touch'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">接客復帰時間</div>
        <div class="col-md-8">
          <select name="sekkyaku_release_timer" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_sekkyaku_release_timer as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->sekkyaku_release_timer == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('sekkyaku_release_timer'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">接客ボイス保持</div>
        <div class="col-md-8">
          <input style="width: 100px; padding: 0 5px;" class="form-control input-sm" type="text" id="sekkyaku_voice_timer" 
            name="sekkyaku_voice_timer" value="<?php echo set_value('sekkyaku_voice_timer', $hdy_config->sekkyaku_voice_timer); ?>"/>
          <span>1～5（秒）</span>
          <?php echo form_error('sekkyaku_voice_timer'); ?>
        </div>
      </div>

    </div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">緊急動作設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">

      <div class="row">
        <div class="col-md-4 poc-list-title">緊急動作　受信禁止</div>
        <div class="col-md-8">
          <select name="emergency_receive" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_message_block as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->emergency_receive == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('emergency_receive'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">緊急動作　警報音のみ</div>
        <div class="col-md-8">
          <input style="width: 100px; padding: 0 5px;" class="form-control input-sm" type="text" id="emergency_alarm_duration" 
            name="emergency_alarm_duration" value="<?php echo set_value('emergency_alarm_duration', $hdy_config->emergency_alarm_duration); ?>"/>
          <span>0=OFF/1～60（秒）</span>
          <?php echo form_error('emergency_alarm_duration'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">緊急動作　警報音+発報</div>
        <div class="col-md-8">
          <input style="width: 100px; padding: 0 5px;" class="form-control input-sm" type="text" id="emergency_alarm_ptt_duration" 
            name="emergency_alarm_ptt_duration" value="<?php echo set_value('emergency_alarm_ptt_duration', $hdy_config->emergency_alarm_ptt_duration); ?>"/>
          <span>0=OFF/1～60（秒）</span>
          <?php echo form_error('emergency_alarm_ptt_duration'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">緊急動作　発報のみ</div>
        <div class="col-md-8">
          <input style="width: 100px; padding: 0 5px;" class="form-control input-sm" type="text" id="emergency_silent_ptt_duration" 
            name="emergency_silent_ptt_duration" value="<?php echo set_value('emergency_silent_ptt_duration', $hdy_config->emergency_silent_ptt_duration); ?>"/>
          <span>0=OFF/1～60（秒）</span>
          <?php echo form_error('emergency_silent_ptt_duration'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">緊急動作　音声送信</div>
        <div class="col-md-8">
          <input style="width: 100px; padding: 0 5px;" class="form-control input-sm" type="text" id="emergency_live_ptt_duration" 
            name="emergency_live_ptt_duration" value="<?php echo set_value('emergency_live_ptt_duration', $hdy_config->emergency_live_ptt_duration); ?>"/>
          <span>0=OFF/1～60（秒）</span>
          <?php echo form_error('emergency_live_ptt_duration'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">緊急動作　警報音量（内部）</div>
        <div class="col-md-8">
          <select name="emergency_intnl_vol" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_emergency_vol as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->emergency_intnl_vol == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('emergency_intnl_vol'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">緊急動作　警報音量（外部）</div>
        <div class="col-md-8">
          <select name="emergency_extnl_vol" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_emergency_vol as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->emergency_extnl_vol == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('emergency_extnl_vol'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">緊急速報機能</div>
        <div class="col-md-8">
          <select name="kinkyu_sokuho" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_off_on_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->kinkyu_sokuho == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('kinkyu_sokuho'); ?>
        </div>
      </div>

    </div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">端末システム設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">

      <div class="row">
        <div class="col-md-4 poc-list-title">バックライトタイマー</div>
        <div class="col-md-8">
          <select name="backlight_timer" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_backlight_timer as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->backlight_timer == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('backlight_timer'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">コントラスト</div>
        <div class="col-md-8">
            <input style="width: 100px; padding: 0 5px;" class="form-control input-sm" type="text" id="display_lcd_contrast" 
              name="display_lcd_contrast" value="<?php echo set_value('display_lcd_contrast', $hdy_config->display_lcd_contrast); ?>"/>
            <span>1～10</span>
          <?php echo form_error('display_lcd_contrast'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">バッテリーセーブ</div>
        <div class="col-md-8">
          <select name="battery_save" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_off_on_names as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->battery_save == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('battery_save'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">オートパワーオフ</div>
        <div class="col-md-8">
          <select name="power_off_timer" style="width: 100px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_power_off_timer as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->power_off_timer == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('power_off_timer'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">音声コーデック設定</div>
        <div class="col-md-8">
          <select name="audio_codec" style="width: 150px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_audio_codec as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->audio_codec == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('audio_codec'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">セットモード切り替え</div>
        <div class="col-md-8">
          <select name="set_mode" style="width: 150px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_set_mode as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->set_mode == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('set_mode'); ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 poc-list-title">リセット動作禁止</div>
        <div class="col-md-8">
          <select name="reset_disable" style="width: 150px; padding: 0 5px;" class="form-control">
            <?php foreach ($global_handy_message_block as $key => $value) { ?>
              <option value="<?php echo $key ?>" <?php if ($hdy_config->reset_disable == $key) echo 'selected="selected"' ?> ><?php echo htmlentities($value); ?></option>
            <?php } ?>
          </select>
          <?php echo form_error('reset_disable'); ?>
        </div>
      </div>
      
    </div>
  </div>
</div>

<div class="text-right poc-control-panel">
  <button type="submit" class="btn btn-primary">保存</button>
  <?php if ($config_type == 'tenant_admin'): ?>
    <a href="<?php echo base_url('handy_tenant/view/'); ?>" class="btn btn-default">キャンセル</a>
  <?php else: ?>
    <a href="<?php echo base_url('handy_tenant/view/'.$tenant->company_id); ?>" class="btn btn-default">キャンセル</a>
  <?php endif ?>
</div>

<?php echo form_close(); ?>

<?php
$this->load->view('templates/footer', $data);
?>
