<?php
$data['username'] = $username;
$data['usermode'] = $usermode;
$data['css'] = 'dummy.css';
$data['menu'] = 'group';

// setup breadcrumb
$breadcrumb = array(
	'ホーム' => 	base_url('home'),
	'グループ管理' => false,
);

$data['breadcrumb'] = $breadcrumb;

$this->load->view('templates/header', $data);
$this->load->view('templates/sidemenu', $data);
?>

<?php if (!USE_BREADCRUMB_IN_HEADER && isset($breadcrumb)): ?>
	<ol class="breadcrumb"> <!-- パンくず対応済み -->
<?php
		foreach ($breadcrumb as $_title => $_url) {
			if ($_url) { echo '<li><a href="'.$_url.'">'.$_title.'</a></li>'; }
			else { echo '<li class="active">'.$_title.'</li>'; }
		}
?>
	</ol>
<?php endif ?>

<h2 class="page-header">グループ管理</h2>


<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">テナント別グループ一覧</h3>
  </div>
  <div class="panel-body">
    テナントを選択してください。
  </div>

  <table class="table table-striped table-condensed table-hover poc-table">
    <thead>
      <tr>
        <th>テナント名</th>
      </tr>
    </thead>
    <tbody>
  <?php
      foreach ($tenants as $row) {
          echo '<tr>';
          echo '<td><a href="'.base_url('group/view_list/'.$row->company_id).'">'.$row->company_name.'</a></td>';
          echo '</tr>';
      }
  ?>
    </tobdy>
  </table>
</div>

<div class="panel panel-info" id="update_sip">
  <div class="panel-heading">
    <h3 class="panel-title">SIPアカウント更新</h3>
  </div>
  <div class="panel-body">
    「SIP更新」ボタンをクリックすると、グループの追加/削除/有効無効の設定をSIPサーバーに反映します。
    <div class="text-center" style="margin-top:20px">
      <a href="<?php echo base_url('pocaccount/update_sipconf/1'); ?>" class="btn btn-primary">SIP更新</a>
    </div>
  </div>
</div>


<?php
$this->load->view('templates/footer', $data);
?>
