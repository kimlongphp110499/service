<?php
$data['username'] = $username;
$data['usermode'] = $usermode;
$data['css'] = 'dummy.css';
$data['menu'] = 'devicesetting';

// setup breadcrumb
$breadcrumb = array(
  'ホーム' => 	base_url('home'),
  'デバイス設定詳細' => base_url('devicesetting/view/'.$tenant->company_id),
	'デバイス設定編集' => false,
);

$data['breadcrumb'] = $breadcrumb;

$this->load->view('templates/header', $data);
$this->load->view('templates/sidemenu', $data);
?>

<?php if (!USE_BREADCRUMB_IN_HEADER && isset($breadcrumb)): ?>
	<ol class="breadcrumb"> <!-- パンくず対応済み -->
<?php
		foreach ($breadcrumb as $_title => $_url) {
			if ($_url) { echo '<li><a href="'.$_url.'">'.$_title.'</a></li>'; }
			else { echo '<li class="active">'.$_title.'</li>'; }
		}
?>
	</ol>
<?php endif ?>

<h2 class="page-header">デバイス設定編集</h2>

<?php if ($usermode == 'admin'): ?>
<h3>テナント: <?php echo $tenant->company_name; ?></h3>
<?php endif; ?>

<?php echo form_open('devicesetting/edit/'.$tenant->company_id); ?>

<div class="poc-message-box">
全デバイスで共通する設定項目です。
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">Air-InCom.設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="form-horizontal">

      <div class="form-group">
        <label class="control-label col-md-4" for="gps_interval">GPSデータ送信間隔</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="gps_interval" name="gps_interval" value="<?php echo set_value('gps_interval', $spt_config->gps_interval); ?>"/>
          <?php echo form_error('gps_interval'); ?>
        </div>
      </div>

      <!--<div class="form-group">
        <label class="control-label col-md-4" for="bluetooth_address">Bluetoothアドレス</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="bluetooth_address" name="bluetooth_address" value="<?php echo set_value('bluetooth_address', $spt_config->bluetooth_address); ?>"/>
          <?php echo form_error('bluetooth_address'); ?>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-4" for="bluetooth_interval">Bluetooth間隔</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="bluetooth_interval" name="bluetooth_interval" value="<?php echo set_value('bluetooth_interval', $spt_config->bluetooth_interval); ?>"/>
          <?php echo form_error('bluetooth_interval'); ?>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-4" for="bluetooth_rssi_threshold">Bluetooth RSSI閾値</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="bluetooth_rssi_threshold" name="bluetooth_rssi_threshold" value="<?php echo set_value('bluetooth_rssi_threshold', $spt_config->bluetooth_rssi_threshold); ?>"/>
          <?php echo form_error('bluetooth_rssi_threshold'); ?>
        </div>
      </div>-->

<?php if ($usermode == 'admin') : ?>
      <div class="form-group">
        <label class="control-label col-md-4" for="xmpp_server_domain">XMPPサーバーホスト名</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="xmpp_server_domain" name="xmpp_server_domain" value="<?php echo set_value('xmpp_server_domain', $spt_config->xmpp_server_domain); ?>"/>
          <?php echo form_error('xmpp_server_domain'); ?>
        </div>
      </div>
<?php else : ?>
      <input type="hidden" name="xmpp_server_domain" value="<?php echo $spt_config->xmpp_server_domain; ?>"/>
<?php endif ?>

<?php if ($usermode == 'admin') : ?>
      <div class="form-group">
        <label class="control-label col-md-4" for="xmpp_port">XMPPサーバーポート番号</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="xmpp_port" name="xmpp_port" value="<?php echo set_value('xmpp_port', $spt_config->xmpp_port); ?>"/>
          <?php echo form_error('xmpp_port'); ?>
        </div>
      </div>
<?php else : ?>
      <input type="hidden" name="xmpp_port" value="<?php echo $spt_config->xmpp_port; ?>"/>
<?php endif ?>

<?php if ($usermode == 'admin') : ?>
      <div class="form-group">
        <label class="control-label col-md-4" for="xmpp_service_name">XMPPサービス名</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="xmpp_service_name" name="xmpp_service_name" value="<?php echo set_value('xmpp_service_name', $spt_config->xmpp_service_name); ?>"/>
          <?php echo form_error('xmpp_service_name'); ?>
        </div>
      </div>
<?php else : ?>
      <input type="hidden" name="xmpp_service_name" value="<?php echo $spt_config->xmpp_service_name; ?>"/>
<?php endif ?>

      <div class="form-group">
        <label class="control-label col-md-4" for="send_image_interval">画像送信間隔</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="send_image_interval" name="send_image_interval" value="<?php echo set_value('send_image_interval', $spt_config->send_image_interval); ?>"/>
          <?php echo form_error('send_image_interval'); ?>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-4" for="send_image_quality">画像品質</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="send_image_quality" name="send_image_quality" value="<?php echo set_value('send_image_quality', $spt_config->send_image_quality); ?>"/>
          <?php echo form_error('send_image_quality'); ?>
        </div>
      </div>

    </div>
  </div>
</div>

<!--
<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">ISM-101設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="form-horizontal">

      <div class="form-group">
        <label class="control-label col-md-4" for="call1">MODE1発信先番号</label>
        <div class="col-md-8">
          <select name="call1" class="form-control">
          <?php
          foreach ($contacts as $row) {
             echo '<option value="'.$row['sip_number'].'" '
			 .set_select('call1', $row['sip_number'], $ism_config->call1 == $row['sip_number'] ? TRUE : FALSE)
			 .'>'.$row['name'].' ('.$row['sip_number'].')'
             .'</option>';
          }
          ?>
          </select>
          <?php echo form_error('call1'); ?>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-4" for="call2">MODE2発信先番号</label>
        <div class="col-md-8">
          <select name="call2" class="form-control">
          <?php
          foreach ($contacts as $row) {
             echo '<option value="'.$row['sip_number'].'" '
			 .set_select('call2', $row['sip_number'], $ism_config->call2 == $row['sip_number'] ? TRUE : FALSE)
			 .'>'.$row['name'].' ('.$row['sip_number'].')'
             .'</option>';
          }
          ?>
          </select>
          <?php echo form_error('call2'); ?>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-4" for="call3">MODE3発信先番号</label>
        <div class="col-md-8">
          <select name="call3" class="form-control">
          <?php
          foreach ($contacts as $row) {
             echo '<option value="'.$row['sip_number'].'" '
			 .set_select('call3', $row['sip_number'], $ism_config->call3 == $row['sip_number'] ? TRUE : FALSE)
			 .'>'.$row['name'].' ('.$row['sip_number'].')'
             .'</option>';
          }
          ?>
          </select>
          <?php echo form_error('call3'); ?>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-4" for="geomode">GPS測位モード</label>
        <div class="col-md-8">
          <select name="geomode" class="form-control">
            <option value="0" <?php echo set_select('geomode', 0, $ism_config->geomode == 0 ? TRUE : FALSE); ?>>SET-Based方式</option>
            <option value="1" <?php echo set_select('geomode', 1, $ism_config->geomode == 1 ? TRUE : FALSE); ?>>Auto方式</option>
            <option value="2" <?php echo set_select('geomode', 2, $ism_config->geomode == 2 ? TRUE : FALSE); ?>>SET-Assisted方式</option>
            <option value="3" <?php echo set_select('geomode', 3, $ism_config->geomode == 3 ? TRUE : FALSE); ?>>Standalone方式</option>
          </select>
          <?php echo form_error('geomode'); ?>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-4" for="geointerval">GPS測位間隔時間</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="geointerval" name="geointerval" value="<?php echo set_value('geointerval', $ism_config->geointerval); ?>"/>
          <?php echo form_error('geointerval'); ?>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-4" for="geodistance">GPS測位間隔距離</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="geodistance" name="geodistance" value="<?php echo set_value('geodistance', $ism_config->geodistance); ?>"/>
          <?php echo form_error('geodistance'); ?>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-4" for="callbacktimer">コールバックタイマー</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="callbacktimer" name="callbacktimer" value="<?php echo set_value('callbacktimer', $ism_config->callbacktimer); ?>"/>
          <?php echo form_error('callbacktimer'); ?>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-4" for="newvoicemail">不在伝言再生番号</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="newvoicemail" name="newvoicemail" value="<?php echo set_value('newvoicemail', $ism_config->newvoicemail); ?>"/>
          <?php echo form_error('newvoicemail'); ?>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-4" for="novoicemail">ラストコール再生番号</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="novoicemail" name="novoicemail" value="<?php echo set_value('novoicemail', $ism_config->novoicemail); ?>"/>
          <?php echo form_error('novoicemail'); ?>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-4" for="mic">マイク音量</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="mic" name="mic" value="<?php echo set_value('mic', $ism_config->mic); ?>"/>
          <?php echo form_error('mic'); ?>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-4" for="speaker">スピーカー音量</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="speaker" name="speaker" value="<?php echo set_value('speaker', $ism_config->speaker); ?>"/>
          <?php echo form_error('speaker'); ?>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-4" for="gpsurl">GPSデータ送信先URL</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="gpsurl" name="gpsurl" value="<?php echo set_value('gpsurl', $ism_config->gpsurl); ?>"/>
          <?php echo form_error('gpsurl'); ?>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-4" for="appversion">アプリバージョン</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="appversion" name="appversion" value="<?php echo set_value('appversion', $ism_config->appversion); ?>"/>
          <?php echo form_error('appversion'); ?>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-4" for="apppath">アプリパス</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="apppath" name="apppath" value="<?php echo set_value('apppath', $ism_config->apppath); ?>"/>
          <?php echo form_error('apppath'); ?>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-4" for="kernelversion">カーネルバージョン</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="kernelversion" name="kernelversion" value="<?php echo set_value('kernelversion', $ism_config->kernelversion); ?>"/>
          <?php echo form_error('kernelversion'); ?>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-4" for="kernelpath">カーネルパス</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="kernelpath" name="kernelpath" value="<?php echo set_value('kernelpath', $ism_config->kernelpath); ?>"/>
          <?php echo form_error('kernelpath'); ?>
        </div>
      </div>
    </div>
  </div>
</div>
-->

  <input type="hidden" name="company_id" value="<?php echo $tenant->company_id; ?>" />

  <div class="text-right poc-control-panel">
    <button type="submit" class="btn btn-primary">保存</button>
    <a href="<?php echo base_url('devicesetting/view/'.$tenant->company_id); ?>" class="btn btn-default">キャンセル</a>
  </div>
</form>

<?php
$this->load->view('templates/footer', $data);
?>
