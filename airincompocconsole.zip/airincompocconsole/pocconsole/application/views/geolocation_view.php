<?php
$data['username'] = $username;
$data['usermode'] = $usermode;
$data['css'] = 'dummy.css';
$data['menu'] = 'geo';
$this->load->view('templates/header', $data);
$this->load->view('templates/sidemenu', $data);
?>

<ol class="breadcrumb">
  <li><a href="<?php echo base_url('home'); ?>">ホーム</a></li>
  <li class="active">位置表示</li>
</ol>

<h2 class="page-header">位置表示</h2>

<div id="gmap" style="border:solid lime 2px"></div>

<div class="text-right poc-control-panel">
  <a href="<?php echo base_url('geolocation/download_csv/'.$tenant->company_id); ?>" class="btn btn-default"><span class="glyphicon glyphicon-save"></span> 位置履歴ダウンロード</a>
</div>

<!--<script src="https://maps.google.com/maps/api/js?key=AIzaSyDJfYKYZEzTgawgsd7buo1gncOMwFnAcfk&language=ja"></script>-->
<script src="https://maps.google.com/maps/api/js?key=AIzaSyDlRBJeBS0oSCtp5sEw9N73a90kfMoLbig&language=ja"></script>
<script>
var timer = false;
var staffMarkers = [];
var map;

function updateStaffMarkers(json) {
    console.log('updateStaffMarkers');
    staffMarkers.forEach(function(marker) {
        marker.marked = false;
    });

    for (let i = 0; i < json.length; i++) {
        let staff = json[i];
        //console.log('display_name='+staff['display_name']+' lon='+staff['lon']+' lat='+staff['lat']);
        if (staff['lon'] != null && staff['lat'] != null) {
            let marker = null;
            for (let j = 0; j < staffMarkers.length; j++) {
                if (staffMarkers[j].poc_id == staff['poc_id']) {
                    marker = staffMarkers[j];
                    break;
                }
            }
            if (marker == null) {
                marker = new google.maps.Marker({
                    position: {
                        lat: parseFloat(staff['lat']),
                        lng: parseFloat(staff['lon']),
                    },
                    map: map,
                    label: {
                        text: staff['display_name'],
                        fontWeight: 'bold',
                        fontSize: '12px',
                        color: '#000080',
                    },
                    icon: {
                        url: '<?php echo base_url('images/staff_icon_48.png'); ?>',
                        labelOrigin: new google.maps.Point(24, 54)
                    },
                });
                marker.poc_id = staff['poc_id'];
                staffMarkers.push(marker);
            } else {
                let lat = parseFloat(staff['lat']);
                let lng = parseFloat(staff['lon']);
                marker.setPosition(new google.maps.LatLng(lat, lng));
            }
            marker.marked = true;
        }
    }

    let newStaffMarkers = [];
    staffMarkers.forEach(function(marker) {
        if (marker.marked) {
            newStaffMarkers.push(marker);
        } else {
            marker.setMap(null);
        }
    });
    staffMarkers = newStaffMarkers;
}

function getStaffLocations() {
    $.ajax({
       url: '<?php echo base_url('geolocation/getStaffLocations/'.$tenant->company_id); ?>',
       dataType: 'json',
       success: function(json) {
           updateStaffMarkers(json);
           setTimeout(getStaffLocations, 10 * 1000);
       },
       error: function(xhr, text) {
           var data = JSON.parse(xhr.responseText);
           console.error(data.message);
       },
   });
}

$(function() {
	$("#gmap").css("height", window.innerHeight - 300);
	$(window).resize(function() {
		if (timer !== false) {
			clearTimeout(timer);
		}
		timer = setTimeout(function() {
			$("#gmap").css("height", window.innerHeight - 300);
			}, 0);
    });

    // google map表示
    let myLatLng = new google.maps.LatLng(35.6811673, 139.7670516);
    let options = {
        zoom: 5,
        center: myLatLng,
        mapTypeId: 'roadmap'
    };
    map = new google.maps.Map(document.getElementById('gmap'), options);

    setTimeout(getStaffLocations, 0);
});
</script>
<?php
$this->load->view('templates/footer', $data);
?>

