<h1 class="page-header">通話記録</h1>
<div class="container-fluid">
  <div class="row">
    <div class="col-md-8">
      <div>○○/○○MB使用中。およそ○○日分の記憶容量が残っています。</div>
      <div><small>※上記記憶容量の計算は、これまでの平均保存容量から割り出した概算でありあくまで目安としてご参考ください。</small></div>
    </div>
    <div class="col-md-4">
      <a href="#" class="btn btn-primary btn-block">MP3ファイルへエクスポート</a>
      <a href="#" class="btn btn-default btn-block">全消去(復元できません)</a>
    </div>
  </div>
</div>
<table class="table table-striped table-condensed table-hover">
  <thead>
    <tr>
      <th>ID</th>
      <th>発信端末名</th>
      <th>着信端末・グループ</th>
      <th>録音開始日時</th>
      <th>コールタイプ</th>
      <th>通話時間</th>
      <th>再生</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>00001</td>
      <td>車載機1</td>
      <td>グループ1</td>
      <td>2015/10/01 10:22:33</td>
      <td>同報呼</td>
      <td>15:00</td>
      <td>
        <a href="#" class="btn btn-success btn-xs glyphicon glyphicon-play"></a>
      </td>
    </tr>
    <tr>
      <td>00001</td>
      <td>車載機1</td>
      <td>グループ1</td>
      <td>2015/10/01 10:22:33</td>
      <td>同報呼</td>
      <td>15:00</td>
      <td>
        <a href="#" class="btn btn-success btn-xs glyphicon glyphicon-play"></a>
      </td>
    </tr>
    <tr>
      <td>00001</td>
      <td>車載機1</td>
      <td>グループ1</td>
      <td>2015/10/01 10:22:33</td>
      <td>同報呼</td>
      <td>15:00</td>
      <td>
        <a href="#" class="btn btn-success btn-xs glyphicon glyphicon-play"></a>
      </td>
    </tr>
  </tobdy>
</table>
