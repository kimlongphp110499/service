<ol class="breadcrumb">
  <li><a href="<?php echo base_url('home'); ?>">ホーム</a></li>
  <li><a href="<?php echo base_url('inquiry/view_list'); ?>">問い合わせ一覧</a></li>
  <li class="active">問い合わせ回答</li>
</ol>

<h2 class="page-header">問い合わせ回答</h2>
     
<table class="table table-condensed table-hover poc-table">
  <tbody>
    <tr>
      <td class="poc-td-right">管理番号</td>
      <td>0003</td>
    </tr>
    <tr>
      <td class="poc-td-right">登録日時</td>
	  <td>2015-12-10 12:00:00</td>
    </tr>
    <tr>
      <td class="poc-td-right">テナント</td>
	  <td>iforce</td>
    </tr>
    <tr>
      <td class="poc-td-right">質問者</td>
	  <td>木本</td>
    </tr>
    <tr>
      <td class="poc-td-right">タイトル</td>
	  <td>発信できない</td>
    </tr>
    <tr>
      <td class="poc-td-right">問い合わせ内容</td>
	  <td>発信できません。</td>
    </tr>
    <tr>
      <td class="poc-td-right">回答者</td>
      <td>
        <input class="form-control input-sm" type="text" name="person" />
      </td>
    </tr>
    <tr>
      <td class="poc-td-right">回答内容</td>
      <td>
        <textarea class="form-control" type="text" name="detail" rows="10"></textarea>
      </td>
    </tr>
  </tbody>
</table>


<div class="text-right">
  <button type="submit" class="btn btn-primary">登録</button>
  <a href="<?php echo base_url('inquiry/view_list'); ?>" class="btn btn-default">キャンセル</a>
</div>
