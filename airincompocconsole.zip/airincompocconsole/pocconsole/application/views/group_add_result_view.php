<?php
$data['username'] = $username;
$data['usermode'] = $usermode;
$data['css'] = 'dummy.css';
$data['menu'] = 'group';

// setup breadcrumb
$breadcrumb = array(
	'ホーム' => 	base_url('home'),
  'グループ一覧' => base_url('pocaccount/view_list/'.$tenant->company_id),
  '新規グループ追加' => false,
);

$data['breadcrumb'] = $breadcrumb;

$this->load->view('templates/header', $data);
$this->load->view('templates/sidemenu', $data);
?>

<?php if (!USE_BREADCRUMB_IN_HEADER && isset($breadcrumb)): ?>
	<ol class="breadcrumb"> <!-- パンくず対応済み -->
<?php
		foreach ($breadcrumb as $_title => $_url) {
			if ($_url) { echo '<li><a href="'.$_url.'">'.$_title.'</a></li>'; }
			else { echo '<li class="active">'.$_title.'</li>'; }
		}
?>
	</ol>
<?php endif ?>

<h2 class="page-header">新規グループ追加</h2>
<h3>テナント: <?php echo $tenant->company_name; ?></h3>
<div class="bg-info">
	 <?php echo count($groups); ?>件のグループを追加しました。グループメニューから[SIP更新]を行ってください。
</div>

  <table class="table table-striped table-condensed poc-table">
    <thead>
      <tr>
        <th>No.</th>
        <th>グループ名</th>
        <th>グループSIP番号</th>
        <th>会議室SIP番号</th>
      </tr>
    </thead>
    <tbody>
	 <?php
	 $count = 1;
	 foreach ($groups as $row) {
	 echo '<tr>';
	 echo '<td>'.$count.'</td>';
	 echo '<td>'.$row['group_name'].'</td>';
	 echo '<td>'.$row['sip_number'].'</td>';
	 echo '<td>'.$row['conf_sip_number'].'</td>';
	 echo '</tr>';
	 $count++;
     }
	 ?>
    </tbody>
  </table>

  <div class="text-right">
    <a href="<?php echo base_url('group/view_list/'.$tenant->company_id); ?>" class="btn btn-default">OK</a>
  </div>

</form>

<?php
$this->load->view('templates/footer', $data);
?>
