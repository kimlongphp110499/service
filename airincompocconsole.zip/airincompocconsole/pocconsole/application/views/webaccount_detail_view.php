<?php
$data['username'] = $username;
$data['usermode'] = $usermode;
$data['css'] = 'dummy.css';
$data['menu'] = 'webaccount';

// setup breadcrumb
$breadcrumb = array(
	'ホーム' => 	base_url('home'),
  'Webアカウント一覧' => base_url('webaccount/view_list'),
  'Webアカウント詳細' => false,
);

$data['breadcrumb'] = $breadcrumb;

$this->load->view('templates/header', $data);
$this->load->view('templates/sidemenu', $data);

global $global_web_account_type_names;

?>

<?php if (!USE_BREADCRUMB_IN_HEADER && isset($breadcrumb)): ?>
	<ol class="breadcrumb"> <!-- パンくず対応済み -->
<?php
		foreach ($breadcrumb as $_title => $_url) {
			if ($_url) { echo '<li><a href="'.$_url.'">'.$_title.'</a></li>'; }
			else { echo '<li class="active">'.$_title.'</li>'; }
		}
?>
	</ol>
<?php endif ?>

<h2 class="page-header">Webアカウント詳細： <?php echo $account->username; ?></h2>

<div class="container-fluid poc-list">
  <div class="row">
    <div class="col-md-3 poc-list-title">ログインID</div>
    <div class="col-md-9"><?php echo $account->login_id; ?></div>
  </div>
  <div class="row">
    <div class="col-md-3 poc-list-title">ユーザー名</div>
    <div class="col-md-9"><?php echo $account->username; ?></div>
  </div>
  <div class="row">
    <div class="col-md-3 poc-list-title">アカウント種別</div>
    <div class="col-md-9"><?php echo ($global_web_account_type_names[empty($account->type) ? 'tenant' : $account->type]); ?></div>
  </div>
<?php if ($account->type == 'tenant_api'): ?>
  <div class="row">
    <div class="col-md-3 poc-list-title">APIキー</div>
    <div class="col-md-9"><?php echo $account->api_key; ?></div>
  </div>
<?php endif; ?>
  <div class="row">
    <div class="col-md-3 poc-list-title">状態</div>
    <div class="col-md-9"><?php echo ($account->status ? '有効' : '無効'); ?></div>
  </div>
  <div class="row">
    <div class="col-md-3 poc-list-title">所属テナント</div>
    <div class="col-md-9"><?php echo $account->company_name; ?></div>
  </div>
  <div class="row">
    <div class="col-md-3 poc-list-title">登録日</div>
    <div class="col-md-9"><?php echo $account->register_date; ?></div>
  </div>
  <div class="row">
    <div class="col-md-3 poc-list-title">更新日</div>
    <div class="col-md-9"><?php echo $account->update_date; ?></div>
  </div>
  <div class="row">
    <div class="col-md-3 poc-list-title">最終ログイン</div>
    <div class="col-md-9"><?php echo $account->last_login; ?></div>
  </div>
</div>

<div class="text-right poc-control-panel">
  <a href="<?php echo base_url('webaccount/edit/'.$account->account_id); ?>" class="btn btn-primary">編集</a>
<?php if ($usermode == 'admin') : ?>
  <button type="button" class="btn btn-default" data-toggle="modal" data-target="#modal">削除</button>
<?php endif ?>
  <a href="<?php echo base_url('webaccount/view_list'); ?>" class="btn btn-default">キャンセル</a>
</div>
     
<!-- modal for deleting tenant -->
<div class="modal fade" id="modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">確認</h4>
      </div>
      <div class="modal-body">
        Webアカウントを削除しますか？
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <a href="<?php echo base_url('webaccount/delete/'.$account->account_id); ?>" class="btn btn-primary">削除</a>
      </div>
    </div>
  </div>
</div>

<?php
$this->load->view('templates/footer', $data);
?>
