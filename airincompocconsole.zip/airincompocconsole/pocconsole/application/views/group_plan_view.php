<?php
$data['username'] = $username;
$data['usermode'] = $usermode;
$data['css'] = 'dummy.css';
$data['menu'] = 'group';

// setup breadcrumb
$breadcrumb = array(
	'ホーム' => 	base_url('home'),
  'グループ一覧' => base_url('group/view_list/'.$tenant->company_id),
  'グループメンバー編集' => false,
);

$data['breadcrumb'] = $breadcrumb;

$this->load->view('templates/header', $data);
$this->load->view('templates/sidemenu', $data);
?>

<?php if (!USE_BREADCRUMB_IN_HEADER && isset($breadcrumb)): ?>
	<ol class="breadcrumb"> <!-- パンくず対応済み -->
<?php
		foreach ($breadcrumb as $_title => $_url) {
			if ($_url) { echo '<li><a href="'.$_url.'">'.$_title.'</a></li>'; }
			else { echo '<li class="active">'.$_title.'</li>'; }
		}
?>
	</ol>
<?php endif ?>

<h2 class="page-header">グループメンバー編集：<?php echo $group->group_name; ?></h2>
<?php echo form_open('group/plan/'.$tenant->company_id.'/'.$group->group_id); ?>

<?php if (!$accounts) : ?>

<div class="poc-message-box">
デバイスが登録されていません。
</div>
<div class="text-right poc-control-panel">
  <a href="<?php echo base_url('group/view_list/'.$tenant->company_id); ?>" class="btn btn-primary">戻る</a>
</div>

<?php else : ?>

<div class="poc-message-box">
このグループに参加させるアカウントにチェックを入れてください。
</div>

<table class="table table-striped table-condensed table-hover poc-table">
  <thead>
    <tr>
      <th width="10%">メンバー</th>
<?php
	 $sorticon = '<span class="glyphicon glyphicon-triangle-'
	 .($order == 'asc' ? 'top' : 'bottom').' poc-icon"></span>';

    // アカウント名
	$dir = ($sortkey == 'username' && $order == 'asc') ? 'desc' : 'asc';
	$param = $tenant->company_id.'/'.$group->group_id.'/username/'.$dir;
	echo '<th><a href="'.base_url('group/plan/'.$param).'">アカウント名 ';
	if ($sortkey == 'username') {
		echo $sorticon;
	}
	echo '</a></th>';

    // 表示名
	$dir = ($sortkey == 'display_name' && $order == 'asc') ? 'desc' : 'asc';
	$param = $tenant->company_id.'/'.$group->group_id.'/display_name/'.$dir;
	echo '<th><a href="'.base_url('group/plan/'.$param).'">表示名 ';
	if ($sortkey == 'display_name') {
		echo $sorticon;
	}
	echo '</a></th>';

    // SIP番号
	$dir = ($sortkey == 'sip_number' && $order == 'asc') ? 'desc' : 'asc';
	$param = $tenant->company_id.'/'.$group->group_id.'/sip_number/'.$dir;
	echo '<th><a href="'.base_url('group/plan/'.$param).'">SIP番号 ';
	if ($sortkey == 'sip_number') {
		echo $sorticon;
	}
	echo '</a></th>';

    // 機種
	$dir = ($sortkey == 'device_name' && $order == 'asc') ? 'desc' : 'asc';
	$param = $tenant->company_id.'/'.$group->group_id.'/device_name/'.$dir;
	echo '<th><a href="'.base_url('group/plan/'.$param).'">使用機種 ';
	if ($sortkey == 'device_name') {
		echo $sorticon;
	}
	echo '</a></th>';

?>
    </tr>
  </thead>
  <tbody>
<?php
         foreach ($accounts as $row) {
             echo '<tr>';
             echo '<td><label><input type="checkbox" name="poc_id[]" class="check" value="'.$row->poc_id.'" ';
             if (in_array($row->poc_id, $group_members)) {
                 echo 'checked ';
             }
             echo '/></label></td>';
             echo '<td>'.$row->username.'</td>';
             echo '<td>'.$row->display_name.'</td>';
             echo '<td>'.$row->sip_number.'</td>';
             echo '<td>'.$row->device_name.'</td>';
             echo '</tr>';
         }
?>
  </tbody>
</table>
<input type="checkbox" id="select_all"> 全選択
  <input type="hidden" name="company_id" value="<?php echo $tenant->company_id; ?>" />
  <div class="text-right poc-control-panel">
    <button type="submit" class="btn btn-primary">保存</button>
    <a href="<?php echo base_url('group/view_list/'.$tenant->company_id); ?>" class="btn btn-default">キャンセル</a>
  </div>

<?php endif ?>

<script>
$(function() {
    $('#select_all').change(function() {
        let checked = $(this).prop('checked');
        $('tbody .check').prop('checked', checked);
    });
});
</script>

<?php
$this->load->view('templates/footer', $data);
?>
