<?php
$data['username'] = $username;
$data['usermode'] = $usermode;
$data['css'] = 'dummy.css';
$data['menu'] = 'webaccount';

// setup breadcrumb
$breadcrumb = array(
	'ホーム' => 	base_url('home'),
	'Webアカウント一覧' => false,
);

$data['breadcrumb'] = $breadcrumb;

$this->load->view('templates/header', $data);
$this->load->view('templates/sidemenu', $data);

global $global_web_account_type_names;

?>

<?php if (!USE_BREADCRUMB_IN_HEADER && isset($breadcrumb)): ?>
	<ol class="breadcrumb"> <!-- パンくず対応済み -->
<?php
		foreach ($breadcrumb as $_title => $_url) {
			if ($_url) { echo '<li><a href="'.$_url.'">'.$_title.'</a></li>'; }
			else { echo '<li class="active">'.$_title.'</li>'; }
		}
?>
	</ol>
<?php endif ?>

<h2 class="page-header">Webアカウント一覧</h2>
<?php if ($usermode == 'admin') : ?>
<div class="text-right">
  <a href="<?php echo base_url('webaccount/add'); ?>" class="btn btn-primary"><span class="glyphicon glyphicon-plus"></span> 新規アカウント追加</a>
</div>
<?php endif ?>
     
<?php
     if ($accounts) {
         $sorticon = '<span class="glyphicon glyphicon-triangle-'
		     .($order == 'asc' ? 'top' : 'bottom').' poc-icon"></span>';

		 echo '登録アカウント数: '.count($accounts);
         echo '<table class="table table-striped table-condensed table-hover poc-table">';
		 echo '<thead>';
		 echo '<tr>';

		 // ログインID
         $dir = ($sortkey == 'login_id' && $order == 'asc') ? 'desc' : 'asc';
		 $param = 'login_id/'.$dir;
         echo '<th><a href="'.base_url('webaccount/view_list/'.$param).'">ログインID ';
		 if ($sortkey == 'login_id') {
			 echo $sorticon;
		 }
		 echo '</a></th>';

		 // ユーザー名
         $dir = ($sortkey == 'username' && $order == 'asc') ? 'desc' : 'asc';
		 $param = 'username/'.$dir;
         echo '<th><a href="'.base_url('webaccount/view_list/'.$param).'">ユーザー名 ';
		 if ($sortkey == 'username') {
			 echo $sorticon;
		 }
		 echo '</a></th>';

		 // 種別
         $dir = ($sortkey == 'type' && $order == 'asc') ? 'desc' : 'asc';
		 $param = 'type/'.$dir;
         echo '<th><a href="'.base_url('webaccount/view_list/'.$param).'">種別 ';
		 if ($sortkey == 'type') {
			 echo $sorticon;
		 }
		 echo '</a></th>';

		 // 所属テナント
		 if ($usermode == 'admin') {
			 $dir = ($sortkey == 'company_id' && $order == 'asc') ? 'desc' : 'asc';
			 $param = 'company_id/'.$dir;
			 echo '<th><a href="'.base_url('webaccount/view_list/'.$param).'">所属テナント ';
			 if ($sortkey == 'company_id') {
				 echo $sorticon;
			 }
			 echo '</a></th>';
		 }

		 // 最終ログイン
		 $dir = ($sortkey == 'last_login' && $order == 'asc') ? 'desc' : 'asc';
		 $param = 'last_login/'.$dir;
		 echo '<th><a href="'.base_url('webaccount/view_list/'.$param).'">最終ログイン ';
		 if ($sortkey == 'last_login') {
			 echo $sorticon;
		 }
		 echo '</a></th>';

		 // 状態
         $dir = ($sortkey == 'status' && $order == 'asc') ? 'desc' : 'asc';
		 $param = 'status/'.$dir;
         echo '<th><a href="'.base_url('webaccount/view_list/'.$param).'">状態 ';
		 if ($sortkey == 'status') {
			 echo $sorticon;
		 }
		 echo '</a></th>';

		 echo '</tr>';
		 echo '</thead>';
		 echo '<tbody>';

         foreach ($accounts as $row) {
             echo '<tr>';
             echo '<td><a href="'.base_url('webaccount/view/'.$row->account_id).'"/a>'.$row->login_id.'</a></td>';
             echo '<td>'.$row->username.'</td>';
			 // now "$row->type" cannot be NULL but for safety
             echo '<td>'.($global_web_account_type_names[empty($row->type) ? 'tenant' : $row->type]).'</td>';
			 if ($usermode == 'admin') {
                 echo '<td>'.$row->company_name.'</td>';
             }
			 echo '<td>'.$row->last_login.'</td>';
             if ($row->status) {
                 echo '<td><span class="glyphicon glyphicon-ok poc-icon-ok"></span> 有効</span></td>';
             }
             else {
                 echo '<td><span class="glyphicon glyphicon-remove poc-icon-ng"></span> 無効</td>';
             }
             echo '</tr>';
         }
         
         echo '</tbody></table>';
		 echo '<div class="text-right">';
		 echo '<a href="'.base_url('webaccount/export').'" class="btn btn-sm btn-default"><span class="glyphicon glyphicon-save"></span> CSVエクスポート</a>';
		 echo '</div>';
     }
     else {
         echo "登録されたアカウントはありません。";
     }
?>

<?php
$this->load->view('templates/footer', $data);
?>
