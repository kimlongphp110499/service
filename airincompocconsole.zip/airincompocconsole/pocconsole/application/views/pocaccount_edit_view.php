<?php
$data['username'] = $username;
$data['usermode'] = $usermode;
$data['css'] = 'dummy.css';
$data['menu'] = 'pocaccount';

// setup breadcrumb
$breadcrumb = array(
	'ホーム' => 	base_url('home'),
  'アカウント一覧' => base_url('pocaccount/view_list/'.$tenant->company_id),
  'アカウント詳細' => base_url('pocaccount/view/'.$tenant->company_id.'/'.$account->poc_id),
  'アカウント編集' => false,
);

$data['breadcrumb'] = $breadcrumb;

$this->load->view('templates/header', $data);
$this->load->view('templates/sidemenu', $data);
?>

<?php if (!USE_BREADCRUMB_IN_HEADER && isset($breadcrumb)): ?>
	<ol class="breadcrumb"> <!-- パンくず対応済み -->
<?php
		foreach ($breadcrumb as $_title => $_url) {
			if ($_url) { echo '<li><a href="'.$_url.'">'.$_title.'</a></li>'; }
			else { echo '<li class="active">'.$_title.'</li>'; }
		}
?>
	</ol>
<?php endif ?>

<h2 class="page-header">アカウント編集：<?php echo $account->username; ?></h2>
<?php echo form_open('pocaccount/edit/'.$tenant->company_id.'/'.$account->poc_id); ?>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">基本設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="form-horizontal">

      <div class="form-group">
        <label class="control-label col-md-4" for="username">アカウント名</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="username" name="username" value="<?php echo set_value('username', $account->username); ?>"/>
	      <?php echo form_error('username'); ?>
        アカウント名は英文字から始まるシステムでユニークな4文字から16文字までの半角英数字が有効です(英大文字小文字を区別します)
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-4" for="display_name">表示名</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="display_name" name="display_name" value="<?php echo set_value('display_name', $account->display_name); ?>"/>
          <?php echo form_error('display_name'); ?>
          表示名はテナント内でユニークな7文字以上50文字以下の文字列です
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-4" for="passord">パスワード</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="password" id="password" name="password"/>
          <?php echo form_error('password'); ?>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-4" for="confirm">パスワード(確認)</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="password" id="confirm" name="confirm"/>
          <?php echo form_error('confirm'); ?>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-4">使用機種</label>
        <div class="col-md-8">
          <div class="form-control-static"><?php echo $account->device_name; ?></div>
          <input type="hidden" id="device_id" name="device_id" value="<?php echo $account->device_id; ?>" />
        </div>
      </div>
<!--1/12・SIPサーバードメイン・SIPサーバーポート番号を非表示に修正-->
<!--
<?php if ($usermode == 'admin') : ?>
      <div class="form-group">
        <label class="control-label col-md-4" for="sip_server_domain">SIPサーバードメイン</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="sip_server_domain" name="sip_server_domain" value="<?php echo set_value('sip_server_domain', $account->sip_server_domain); ?>"/>
          <?php echo form_error('sip_server_domain'); ?>
        </div>
      </div>
<?php else : ?>
      <input type="hidden" name="sip_server_domain" value="<?php echo $account->sip_server_domain; ?>" />
<?php endif ?>

<?php if ($usermode == 'admin') : ?>
      <div class="form-group">
        <label class="control-label col-md-4" for="sip_port">SIPサーバーポート番号</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="sip_port" name="sip_port" value="<?php echo set_value('sip_port', $account->sip_port); ?>"/>
          <?php echo form_error('sip_port'); ?>
        </div>
      </div>
<?php else : ?>
      <input type="hidden" name="sip_port" value="<?php echo $account->sip_port; ?>" />
<?php endif ?>
-->
      <div class="form-group">
        <label class="control-label col-md-4" for="sip_number">SIP番号</label>
        <div class="col-md-8">
<?php if ($usermode == 'admin') : ?>
          <input class="form-control input-sm" type="text" id="sip_number" name="sip_number" value="<?php echo set_value('sip_number', $account->sip_number); ?>"/>
          <?php echo form_error('sip_number'); ?>
          SIP番号は10桁の数字が有効です。
<?php else : ?>
          <div class="form-control-static"><?php echo $account->sip_number; ?></div>
          <input type="hidden" id="sip_number" name="sip_number" value="<?php echo $account->sip_number; ?>" />
<?php endif ?>
        </div>
      </div>

<?php if ($account->device_id == DEVICE_ISM) : ?>
      <div class="form-group">
        <label class="control-label col-md-4" for="mac_address">MACアドレス</label>
        <div class="col-md-8">
<?php if ($usermode == 'admin') : ?>
          <input class="form-control input-sm" type="text" id="mac_address" name="mac_address" value="<?php echo set_value('mac_address', $account->mac_address); ?>"/>
          <?php echo form_error('mac_address'); ?>
<?php else : ?>
          <div class="form-control-static"><?php echo $account->mac_address; ?></div>
          <input type="hidden" name="mac_address" value="<?php echo $account->mac_address; ?>" />
        </div>
      </div>
<?php endif ?>
<?php endif ?>

<?php if ($account->device_id == DEVICE_HDY) : ?>
      <div class="form-group">
        <label class="control-label col-md-4" for="imei">IMEI</label>
        <div class="col-md-8">
<?php if ($usermode == 'admin') : ?>
          <input class="form-control input-sm" type="text" id="imei" name="imei" value="<?php echo set_value('imei', $account->imei); ?>"/>
          <?php echo form_error('imei'); ?>
<?php else : ?>
          <div class="form-control-static"><?php echo $account->imei; ?></div>
          <input type="hidden" name="imei" value="<?php echo $account->imei; ?>" />
<?php endif ?>
        </div>
      </div>
<?php endif ?>

      <div class="form-group">
		   <label class="control-label col-md-4" for="use_srtp">音声通話暗号化(TLS+SRTP)</label>
        <div class="col-md-8">
<?php if ($account->device_id != DEVICE_HDY) : ?>
          <div class="form-control-static">無効</div>
          <input type="hidden" id="use_srtp" name="use_srtp" value="0" />
<?php elseif ($usermode == 'admin') : ?>
          <label calss="radio-inline">
            <input type="radio" name="use_srtp" value="1" <?php echo set_radio('use_srtp', '1', $account->use_srtp == 1 ? TRUE : FALSE); ?> /> 有効
          </label>
          <label calss="radio-inline">
            <input type="radio" name="use_srtp" value="0" <?php echo set_radio('use_srtp', '0', $account->use_srtp == 0 ? TRUE : FALSE); ?> /> 無効
          </label>
          <?php echo form_error('use_srtp'); ?>
<?php else : ?>
          <div class="form-control-static">
            <?php echo $account->use_srtp
                      ? '<span class="glyphicon glyphicon-ok poc-icon-ok"></span> 有効'
	                  : '<span class="glyphicon glyphicon-remove poc-icon-ng"></span> 無効'; ?>
          </div>
          <input type="hidden" id="use_srtp" name="use_srtp" value="<?php echo $account->use_srtp; ?>" />
<?php endif ?>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-4">状態</label>
        <div class="col-md-8">
          <label calss="radio-inline">
            <input type="radio" name="status" value="1" <?php echo set_radio('status', '1', $account->status == 1 ? TRUE : FALSE); ?> /> 有効
          </label>
          <label calss="radio-inline">
            <input type="radio" name="status" value="0" <?php echo set_radio('status', '0', $account->status == 0 ? TRUE : FALSE); ?> /> 無効
          </label>
          <?php echo form_error('status'); ?>
        </div>
      </div>

    </div>
  </div>
</div>

<?php if ($account->device_id == DEVICE_HDY) : ?>
<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">DJCP100設定</h3>
  </div>
	<div class="panel-body poc-panel-body">
		<div class="container-fluid poc-list">
			<a href="<?php echo base_url('pocaccount/handy_edit/'.$tenant->company_id.'/'.$account->poc_id); ?>" class="btn btn-default">アカウント別設定編集</a>
		</div>
      <p />
	  <p>テナント共通の設定は「デバイス設定」メニューから行います。</p>
	</div>
</div>
<?php endif ?>

<?php if ($account->device_id == DEVICE_SPT) : ?>
<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">Air-InCom.設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="form-horizontal">

      <div class="form-group">
        <label class="control-label col-md-4" for="gps_interval">GPSデータ送信間隔</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="gps_interval" name="gps_interval" value="<?php echo set_value('gps_interval', $account->gps_interval); ?>"/>
          <?php echo form_error('gps_interval'); ?>
        </div>
      </div>

      <!--<div class="form-group">
        <label class="control-label col-md-4" for="bluetooth_interval">Bluetooth間隔</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="bluetooth_interval" name="bluetooth_interval" value="<?php echo set_value('bluetooth_interval', $account->bluetooth_interval); ?>"/>
          <?php echo form_error('bluetooth_interval'); ?>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-4" for="bluetooth_rssi_threshold">Bluetooth RSSI閾値</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="bluetooth_rssi_threshold" name="bluetooth_rssi_threshold" value="<?php echo set_value('bluetooth_rssi_threshold', $account->bluetooth_rssi_threshold); ?>"/>
          <?php echo form_error('bluetooth_rssi_threshold'); ?>
        </div>
      </div>-->

<?php if ($usermode == 'admin') : ?>
      <div class="form-group">
        <label class="control-label col-md-4" for="xmpp_server_domain">XMPPサーバーホスト名</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="xmpp_server_domain" name="xmpp_server_domain" value="<?php echo set_value('xmpp_server_domain', $account->xmpp_server_domain); ?>"/>
          <?php echo form_error('xmpp_server_domain'); ?>
        </div>
      </div>
<?php else : ?>
      <input type="hidden" name="xmpp_server_domain" value="<?php echo $account->xmpp_server_domain; ?>"/>
<?php endif ?>

<?php if ($usermode == 'admin') : ?>
      <div class="form-group">
        <label class="control-label col-md-4" for="xmpp_port">XMPPサーバーポート番号</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="xmpp_port" name="xmpp_port" value="<?php echo set_value('xmpp_port', $account->xmpp_port); ?>"/>
          <?php echo form_error('xmpp_port'); ?>
        </div>
      </div>
<?php else : ?>
      <input type="hidden" name="xmpp_port" value="<?php echo $account->xmpp_port; ?>"/>
<?php endif ?>

<?php if ($usermode == 'admin') : ?>
      <div class="form-group">
        <label class="control-label col-md-4" for="xmpp_service_name">XMPPサービス名</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="xmpp_service_name" name="xmpp_service_name" value="<?php echo set_value('xmpp_service_name', $account->xmpp_service_name); ?>"/>
          <?php echo form_error('xmpp_service_name'); ?>
        </div>
      </div>
<?php else : ?>
      <input type="hidden" name="xmpp_service_name" value="<?php echo $account->xmpp_service_name; ?>"/>
<?php endif ?>

<?php if ($usermode == 'admin') : ?>
      <div class="form-group">
        <label class="control-label col-md-4" for="xmpp_username">XMPPユーザー名</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="xmpp_username" name="xmpp_username" value="<?php echo set_value('xmpp_username', $account->xmpp_username); ?>"/>
          <?php echo form_error('xmpp_username'); ?>
        </div>
      </div>
<?php else : ?>
      <input type="hidden" name="xmpp_username" value="<?php echo $account->xmpp_username; ?>"/>
<?php endif ?>

<?php if ($usermode == 'admin') : ?>
      <div class="form-group">
        <label class="control-label col-md-4" for="xmpp_password">XMPPパスワード</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="xmpp_password" name="xmpp_password" value="<?php echo set_value('xmpp_password', $account->xmpp_password); ?>"/>
          <?php echo form_error('xmpp_password'); ?>
        </div>
      </div>
<?php else : ?>
      <input type="hidden" name="xmpp_password" value="<?php echo $account->xmpp_password; ?>"/>
<?php endif ?>

      <div class="form-group">
        <label class="control-label col-md-4" for="send_image_interval">画像送信間隔</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="send_image_interval" name="send_image_interval" value="<?php echo set_value('send_image_interval', $account->send_image_interval); ?>"/>
          <?php echo form_error('send_image_interval'); ?>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-4" for="send_image_quality">画像品質</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="send_image_quality" name="send_image_quality" value="<?php echo set_value('send_image_quality', $account->send_image_quality); ?>"/>
          <?php echo form_error('send_image_quality'); ?>
        </div>
      </div>
    </div>
  </div>
</div>
<?php endif ?>

<?php if ($account->device_id == DEVICE_ISM) : ?>
<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">ISM-101設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="form-horizontal">

      <div class="form-group">
        <label class="control-label col-md-4" for="call1">MODE1発信先番号</label>
        <div class="col-md-8">
          <select name="call1" class="form-control">
            <option value="">(設定なし)</option>
          <?php
          foreach ($contacts as $row) {
             echo '<option value="'.$row['sip_number'].'" '
			 .set_select('call1', $row['sip_number'], $account->call1 == $row['sip_number'] ? TRUE : FALSE)
			 .'>'.$row['name'].' ('.$row['sip_number'].')'
             .'</option>';
          }
          ?>
          </select>
          <?php echo form_error('call1'); ?>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-4" for="call2">MODE2発信先番号</label>
        <div class="col-md-8">
          <select name="call2" class="form-control">
            <option value="">(設定なし)</option>
          <?php
          foreach ($contacts as $row) {
             echo '<option value="'.$row['sip_number'].'" '
			 .set_select('call2', $row['sip_number'], $account->call2 == $row['sip_number'] ? TRUE : FALSE)
			 .'>'.$row['name'].' ('.$row['sip_number'].')'
             .'</option>';
          }
          ?>
          </select>
          <?php echo form_error('call2'); ?>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-4" for="call3">MODE3発信先番号</label>
        <div class="col-md-8">
          <select name="call3" class="form-control">
            <option value="">(設定なし)</option>
          <?php
          foreach ($contacts as $row) {
             echo '<option value="'.$row['sip_number'].'" '
			 .set_select('call3', $row['sip_number'], $account->call3 == $row['sip_number'] ? TRUE : FALSE)
			 .'>'.$row['name'].' ('.$row['sip_number'].')'
             .'</option>';
          }
          ?>
          </select>
          <?php echo form_error('call3'); ?>
        </div>
      </div>

<!--
      <div class="form-group">
        <label class="control-label col-md-4" for="geomode">GPS測位モード</label>
        <div class="col-md-8">
          <select name="geomode" class="form-control">
            <option value="0" <?php echo set_select('geomode', 0, $account->geomode == 0 ? TRUE : FALSE); ?>>SET-Based方式</option>
            <option value="1" <?php echo set_select('geomode', 1, $account->geomode == 1 ? TRUE : FALSE); ?>>Auto方式</option>
            <option value="2" <?php echo set_select('geomode', 2, $account->geomode == 2 ? TRUE : FALSE); ?>>SET-Assisted方式</option>
            <option value="3" <?php echo set_select('geomode', 3, $account->geomode == 3 ? TRUE : FALSE); ?>>Standalone方式</option>
          </select>
          <?php echo form_error('geomode'); ?>
        </div>
      </div>
-->

      <div class="form-group">
        <label class="control-label col-md-4" for="geointerval">GPS測位間隔時間</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="geointerval" name="geointerval" value="<?php echo set_value('geointerval', $account->geointerval); ?>"/>
          <?php echo form_error('geointerval'); ?>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-4" for="geodistance">GPS測位間隔距離</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="geodistance" name="geodistance" value="<?php echo set_value('geodistance', $account->geodistance); ?>"/>
          <?php echo form_error('geodistance'); ?>
        </div>
      </div>

      <!--
      <div class="form-group">
        <label class="control-label col-md-4" for="callbacktimer">コールバックタイマー</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="callbacktimer" name="callbacktimer" value="<?php echo set_value('callbacktimer', $account->callbacktimer); ?>"/>
          <?php echo form_error('callbacktimer'); ?>
        </div>
      </div>
      -->

      <div class="form-group">
        <label class="control-label col-md-4" for="newvoicemail">不在伝言再生番号</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="newvoicemail" name="newvoicemail" value="<?php echo set_value('newvoicemail', $account->newvoicemail); ?>"/>
          <?php echo form_error('newvoicemail'); ?>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-4" for="novoicemail">ラストコール再生番号</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="novoicemail" name="novoicemail" value="<?php echo set_value('novoicemail', $account->novoicemail); ?>"/>
          <?php echo form_error('novoicemail'); ?>
        </div>
      </div>

      <!--
      <div class="form-group">
        <label class="control-label col-md-4" for="mic">マイク音量</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="mic" name="mic" value="<?php echo set_value('mic', $account->mic); ?>"/>
          <?php echo form_error('mic'); ?>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-4" for="speaker">スピーカー音量</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="speaker" name="speaker" value="<?php echo set_value('speaker', $account->speaker); ?>"/>
          <?php echo form_error('speaker'); ?>
        </div>
      </div>
      -->

      <div class="form-group">
        <label class="control-label col-md-4" for="gpsurl">GPSデータ送信先URL</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="gpsurl" name="gpsurl" value="<?php echo set_value('gpsurl', $account->gpsurl); ?>"/>
          <?php echo form_error('gpsurl'); ?>
        </div>
      </div>

      <!--
      <div class="form-group">
        <label class="control-label col-md-4" for="fw_update">ファーム更新</label>
        <div class="col-md-8">
          <label calss="radio-inline">
            <input type="radio" name="fw_update" value="1" <?php echo set_radio('fw_update', '1', $account->fw_update == 1 ? TRUE : FALSE); ?> /> する
          </label>
          <label calss="radio-inline">
            <input type="radio" name="fw_update" value="0" <?php echo set_radio('fw_update', '0', $account->fw_update == 0 ? TRUE : FALSE); ?> /> しない
          </label>
          <?php echo form_error('use_srtp'); ?>
        </div>
      </div>
      -->
      <input type="hidden" name="fw_update" value="1" />

      <div class="form-group">
        <label class="control-label col-md-4" for="appversion">アプリバージョン</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="appversion" name="appversion" value="<?php echo set_value('appversion', $account->appversion); ?>"/>
          <?php echo form_error('appversion'); ?>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-4" for="apppath">アプリパス</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="apppath" name="apppath" value="<?php echo set_value('apppath', $account->apppath); ?>"/>
          <?php echo form_error('apppath'); ?>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-4" for="kernelversion">カーネルバージョン</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="kernelversion" name="kernelversion" value="<?php echo set_value('kernelversion', $account->kernelversion); ?>"/>
          <?php echo form_error('kernelversion'); ?>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-4" for="kernelpath">カーネルパス</label>
        <div class="col-md-8">
          <input class="form-control input-sm" type="text" id="kernelpath" name="kernelpath" value="<?php echo set_value('kernelpath', $account->kernelpath); ?>"/>
          <?php echo form_error('kernelpath'); ?>
        </div>
      </div>
    </div>
  </div>
</div>
<?php endif ?>

  <input type="hidden" name="company_id" value="<?php echo $tenant->company_id; ?>" />

  <div class="text-right poc-control-panel">
    <button type="submit" class="btn btn-primary">保存</button>
    <a href="<?php echo base_url('pocaccount/view/'.$tenant->company_id.'/'.$account->poc_id); ?>" class="btn btn-default">キャンセル</a>
  </div>
</form>

<?php
$this->load->view('templates/footer', $data);
?>
