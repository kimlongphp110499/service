<?php
$data['username'] = $username;
$data['usermode'] = $usermode;
$data['css'] = 'dummy.css';
$data['menu'] = 'dialplan';

// setup breadcrumb
$breadcrumb = array(
	'ホーム' => 	base_url('home'),
	'緊急呼出' => false,
);

$data['breadcrumb'] = $breadcrumb;

$this->load->view('templates/header', $data);
$this->load->view('templates/sidemenu', $data);
?>

<?php if (!USE_BREADCRUMB_IN_HEADER && isset($breadcrumb)): ?>
	<ol class="breadcrumb"> <!-- パンくず対応済み -->
<?php
		foreach ($breadcrumb as $_title => $_url) {
			if ($_url) { echo '<li><a href="'.$_url.'">'.$_title.'</a></li>'; }
			else { echo '<li class="active">'.$_title.'</li>'; }
		}
?>
	</ol>
<?php endif ?>

<h2 class="page-header">緊急呼出設定：<?php echo $tenant->company_name; ?></h2>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">緊急呼出時の発信先選択</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">
<!--
      <div class="row">
        <div class="col-md-4 poc-list-title">ノーマル用 発信先アカウント</div>
        <div class="col-md-8"><?php echo (empty($emergency_sip_normal_name->display_name) ? '(未設定)' : $emergency_sip_normal_name->display_name); ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">モニター用 発信先アカウント</div>
        <div class="col-md-8"><?php echo (empty($emergency_sip_monitor_name->display_name) ? '(未設定)' : $emergency_sip_monitor_name->display_name); ?></div>
      </div>
-->
      <div class="row">
        <div class="col-md-4 poc-list-title">発信先</div>
        <div class="col-md-8"><?php echo (empty($emergency_sip_group_name->group_name) ? '(未設定)' : $emergency_sip_group_name->group_name); ?></div>
      </div>
    </div>
  </div>
</div>

<div class="text-right poc-control-panel">
  <a href="<?php echo base_url('dialplan/edit/'.$tenant->company_id); ?>" class="btn btn-primary">編集</a>
<?php if ($usermode == 'admin') : ?>
  <a href="<?php echo base_url('dialplan/view/0'); ?>" class="btn btn-default">キャンセル</a>
<?php endif ?>
</div>

<?php
$this->load->view('templates/footer', $data);
?>
     
