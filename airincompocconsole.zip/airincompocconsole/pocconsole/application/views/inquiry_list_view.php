<ol class="breadcrumb">
  <li><a href="<?php echo base_url('home'); ?>">ホーム</a></li>
  <li class="active">問い合わせ一覧</li>
</ol>

<h2 class="page-header">問い合わせ一覧</h2>
     
<p>
未回答の問い合わせがxx件あります。
</p>
<table class="table table-striped table-condensed table-hover poc-table">
  <thead>
    <tr>
      <th>管理番号</th>
      <th>登録日時</th>
      <th>テナント</th>
      <th>タイトル</th>
      <th>対処</th>
    </tr>
  </thead>
  <tbody>
    <tr>
	  <td>00003</td>
	  <td>2015-12-10 12:00:00</td>
      <td>iforce</td>
      <td>発信できない</td>
      <td><a href="<?php echo base_url('inquiry/answer/3'); ?>" class="btn btn-warning btn-sm">回答</a></td>
    </tr>
    <tr>
	  <td>00002</td>
	  <td>2015-12-10 13:00:00</td>
      <td>iforce</td>
      <td>着信できない</td>
      <td>回答済み</td>
    </tr>
    <tr>
	  <td>00001</td>
	  <td>2015-12-10 13:00:00</td>
      <td>iforce</td>
      <td>グループの最大数</td>
      <td>回答済み</td>
    </tr>
  </tbody>
</table>
<div class="text-right">
<a href="#" class="btn btn-sm btn-default"><span class="glyphicon glyphicon-save"></span> エクスポート</a>
</div>
