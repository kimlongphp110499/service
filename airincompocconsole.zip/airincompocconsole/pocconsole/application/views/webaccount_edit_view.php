<?php
$data['username'] = $username;
$data['usermode'] = $usermode;
$data['css'] = 'dummy.css';
$data['menu'] = 'webaccount';

// setup breadcrumb
$breadcrumb = array(
	'ホーム' => 	base_url('home'),
  'Webアカウント一覧' => base_url('webaccount/view_list'),
  'Webアカウント詳細' => base_url('webaccount/view/'.$account->account_id),
  'Webアカウント編集' => false,
);

$data['breadcrumb'] = $breadcrumb;

$this->load->view('templates/header', $data);
$this->load->view('templates/sidemenu', $data);

global $global_web_account_type_names;

?>

<?php if (!USE_BREADCRUMB_IN_HEADER && isset($breadcrumb)): ?>
	<ol class="breadcrumb"> <!-- パンくず対応済み -->
<?php
		foreach ($breadcrumb as $_title => $_url) {
			if ($_url) { echo '<li><a href="'.$_url.'">'.$_title.'</a></li>'; }
			else { echo '<li class="active">'.$_title.'</li>'; }
		}
?>
	</ol>
<?php endif ?>

<h2 class="page-header">Webアカウント編集： <?php echo $account->username; ?></h2>

<?php echo form_open('webaccount/edit/'.$account->account_id); ?>


  <div class="form-horizontal">

<?php if ($account->type == 'tenant_api'): ?>
    <div class="form-group">
      <div class="col-md-9">以下のAPI用テナントパスワードを変更すると、APIキーは再生成されます。</div>
    </div>
<?php endif; ?>

    <div class="form-group">
      <label class="control-label col-md-3">ログインID</label>
      <div class="col-md-9">
        <div class="form-control-static"><?php echo $account->login_id; ?></div>
        <input type="hidden" name="login_id" value="<?php echo $account->login_id; ?>"/>
      </div>
    </div>

    <div class="form-group">
      <label class="control-label col-md-3" for="username">ユーザー名</label>
      <div class="col-md-9">
        <input class="form-control input-sm" type="text" id="username" name="username" value="<?php echo set_value('username', $account->username); ?>"/>
	    <?php echo form_error('username'); ?>
      </div>
    </div>

    <div class="form-group">
      <label class="control-label col-md-3" for="passord">パスワード</label>
      <div class="col-md-9">
        <input class="form-control input-sm" type="password" id="password" name="password"/>
	    <?php echo form_error('password'); ?>
      </div>
    </div>

    <div class="form-group">
      <label class="control-label col-md-3" for="confirm">パスワード(確認)</label>
      <div class="col-md-9">
        <input class="form-control input-sm" type="password" id="confirm" name="confirm"/>
	    <?php echo form_error('confirm'); ?>
      </div>
    </div>

    <div class="form-group">
      <label class="control-label col-md-3">アカウント種別</label>
      <div class="col-md-9">
      	<div class="form-control-static"><?php echo ($global_web_account_type_names[empty($account->type) ? 'tenant' : $account->type]); ?></div>
        <input type="hidden" name="type" value="<?php echo (empty($account->type) ? 'tenant' : $account->type); ?>" />
      </div>
    </div>

    <div class="form-group">
      <label class="control-label col-md-3">状態</label>
      <div class="col-md-9">
        <label calss="radio-inline">
          <input type="radio" name="status" value="1" <?php echo set_radio('status', '1', $account->status ? TRUE : FALSE); ?> /> 有効
        </label>
        <label calss="radio-inline">
          <input type="radio" name="status" value="0"  <?php echo set_radio('status', '0', !$account->status ? TRUE : FALSE); ?> /> 無効
        </label>
        <?php echo form_error('status'); ?>
      </div>
    </div>

<?php if ($usermode == 'admin') : ?>
    <div class="form-group">
      <label class="control-label col-md-3">所属テナント</label>
      <div class="col-md-9">
        <div class="form-control-static"><?php echo $account->company_name; ?></div>
        <input type="hidden" name="company_name" value="<?php echo $account->company_name; ?>"/>
      </div>
    </div>
<?php endif ?>

  <div class="text-right poc-control-panel">
    <button type="submit" class="btn btn-primary">保存</button>
    <a href="<?php echo base_url('webaccount/view/'.$account->account_id); ?>" class="btn btn-default">キャンセル</a>
  </div>
</form>

<?php
$this->load->view('templates/footer', $data);
?>
