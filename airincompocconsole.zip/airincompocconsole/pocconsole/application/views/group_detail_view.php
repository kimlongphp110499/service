<?php
$data['username'] = $username;
$data['usermode'] = $usermode;
$data['css'] = 'dummy.css';
$data['menu'] = 'group';

// setup breadcrumb
$breadcrumb = array(
	'ホーム' => 	base_url('home'),
  'グループ一覧' => base_url('group/view_list/'.$tenant->company_id),
  'グループ詳細' => false,
);

$data['breadcrumb'] = $breadcrumb;

$this->load->view('templates/header', $data);
$this->load->view('templates/sidemenu', $data);
?>

<?php if (!USE_BREADCRUMB_IN_HEADER && isset($breadcrumb)): ?>
	<ol class="breadcrumb"> <!-- パンくず対応済み -->
<?php
		foreach ($breadcrumb as $_title => $_url) {
			if ($_url) { echo '<li><a href="'.$_url.'">'.$_title.'</a></li>'; }
			else { echo '<li class="active">'.$_title.'</li>'; }
		}
?>
	</ol>
<?php endif ?>

<h2 class="page-header">グループ詳細：<?php echo $group->group_name; ?></h2>

<div class="container-fluid poc-list">
  <div class="row">
    <div class="col-md-3 poc-list-title">グループSIP番号</div>
    <div class="col-md-9"><?php echo $group->sip_number; ?></div>
  </div>
  <div class="row">
    <div class="col-md-3 poc-list-title">会議室SIP番号</div>
    <div class="col-md-9"><?php echo $group->conf_sip_number; ?></div>
  </div>
  <div class="row">
    <div class="col-md-3 poc-list-title">状態</div>
    <div class="col-md-9"><?php echo ($group->status ? '有効' : '無効'); ?></div>
  </div>
  <div class="row">
    <div class="col-md-3 poc-list-title">登録日</div>
    <div class="col-md-9"><?php echo $group->register_date; ?></div>
  </div>
  <div class="row">
    <div class="col-md-3 poc-list-title">更新日</div>
    <div class="col-md-9"><?php echo $group->update_date; ?></div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">メンバー</h3>
  </div>
  <div class="panel-body">
<?php if (empty($members)) : ?>
    登録されていません。
<?php endif ?>
  </div>
  <table class="table table-striped table-condensed">
      <thead>
        <tr>
<?php
	$sorticon = '<span class="glyphicon glyphicon-triangle-'
		.($order == 'asc' ? 'top' : 'bottom').' poc-icon"></span>';

    // アカウント名
    $dir = ($sortkey == 'username' && $order == 'asc') ? 'desc' : 'asc';
    $param = $tenant->company_id.'/'.$group->group_id.'/username/'.$dir;
    echo '<th><a href="'.base_url('group/view/'.$param).'">アカウント名 ';
    if ($sortkey == 'username') {
        echo $sorticon;
    }
    echo '</a></th>';
    
    // 表示名
    $dir = ($sortkey == 'display_name' && $order == 'asc') ? 'desc' : 'asc';
    $param = $tenant->company_id.'/'.$group->group_id.'/display_name/'.$dir;
    echo '<th><a href="'.base_url('group/view/'.$param).'">表示名 ';
    if ($sortkey == 'display_name') {
        echo $sorticon;
    }
    echo '</a></th>';
    
    // SIP番号
    $dir = ($sortkey == 'sip_number' && $order == 'asc') ? 'desc' : 'asc';
    $param = $tenant->company_id.'/'.$group->group_id.'/sip_number/'.$dir;
    echo '<th><a href="'.base_url('group/view/'.$param).'">SIP番号 ';
    if ($sortkey == 'sip_number') {
        echo $sorticon;
    }
    echo '</a></th>';
    
    // 機種
    $dir = ($sortkey == 'device_name' && $order == 'asc') ? 'desc' : 'asc';
    $param = $tenant->company_id.'/'.$group->group_id.'/device_name/'.$dir;
    echo '<th><a href="'.base_url('group/view/'.$param).'">使用機種 ';
    if ($sortkey == 'device_name') {
        echo $sorticon;
    }
    echo '</a></th>';
    
?>
        </tr>
      </thead>
      <tbody>
<?php
	 foreach ($members as $row) {
	     echo '<tr>';
	     echo '<td>'.$row->username.'</td>';
	     echo '<td>'.$row->display_name.'</td>';
	     echo '<td>'.$row->sip_number.'</td>';
	     echo '<td>'.$row->device_name.'</td>';
	     echo '</tr>';
     }
?>
      </tbody>
  </table>
</div>

<div class="text-right poc-control-panel">
  <a href="<?php echo base_url('group/edit/'.$tenant->company_id.'/'.$group->group_id); ?>" class="btn btn-primary">編集</a>
<?php if ($usermode == 'admin') : ?>
  <button type="button" class="btn btn-default" data-toggle="modal" data-target="#modal">削除</button>
<?php endif ?>
  <a href="<?php echo base_url('group/view_list/'.$tenant->company_id); ?>" class="btn btn-default">キャンセル</a>
</div>

<!-- modal for deleting PoC Account -->
<div class="modal fade" id="modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">確認</h4>
      </div>
      <div class="modal-body">
        グループを削除しますか？
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <a href="<?php echo base_url('group/delete/'.$tenant->company_id.'/'.$group->group_id); ?>" class="btn btn-primary">削除</a>
      </div>
    </div>
  </div>
</div>

<?php
$this->load->view('templates/footer', $data);
?>
     
