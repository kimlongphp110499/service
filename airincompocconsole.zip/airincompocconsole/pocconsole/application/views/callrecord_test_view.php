<?php
$data['username'] = 'test';
$data['usermode'] = 'admin';
$data['css'] = 'dummy.css';
$data['menu'] = 'callrecord';
$this->load->view('templates/header', $data);
$this->load->view('templates/sidemenu', $data);

$request_url = $default_value->request_url;
?>

Base URL = <?php echo $request_url; ?>


<div>
    <div class="row">
        <div>ファイル名</div>
        <div>
        <input type="text" size="50" id="filename" value="<?php echo set_value('filename', $default_value->filename); ?>"/>
        </div>
    </div>
</div>

<button type="button" onclick="play_record()" data-toggle="modal" data-target="#modal">再生</button>

<!-- modal for audio player -->
<div class="modal fade" id="modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">再生</h4>
      </div>
      <div class="modal-body">
        <div class="text-center">
		  <div id="player_message" class="poc-message-box"></div>
          <audio id="player" controls="controls"></audio>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<script type="text/javascript">
function play_record() {
  <!-- base_url は　最後に / をつけない -->
  url = "<?php echo base_url('callrecord_test/play_record'); ?>" + "/" + document.getElementById('filename').value;
	$('#player_message').html('');
	$.get(url, null, function(data) {
			if (data.search(/Error:/) != -1) {
				$('#player_message').html(data);
			}
			else {
				$('#player').get(0).src = data;
				$('#player').get(0).play();
			}
		});
}
</script>

<?php
$this->load->view('templates/footer', $data);
?>
