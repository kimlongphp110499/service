<?php
$data['username'] = $username;
$data['usermode'] = $usermode;
$data['css'] = 'dummy.css';
$data['menu'] = 'pocaccount';

// setup breadcrumb
$breadcrumb = array(
	'ホーム' => 	base_url('home'),
  'アカウント一覧' => base_url('pocaccount/view_list/'.$tenant->company_id),
  '新規アカウント追加' => false,
);

$data['breadcrumb'] = $breadcrumb;

$this->load->view('templates/header', $data);
$this->load->view('templates/sidemenu', $data);
?>

<?php if (!USE_BREADCRUMB_IN_HEADER && isset($breadcrumb)): ?>
	<ol class="breadcrumb"> <!-- パンくず対応済み -->
<?php
		foreach ($breadcrumb as $_title => $_url) {
			if ($_url) { echo '<li><a href="'.$_url.'">'.$_title.'</a></li>'; }
			else { echo '<li class="active">'.$_title.'</li>'; }
		}
?>
	</ol>
<?php endif ?>

<h2 class="page-header">新規アカウント追加</h2>
<h3>テナント: <?php echo $tenant->company_name; ?></h3>
<?php echo form_open_multipart('pocaccount/add_batch/'.$tenant->company_id); ?>

  <div class="panel panel-info">
    <div class="panel-heading">
	  <h3 class="panel-title">新規アカウント作成</h3>
    </div>
    <div class="panel-body">
      <div class="form-horizontal">
        <div class="form-group">
          <label for="device_type" class="control-label col-md-3">デバイス種類</label>
          <div class="col-md-6">
            <select name="device_type" style="width: 225px; padding: 0 5px;" class="form-control">
<?php
    foreach ($devices as $row) {
        if ($row->device_id != 2) {
            echo '<option value="'.$row->device_id.'" ';
            if (4 == $row->device_id) {
                echo 'selected="selected"';
            }
            echo '>'.$row->device_name.'</option>';
        }
    }
?>
            </select>
            <?php echo form_error('device_type'); ?>
          </div>
        </div>
        <div class="form-group">
          <label for="account_num" class="control-label col-md-3">アカウント数</label>
          <div class="col-md-6">
            <input type="text" size="4" class="form-control input-sm" id="account_num" name="account_num" value="<?php echo set_value('account_num', '1'); ?>" />
            <?php echo form_error('account_num'); ?>
          </div>
        </div>
        <div class="form-group">
          <label for="prefix" class="control-label col-md-3">プレフィックス</label>
          <div class="col-md-6">
            <input type="text" class="form-control input-sm" id="prefix" name="prefix" value="<?php echo set_value('prefix'); ?>" />
            <?php echo form_error('prefix'); ?>
            4文字以上8文字までの半角英字を指定します
          </div>
        </div>
<!--
        <div class="form-group">
          <label for="ism_file" class="control-label col-md-3">MACアドレスファイル(.csv)</label>
          <div class="col-md-6">
            <div class="input-group">
              <input type="file" id="ism_file" name="ism_file" style="display: none"/>
              <a class="input-group-addon input-sm" onclick="$('#ism_file').click();"><i class="glyphicon glyphicon-folder-open"></i></a>
              <input id="cover" type="text" class="form-control input-sm" placeholder="ファイルを選択" disabled="disabled" />
            </div>
            <?php echo form_error('ism_file'); ?>
            ISM-101 の時のみ指定します。
          </div>
          <script>
	 $('#ism_file').change(function() {
			 $('#cover').val($(this).val());
		 });
          </script>
        </div>
-->
      </div>
    </div>
  </div>

  <input type="hidden" name="company_id" value="<?php echo $tenant->company_id; ?>" />
  <div class="text-right poc-control-panel">
    <button type="submit" class="btn btn-primary">追加</button>
    <a href="<?php echo base_url('pocaccount/view_list/'.$tenant->company_id); ?>" class="btn btn-default">キャンセル</a>
  </div>

</form>

<?php
$this->load->view('templates/footer', $data);
?>
