<ol class="breadcrumb">
  <li><a href="<?php echo base_url('home'); ?>">ホーム</a></li>
  <li><a href="<?php echo base_url('alert/view_list'); ?>">アラート一覧</a></li>
  <li class="active">アラート対処</li>
</ol>

<h2 class="page-header">アラート対処</h2>
     
<table class="table table-condensed table-hover poc-table">
  <tbody>
    <tr>
      <td class="poc-td-right">管理番号</td>
      <td>0003</td>
    </tr>
    <tr>
      <td class="poc-td-right">発生日時</td>
	  <td>2015-12-10 12:00:00</td>
    </tr>
    <tr>
      <td class="poc-td-right">テナント</td>
	  <td>iforce</td>
    </tr>
    <tr>
      <td class="poc-td-right">アラート識別</td>
	  <td>NAS使用量</td>
    </tr>
    <tr>
      <td class="poc-td-right">対処日</td>
      <td>
　　　　TODO:カレンダーコントロールを入れる
        <input type="text" name="handle_date" id="handle_date" class="form-control input-sm" />
      </td>
    </tr>
    <tr>
      <td class="poc-td-right">対処者</td>
      <td>
        <input class="form-control input-sm" type="text" name="person" />
      </td>
    </tr>
    <tr>
      <td class="poc-td-right">対処内容</td>
      <td>
        <textarea class="form-control" type="text" name="detail" rows="10"></textarea>
      </td>
    </tr>
  </tbody>
</table>
