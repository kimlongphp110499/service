degrees<?php
$data['username'] = $username;
$data['usermode'] = $usermode;
$data['css'] = 'dummy.css';
$data['menu'] = 'devicesetting';

// setup breadcrumb
$breadcrumb = array(
	'ホーム' => 	base_url('home'),
  'デバイス設定' => base_url('devicesetting/view'),
  '工場出荷マスターデータ' => false,
);

$data['breadcrumb'] = $breadcrumb;

$this->load->view('templates/header', $data);
$this->load->view('templates/sidemenu', $data);

global $global_handy_off_on_names;
global $global_handy_clock_type_names;
global $global_handy_call_notice_names;
global $global_handy_mic_type_names;
global $global_handy_simcard_types;
global $global_handy_ping_interval;
global $global_handy_register_interval;
global $global_handy_pri_ap_mode;
global $global_handy_pri_wifi_nw_mode;
global $global_handy_gps_mode;
global $global_handy_emergency_mode_type;
global $global_handy_history_timestamp;
global $global_handy_history_info_settings;
global $global_handy_history_custom_settings;
global $global_handy_auto_mic_gain;
global $global_handy_time_out_timer;
global $global_handy_ptt_call;
global $global_handy_direct_call;
global $global_handy_tx_block;
global $global_handy_callback_timer;
global $global_handy_audio_alc;
global $global_handy_audio_reduce;
global $global_handy_record_mode;
global $global_handy_message_block;
global $global_handy_speaker_beep_vol;
global $global_handy_bell_mode;
global $global_handy_voice_guide;
global $global_handy_voice_guide_vol;
global $global_handy_alarm_low_battery;
global $global_handy_shortcut_key;
global $global_handy_speaker_extnl_vol;
global $global_handy_speaker_vol_mode;
global $global_handy_earphone_sekkyaku_mode;
global $global_handy_sekkyaku_touch;
global $global_handy_sekkyaku_release_timer;
global $global_handy_emergency_vol;
global $global_handy_backlight_timer;
global $global_handy_audio_codec;
global $global_handy_vox;
global $global_handy_set_mode;
global $global_handy_power_off_timer;

?>

<?php if (!USE_BREADCRUMB_IN_HEADER && isset($breadcrumb)): ?>
	<ol class="breadcrumb"> <!-- パンくず対応済み -->
<?php
		foreach ($breadcrumb as $_title => $_url) {
			if ($_url) { echo '<li><a href="'.$_url.'">'.$_title.'</a></li>'; }
			else { echo '<li class="active">'.$_title.'</li>'; }
		}
?>
	</ol>
<?php endif ?>

<h2 class="page-header">DJCP100 工場出荷マスターデータ</h2>
<div class="poc-message-box">
工場出荷マスターデータです。
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">システム情報</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">
      <div class="row">
        <div class="col-md-4 poc-list-title">ファーム更新フラグ</div>
        <div class="col-md-8"><?php echo $global_handy_off_on_names[$hdy_config->FW_flag]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">アプリケーションバージョン</div>
        <div class="col-md-8"><?php echo $hdy_config->App_ver; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">アプリケーションパス（URL）</div>
        <div class="col-md-8"><?php echo $hdy_config->App_path; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">カーネルバージョン</div>
        <div class="col-md-8"><?php echo $hdy_config->Kernel_ver; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">カーネルパス（URL）</div>
        <div class="col-md-8"><?php echo $hdy_config->Kernel_path; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">モジュールファーム更新フラグ</div>
        <div class="col-md-8"><?php echo $global_handy_off_on_names[$hdy_config->mod_flag]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">モジュールファームバージョン</div>
        <div class="col-md-8"><?php echo $hdy_config->mod_ver; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">モジュールファームパス（URL）</div>
        <div class="col-md-8"><?php echo $hdy_config->mod_path; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">SIMカード種別</div>
        <div class="col-md-8"><?php echo $global_handy_simcard_types[$hdy_config->sim]; ?></div>
      </div>
    </div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">システム設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">
      <div class="row">
        <div class="col-md-4 poc-list-title">時刻表示設定</div>
        <div class="col-md-8"><?php echo $global_handy_clock_type_names[$hdy_config->clock]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">Private Wi-Fi</div>
        <div class="col-md-8"><?php echo $global_handy_off_on_names[$hdy_config->pri_wifi]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">音声ガイダンス</div>
        <div class="col-md-8"><?php echo $global_handy_off_on_names[$hdy_config->voice_info]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">暗号鍵情報</div>
        <div class="col-md-8"><?php echo $global_handy_off_on_names[$hdy_config->key_info]; ?></div>
      </div>
    </div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">SIP設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">
      <div class="row">
        <div class="col-md-4 poc-list-title">LTE優先度</div>
        <div class="col-md-8"><?php echo number_format($hdy_config->prefix_lte); ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">RTPパケット破棄</div>
        <div class="col-md-8"><?php echo number_format($hdy_config->rtp_discard); ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">RTP delay</div>
        <div class="col-md-8"><?php echo number_format($hdy_config->rtp_delay); echo 'ミリ秒'; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">PING interval（Keep Alive）</div>
        <div class="col-md-8"><?php echo $global_handy_ping_interval[$hdy_config->ping_interval]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">REGISTER interval</div>
        <div class="col-md-8"><?php echo $global_handy_register_interval[$hdy_config->registar_interval]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">Wi-Fi優先度</div>
        <div class="col-md-8"><?php echo number_format($hdy_config->prefix_wifi); ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">Wi-Fi REGISTER Interval</div>
        <div class="col-md-8"><?php echo $global_handy_register_interval[$hdy_config->register_interval_pri_wifi]; ?></div>
      </div>
    </div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">アカウント情報</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">
      <div class="row">
        <div class="col-md-4 poc-list-title">表示名</div>
        <div class="col-md-8"><?php echo $hdy_config->disp_name; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">SIP番号</div>
        <div class="col-md-8"><?php echo $hdy_config->sip_id; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">SIPサーバードメイン（URL）</div>
        <div class="col-md-8"><?php echo $hdy_config->sip_server_domain; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">SIPサーバーポート番号</div>
        <div class="col-md-8"><?php echo $hdy_config->sip_server_port; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">SIPサーバーIPアドレス（CRG用）</div>
        <div class="col-md-8"><?php echo $hdy_config->sip_server_ip_crg; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">SIPサーバーポート番号（CRG用）</div>
        <div class="col-md-8"><?php echo $hdy_config->sip_server_port_crg; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">XMPPサーバーホスト名</div>
        <div class="col-md-8"><?php echo $hdy_config->xmpp_server_host; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">XMPPサーバーポート番号</div>
        <div class="col-md-8"><?php echo $hdy_config->xmpp_server_port; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">XMPPサービス名</div>
        <div class="col-md-8"><?php echo $hdy_config->xmpp_service; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">XMPPユーザー名</div>
        <div class="col-md-8"><?php echo $hdy_config->xmpp_user_name; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">XMPPパスワード</div>
        <div class="col-md-8"><?php echo $hdy_config->xmpp_password; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">不在伝言再生番号</div>
        <div class="col-md-8"><?php echo $hdy_config->unattended_rec_id; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">ラストコール再生番号</div>
        <div class="col-md-8"><?php echo $hdy_config->lastcall_id; ?></div>
      </div>
    </div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">Webアカウント情報</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">
      <div class="row">
        <div class="col-md-4 poc-list-title">WebサーバーログインID</div>
        <div class="col-md-8"><?php echo $hdy_config->web_account_login_id; ?></div>
      </div>
    </div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">Wi-Fi設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">
      <div class="row">
        <div class="col-md-4 poc-list-title">Private Wi-Fi Mode</div>
        <div class="col-md-8"><?php echo $global_handy_pri_ap_mode[$hdy_config->pri_ap_mode]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">Private Wi-Fiネットワークモード</div>
        <div class="col-md-8"><?php echo $global_handy_pri_wifi_nw_mode[$hdy_config->pri_wifi_nw_mode]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">Private Wi-Fi SSID</div>
        <div class="col-md-8"><?php echo $hdy_config->pri_wifi_ssid; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">Transparent（テザリング）許可</div>
        <div class="col-md-8"><?php echo $global_handy_off_on_names[$hdy_config->pri_wifi_transparent]; ?></div>
      </div>
    </div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">GPS設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">
      <div class="row">
        <div class="col-md-4 poc-list-title">GPS測位間隔時間</div>
        <div class="col-md-8"><?php echo number_format($hdy_config->gps_conf_interval); echo ' sec'; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">GPSデータ送信先URL</div>
        <div class="col-md-8"><?php echo $hdy_config->gps_server_url; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">GPS測位方式</div>
        <div class="col-md-8"><?php echo $global_handy_gps_mode[$hdy_config->gps_mode]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">GPSデータ送信間隔</div>
        <div class="col-md-8"><?php echo number_format($hdy_config->gps_server_interval); echo ' sec'; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">GPSデータ送信距離間隔</div>
        <div class="col-md-8"><?php echo number_format($hdy_config->gps_distance); echo ' m'; ?></div>
      </div>
    </div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">通話設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">
      <div class="row">
        <div class="col-md-4 poc-list-title">LTE Callback Timer</div>
        <div class="col-md-8"><?php echo number_format($hdy_config->lte_callback_timer); echo ' sec'; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">LTE Time out Timer</div>
        <div class="col-md-8"><?php echo number_format($hdy_config->lte_time_out_timer); echo ' sec'; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">LTE Time out Rekey Time</div>
        <div class="col-md-8"><?php echo number_format($hdy_config->lte_time_out_time_rekey); echo ' sec'; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">Wi-Fi Callback Timer</div>
        <div class="col-md-8"><?php echo number_format($hdy_config->wifi_callback_timer); echo ' sec'; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">Wi-Fi Time out Timer</div>
        <div class="col-md-8"><?php echo number_format($hdy_config->wifi_time_out_timer); echo ' sec'; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">Wi-Fi Time out Rekey Time</div>
        <div class="col-md-8"><?php echo number_format($hdy_config->wifi_time_out_time_rekey); echo ' sec'; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">LTEジッターバッファ</div>
        <div class="col-md-8"><?php echo number_format($hdy_config->lte_jitter_buff); echo ' ms'; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">Wi-Fiジッターバッファ</div>
        <div class="col-md-8"><?php echo number_format($hdy_config->wifi_jitter_buff); echo ' ms'; ?></div>
      </div>
    </div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">受信通知設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">
      <div class="row">
        <div class="col-md-4 poc-list-title">LTE音声受信通知</div>
        <div class="col-md-8"><?php echo $global_handy_call_notice_names[$hdy_config->speaker_lte_vib]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">Wi-Fi音声受信通知</div>
        <div class="col-md-8"><?php echo $global_handy_call_notice_names[$hdy_config->speaker_pri_wifi_vib]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">LTEデータ受信通知</div>
        <div class="col-md-8"><?php echo $global_handy_call_notice_names[$hdy_config->speaker_lte_data]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">Wi-Fiデータ受信通知</div>
        <div class="col-md-8"><?php echo $global_handy_call_notice_names[$hdy_config->speaker_pri_wifi_data]; ?></div>
      </div>
    </div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">マイク設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">
      <div class="row">
        <div class="col-md-4 poc-list-title">マイク種別</div>
        <div class="col-md-8"><?php echo $global_handy_mic_type_names[$hdy_config->audio_mic_type]; ?></div>
      </div>
    </div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">定型メッセージリスト</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">
      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ1</div>
        <div class="col-md-8"><?php echo $hdy_config->message_list_m1; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ2</div>
        <div class="col-md-8"><?php echo $hdy_config->message_list_m2; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ3</div>
        <div class="col-md-8"><?php echo $hdy_config->message_list_m3; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ4</div>
        <div class="col-md-8"><?php echo $hdy_config->message_list_m4; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ5</div>
        <div class="col-md-8"><?php echo $hdy_config->message_list_m5; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ6</div>
        <div class="col-md-8"><?php echo $hdy_config->message_list_m6; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ7</div>
        <div class="col-md-8"><?php echo $hdy_config->message_list_m7; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ8</div>
        <div class="col-md-8"><?php echo $hdy_config->message_list_m8; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ9</div>
        <div class="col-md-8"><?php echo $hdy_config->message_list_m9; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ10</div>
        <div class="col-md-8"><?php echo $hdy_config->message_list_m10; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ11</div>
        <div class="col-md-8"><?php echo $hdy_config->message_list_m11; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ12</div>
        <div class="col-md-8"><?php echo $hdy_config->message_list_m12; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ13</div>
        <div class="col-md-8"><?php echo $hdy_config->message_list_m13; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ14</div>
        <div class="col-md-8"><?php echo $hdy_config->message_list_m14; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ15</div>
        <div class="col-md-8"><?php echo $hdy_config->message_list_m15; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ16</div>
        <div class="col-md-8"><?php echo $hdy_config->message_list_m16; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ17</div>
        <div class="col-md-8"><?php echo $hdy_config->message_list_m17; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ18</div>
        <div class="col-md-8"><?php echo $hdy_config->message_list_m18; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ19</div>
        <div class="col-md-8"><?php echo $hdy_config->message_list_m19; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ20</div>
        <div class="col-md-8"><?php echo $hdy_config->message_list_m20; ?></div>
      </div>
    </div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">履歴設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">
    
      <div class="row">
        <div class="col-md-4 poc-list-title">時刻情報付加設定</div>
        <div class="col-md-8"><?php echo $global_handy_history_timestamp[$hdy_config->history_timestamp]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">発着信履歴情報</div>
        <div class="col-md-8"><?php echo $global_handy_history_info_settings[$hdy_config->history_call]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">着信履歴</div>
        <div class="col-md-8"><?php echo $global_handy_history_info_settings[$hdy_config->history_income]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">発信履歴</div>
        <div class="col-md-8"><?php echo $global_handy_history_info_settings[$hdy_config->history_outcome]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ着信履歴</div>
        <div class="col-md-8"><?php echo $global_handy_history_info_settings[$hdy_config->history_message_in]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ発信履歴</div>
        <div class="col-md-8"><?php echo $global_handy_history_info_settings[$hdy_config->history_message_out]; ?></div>
      </div>
    </div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">カスタム設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">
      <div class="row">
        <div class="col-md-4 poc-list-title">カスタム1</div>
        <div class="col-md-8"><?php echo $global_handy_history_custom_settings[$hdy_config->custom1]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">カスタム2</div>
        <div class="col-md-8"><?php echo $global_handy_history_custom_settings[$hdy_config->custom2]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">カスタム3</div>
        <div class="col-md-8"><?php echo $global_handy_history_custom_settings[$hdy_config->custom3]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">カスタム4</div>
        <div class="col-md-8"><?php echo $global_handy_history_custom_settings[$hdy_config->custom4]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">カスタム5</div>
        <div class="col-md-8"><?php echo $global_handy_history_custom_settings[$hdy_config->custom5]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">カスタム6</div>
        <div class="col-md-8"><?php echo $global_handy_history_custom_settings[$hdy_config->custom6]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">カスタム7</div>
        <div class="col-md-8"><?php echo $global_handy_history_custom_settings[$hdy_config->custom7]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">カスタム8</div>
        <div class="col-md-8"><?php echo $global_handy_history_custom_settings[$hdy_config->custom8]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">カスタム9</div>
        <div class="col-md-8"><?php echo $global_handy_history_custom_settings[$hdy_config->custom9]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">カスタム10</div>
        <div class="col-md-8"><?php echo $global_handy_history_custom_settings[$hdy_config->custom10]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">カスタム11</div>
        <div class="col-md-8"><?php echo $global_handy_history_custom_settings[$hdy_config->custom11]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">カスタム12</div>
        <div class="col-md-8"><?php echo $global_handy_history_custom_settings[$hdy_config->custom12]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">カスタム13</div>
        <div class="col-md-8"><?php echo $global_handy_history_custom_settings[$hdy_config->custom13]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">カスタム14</div>
        <div class="col-md-8"><?php echo $global_handy_history_custom_settings[$hdy_config->custom14]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">カスタム15</div>
        <div class="col-md-8"><?php echo $global_handy_history_custom_settings[$hdy_config->custom15]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">カスタム16</div>
        <div class="col-md-8"><?php echo $global_handy_history_custom_settings[$hdy_config->custom16]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">カスタム17</div>
        <div class="col-md-8"><?php echo $global_handy_history_custom_settings[$hdy_config->custom17]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">カスタム18</div>
        <div class="col-md-8"><?php echo $global_handy_history_custom_settings[$hdy_config->custom18]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">カスタム19</div>
        <div class="col-md-8"><?php echo $global_handy_history_custom_settings[$hdy_config->custom19]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">カスタム20</div>
        <div class="col-md-8"><?php echo $global_handy_history_custom_settings[$hdy_config->custom20]; ?></div>
      </div>
    </div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">送信設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">
      <div class="row">
        <div class="col-md-4 poc-list-title">内部マイク感度</div>
        <div class="col-md-8"><?php echo $global_handy_auto_mic_gain[$hdy_config->audio_intnl_mic_gain]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">外部マイク感度</div>
        <div class="col-md-8"><?php echo $global_handy_auto_mic_gain[$hdy_config->audio_extnl_mic_gain]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">緊急時マイク感度</div>
        <div class="col-md-8"><?php echo $global_handy_auto_mic_gain[$hdy_config->audio_emergency_mic_gain]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">PTTホールド</div>
        <div class="col-md-8"><?php echo $global_handy_off_on_names[$hdy_config->key_ptt_hold]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">コールバック</div>
        <div class="col-md-8"><?php echo $global_handy_off_on_names[$hdy_config->audio_earphone_callback]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">VOX動作設定</div>
        <div class="col-md-8"><?php echo $global_handy_vox[$hdy_config->vox]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">VOX動作レベル</div>
        <div class="col-md-8"><?php echo $hdy_config->vox_thresh; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">ノイズキャンセラー</div>
        <div class="col-md-8"><?php echo $global_handy_off_on_names[$hdy_config->audio_noise_can]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">エコーキャンセラー</div>
        <div class="col-md-8"><?php echo $global_handy_off_on_names[$hdy_config->audio_echo_can]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">連続送信制限時間</div>
        <div class="col-md-8"><?php echo $global_handy_time_out_timer[$hdy_config->time_out_timer]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">PTT通信相手選択</div>
        <div class="col-md-8"><?php echo $global_handy_ptt_call[$hdy_config->ptt_call]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">PTT通信グループ</div>
        <div class="col-md-8"><?php echo $hdy_config->ptt_group; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">PTT通信会議室</div>
        <div class="col-md-8"><?php echo $hdy_config->ptt_conference; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">直通相手選択</div>
        <div class="col-md-8"><?php echo $global_handy_direct_call[$hdy_config->direct_call]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">直接通信グループ</div>
        <div class="col-md-8"><?php echo $hdy_config->direct_group; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">送信禁止</div>
        <div class="col-md-8"><?php echo $global_handy_tx_block[$hdy_config->tx_block]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">個別呼出切替</div>
        <div class="col-md-8"><?php echo $global_handy_callback_timer[$hdy_config->ind_callback_timer]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">グループ呼出切替</div>
        <div class="col-md-8"><?php echo $global_handy_callback_timer[$hdy_config->group_callback_timer]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">全員呼出切替</div>
        <div class="col-md-8"><?php echo $global_handy_callback_timer[$hdy_config->all_callback_timer]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">個別通話禁止</div>
        <div class="col-md-8"><?php echo $global_handy_message_block[$hdy_config->individual_call_disable]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">個別メッセージ禁止</div>
        <div class="col-md-8"><?php echo $global_handy_message_block[$hdy_config->individual_message_disable]; ?></div>
      </div>
    </div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">受信設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">
      <div class="row">
        <div class="col-md-4 poc-list-title">音量一定化</div>
        <div class="col-md-8"><?php echo $global_handy_audio_alc[$hdy_config->audio_alc]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">低音域抑制</div>
        <div class="col-md-8"><?php echo $global_handy_audio_reduce[$hdy_config->audio_bass_reduce]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">高音域抑制</div>
        <div class="col-md-8"><?php echo $global_handy_audio_reduce[$hdy_config->audio_treble_reduce]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">録音動作設定</div>
        <div class="col-md-8"><?php echo $global_handy_record_mode[$hdy_config->record_mode]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">メッセージ受信禁止</div>
        <div class="col-md-8"><?php echo $global_handy_message_block[$hdy_config->message_block]; ?></div>
      </div>
    </div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">通知/警告設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">
      <div class="row">
        <div class="col-md-4 poc-list-title">ビープ音量</div>
        <div class="col-md-8"><?php echo $global_handy_speaker_beep_vol[$hdy_config->speaker_beep_vol]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">ベル機能</div>
        <div class="col-md-8"><?php echo $global_handy_off_on_names[$hdy_config->alarm_bell]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">ベルの音色</div>
        <div class="col-md-8"><?php echo $global_handy_bell_mode[$hdy_config->bell_mode]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">音声ガイド</div>
        <div class="col-md-8"><?php echo $global_handy_voice_guide[$hdy_config->voice_guide]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">音声ガイド音量</div>
        <div class="col-md-8"><?php echo $global_handy_voice_guide_vol[$hdy_config->voice_guide_vol]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">減電池警告</div>
        <div class="col-md-8"><?php echo $global_handy_alarm_low_battery[$hdy_config->alarm_low_battery]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">イヤホン断線検知</div>
        <div class="col-md-8"><?php echo $global_handy_off_on_names[$hdy_config->alarm_earphone_broken]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">接続通知</div>
        <div class="col-md-8"><?php echo $global_handy_off_on_names[$hdy_config->alarm_ind_call_ok]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">失敗通知</div>
        <div class="col-md-8"><?php echo $global_handy_off_on_names[$hdy_config->alarm_ind_call_ng]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">PTTビープ</div>
        <div class="col-md-8"><?php echo $global_handy_off_on_names[$hdy_config->audio_ptt_beep]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">エンドピー</div>
        <div class="col-md-8"><?php echo $global_handy_off_on_names[$hdy_config->audio_end_beep]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">通信圏外警告</div>
        <div class="col-md-8"><?php echo $global_handy_off_on_names[$hdy_config->alarm_connect]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">圏外時コールバック停止</div>
        <div class="col-md-8"><?php echo $global_handy_off_on_names[$hdy_config->alarm_stop_callback]; ?></div>
      </div>
    </div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">各種動作設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">
      <div class="row">
        <div class="col-md-4 poc-list-title">短縮キー動作</div>
        <div class="col-md-8"><?php echo $global_handy_shortcut_key[$hdy_config->shortcut_key]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">外部音量設定</div>
        <div class="col-md-8"><?php echo $global_handy_speaker_extnl_vol[$hdy_config->speaker_extnl_vol]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">音量の調整方法</div>
        <div class="col-md-8"><?php echo $global_handy_speaker_vol_mode[$hdy_config->speaker_vol_mode]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">固定音量レベル</div>
        <div class="col-md-8"><?php echo $hdy_config->speaker_fixed_vol; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">最大音量レベル</div>
        <div class="col-md-8"><?php echo $hdy_config->speaker_max_vol; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">最小音量レベル</div>
        <div class="col-md-8"><?php echo $hdy_config->speaker_min_vol; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">接客モード</div>
        <div class="col-md-8"><?php echo $global_handy_earphone_sekkyaku_mode[$hdy_config->earphone_sekkyaku_mode]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">接客ボイス感度</div>
        <div class="col-md-8"><?php echo $hdy_config->sekkyaku_voice; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">接客タッチ感度</div>
        <div class="col-md-8"><?php echo $global_handy_sekkyaku_touch[$hdy_config->sekkyaku_touch]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">接客復帰時間</div>
        <div class="col-md-8"><?php echo $global_handy_sekkyaku_release_timer[$hdy_config->sekkyaku_release_timer]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">接客ボイス保持</div>
        <div class="col-md-8"><?php echo $hdy_config->sekkyaku_voice_timer; echo ' 秒'?></div>
      </div>
    </div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">緊急動作設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">
      <div class="row">
        <div class="col-md-4 poc-list-title">緊急動作　受信禁止</div>
        <div class="col-md-8"><?php echo $global_handy_message_block[$hdy_config->emergency_receive]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">緊急動作　警報音のみ</div>
        <div class="col-md-8"><?php echo $hdy_config->emergency_alarm_duration; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">緊急動作　警報音+発報</div>
        <div class="col-md-8"><?php echo $hdy_config->emergency_alarm_ptt_duration; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">緊急動作　発報のみ</div>
        <div class="col-md-8"><?php echo $hdy_config->emergency_silent_ptt_duration; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">緊急動作　音声送信</div>
        <div class="col-md-8"><?php echo $hdy_config->emergency_live_ptt_duration; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">緊急動作　警報音量（内部）</div>
        <div class="col-md-8"><?php echo $global_handy_emergency_vol[$hdy_config->emergency_intnl_vol]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">緊急動作　警報音量（外部）</div>
        <div class="col-md-8"><?php echo $global_handy_emergency_vol[$hdy_config->emergency_extnl_vol]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">緊急速報機能</div>
        <div class="col-md-8"><?php echo $global_handy_off_on_names[$hdy_config->kinkyu_sokuho]; ?></div>
      </div>
    </div>
  </div>
</div>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">端末システム設定</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">
      <div class="row">
        <div class="col-md-4 poc-list-title">バックライトタイマー</div>
        <div class="col-md-8"><?php echo $global_handy_backlight_timer[$hdy_config->backlight_timer]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">コントラスト</div>
        <div class="col-md-8"><?php echo $hdy_config->display_lcd_contrast; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">バッテリーセーブ</div>
        <div class="col-md-8"><?php echo $global_handy_off_on_names[$hdy_config->battery_save]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">オートパワーオフ</div>
        <div class="col-md-8"><?php echo $global_handy_power_off_timer[$hdy_config->power_off_timer]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">音声コーデック設定</div>
        <div class="col-md-8"><?php echo $global_handy_audio_codec[$hdy_config->audio_codec]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">セットモード切り替え</div>
        <div class="col-md-8"><?php echo $global_handy_set_mode[$hdy_config->set_mode]; ?></div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">リセット動作禁止</div>
        <div class="col-md-8"><?php echo $global_handy_message_block[$hdy_config->reset_disable]; ?></div>
      </div>
    </div>
  </div>
</div>

<div class="text-right poc-control-panel">
    <a href="<?php echo base_url('handy_factory/edit'); ?>" class="btn btn-primary">編集</a>
    <a href="<?php echo base_url('devicesetting/view/'); ?>" class="btn btn-default">戻る</a>
</div>

<?php
$this->load->view('templates/footer', $data);
?>
