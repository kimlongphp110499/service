<?php echo validation_errors('<div class="alert alert-danger poc-alert" role="alert">','</div>'); ?>
<!DOCTYPE html>
<html lang="ja">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>アルインコクラウドサービス</title>
<!--    <base href="<?php echo base_url(); ?>"/>-->

    <!-- Bootstrap -->
    <link href="<?php echo base_url(); ?>bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="<?php echo base_url(); ?>css/common.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>css/<?php echo $css; ?>" rel="stylesheet">
                                                                  
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
<body>
<div class="container">
  <?php echo form_open('verifylogin'); ?>
    <div class="form-signin text-center">
      <h3 class="form-signin-heading">アルインコクラウドサービス</h3>
      <label for="login_id" class="sr-only">ログインID</label>
      <input type="text" size="20" id="login_id" name="login_id" class="form-control" placeholder="ログインID" required autofocus />
      <label for="password" class="sr-only">パスワード</label>
      <input type="password" size="20" id="password" name="password" class="form-control" placeholder="パスワード" required />
      <button type="submit" class="btn btn-lg btn-primary">ログイン</button>
    </div>
  </form>
</div>

<!-- for footer -->
<div><div><div>
