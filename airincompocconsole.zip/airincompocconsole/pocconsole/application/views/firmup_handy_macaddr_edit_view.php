<?php
$data['username'] = $username;
$data['usermode'] = $usermode;
$data['css'] = 'dummy.css';
$data['menu'] = 'firmup_handy';

// setup breadcrumb
$breadcrumb = array(
    'ホーム' => 	base_url('home'),
    'ファームアップ管理' => base_url('firmup_handy/view_list'),
    'ファームアップファイル編集' => base_url('firmup_handy/edit/'.$firmup_file ->id),
    'IMEI登録' => false,
);

$data['breadcrumb'] = $breadcrumb;

$this->load->view('templates/header', $data);
$this->load->view('templates/sidemenu', $data);

global $global_web_account_type_names;

?>

<?php if (!USE_BREADCRUMB_IN_HEADER && isset($breadcrumb)): ?>
	<ol class="breadcrumb"> <!-- パンくず対応済み -->
<?php
		foreach ($breadcrumb as $_title => $_url) {
			if ($_url) { echo '<li><a href="'.$_url.'">'.$_title.'</a></li>'; }
			else { echo '<li class="active">'.$_title.'</li>'; }
		} 
?>
	</ol>
<?php endif ?>

<h2 class="page-header">IMEI登録</h2>
<?php echo form_open_multipart('firmup_handy/macaddr_edit/'.$firmup_file ->id); ?>
  <div class="form-horizontal">

    <div class="form-group">
      <label class="control-label col-md-3">テナント番号</label>
      <div class="col-md-9">
        <div class="form-control-static"><?php echo $firmup_file ->company_id; ?></div>
        <input type="hidden" name="company_id" value="<?php echo $firmup_file ->company_id; ?>"/>
      </div>
    </div>

    <div class="form-group">
      <label class="control-label col-md-3">テナント名</label>
      <div class="col-md-9">
        <div class="form-control-static"><?php echo $firmup_file ->company_name; ?></div>
        <input type="hidden" name="company_name" value="<?php echo $firmup_file ->company_name; ?>"/>
      </div>
    </div>

    <div class="form-group">
      <label class="control-label col-md-3">登録端末一覧</label>
      <div class="col-md-9">
        <a href="<?php echo base_url('firmup_handy/export/'.$firmup_file ->id); ?>" class="btn btn-default">CSVダウンロード</a>
      </div>
    </div>    

    <div class="form-group">
      <label class="control-label col-md-3">機種名</label>
      <div class="col-md-9">
        <div class="form-control-static"><?php echo $firmup_file ->device_name; ?></div>
        <input type="hidden" name="device_name" value="<?php echo $firmup_file ->device_name; ?>"/>
      </div>
    </div>

    <div class="form-group">
        <label for="form_item" class="control-label col-md-3">CSVファイル選択</label>
        <div class="col-md-6">
        <div class="input-group">
            <input type="file" id="form_item" name="form_item" style="display: none"/>
            <a class="input-group-addon input-sm" onclick="$('#form_item').click();"><i class="glyphicon glyphicon-folder-open"></i></a>
            <input id="cover" type="text" class="form-control input-sm" placeholder="ファイルを選択" disabled="disabled" />
        </div>
        <?php echo form_error('form_item'); ?>
        
        </div>
        <script>
	$('#form_item').change(function() {
			$('#cover').val($(this).val());
		});
        </script>
    </div>


  <div class="text-right poc-control-panel">
    <button type="submit" class="btn btn-primary">登録</button>
    <a href="<?php echo base_url('firmup_handy/edit/'.$firmup_file ->id); ?>" class="btn btn-default">キャンセル</a>
  </div>

</form>

<?php
$this->load->view('templates/footer', $data);
?>
