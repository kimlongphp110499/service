<?php
$data['username'] = $username;
$data['usermode'] = $usermode;
$data['css'] = 'dummy.css';
$data['menu'] = 'webaccount';

// setup breadcrumb
$breadcrumb = array(
	'ホーム' => 	base_url('home'),
  'Webアカウント一覧' => base_url('webaccount/view_list'),
  '新規アカウント追加' => false,
);

$data['breadcrumb'] = $breadcrumb;

$this->load->view('templates/header', $data);
$this->load->view('templates/sidemenu', $data);

global $global_web_account_type_names;

?>

<?php if (!USE_BREADCRUMB_IN_HEADER && isset($breadcrumb)): ?>
	<ol class="breadcrumb"> <!-- パンくず対応済み -->
<?php
		foreach ($breadcrumb as $_title => $_url) {
			if ($_url) { echo '<li><a href="'.$_url.'">'.$_title.'</a></li>'; }
			else { echo '<li class="active">'.$_title.'</li>'; }
		}
?>
	</ol>
<?php endif ?>

<h2 class="page-header">新規アカウント追加</h2>
<?php echo form_open('webaccount/add'); ?>

  <div class="form-horizontal">

    <div class="form-group has-feedback">
      <label class="control-label col-md-3" for="login_id">ログインID</label>
      <div class="col-md-9">
        <input class="form-control input-sm" type="text" id="login_id" name="login_id" value="<?php echo set_value('login_id'); ?>"/>
	    <?php echo form_error('login_id'); ?>
      </div>
    </div>

    <div class="form-group has-feedback">
      <label class="control-label col-md-3" for="username">ユーザー名</label>
      <div class="col-md-9">
        <input class="form-control input-sm" type="text" id="username" name="username" value="<?php echo set_value('username'); ?>"/>
	    <?php echo form_error('username'); ?>
      </div>
    </div>

    <div class="form-group has-feedback">
      <label class="control-label col-md-3" for="password">パスワード</label>
      <div class="col-md-9">
        <input class="form-control input-sm" type="password" id="password" name="password"/>
	    <?php echo form_error('password'); ?>
      </div>
    </div>

    <div class="form-group has-feedback">
      <label class="control-label col-md-3" for="confirm">パスワード(確認)</label>
      <div class="col-md-9">
        <input class="form-control input-sm" type="password" id="confirm" name="confirm"/>
	    <?php echo form_error('confirm'); ?>
      </div>
    </div>

    <div class="form-group has-feedback">
      <label class="control-label col-md-3">アカウント種別</label>
      <div class="col-md-9">
        <label calss="radio-inline">
        	<input type="radio" name="type" value="admin" <?php echo set_radio('type', 'admin', TRUE); ?> />
			<?php echo $global_web_account_type_names['admin']; ?>
        </label>
        <label calss="radio-inline">
        	<input type="radio" name="type" value="tenant" <?php echo set_radio('type', 'tenant'); ?> />
			<?php echo $global_web_account_type_names['tenant']; ?>
        </label>
        <label calss="radio-inline">
        	<input type="radio" name="type" value="tenant_api" <?php echo set_radio('type', 'tenant_api'); ?> />
			<?php echo $global_web_account_type_names['tenant_api']; ?>
        </label>
        <?php echo form_error('type'); ?>
      </div>
    </div>

    <div class="form-group has-feedback">
      <label class="control-label col-md-3">状態</label>
      <div class="col-md-9">
        <label calss="radio-inline">
          <input type="radio" name="status" value="1" <?php echo set_radio('status', '1', TRUE); ?> /> 有効
        </label>
        <label calss="radio-inline">
          <input type="radio" name="status" value="0" <?php echo set_radio('status', '0'); ?> /> 無効
        </label>
        <?php echo form_error('status'); ?>
      </div>
    </div>

    <div class="form-group has-feedback">
      <label class="control-label col-md-3" for="company_id">所属テナント</label>
      <div class="col-md-9">
        <select name="company_id" class="form-control input-sm">
<?php
     foreach ($tenants as $row) {
         echo '<option value="'.$row->company_id.'" '
		 .set_select('company_id', $row->company_id).'>'.$row->company_name.'</option>';
     }
?>
        </select>
        <?php echo form_error('company_id'); ?>
      </div>
    </div>
  </div>

  <div class="text-right poc-control-panel">
    <button type="submit" class="btn btn-primary">追加</button>
    <a href="<?php echo base_url('webaccount/view_list'); ?>" class="btn btn-default">キャンセル</a>
  </div>

</form>

<?php
$this->load->view('templates/footer', $data);
?>
