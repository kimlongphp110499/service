<?php
$data['username'] = $username;
$data['usermode'] = $usermode;
$data['css'] = 'dummy.css';
$data['menu'] = 'pocaccount';

// setup breadcrumb
$breadcrumb = array(
	'ホーム' => 	base_url('home'),
	'アカウント一覧' => false,
);

$data['breadcrumb'] = $breadcrumb;

$this->load->view('templates/header', $data);
$this->load->view('templates/sidemenu', $data);
?>

<?php if (!USE_BREADCRUMB_IN_HEADER && isset($breadcrumb)): ?>
	<ol class="breadcrumb"> <!-- パンくず対応済み -->
<?php
		foreach ($breadcrumb as $_title => $_url) {
			if ($_url) { echo '<li><a href="'.$_url.'">'.$_title.'</a></li>'; }
			else { echo '<li class="active">'.$_title.'</li>'; }
		}
?>
	</ol>
<?php endif ?>

<h2 class="page-header">アカウント一覧</h2>
         
<?php if ($usermode == 'admin'): ?>
<h3>テナント: <?php echo $tenant->company_name; ?></h3>
        
<div class="text-right">
  <a href="<?php echo base_url('pocaccount/add_batch/'.$tenant->company_id); ?>" class="btn btn-primary"><span class="glyphicon glyphicon-plus"></span> 新規アカウント追加</a>
</div>

<?php endif; ?>
         
<?php if (!$accounts) : ?>
<div class="poc-messge-box">
  登録されたアカウントはありません。
</div>

<?php else : ?>
登録アカウント数: <?php echo count($accounts); ?>
<table class="table table-striped table-condensed table-hover poc-table">
  <thead>
    <tr>
<?php
	$sorticon = '<span class="glyphicon glyphicon-triangle-'
	    .($order == 'asc' ? 'top' : 'bottom').' poc-icon"></span>';

    // アカウント名
    $dir = ($sortkey == 'username' && $order == 'asc') ? 'desc' : 'asc';
    $param = $tenant->company_id.'/username/'.$dir;
    echo '<th><a href="'.base_url('pocaccount/view_list/'.$param).'">アカウント名 ';
	if ($sortkey == 'username') {
		echo $sorticon;
	}
	echo '</a></th>';

    // 表示名
    $dir = ($sortkey == 'display_name' && $order == 'asc') ? 'desc' : 'asc';
    $param = $tenant->company_id.'/display_name/'.$dir;
    echo '<th><a href="'.base_url('pocaccount/view_list/'.$param).'">表示名 ';
	if ($sortkey == 'display_name') {
		echo $sorticon;
	}
	echo '</a></th>';

    // 使用機種
    $dir = ($sortkey == 'device_name' && $order == 'asc') ? 'desc' : 'asc';
    $param = $tenant->company_id.'/device_name/'.$dir;
    echo '<th><a href="'.base_url('pocaccount/view_list/'.$param).'">使用機種 ';
	if ($sortkey == 'device_name') {
		echo $sorticon;
	}
	echo '</a></th>';

    // SIP番号
    $dir = ($sortkey == 'sip_number' && $order == 'asc') ? 'desc' : 'asc';
    $param = $tenant->company_id.'/sip_number/'.$dir;
    echo '<th><a href="'.base_url('pocaccount/view_list/'.$param).'">SIP番号 ';
	if ($sortkey == 'sip_number') {
		echo $sorticon;
	}
	echo '</a></th>';

    // IPアドレス
    // $dir = ($sortkey == 'ip_address' && $order == 'asc') ? 'desc' : 'asc';
    // $param = $tenant->company_id.'/ip_address/'.$dir;
    // echo '<th><a href="'.base_url('pocaccount/view_list/'.$param).'">IPアドレス ';
	// if ($sortkey == 'ip_address') {
	// 	echo $sorticon;
	// }
	// echo '</a></th>';

    // IMEI
    $dir = ($sortkey == 'imei' && $order == 'asc') ? 'desc' : 'asc';
    $param = $tenant->company_id.'/imei/'.$dir;
    echo '<th><a href="'.base_url('pocaccount/view_list/'.$param).'">IMEI ';
	if ($sortkey == 'imei') {
		echo $sorticon;
	}
	echo '</a></th>';

    // アプリバージョン
    $dir = ($sortkey == 'app_version' && $order == 'asc') ? 'desc' : 'asc';
    $param = $tenant->company_id.'/app_version/'.$dir;
    echo '<th><a href="'.base_url('pocaccount/view_list/'.$param).'">アプリバージョン ';
	if ($sortkey == 'app_version') {
		echo $sorticon;
	}
	echo '</a></th>';

    // 状態
    $dir = ($sortkey == 'status' && $order == 'asc') ? 'desc' : 'asc';
    $param = $tenant->company_id.'/status/'.$dir;
    echo '<th><a href="'.base_url('pocaccount/view_list/'.$param).'">状態 ';
	if ($sortkey == 'status') {
		echo $sorticon;
	}
	echo '</a></th>';
?>
    </tr>
  </thead>
  <tbody>

<?php    
	foreach ($accounts as $row) {
		echo '<tr>';
		echo '<td><a href="'.base_url('pocaccount/view/'.$tenant->company_id.'/'.$row->poc_id).'"/a>'.$row->username.'</a></td>';
		echo '<td>'.$row->display_name.'</td>';
		echo '<td>'.$row->device_name.'</td>';
		echo '<td>'.$row->sip_number.'</td>';
		// echo '<td>';
		// if (!empty($row->ip_address)) {
		// 	echo $row->ip_address;
		// }
		// else {
		// 	echo '-';
		// }
		// echo '</td>';
		echo '<td>';
		if (!empty($row->imei)) {
			echo $row->imei;
		}
		else {
			echo '-';
		}
		echo '</td>';
		echo '<td>';
		if (!empty($row->app_version)) {
			echo $row->app_version;
		}
		else {
			echo '-';
		}
		echo '</td>';
		if ($row->status) {
			echo '<td><span class="glyphicon glyphicon-ok poc-icon-ok"></span> 有効</span></td>';
		}
		else {
			echo '<td><span class="glyphicon glyphicon-remove poc-icon-ng"></span> 無効</td>';
		}
		echo '</tr>';
	}
?>
         
  </tbody>
</table>

<div class="text-right poc-control-panel">
<p>
<?php if ($usermode == 'admin') : ?>
  <button type="button" class="btn btn-default" data-toggle="modal" data-target="#modal">
    <span class="glyphicon glyphicon-remove"></span> 全削除
  </button>
<?php endif ?>
	<a href="<?php echo base_url('pocaccount/export/'.$tenant->company_id); ?>" class="btn btn-default"><span class="glyphicon glyphicon-save"></span> CSVエクスポート</a>
</p>

</div>

<?php if ($usermode == 'admin') : ?>
<!-- 全削除ダイアログ -->
<div class="modal fade" id="modal" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"></button>
        <h4 class="modal-title" id="myModalLabel">確認</h4>
      </div>
      <div class="modal-body">
        <span class="glyphicon glyphicon-exclamation-sign"></span>
        全てのアカウントが削除されます。よろしいですか？
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <a href="<?php echo base_url('pocaccount/delete_all/'.$tenant->company_id); ?>" class="btn btn-primary">全削除</a>
      </div>
    </div>
  </div>
</div>
<?php endif ?>

<?php endif ?><!-- if ($account) -->

<?php if ($usermode == 'admin') : ?>

<?php echo form_open_multipart('pocaccount/import/'.$tenant->company_id); ?>
	<div class="text-right">
			<div class="form-horizontal">
		<p>
				<div class="input-group" style="width: 33%; margin-left: auto">
						<input type="file" id="import_file" name="import_file" style="display: none"/>
						<a class="input-group-addon input-sm" onclick="$('#import_file').click();"><i class="glyphicon glyphicon-folder-open"></i></a>
						<input id="cover" type="text" class="form-control input-sm" placeholder="ファイルを選択" disabled="disabled" />
				</div>
				<button class="btn btn-default" type="submit"><span class="glyphicon glyphicon-open"></span> CSVインポート</button>
			</div>
		</p>
			<script>
			$('#import_file').change(function() {
					$('#cover').val($(this).val());
				});
			</script>
	</div>
<?php echo form_close(); ?>

<?php endif ?>

<?php
$this->load->view('templates/footer', $data);
?>
