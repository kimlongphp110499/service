<?php
$data['username'] = $username;
$data['usermode'] = $usermode;
$data['css'] = 'dummy.css';
$data['menu'] = 'group';

// setup breadcrumb
$breadcrumb = array(
	'ホーム' => 	base_url('home'),
	'グループ一覧' => false,
);

$data['breadcrumb'] = $breadcrumb;

$this->load->view('templates/header', $data);
$this->load->view('templates/sidemenu', $data);
?>

<?php if (!USE_BREADCRUMB_IN_HEADER && isset($breadcrumb)): ?>
	<ol class="breadcrumb"> <!-- パンくず対応済み -->
<?php
		foreach ($breadcrumb as $_title => $_url) {
			if ($_url) { echo '<li><a href="'.$_url.'">'.$_title.'</a></li>'; }
			else { echo '<li class="active">'.$_title.'</li>'; }
		}
?>
	</ol>
<?php endif ?>

<h2 class="page-header">グループ一覧</h2>
<?php if ($usermode == 'admin'): ?>
<h3>テナント: <?php echo $tenant->company_name; ?></h3>
        
<div class="text-right">
  <a href="<?php echo base_url('group/add_batch/'.$tenant->company_id); ?>" class="btn btn-primary"><span class="glyphicon glyphicon-plus"> 新規グループ追加</a>
  <!--<a href="<?php echo base_url('pocaccount/add/'.$tenant->company_id); ?>" class="btn btn-default"><span class="glyphicon glyphicon-open"></span> CSV一括登録</a>-->
</div>
<?php endif; ?>
         
<?php
     if ($accounts) {
		 $sorticon = '<span class="glyphicon glyphicon-triangle-'
			 .($order == 'asc' ? 'top' : 'bottom').' poc-icon"></span>';
		 echo '登録グループ数: '.count($accounts);
         echo '<table class="table table-striped table-condensed table-hover poc-table">';
         echo '<thead>';
         echo '<tr>';
		 // グループ名
		 $dir = ($sortkey == 'group_name' && $order == 'asc') ? 'desc' : 'asc';
		 $param = $tenant->company_id.'/group_name/'.$dir;
		 echo '<th><a href="'.base_url('group/view_list/'.$param).'">グループ名 ';
		 if ($sortkey == 'group_name') {
			 echo $sorticon;
		 }
		 echo '</a></th>';

		 // グループSIP番号
		 $dir = ($sortkey == 'sip_number' && $order == 'asc') ? 'desc' : 'asc';
		 $param = $tenant->company_id.'/sip_number/'.$dir;
		 echo '<th><a href="'.base_url('group/view_list/'.$param).'">グループSIP番号 ';
		 if ($sortkey == 'sip_number') {
			 echo $sorticon;
		 }
		 echo '</a></th>';

		 // 会議室SIP番号
		 $dir = ($sortkey == 'conf_sip_number' && $order == 'asc') ? 'desc' : 'asc';
		 $param = $tenant->company_id.'/conf_sip_number/'.$dir;
		 echo '<th><a href="'.base_url('group/view_list/'.$param).'">会議室SIP番号 ';
		 if ($sortkey == 'conf_sip_number') {
			 echo $sorticon;
		 }
		 echo '</a></th>';

		 // 状態
		 $dir = ($sortkey == 'status' && $order == 'asc') ? 'desc' : 'asc';
		 $param = $tenant->company_id.'/status/'.$dir;
		 echo '<th><a href="'.base_url('group/view_list/'.$param).'">状態 ';
		 if ($sortkey == 'status') {
			 echo $sorticon;
		 }
		 echo '</a></th>';

         echo '<th>メンバー編集</th>';

//         echo '<th>操作</th>';
         echo '</tr>';
         echo '</thead>';
         echo '<tbody>';
         
         foreach ($accounts as $row) {
             echo '<tr>';
             echo '<td><a href="'.base_url('group/view/'.$tenant->company_id.'/'.$row->group_id).'"/a>'.$row->group_name.'</a></td>';
             echo '<td>'.$row->sip_number.'</td>';
             echo '<td>'.$row->conf_sip_number.'</td>';
             if ($row->status) {
                 echo '<td><span class="glyphicon glyphicon-ok poc-icon-ok"></span> 有効</span></td>';
             }
             else {
                 echo '<td><span class="glyphicon glyphicon-remove poc-icon-ng"></span> 無効</td>';
             }
             echo '<td><a href="'.base_url('group/plan/'.$tenant->company_id.'/'.$row->group_id).'" class="btn btn-xs btn-info">編集</a></td>';
             // 以下テスト
			 //echo '<td>';
             //echo '<div class="btn-group">';
             //echo '<a href="#" class="btn btn-success btn-xs glyphicon glyphicon-earphone"></a>';
             //echo '<a href="#" class="btn btn-default btn-xs glyphicon glyphicon-map-marker"></a>';
             //echo '<a href="#" class="btn btn-default btn-xs glyphicon glyphicon-pencil"></a>';
             //echo '</div>';
             //echo '</td>';
             echo '</tr>';
         }
         
         echo '</tbody></table>';
         echo '<div class="text-right poc-control-panel">';         
         echo '<p>';
		 echo '<a href="'.base_url('group/export/'.$tenant->company_id).'" class="btn btn-default"><span class="glyphicon glyphicon-save"></span> CSVエクスポート</a>';
         echo '</p>';
		 echo '</div>';
     }
     else {
         echo "登録されたグループはありません。";
     }
?>

<?php if ($usermode == 'admin') : ?>
            
            <?php echo form_open_multipart('group/import/'.$tenant->company_id); ?>
                <div class="text-right">
                        <div class="form-horizontal">
                    <p>
                            <div class="input-group" style="width: 33%; margin-left: auto">
                                    <input type="file" id="import_group" name="import_group" style="display: none"/>
                                    <a class="input-group-addon input-sm" onclick="$('#import_group').click();"><i class="glyphicon glyphicon-folder-open"></i></a>
                                    <input id="cover" type="text" class="form-control input-sm" placeholder="ファイルを選択" disabled="disabled" />
                            </div>
                            <button class="btn btn-default" type="submit"><span class="glyphicon glyphicon-open"></span> CSVインポート</button>
                        </div>
                    </p>
                    <script>
                    $('#import_group').change(function() {
                            $('#cover').val($(this).val());
                        });
                    </script>
                </div>
            <?php echo form_close(); ?>
            
<?php endif ?>


<?php
$this->load->view('templates/footer', $data);
?>
