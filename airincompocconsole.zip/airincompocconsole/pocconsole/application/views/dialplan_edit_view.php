<?php
$data['username'] = $username;
$data['usermode'] = $usermode;
$data['css'] = 'dummy.css';
$data['menu'] = 'dialplan';

// setup breadcrumb
$breadcrumb = array(
	'ホーム' => 	base_url('home'),
	'緊急呼出' => false,
);

$data['breadcrumb'] = $breadcrumb;

$this->load->view('templates/header', $data);
$this->load->view('templates/sidemenu', $data);

// use $tenant, $accounts, $groups for data display
?>

<?php if (!USE_BREADCRUMB_IN_HEADER && isset($breadcrumb)): ?>
	<ol class="breadcrumb"> <!-- パンくず対応済み -->
<?php
		foreach ($breadcrumb as $_title => $_url) {
			if ($_url) { echo '<li><a href="'.$_url.'">'.$_title.'</a></li>'; }
			else { echo '<li class="active">'.$_title.'</li>'; }
		}
?>
	</ol>
<?php endif ?>

<h2 class="page-header">緊急呼出編集：<?php echo $tenant->company_name; ?></h2>

<?php
  echo form_open('dialplan/edit/'.$tenant->company_id);
?>

<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">緊急呼出時の発信先選択</h3>
  </div>
  <div class="panel-body poc-panel-body">
    <div class="container-fluid poc-list">
<!--
      <div class="row">
        <div class="col-md-4 poc-list-title">ノーマル用 発信先リスト</div>
          <div class="col-md-8">
          <select name="emergency_sip_normal" style="width: 225px; padding: 0 5px;" class="form-control">
            <?php foreach ($accounts as $row) { ?>
              <option value="<?php echo $row->sip_number; ?>"
                 <?php if ($row->sip_number == $tenant->emergency_sip_normal) echo 'selected="selected"' ?> >
                 <?php echo $row->display_name; ?>
                 <?php echo '(',$row->sip_number,')'; ?>
                 </option>
            <?php } ?>
          </select>
          <?php echo form_error('emergency_sip_normal'); ?>
        </div>
      </div>
      <div class="row">
        <div class="col-md-4 poc-list-title">モニター用 発信先リスト</div>
        <div class="col-md-8">
          <select name="emergency_sip_monitor" style="width: 225px; padding: 0 5px;" class="form-control">
          <?php foreach ($accounts as $row) { ?>
            <option value="<?php echo $row->sip_number; ?>"
              <?php if ($row->sip_number == $tenant->emergency_sip_monitor) echo 'selected="selected"' ?> >
              <?php echo $row->display_name; ?>
              <?php echo '(',$row->sip_number,')'; ?>
              </option>
          <?php } ?>
          </select>
          <?php echo form_error('emergency_sip_monitor'); ?>
        </div>
      </div>
-->
      <div class="row">
        <div class="col-md-4 poc-list-title">発信先</div>
        <div class="col-md-8">
          <select name="emergency_sip_group" style="width: 225px; padding: 0 5px;" class="form-control">
          <?php foreach ($groups as $row) { ?>
            <option value="<?php echo $row->sip_number; ?>"
              <?php if ($row->sip_number == $tenant->emergency_sip_group) echo 'selected="selected"' ?> >
              <?php echo $row->group_name; ?>
              <?php echo '(',$row->sip_number,')'; ?>
              </option>
          <?php } ?>
          </select>
          <?php echo form_error('emergency_sip_group'); ?>
        </div>
      </div>
    </div>
  </div>
</div>


  <input type="hidden" name="company_id" value="<?php echo $tenant->company_id; ?>" />
  <div class="text-right poc-control-panel">
    <button type="submit" class="btn btn-primary">保存</button>
    <a href="<?php echo base_url('dialplan/view/'.$tenant->company_id); ?>" class="btn btn-default">キャンセル</a>
  </div>
</form>

<?php
$this->load->view('templates/footer', $data);
?>
