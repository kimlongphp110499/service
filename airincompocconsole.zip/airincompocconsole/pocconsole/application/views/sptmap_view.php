<!DOCTYPE html>
<html lang="ja">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>アルインコクラウドサービス</title>

    <!-- Bootstrap -->
    <link href="<?php echo base_url('bootstrap/css/bootstrap.min.css'); ?>" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="<?php echo base_url('css/common.css'); ?>" rel="stylesheet">
                                                                  
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>-->
    <script src="<?php echo base_url('jquery/jquery-1.12.2.min.js'); ?>"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo base_url('bootstrap/js/bootstrap.min.js'); ?>"></script>
  </head>
<body style="margin:0;padding:0">

<div id="gmap" style="margin:auto;width:100vw;height:95vh"></div>

<script src="https://maps.google.com/maps/api/js?key=AIzaSyDlRBJeBS0oSCtp5sEw9N73a90kfMoLbig&language=ja"></script>
<script>
var timer = false;
var staffMarkers = [];
var map;

function updateStaffMarkers(json) {
    console.log('updateStaffMarkers');
    staffMarkers.forEach(function(marker) {
        marker.marked = false;
    });

    for (let i = 0; i < json.length; i++) {
        let staff = json[i];
        //console.log('display_name='+staff['display_name']+' lon='+staff['lon']+' lat='+staff['lat']);
        if (staff['lon'] != null && staff['lat'] != null) {
            let marker = null;
            for (let j = 0; j < staffMarkers.length; j++) {
                if (staffMarkers[j].poc_id == staff['poc_id']) {
                    marker = staffMarkers[j];
                    break;
                }
            }
            if (marker == null) {
                marker = new google.maps.Marker({
                    position: {
                        lat: parseFloat(staff['lat']),
                        lng: parseFloat(staff['lon']),
                    },
                    map: map,
                    label: {
                        text: staff['display_name'],
                        fontWeight: 'bold',
                        fontSize: '12px',
                        color: '#000080',
                    },
                    icon: {
                        url: '<?php echo base_url('images/staff_icon_48.png'); ?>',
                        labelOrigin: new google.maps.Point(24, 54)
                    },
                });
                marker.poc_id = staff['poc_id'];
                staffMarkers.push(marker);
            } else {
                let lat = parseFloat(staff['lat']);
                let lng = parseFloat(staff['lon']);
                marker.setPosition(new google.maps.LatLng(lat, lng));
            }
            marker.marked = true;
        }
    }

    let newStaffMarkers = [];
    staffMarkers.forEach(function(marker) {
        if (marker.marked) {
            newStaffMarkers.push(marker);
        } else {
            marker.setMap(null);
        }
    });
    staffMarkers = newStaffMarkers;
}

function getStaffLocations() {
    $.ajax({
       url: '<?php echo base_url('sptmap/getStaffLocations/'.$token); ?>',
       dataType: 'json',
       success: function(json) {
           updateStaffMarkers(json);
           setTimeout(getStaffLocations, 10 * 1000);
       },
       error: function(xhr, text) {
           var data = JSON.parse(xhr.responseText);
           console.error(data.message);
       },
   });
}

var ini_lon = <?php echo $ini_lon ? $ini_lon : '139.7670516'; ?>;
var ini_lat = <?php echo $ini_lat ? $ini_lat : '35.6811673'; ?>;

$(function() {
    // google map表示
    let myLatLng = new google.maps.LatLng(ini_lat, ini_lon);
    let options = {
        zoom: 15,
        center: myLatLng,
        mapTypeId: 'roadmap'
    };
    map = new google.maps.Map(document.getElementById('gmap'), options);

    setTimeout(getStaffLocations, 0);
});
</script>

</body>
</html>
