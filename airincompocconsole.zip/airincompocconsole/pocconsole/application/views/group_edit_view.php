<?php
$data['username'] = $username;
$data['usermode'] = $usermode;
$data['css'] = 'dummy.css';
$data['menu'] = 'group';

// setup breadcrumb
$breadcrumb = array(
	'ホーム' => 	base_url('home'),
  'グループ一覧' => base_url('group/view_list/'.$tenant->company_id),
  'グループ詳細' => base_url('group/view/'.$tenant->company_id.'/'.$group->group_id),
  'グループ編集' => false,
);

$data['breadcrumb'] = $breadcrumb;

$this->load->view('templates/header', $data);
$this->load->view('templates/sidemenu', $data);
?>

<?php if (!USE_BREADCRUMB_IN_HEADER && isset($breadcrumb)): ?>
	<ol class="breadcrumb"> <!-- パンくず対応済み -->
<?php
		foreach ($breadcrumb as $_title => $_url) {
			if ($_url) { echo '<li><a href="'.$_url.'">'.$_title.'</a></li>'; }
			else { echo '<li class="active">'.$_title.'</li>'; }
		}
?>
	</ol>
<?php endif ?>

<h2 class="page-header">グループ編集：<?php echo $group->group_name; ?></h2>
<?php echo form_open('group/edit/'.$tenant->company_id.'/'.$group->group_id); ?>

  <div class="form-horizontal">

    <div class="form-group">
      <label class="control-label col-md-3">グループSIP番号</label>
      <div class="col-md-9">
          <div class="form-control-static"><?php echo $group->sip_number; ?></div>
          <input type="hidden" name="sip_number" value="<?php echo $group->sip_number; ?>" />
      </div>
    </div>

    <div class="form-group">
      <label class="control-label col-md-3">会議室SIP番号</label>
      <div class="col-md-9">
          <div class="form-control-static"><?php echo $group->conf_sip_number; ?></div>
          <input type="hidden" name="sip_number" value="<?php echo $group->conf_sip_number; ?>" />
      </div>
    </div>

    <div class="form-group">
      <label class="control-label col-md-3" for="group_name">グループ名</label>
      <div class="col-md-9">
        <input class="form-control input-sm" type="text" id="group_name" name="group_name" value="<?php echo set_value('group_name', $group->group_name); ?>"/>
	    <?php echo form_error('group_name'); ?>
      グループ名はテナント内でユニークな7文字以上50文字以下の文字列です
      </div>
    </div>

    <div class="form-group">
      <label class="control-label col-md-3">状態</label>
      <div class="col-md-9">
        <label calss="radio-inline">
          <input type="radio" name="status" value="1" <?php echo set_radio('status', '1', $group->status == 1 ? TRUE : FALSE); ?> /> 有効
        </label>
        <label calss="radio-inline">
          <input type="radio" name="status" value="0" <?php echo set_radio('status', '0', $group->status == 0 ? TRUE : FALSE); ?> /> 無効
        </label>
        <?php echo form_error('status'); ?>
      </div>
    </div>
  </div>

  <input type="hidden" name="company_id" value="<?php echo $tenant->company_id; ?>" />
  <div class="text-right poc-control-panel">
    <button type="submit" class="btn btn-primary">保存</button>
    <a href="<?php echo base_url('group/view/'.$tenant->company_id.'/'.$group->group_id); ?>" class="btn btn-default">キャンセル</a>
  </div>
</form>

<?php
$this->load->view('templates/footer', $data);
?>
