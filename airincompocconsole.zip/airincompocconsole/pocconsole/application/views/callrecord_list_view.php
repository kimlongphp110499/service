<?php
$data['username'] = $username;
$data['usermode'] = $usermode;
$data['css'] = 'dummy.css';
$data['menu'] = 'callrecord';

// setup breadcrumb
$breadcrumb = array(
	'ホーム' => 	base_url('home'),
  '通話記録' => false,
);

$data['breadcrumb'] = $breadcrumb;

$this->load->view('templates/header', $data);
$this->load->view('templates/sidemenu', $data);
?>

<?php if (!USE_BREADCRUMB_IN_HEADER && isset($breadcrumb)): ?>
	<ol class="breadcrumb"> <!-- パンくず対応済み -->
<?php
		foreach ($breadcrumb as $_title => $_url) {
			if ($_url) { echo '<li><a href="'.$_url.'">'.$_title.'</a></li>'; }
			else { echo '<li class="active">'.$_title.'</li>'; }
		}
?>
	</ol>
<?php endif ?>

<h2 class="page-header">通話記録</h2>

<span id="modalMessageArea"></span>

<div class="poc-message-box">
<?php
	if (!$records) {
		echo '通話記録がありません。';
	}
	else {
		$start = $page * 50 + 1;
		$end = $start + 49;
		if ($end > $record_count) {
			$end = $record_count;
		}
		echo $record_count.' 件の通話記録があります。<br/>';
		echo $start.'-'.$end.'を表示';
	}
?>
</div>

<?php if ($records) : ?>
<table class="table table-striped table-condensed table-hover">
  <thead>
    <tr>
<?php
	$sorticon = '<span class="glyphicon glyphicon-triangle-'
	    .($order == 'asc' ? 'top' : 'bottom').' poc-icon"></span>';

    // #
    $dir = ($sortkey == 'id' && $order == 'asc') ? 'desc' : 'asc';
    $param = $tenant->company_id.'/0/id/'.$dir;
    echo '<th><a href="'.base_url('callrecord/view_list/'.$param).'"># ';
	if ($sortkey == 'id') {
		echo $sorticon;
	}
	echo '</a></th>';

    // 日時
    $dir = ($sortkey == 'date_time' && $order == 'asc') ? 'desc' : 'asc';
    $param = $tenant->company_id.'/0/date_time/'.$dir;
    echo '<th><a href="'.base_url('callrecord/view_list/'.$param).'">日時 ';
	if ($sortkey == 'date_time') {
		echo $sorticon;
	}
	echo '</a></th>';

    // 発信元
    $dir = ($sortkey == 'send_from' && $order == 'asc') ? 'desc' : 'asc';
    $param = $tenant->company_id.'/0/send_from/'.$dir;
    echo '<th><a href="'.base_url('callrecord/view_list/'.$param).'">発信元 ';
	if ($sortkey == 'send_from') {
		echo $sorticon;
	}
	echo '</a></th>';

    // 発信先
    $dir = ($sortkey == 'send_to' && $order == 'asc') ? 'desc' : 'asc';
    $param = $tenant->company_id.'/0/send_to/'.$dir;
    echo '<th><a href="'.base_url('callrecord/view_list/'.$param).'">発信先 ';
	if ($sortkey == 'send_to') {
		echo $sorticon;
	}
	echo '</a></th>';

    // 通話時間
    $dir = ($sortkey == 'duration' && $order == 'asc') ? 'desc' : 'asc';
    $param = $tenant->company_id.'/0/duration/'.$dir;
    echo '<th><a href="'.base_url('callrecord/view_list/'.$param).'">通話時間 ';
	if ($sortkey == 'duration') {
		echo $sorticon;
	}
	echo '</a></th>';

    // 種別
    $dir = ($sortkey == 'type' && $order == 'asc') ? 'desc' : 'asc';
    $param = $tenant->company_id.'/0/type/'.$dir;
    echo '<th><a href="'.base_url('callrecord/view_list/'.$param).'">種別 ';
	if ($sortkey == 'type') {
		echo $sorticon;
	}
	echo '</a></th>';

?>
      <!--<th>再生</th>-->
    </tr>
  </thead>
  <tbody>
<?php
	$count = 1;
     foreach ($records as $row) {
         echo '<tr>';
         echo '<td class="text-right">'.$row->id.'</td>';
		 $epoch = $row->date_time / 1000;
         echo '<td>'.date('Y-m-d H:i:s', $epoch).'</td>';
         echo '<td>'.$row->send_from.'</td>';
         echo '<td>'.(empty($row->send_to) ? $row->group_name : $row->send_to).'</td>';
	 if ($row->type == 13) {
	     echo '<td>-</td>';
	 } else {
             echo '<td>'.sprintf('%02d:%02d',($row->duration / 1000) / 60, ($row->duration / 1000) % 60).'</td>';
         }
		 switch ($row->type) {
		 case 5:
			 echo '<td>個別:全二重</td>';
			 break;
		 case 6:
			 echo '<td>個別:半二重</td>';
			 break;
		 case 7:
			 echo '<td>同報:全二重</td>';
			 break;
		 case 8:
			 echo '<td>同報:半二重</td>';
			 break;
		 case 13:
			 echo '<td>会議室</td>';
			 break;
		 case 14:
			 echo '<td>モニタ</td>';
			 break;
		 default:
			 echo '<td>-</td>';
		 }
         //echo '<td><button type="button" id="msgid'.$row->id.'" onclick="audio_play(this)" class="btn btn-success btn-xs glyphicon glyphicon-play" data-toggle="modal" data-target="#modal"></button></td>';
         echo '</tr>';
		 $count++;
     }
?>
  </tobdy>
</table>

<div class="row">
  <ul class="col-md-10 pagination pagination-sm">
<?php
	$total = ceil($record_count / 50);
    if ($page > 0) {
		$param = $tenant->company_id.'/'.($page - 1);
		if ($sortkey) {
			$param .= '/'.$sortkey.'/'.$order;
		}		
		echo '<li><a href="'.base_url('callrecord/view_list/'.$param).'">&laquo;</a></li>';
	}
	else {
		echo '<li class="disabled"><a href="#">&laquo;</a></li>';
	}

    for ($i = 0; $i < $total; $i++) {
		$param = $tenant->company_id.'/'.$i;
		if ($sortkey) {
			$param .= '/'.$sortkey.'/'.$order;
		}		
        echo '<li';
		if ($i == $page) {
			echo ' class="active"';
		}
		echo '><a href="'.base_url('callrecord/view_list/'.$param).'">'.($i + 1).'</a></li>';
	}

    if ($page < $total - 1) {
		$param = $tenant->company_id.'/'.($page + 1);
		if ($sortkey) {
			$param .= '/'.$sortkey.'/'.$order;
		}		
		echo '<li><a href="'.base_url('callrecord/view_list/'.$param).'">&raquo;</a></li>';
	}
	else {
		echo '<li class="disabled"><a href="#">&raquo;</a></li>';
	}
?>
  </ul>
  <div class="col-md-2 text-right">
    <a href="<?php echo base_url('callrecord/export/'.$tenant->company_id); ?>" class="btn btn-default"><span class="glyphicon glyphicon-save"></span> エクスポート</a>
  </div>
</div>

<!-- modal for audio player -->
<div class="modal fade" id="modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">通話記録再生</h4>
      </div>
      <div class="modal-body">
        <div class="text-center">
		  <div id="player_message" class="poc-message-box"></div>
          <audio id="player" controls="controls" controlslist="nodownload"></audio>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<script type="text/javascript">
function audio_play(elm) {
    url = "<?php echo base_url('callrecord/play_message/'.$tenant->company_id); ?>" + "/" + $(elm).attr("id").substring(5);
	$('#player_message').html('');
	$.get(url, null, function(data) {
			if (data.search(/Error/) != -1) {
				$('#player_message').html(data);
			}
			else {
				$('#player').get(0).src = data;
				$('#player').get(0).play();
			}
		});
}

$(function() {
	// bootstrap3 modal events: 'show.bs.modal', 'shown.bs.modal', 'hide.bs.modal', 'hidden.bs.modal'
	$('#modal').on('hide.bs.modal', function() {
		//$('#modalMessageArea').text("hide.bs.modal event!");
		$('#player').get(0).pause();
		//$('#player_message').html('');
	});
});

</script>
<?php endif ?>

<?php
$this->load->view('templates/footer', $data);
?>
