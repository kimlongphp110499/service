<?php
$data['username'] = $username;
$data['usermode'] = $usermode;
$data['css'] = 'dummy.css';
$data['menu'] = 'firmup_handy';

// setup breadcrumb
$breadcrumb = array(
	'ホーム' => 	base_url('home'),
	'ファームアップ管理' => false,
);

$data['breadcrumb'] = $breadcrumb;

$this->load->view('templates/header', $data);
$this->load->view('templates/sidemenu', $data);

// global $global_web_account_type_names;

?>

<?php if (!USE_BREADCRUMB_IN_HEADER && isset($breadcrumb)): ?>
	<ol class="breadcrumb"> <!-- パンくず対応済み -->
<?php
		foreach ($breadcrumb as $_title => $_url) {
			if ($_url) { echo '<li><a href="'.$_url.'">'.$_title.'</a></li>'; }
			else { echo '<li class="active">'.$_title.'</li>'; }
		}
?>
	</ol>
<?php endif ?>

<h2 class="page-header">ファームアップファイル一覧</h2>
<?php if ($usermode == 'admin') : ?>
<div class="text-right">
  <a href="<?php echo base_url('firmup_handy/add'); ?>" class="btn btn-primary"><span class="glyphicon glyphicon-plus"></span> ファームアップ用ファイル追加</a>
</div>
<?php endif ?>
     
<?php
     if (!empty($firmup_handy)) {
         $sorticon = '<span class="glyphicon glyphicon-triangle-'
		     .($order == 'asc' ? 'top' : 'bottom').' poc-icon"></span>';

		 echo '登録機種数: '.count($firmup_handy);
         echo '<table class="table table-striped table-condensed table-hover poc-table">';
		 echo '<thead>';
		 echo '<tr>';

		 // ID番号
         $dir = ($sortkey == 'id' && $order == 'asc') ? 'desc' : 'asc';
		 $param = 'id/'.$dir;
         echo '<th><a href="'.base_url('firmup_handy/view_list/'.$param).'">ID ';
		 if ($sortkey == 'id') {
			 echo $sorticon;
		 }
		 echo '</a></th>';

		 // テナント名
         $dir = ($sortkey == 'company_name' && $order == 'asc') ? 'desc' : 'asc';
		 $param = 'company_name/'.$dir;
         echo '<th><a href="'.base_url('firmup_handy/view_list/'.$param).'">テナント名 ';
		 if ($sortkey == 'company_name') {
			 echo $sorticon;
		 }
		 echo '</a></th>';

		 // 機種名
         $dir = ($sortkey == 'device_name' && $order == 'asc') ? 'desc' : 'asc';
		 $param = 'device_name/'.$dir;
         echo '<th><a href="'.base_url('firmup_handy/view_list/'.$param).'">機種名 ';
		 if ($sortkey == 'device_name') {
			 echo $sorticon;
		 }
		 echo '</a></th>';

		 // 登録中バージョン
         $dir = ($sortkey == 'firm_version' && $order == 'asc') ? 'desc' : 'asc';
		 $param = 'firm_version/'.$dir;
         echo '<th><a href="'.base_url('firmup_handy/view_list/'.$param).'">登録中バージョン ';
		 if ($sortkey == 'firm_version') {
			 echo $sorticon;
		 }
		 echo '</a></th>';

		 // 登録日
		 $dir = ($sortkey == 'register_date' && $order == 'asc') ? 'desc' : 'asc';
		 $param = 'register_date/'.$dir;
		 echo '<th><a href="'.base_url('firmup_handy/view_list/'.$param).'">登録日 ';
		 if ($sortkey == 'register_date') {
			 echo $sorticon;
		 }
		 echo '</a></th>';

		 // 登録端末数
		 echo '<th>登録端末数 ';
		 echo '</th>';

		 // 更新済み端末数
		 echo '<th>更新済み端末数 ';
		 echo '</th>';
		 
		 // 未更新端末数
		 echo '<th>未更新端末数 ';
		 echo '</th>';		 

		 // 状態
         $dir = ($sortkey == 'flag' && $order == 'asc') ? 'desc' : 'asc';
		 $param = 'flag/'.$dir;
         echo '<th><a href="'.base_url('firmup_handy/view_list/'.$param).'">状態 ';
		 if ($sortkey == 'flag') {
			 echo $sorticon;
		 }
		 echo '</a></th>';

		 // FROM
         $dir = ($sortkey == 'validity_from' && $order == 'asc') ? 'desc' : 'asc';
		 $param = 'validity_from/'.$dir;
         echo '<th><a href="'.base_url('firmup_handy/view_list/'.$param).'">FROM ';
		 if ($sortkey == 'validity_from') {
			 echo $sorticon;
		 }
         echo '</a></th>';
         
		 // TO
         $dir = ($sortkey == 'validity_to' && $order == 'asc') ? 'desc' : 'asc';
		 $param = 'validity_to/'.$dir;
         echo '<th><a href="'.base_url('firmup_handy/view_list/'.$param).'">TO ';
		 if ($sortkey == 'validity_to') {
			 echo $sorticon;
		 }
         echo '</a></th>';
		 
		 echo '<th>削除 ';
         echo '</th>';
         // 削除
         /*
         $dir = ($sortkey == 'device_name' && $order == 'asc') ? 'desc' : 'asc';
		 $param = 'device_name/'.$dir;
         echo '<th><a href="'.base_url('firmup_handy/view_list/'.$param).'">種別 ';
		 if ($sortkey == 'device_name') {
			 echo $sorticon;
		 }
         echo '</a></th>';
         */
		 
		 
		 echo '</tr>';
		 echo '</thead>';
		 echo '<tbody>';

         foreach ($firmup_handy as $row) {
			 echo '<tr>';
			 echo '<td>'.$row['id'].'</td>';
			 echo '<td>'.$row['company_name'].'</td>';			 
			 echo '<td>'.$row['device_name'].'</td>';

			 $firm_version_name = empty($row['firm_version']) ? '(未登録)' : $row['firm_version'];

             echo '<td><a href="'.base_url('firmup_handy/edit/'.$row['id']).'"/a>'.$firm_version_name.'</a></td>';
			 echo '<td>'.$row['register_date'].'</td>';
			 echo '<td><a href="'.base_url('firmup_handy/mac_view_list_1/'.$row['id']).'"/a>'.$row['getMacaddr_reg_num'].'</td>';
			 echo '<td><a href="'.base_url('firmup_handy/mac_view_list_2/'.$row['id']).'"/a>'.$row['getMacaddr_upd_num'].'</td>';
			 echo '<td><a href="'.base_url('firmup_handy/mac_view_list_3/'.$row['id']).'"/a>'.$row['getMacaddr_noupd_num'].'</td>';
			 // now "$row->type" cannot be NULL but for safety
             // echo '<td>'.($global_web_account_type_names[empty($row->type) ? 'tenant' : $row->type]).'</td>';
			 /*
			 if ($usermode == 'admin') {
                 echo '<td>'.$row->company_name.'</td>';
             }
			 echo '<td>'.$row->last_login.'</td>';
			 */
             if ($row['flag']) {
                 echo '<td><span class="glyphicon glyphicon-ok poc-icon-ok"></span> 有効</span></td>';
             }
             else {
                 echo '<td><span class="glyphicon glyphicon-remove poc-icon-ng"></span> 無効</td>';
			 }
			 echo '<td>'.$row['validity_from'].'</td>';
			 echo '<td>'.$row['validity_to'].'</td>';
			 echo '<td><a href="'.base_url('firmup_handy/delete/'.$row['id']).'" class="btn btn-xs btn-info">削除</a></td>';
             echo '</tr>';
         }
		 /*
         echo '</tbody></table>';
		 echo '<div class="text-right">';
		 echo '<a href="'.base_url('firmup_handy/export').'" class="btn btn-sm btn-default"><span class="glyphicon glyphicon-save"></span> CSVエクスポート</a>';
		 echo '</div>';
		 */
     }
     else {
         echo "登録された機種はありません。";
     }
?>

<!-- modal for deleting PoC Account -->
<!--
<div class="modal fade" id="modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">確認</h4>
      </div>
      <div class="modal-body">
        ファイルを削除しますか？
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <a href="<?php echo base_url('firumup_handy/delete/'.$row->id); ?>" class="btn btn-primary">削除</a>
      </div>
    </div>
  </div>
</div>
-->
<?php
$this->load->view('templates/footer', $data);
?>
