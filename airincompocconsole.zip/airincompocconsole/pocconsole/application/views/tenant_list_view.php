<?php
$data['username'] = $username;
$data['usermode'] = $usermode;
$data['css'] = 'dummy.css';
$data['menu'] = 'tenant';

// setup breadcrumb
$breadcrumb = array(
	'ホーム' => 	base_url('home'),
	'テナント一覧' => false,
);

$data['breadcrumb'] = $breadcrumb;

$this->load->view('templates/header', $data);
$this->load->view('templates/sidemenu', $data);
?>

<?php if (!USE_BREADCRUMB_IN_HEADER && isset($breadcrumb)): ?>
	<ol class="breadcrumb"> <!-- パンくず対応済み -->
<?php
		foreach ($breadcrumb as $_title => $_url) {
			if ($_url) { echo '<li><a href="'.$_url.'">'.$_title.'</a></li>'; }
			else { echo '<li class="active">'.$_title.'</li>'; }
		}
?>
	</ol>
<?php endif ?>

<h2 class="page-header">テナント一覧</h2>
<div class="text-right" style="margin-bottom: 20px">
  <a href="<?php echo base_url('tenant/add'); ?>" class="btn btn-primary"><span class="glyphicon glyphicon-plus"></span> 新規テナント追加</a>
</div>
     
<?php
     if ($tenants) {
         $sorticon = '<span class="glyphicon glyphicon-triangle-'
		     .($order == 'asc' ? 'top' : 'bottom').' poc-icon"></span>';
?>
<!-- 検索フィールド -->
<div class="row">
  <div class="col-md-6">
<?php if ($search) : ?>
    <?php echo count($tenants); ?> 件が見つかりました。
<?php else : ?>
    登録テナント数: <?php echo count($tenants); ?>
<?php endif ?>
  </div>
  <div class="col-md-6">
    <?php echo form_open('tenant/view_list_search'); ?>
      <div class="input-group">
        <input type="text" class="form-control input-sm" name="search" placeholder="検索" <?php echo $search ? 'value="'.$search.'"' : ''; ?>/>
        <span class="input-group-btn">
          <button class="btn btn-sm btn-default" type="submit"><span class="glyphicon glyphicon-search"></span></button>
        </span>
      </div>
    </form>
  </div>
</div>
<?php
         echo '<table class="table table-striped table-condensed table-hover poc-table">';
         echo '<thead>';
         echo '<tr>';

		 // テナントID
         $dir = ($sortkey == 'company_id' && $order == 'asc') ? 'desc' : 'asc';
		 $param = 'company_id/'.$dir.'/'.$search;
         echo '<th><a href="'.base_url('tenant/view_list/'.$param).'"># ';
		 if ($sortkey == 'company_id') {
			 echo $sorticon;
		 }
		 echo '</a></th>';

		 // テナント名
         $dir = ($sortkey == 'company_name' && $order == 'asc') ? 'desc' : 'asc';
		 $param = 'company_name/'.$dir.'/'.$search;
         echo '<th><a href="'.base_url('tenant/view_list/'.$param).'">テナント名 ';
		 if ($sortkey == 'company_name') {
			 echo $sorticon;
		 }
		 echo '</a></th>';

		 // SIPコンテキスト名
         $dir = ($sortkey == 'sip_context_name' && $order == 'asc') ? 'desc' : 'asc';
		 $param = 'sip_context_name/'.$dir.'/'.$search;
         echo '<th><a href="'.base_url('tenant/view_list/'.$param).'">SIPコンテキスト名 ';
		 if ($sortkey == 'sip_context_name') {
			 echo $sorticon;
		 }
		 echo '</a></th>';

         echo '<!--<th>アラート識別 <a href="#" class="glyphicon glyphicon-triangle-bottom poc-icon"></a></th>';
         echo '<th>対処</th>';
         echo '<th>操作</th>-->';

		 // 登録日
         $dir = ($sortkey == 'register_date' && $order == 'asc') ? 'desc' : 'asc';
		 $param = 'register_date/'.$dir.'/'.$search;
         echo '<th><a href="'.base_url('tenant/view_list/'.$param).'">登録日 ';
		 if ($sortkey == 'register_date') {
			 echo $sorticon;
		 }
		 echo '</a></th>';

         echo '</tr>';
         echo '</thead>';
         echo '<tbody>';
         
         foreach ($tenants as $row) {
             echo '<tr>';
             echo '<td>'.$row->company_id.'</td>';
             echo '<td><a href="'.base_url('tenant/view/'.$row->company_id).'"/a>'.$row->company_name.'</a></td>';
             echo '<td>'.$row->sip_context_name.'</td>';
             echo '<!--<td>長期無通話</td>';
             echo '<td class="text-center"><buttton class="btn btn-warning btn-sm">対処実行</button></td>';
             // 以下テスト
             echo '<td>';
             echo '<div class="btn-group">';
             echo '<a href="'.base_url('tenant/edit/'.$row->company_id).'" class="btn btn-default btn-xs glyphicon glyphicon-pencil"></a>';
             echo '<a href="#" class="btn btn-default btn-xs glyphicon glyphicon-remove" data-toggle="modal" data-target="#modal" data-dest="'.base_url('tenant/delete/'.$row->company_id).'"></a>';
             echo '</div>';
             echo '</td>-->';
			 echo '<td>'.$row->register_date.'</td>';
             echo '</tr>';
         }
         
         echo '</tbody></table>';
		 echo '<div class="text-right poc-control-panel">';
		 echo '<a href="'.base_url('tenant/export').'" class="btn btn-sm btn-default"><span class="glyphicon glyphicon-save"></span> エクスポート</a>';
		 echo '</div>';
     }
     else {
         echo "登録されたテナントはありません。";
     }
?>
<?php if ($usermode == 'admin') : ?>
<?php echo form_open_multipart('tenant/import/'); ?>
<div class="text-right">
  <div class="form-horizontal">
    <p>
      <div class="input-group" style="width: 33%; margin-left: auto">
        <input type="file" id="import_file" name="import_file" style="display: none"/>
        <a class="input-group-addon input-sm" onclick="$('#import_file').click();"><i class="glyphicon glyphicon-folder-open"></i></a>
        <input id="cover" type="text" class="form-control input-sm" placeholder="ファイルを選択" disabled="disabled" />
      </div>
      <button class="btn btn-default" type="submit"><span class="glyphicon glyphicon-open"></span> CSVインポート</button>
	</p>
    <script>
      $('#import_file').change(function() {
        $('#cover').val($(this).val());
      });
    </script>
  </div>
</div>
<?php echo form_close(); ?>
<?php endif ?>

<!-- modal for deleting tenant -->
<div class="modal fade" id="modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">確認</h4>
      </div>
      <div class="modal-body">
        テナントを削除しますか？
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <a id="modal_delete" href="#" class="btn btn-primary">削除</a>
      </div>
    </div>
  </div>
</div>
<script>
	 $('#modal').on('show.bs.modal', function (event) {
			 var src = $(event.relatedTarget);
			 var link = src.data('dest');
			 var modal = $(this);
			 modal.find('#modal_delete').attr('href', link);
		 });
</script>

<?php
$this->load->view('templates/footer', $data);
?>
