<?php
$data['username'] = $username;
$data['usermode'] = $usermode;
$data['css'] = 'dummy.css';
$data['menu'] = 'callrecord';

// setup breadcrumb
$breadcrumb = array(
	'ホーム' => 	base_url('home'),
  '通話記録' => false,
);

$data['breadcrumb'] = $breadcrumb;

$this->load->view('templates/header', $data);
$this->load->view('templates/sidemenu', $data);
?>

<?php if (!USE_BREADCRUMB_IN_HEADER && isset($breadcrumb)): ?>
<ol class="breadcrumb"> <!-- パンくず対応済み -->
<?php
  foreach ($breadcrumb as $_title => $_url) {
    if ($_url) { echo '<li><a href="'.$_url.'">'.$_title.'</a></li>'; }
    else { echo '<li class="active">'.$_title.'</li>'; }
  }
?>
</ol>
<?php endif ?>

<h2 class="page-header">通話記録</h2>
テナントを選択してください。
     
<table class="table table-striped table-condensed table-hover poc-table">
  <thead>
    <tr>
      <th>ID</th>
      <th>テナント名</th>
    </tr>
  </thead>
  <tbody>
<?php
     foreach ($tenants as $row) {
         echo '<tr>';
         echo '<td>'.$row->company_id.'</td>';
         echo '<td><a href="'.base_url('callrecord/view_list/'.$row->company_id).'">'.$row->company_name.'</a></td>';
         echo '</tr>';
     }
?>
  </tobdy>
</table>

<?php
$this->load->view('templates/footer', $data);
?>
