<?php
$data['username'] = $username;
$data['usermode'] = $usermode;
$data['css'] = $css;
$data['menu'] = $menu;
$this->load->view('templates/header', $data);
$this->load->view('templates/sidemenu', $data);

if ($success) {
	echo '<div class="bg-info text-center poc-message-box">';
    echo '<div class="poc-message">';
    echo (isset($message) ? $message : '成功しました。');
	echo '</div>';
}
else {
	echo '<div class="bg-danger text-center poc-message-box">';
    echo '<div class="poc-message">';
    echo (isset($message) ? $message : '失敗しました。');
	echo '</div>';
}
?>
  <div class="poc-message">
    <a href="<?php echo base_url($back); ?>" class="btn btn-primary">OK</a>
  </div>
</div>

<?php
$this->load->view('templates/footer', $data);
?>