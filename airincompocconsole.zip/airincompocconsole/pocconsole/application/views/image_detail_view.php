<?php
$data['username'] = $username;
$data['usermode'] = $usermode;
$data['css'] = 'dummy.css';
$data['menu'] = 'image';

// setup breadcrumb
$breadcrumb = array(
	'ホーム' => 	base_url('home'),
  '転送画像一覧' => false,
);

$data['breadcrumb'] = $breadcrumb;

$this->load->view('templates/header', $data);
$this->load->view('templates/sidemenu', $data);
?>

<?php if (!USE_BREADCRUMB_IN_HEADER && isset($breadcrumb)): ?>
	<ol class="breadcrumb"> <!-- パンくず対応済み -->
<?php
		foreach ($breadcrumb as $_title => $_url) {
			if ($_url) { echo '<li><a href="'.$_url.'">'.$_title.'</a></li>'; }
			else { echo '<li class="active">'.$_title.'</li>'; }
		}
?>
	</ol>
<?php endif ?>

<h2 class="page-header">画像詳細: <?php echo $account->display_name; ?></h2>

<?php if (!count($image)) : ?>
<div class="poc-message-box">
画像がありません。
</div>
<?php else : ?>
<div id="image-carousel" class="carousel slide">
  <div class="carousel-inner" role="listbox">
<?php for ($i = 0; $i < count($image) - 1; $i++) : ?>
    <div id="img<?php echo $i; ?>" class="item poc-image-pic">
      <img src=""/>
      <div class="carousel-caption">
        <?php echo $image[$i]["date"]; ?> <?php echo $image[$i]["time"]; ?>
      </div>
    </div>
<?php endfor ?>
    <div id="img<?php echo (count($image) - 1); ?>" class="item active poc-image-pic">
      <!--<img src="<?php echo $image_path.$image[count($image) - 1]["file_name"].'.jpeg'; ?>">-->
      <img src="<?php echo $image_path.'/'.$image[count($image) - 1]["file_name"]; ?>">
      <div class="carousel-caption">
	  <?php echo $image[count($image) - 1]["date"]; ?> <?php echo $image[count($image) - 1]["time"]; ?>
      </div>
    </div>
  </div>

  <a class="left carousel-control" href="#image-carousel" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left"></span>
  </a>
  <a class="right carousel-control" href="#image-carousel" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right"></span>
  </a>
</div>
<?php endif ?>

	<div class="poc-control-panel text-right">
<?php if (count($image)) : ?>
      <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modal">この画像を配信</button>
<?php endif ?>
      <a class="btn btn-default" href="<?php echo base_url('image/tile_view/'.$tenant->company_id); ?>">戻る</a>
    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="modal" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <?php echo form_open('image/push_image/'.$tenant->company_id.'/'.$account->poc_id); ?>
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal"></button>
          <h4 class="modal-title">配信先を選択</h4>
        </div>
        <div class="modal-body">
          <div style="height: 400px;overflow: scroll">
            <table class="table table-striped table-condensed">
              <tbody>
<?php
	foreach ($accounts as $row) {
	    echo '<tr>';
		echo '<td><input type="checkbox" name="poc_id[]" value="'.$row->poc_id.'" /></td>';
		echo '<td>'.$row->display_name.'</td>';
		echo '</tr>';
    }
    if ($groups) {
  	    foreach ($groups as $row) {
            echo '<tr>';
			echo '<td><input type="checkbox" name="group_id[]" value="'.$row->group_id.'" /></td>';
			echo '<td>'.$row->group_name.'</td>';
			echo '</tr>';
		}
	}
?>
              </tbody>
            </table>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">配信</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">閉じる</button>
        </div>
		<input type="hidden" id="image_id" name="image_id" value=""/>
      </form>
    </div><!-- modal-content -->
  </div><!-- modal-dialog -->
</div><!-- modal -->

<script>
$(function () {
	var current_image = <?php echo (count($image) - 1); ?>;
	var array = [];
<?php
	  for ($i = 0; $i < count($image); $i++) {
		  echo 'array.push("'.$image[$i]['file_name'].'");';
	  }
?>
	$('#image-carousel').carousel({interval: false});
	$('#image-carousel').on('slide.bs.carousel', function (evt) {
			id = evt.relatedTarget.id.substring(3);
			current_image = id;
			$('#'+evt.relatedTarget.id+' img').attr('src', '<?php echo $image_path; ?>/' + array[id]);
		});

	$("form").submit(function() {
			$('#image_id').val(array[current_image]);
			return true;
		});
});
</script>

<?php
$this->load->view('templates/footer', $data);
?>

