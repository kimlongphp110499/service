<?php
$data['username'] = $username;
$data['usermode'] = $usermode;
$data['css'] = 'dummy.css';
$data['menu'] = 'devicesetting';

// setup breadcrumb
$breadcrumb = array(
	'ホーム' => 	base_url('home'),
	'デバイス設定' => false,
);

$data['breadcrumb'] = $breadcrumb;

$this->load->view('templates/header', $data);
$this->load->view('templates/sidemenu', $data);
?>

<?php if (!USE_BREADCRUMB_IN_HEADER && isset($breadcrumb)): ?>
	<ol class="breadcrumb"> <!-- パンくず対応済み -->
<?php
		foreach ($breadcrumb as $_title => $_url) {
			if ($_url) { echo '<li><a href="'.$_url.'">'.$_title.'</a></li>'; }
			else { echo '<li class="active">'.$_title.'</li>'; }
		}
?>
	</ol>
<?php endif ?>

<h2 class="page-header">デバイス設定</h2>

<div class="panel panel-info">
	<div class="panel-heading">
		<h3 class="panel-title">DJCP100の共通設定 (保守アカウント用)</h3>
	</div>
	<div class="panel-body poc-panel-body">
		<div class="container-fluid poc-list">
			<a href="<?php echo base_url('handy_device/view/0'); ?>" class="btn btn-default">アカウントマスターデータ</a>
			<a href="<?php echo base_url('handy_tenant/view/0'); ?>" class="btn btn-default">テナントマスターデータ</a>
			<a href="<?php echo base_url('handy_factory/view'); ?>" class="btn btn-default">工場出荷マスターデータ</a>
		</div>
		<p />
      <p>テナント個別の設定を変更する時は以下よりテナント名を選択してください。</p>
 	  <p>アカウント個別の設定は「アカウント」から行います。</p>
	</div>
</div>

他の機種の場合、以下よりテナントを選択してください。
     
<table class="table table-striped table-condensed table-hover poc-table">
  <thead>
    <tr>
      <th>テナント名</th>
    </tr>
  </thead>
  <tbody>
<?php
     foreach ($tenants as $row) {
         echo '<tr>';
         echo '<td><a href="'.base_url('devicesetting/view/'.$row->company_id).'">'.$row->company_name.'</a></td>';
         echo '</tr>';
     }
?>
  </tobdy>
</table>

<?php
$this->load->view('templates/footer', $data);
?>
