<?php if (! defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class Firmup_handy extends CI_Controller
{

    public function __construct()
    {        
        parent::__construct();
        $this->load->model('firmup_handy_model', '', true);
        $this->load->model('tenant_model', '', true);
        $this->load->helper(array('form','url'));
    }

    /**
     * Webアカウント一覧を表示する。
     *
     * @param string $sortkey ソートキー。
     * @param string $order 順序('asc'or'desc')
     */
    public function view_list($sortkey = false, $order = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        if ($session_data['usermode'] != 'admin') {
            $this->permission_error($session_data);
            return;
        }

        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['sortkey'] = $sortkey;
        $data['order'] = $order;

        $firm_list = array();

        $firmup_handy = $this->firmup_handy_model->getFirm($sortkey, $order);
        //$macaddr_reg = $this->firmup_handy_model->getMacaddr_reg($firmup_handy->stdClass[0]->id);
        //$macaddr_upd = $this->firmup_handy_model->getMacaddr_updata($firmup_handy->id, $firmup_handy->firm_version);
        //$macaddr_noupd = $this->firmup_handy_model->getMacaddr_noupd($firmup_handy->id, $firmup_handy->firm_version);

        if ($firmup_handy) {
            foreach ($firmup_handy as $row) {
                $firm_data['id'] =$row->id;
                $firm_data['company_id'] = $row->company_id;
                $firm_data['company_name'] = $row->company_name;
                $firm_data['device_name'] = $row->device_name;
                $firm_data['firm_version'] = $row->firm_version;
                $firm_data['register_date'] = $row->register_date;

                $firmMac_data['getMacaddr_reg'] =
                    $this->firmup_handy_model->getMacaddr_reg($row->id);
                if(empty($firmMac_data['getMacaddr_reg'])){
                    $firm_data['getMacaddr_reg_num'] = 0;
                }else{
                    $firm_data['getMacaddr_reg_num'] = count($firmMac_data['getMacaddr_reg']);
                }

                $firmMac_data['getMacaddr_upd'] =
                    $this->firmup_handy_model->getMacaddr_updated($row->id, $row->firm_version);
                if(empty($firmMac_data['getMacaddr_upd'])){
                    $firm_data['getMacaddr_upd_num'] = 0;
                }else{
                    $firm_data['getMacaddr_upd_num'] = count($firmMac_data['getMacaddr_upd']);
                }

                $firmMac_data['getMacaddr_noupd'] =
                    $this->firmup_handy_model->getMacaddr_noupd($row->id, $row->firm_version);
                if(empty($firmMac_data['getMacaddr_noupd'])){
                    $firm_data['getMacaddr_noupd_num'] = 0;
                }else{
                    $firm_data['getMacaddr_noupd_num'] = count($firmMac_data['getMacaddr_noupd']);
                }
                
                $firm_data['flag'] = $row->flag;
                $firm_data['validity_from'] = $row->validity_from;
                $firm_data['validity_to'] = $row->validity_to;
                $firm_list[] = $firm_data;
            }

            $data['firmup_handy'] = $firm_list;
        }
        // otherwise : 登録ファームなし
        
        $this->load->view('firmup_handy_list_view', $data);
        /*
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['sortkey'] = $sortkey;
        $data['order'] = $order;
        if ($session_data['usermode'] == 'admin') {
            $data['accounts'] = $this->webaccount_model->get_all($sortkey, $order);
        } else {
            $data['accounts'] = $this->webaccount_model->get_tenant($session_data['tenant'], $sortkey, $order);
        }
        
        $this->load->view('webaccount_list_view', $data);
        */
    }

    /**
     * 登録端末リストを表示する。
     *
     * @param string $sortkey ソートキー。
     * @param string $order 順序('asc'or'desc')
     */
    public function mac_view_list_1($id, $sortkey = false, $order = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['sortkey'] = $sortkey;
        $data['order'] = $order;
        $data['id'] = $id;

        $data['page_title'] = '登録端末一覧';

        $firm_list = array();


        if ($session_data['usermode'] == 'admin') {
            
            $firmup_macaddr = $this->firmup_handy_model->getMacaddr_reg($id, $sortkey, $order);

            //$macaddr_reg = $this->firmup_handy_model->getMacaddr_reg($firmup_handy->stdClass[0]->id);
            //$macaddr_upd = $this->firmup_handy_model->getMacaddr_updata($firmup_handy->id, $firmup_handy->firm_version);
            //$macaddr_noupd = $this->firmup_handy_model->getMacaddr_noupd($firmup_handy->id, $firmup_handy->firm_version);

            if(!empty($firmup_macaddr)){
                foreach ($firmup_macaddr as $row) {
                    $firm_data['macaddr'] =$row->macaddr;
                    $firm_data['firm_version'] = $row->firm_version;
                    $firm_data['last_connect'] = $row->last_connect;
                    $firm_list[] = $firm_data;
                }
            }
        }

        $data['firmup_macaddr'] = $firm_list;
        
        $this->load->view('firmup_handy_macaddr_list_view', $data);
        /*
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['sortkey'] = $sortkey;
        $data['order'] = $order;
        if ($session_data['usermode'] == 'admin') {
            $data['accounts'] = $this->webaccount_model->get_all($sortkey, $order);
        } else {
            $data['accounts'] = $this->webaccount_model->get_tenant($session_data['tenant'], $sortkey, $order);
        }
        
        $this->load->view('webaccount_list_view', $data);
        */
    }

    /**
     * 登録端末リストを表示する。
     *
     * @param string $sortkey ソートキー。
     * @param string $order 順序('asc'or'desc')
     */
    public function mac_view_list_2($id, $sortkey = false, $order = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['sortkey'] = $sortkey;
        $data['order'] = $order;
        $data['id'] = $id;

        $data['page_title'] = '更新済み端末リスト';

        $firm_list = array();

        if ($session_data['usermode'] == 'admin') {

            $firmup_file = $this->firmup_handy_model->getFirmupfile($id);
            $firmup_macaddr = $this->firmup_handy_model->getMacaddr_updated($id, $firmup_file->firm_version, $sortkey, $order);
            
            //$macaddr_reg = $this->firmup_handy_model->getMacaddr_reg($firmup_handy->stdClass[0]->id);
            //$macaddr_upd = $this->firmup_handy_model->getMacaddr_updata($firmup_handy->id, $firmup_handy->firm_version);
            //$macaddr_noupd = $this->firmup_handy_model->getMacaddr_noupd($firmup_handy->id, $firmup_handy->firm_version);

            if(!empty($firmup_macaddr)){
                foreach ($firmup_macaddr as $row) {
                    $firm_data['macaddr'] =$row->macaddr;
                    $firm_data['firm_version'] = $row->firm_version;
                    $firm_data['last_connect'] = $row->last_connect;
                    $firm_list[] = $firm_data;
                }
            }
            
        }

        $data['firmup_macaddr'] = $firm_list;
        
        $this->load->view('firmup_handy_macaddr_list_view', $data);
        /*
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['sortkey'] = $sortkey;
        $data['order'] = $order;
        if ($session_data['usermode'] == 'admin') {
            $data['accounts'] = $this->webaccount_model->get_all($sortkey, $order);
        } else {
            $data['accounts'] = $this->webaccount_model->get_tenant($session_data['tenant'], $sortkey, $order);
        }
        
        $this->load->view('webaccount_list_view', $data);
        */
    }

    /**
     * 登録端末リストを表示する。
     *
     * @param string $sortkey ソートキー。
     * @param string $order 順序('asc'or'desc')
     */
    public function mac_view_list_3($id, $sortkey = false, $order = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['sortkey'] = $sortkey;
        $data['order'] = $order;
        $data['id'] = $id;

        $data['page_title'] = "未更新端末一覧";

        $firm_list = array();
 

        if ($session_data['usermode'] == 'admin') {

            $firmup_file = $this->firmup_handy_model->getFirmupfile($id);
            $firmup_macaddr = $this->firmup_handy_model->getMacaddr_noupd($id, $firmup_file->firm_version, $sortkey, $order);
            //$macaddr_reg = $this->firmup_handy_model->getMacaddr_reg($firmup_handy->stdClass[0]->id);
            //$macaddr_upd = $this->firmup_handy_model->getMacaddr_updata($firmup_handy->id, $firmup_handy->firm_version);
            //$macaddr_noupd = $this->firmup_handy_model->getMacaddr_noupd($firmup_handy->id, $firmup_handy->firm_version);

            if(!empty($firmup_macaddr)){
                foreach ($firmup_macaddr as $row) {
                    $firm_data['macaddr'] =$row->macaddr;
                    $firm_data['firm_version'] = $row->firm_version;
                    $firm_data['last_connect'] = $row->last_connect;
                    $firm_list[] = $firm_data;
                }
            }

        }

        $data['firmup_macaddr'] = $firm_list;
        
        $this->load->view('firmup_handy_macaddr_list_view', $data);
        /*
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['sortkey'] = $sortkey;
        $data['order'] = $order;
        if ($session_data['usermode'] == 'admin') {
            $data['accounts'] = $this->webaccount_model->get_all($sortkey, $order);
        } else {
            $data['accounts'] = $this->webaccount_model->get_tenant($session_data['tenant'], $sortkey, $order);
        }
        
        $this->load->view('webaccount_list_view', $data);
        */
    }

    /**
     * ファームアップ用ファイル登録画面を表示。
     */
    public function add($id = false)
    {
        
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        if ($session_data['usermode'] != 'admin') {
            $this->permission_error($session_data);
            return;
        }

        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['tenants'] = $this->tenant_model->get_all();
        if (empty($id)){
            $this->load->view('firmup_handy_new_view', $data);
        }else{
            $this->permission_error($session_data);
            return;
        }
        
    }

    /**
     * IMEI登録画面を表示。
     */
    public function macaddr_edit($id)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        if ($session_data['usermode'] != 'admin') {
            $this->permission_error($session_data);
            return;
        }

        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['firmup_file'] = $this->firmup_handy_model->getFirmupfile($id);
        if (empty($id)){
            $this->permission_error($session_data);
            return;
        }else{
            $this->load->view('firmup_handy_macaddr_edit_view', $data);
        }
        
    }

    /**
     * IMEI登録画面を表示。
     */
    public function macaddr_edit_action($id)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        if ($session_data['usermode'] != 'admin') {
            $this->permission_error($session_data);
            return;
        }

        // ここでpostパラメータを取得(もしあれば)

        // CSV アップロードを呼び出す
        $this->import($id, 'form_item');
    }


    /**
     * Webアカウントを追加する。
     */
    public function add_action()
    {
        $this->do_save_file(false);
    }

    /**
     * Webアカウントの詳細情報を表示する。
     *
     * @param int $id 表示するアカウントのID。
     */
    /*
    public function view($id = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        // パラメータチェック
        $account = $this->webaccount_model->get($id);
        if (!$account) {
            $this->permission_error($session_data);
            return;
        }

        if ($session_data['usermode'] != 'admin' && $account->company_id != $session_data['tenant']) {
            $this->permission_error($session_data);
            return;
        }

        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['account'] = $account;
        
        $this->load->view('webaccount_detail_view', $data);
    }
    */
    /**
     * ファームアップ用ファイル追加画面を表示。
     *
     * @param int $id 表示するアカウントのID。
     */
    public function edit($id = false) 
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        // パラメータチェック
        $firmup_file = $this->firmup_handy_model->getFirmupfile($id);
        if (!$firmup_file) {
            $this->permission_error($session_data);
            return;
        }

        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['firmup_file'] = $firmup_file;

        if (empty($id)){
            $this->permission_error($session_data);
            return;
        }else{
            $this->load->view('firmup_handy_edit_view', $data);
        }
        /*
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        // パラメータチェック
        $account = $this->webaccount_model->get($id);
        if (!$account) {
            $this->permission_error($session_data);
            return;
        }

        if ($session_data['usermode'] != 'admin' && $account->company_id != $session_data['tenant']) {
            $this->permission_error($session_data);
            return;
        }

        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['account'] = $account;
        
        $this->load->view('webaccount_edit_view', $data);
        */
    }

    /**
     * Webアカウントを編集する。
     *
     * @param int $id 編集するテナントのID。
     */
    public function edit_action($id)
    {
        $this->do_save_file($id);
    }
    
    /**
     * Webアカウントを削除する。
     *
     * @param int $id 削除するテナントのID。
     */
    public function delete($id)
    {
        
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        // パラメータチェック
        $firmup_handy = $this->firmup_handy_model->getFirmupfile($id);
        if (!$firmup_handy) {
            $this->permission_error($session_data);
            return;
        }

        $message = null;
        $rslt = $this->firmup_handy_model->delete($id);
        if (!$rslt) {
            $message = 'データベースエラーが発生しました。';
        }

        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['css'] = 'dummy.css';
        $data['success'] = $rslt;
        $data['menu'] = 'firmup_handy';
        $data['back'] = 'firmup_handy/view_list';
        $data['message'] = $message;
        $this->load->view('message_view', $data);
        
    }

    /**
     * 追加、編集内容をDBに保存する。
     *
     * @param int $id アカウントのID(編集時)  追加時には falseを渡す
     */
    
    private function do_save_file($id = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        $firmup_file = $this->firmup_handy_model->getFirmupfile($id);
        if ($session_data['usermode'] != 'admin') {
                $this->permission_error($session_data);
                return;
        }

        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('<div class="bg-danger">', '</div>');

        // 共通チェック
        $this->form_validation->set_rules('company_id', 'テナント番号', 'required');
        $this->form_validation->set_rules('firm_version', 'バージョン名', 'required');
        $firm_version = $this->input->post('firm_version');
        if($firm_version)
        {
            $this->form_validation->set_rules('firm_version', '登録中バージョン', 'trim|required|regex_match[/^([a-z0-9-])+$/i]|max_length[128]');
        }

        if ($id) {
            // 編集時のチェック
        }
        else {
            // 新規の時のチェック
            
        }
      
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        
        if ($this->form_validation->run() === false) {
            if ($id) {
                $data['firmup_file'] = $firmup_file;
                $this->load->view('firmup_handy_edit_view', $data);
            } else {
                $data['firmup_file'] = false;
                $data['tenants'] = $this->tenant_model->get_all();
                $this->load->view('firmup_handy_new_view', $data);
            }
            return;
        }

        $message = null;
        
        //
        // ファイルアップロード処理
        //
        $file_name = md5(uniqid(rand(), true));
        $config['upload_path'] = FW_FOLDER;
        $config['file_name'] = $file_name;
        $config['allowed_types'] = '*';
        $config['max_size']	= '10240';

        $this->load->library('upload', $config);
        if ( ! $this->upload->do_upload("firm_name"))
        {
            $this->fileupload_error($data);
            return;
        }
        else
        {
            //
            // DB登録処理
            //
            $file_data = $this->upload->data();
            $file_name = $file_data['file_name'];
            if ($id) {
                $rslt = $this->firmup_handy_model->editFirm($file_name, $id);
            } else {
                $rslt = $this->firmup_handy_model->addFirm($file_name);
            }
            $data['back'] = 'firmup_handy/view_list';
        }

        if (!$rslt) {
            $message = 'データベースエラーが発生しました。';
        }

        $data['css'] = 'dummy.css';
        $data['menu'] = 'webaccount';
        $data['success'] = $rslt;
        $data['message'] = $message;
        $this->load->view('message_view', $data);
    }

    /**
     * パーミッションエラー処理。
     *
     * @param array $session_data セッションデータ。
     */
    private function permission_error($session_data)
    {
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['css'] = 'dummy.css';
        $data['menu'] = 'home';
        $data['success'] = false;
        $data['message'] = '許可されない操作です。';
        $data['back'] = 'home';
        $this->load->view('message_view', $data);
    }

    /**
     * ファイルアップロードエラー処理。
     *
     * @param array $session_data セッションデータ。
     */
    private function fileupload_error($session_data)
    {
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['css'] = 'dummy.css';
        $data['menu'] = 'home';
        $data['success'] = false;
        $data['message'] = 'ファイルアップロードが失敗しました。';
        $data['back'] = 'Firmup_handy/view_list';
        $this->load->view('message_view', $data);
    }

    /**
     * 内部エラー処理。
     *
     * @param array $session_data セッションデータ。
     */
    private function internal_error($session_data, $msg = false)
    {
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['css'] = 'dummy.css';
        $data['menu'] = 'home';
        $data['success'] = false;
        if ($msg) {
            $data['message'] = '内部エラー : '.$msg;
        }
        else {
            $data['message'] = '内部エラー';
       }
        $data['back'] = 'home';
        $this->load->view('message_view', $data);
    }

     /**
     * 正しいCSV用IMEIかチェックする。
     * AABBCCDDEEFF
     * 14桁または15桁の10進数文字、コロンは含めない
     * 
     * @param array &$str チェックする文字列のリファレンス (必須)
     *              参照元を大文字に変換
     */
    public function check_mac_address2(&$str)
    {
        // trim後を想定 : 12文字か?
        if (strlen($str) < 14 || strlen($str) > 15) {
            if (isset($this->form_validation)) {
                $this->form_validation->set_message('check_mac_address', '不正なIMEI');
            }
            return false;
        }

        // 16進文字?
        if (!ctype_xdigit($str)) {
            if (isset($this->form_validation)) {
                $this->form_validation->set_message('check_mac_address', '不正なIMEI');
            }
            return false;
        }

        // 大文字変換を行う
        $str = strtoupper($str);

        return true;
    }

    /**
     * CSVからIMEIリストを読み込んでfirmup_macaddrテーブルを更新
     * IMEIがテーブルに存在する場合 -> '現在のバージョン文字列'が idのものと同じかチェックし、異なるようなら'ファームウエア更新日時'をクリア
     * IMEIがテーブルに存在しない場合 -> 新しくIMEI行を追加
     * 
     * @param int $id ファームアップ用ファイルテーブルのID。(必須)
     * @param string $form_item フォームのinput項目で利用している"name=" の値 (do_uploadの引数)
     */
    public function import($id, $form_item)
    {
        // ログインチェック
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        // この操作が可能なのは管理者のみ
        if ($session_data['usermode'] != 'admin') {
            $this->permission_error($session_data);
            return;
        }

        // id が存在するかチェック
        $firmup_record = $this->firmup_handy_model->getFirmupfile($id);
        if (!$firmup_record) {
            // 本来これは起こらない(内部エラー)
            $this->internal_error($session_data, 'idが無効です');
            return;
        }

        // セッション情報を保存
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];

        // CSV読み込み
        $error = false;
        $new_mac_address = array();
        $existing_mac_address = array();
        // ファームアップが有効な場合はバージョン文字列を取得
        $firmup_version = ( $firmup_record->flag == 1 ) ? $firmup_record->firm_version : '';

        /* アップロードファイルをチェック */
        if (true) {
            $config = [];    // 連想配列を初期化
            $config['upload_path'] = './uploads/';
            $config['allowed_types'] = 'csv';
            $config['max_size'] = '1024';
            $this->load->library('upload', $config);
            if (!$this->upload->do_upload($form_item)) {    // $form_item = form 内の CSVファイル名項目
                $error = true;
                $message = 'csvファイルの読み込みに失敗しました。';
            } else {
                $filepath = $this->upload->data('full_path');
                $file = new SplFileObject($filepath);
                $file->setFlags(SplFileObject::READ_CSV);
                $count = 0;
                $line_num = 1;
                foreach ($file as $line) {
                    $str = $line[0];
                    //$str = strtolower($line[0]);
                    if (!is_null($str)) {
                        if (strpos($str, '#') === 0) {
                            $line_num++;
                            continue;
                        }
                        // 前後の空白を削除
                        $str = trim($str);
                        if (!$this->check_mac_address2($str)) {
                            $error = true;
                            $message = 'CSVファイルの'.$line_num.'行目にエラーがあります。';
                            break;
                        }
                        // str: 大文字変換済み
                        // IEMIは登録済みか?
                        $record = $this->firmup_handy_model->getmac_from_address($str);
                        if ($record) {
                            // 登録済み
                            $record->firmup_file_id = $id;    // firmup_file_id を更新
                            if (!empty($firmup_version)) {  // 有効なファームウエアが登録済み?
                                if (strcmp($firmup_version, $record->firm_version) != 0) {
                                    // バージョン文字列が異なる
                                    $record->last_update = 0;    // 更新日をクリア = バージョンアップが必要
                                }
                            }
                            // 'macaddr' でマッチングして更新。以下の(クリアした)カラムはそのまま残る
                            unset($record->id);
                            unset($record->last_connect);
                            unset($record->last_update);
                            unset($record->firm_version);
                            $existing_mac_address[] = $record;   // 配列にオブジェクトを追加
                        }
                        else {
                            // IMEI新規登録用オブジェクトを作成
                            $obj = new stdClass();
                            $obj->macaddr = $str;    // 大文字変換済み
                            $obj->firmup_file_id = $id;
                            $obj->last_connect = 0;
                            $obj->last_update = 0;
                            $obj->firm_version = '';

                            $new_mac_address[] = $obj;   // 配列にオブジェクトを追加
                        }
                    }
                    $line_num++;
                }
            }
        }

        $records = $this->firmup_handy_model->getMacaddr_reg($id);
        if ($records) {
            foreach ($records as $row) {
                $row->firmup_file_id = null;
                
                unset($row->id);
                unset($row->last_connect);
                unset($row->last_update);
                unset($row->firm_version);
                unset($row->company_name);
                unset($row->device_name);
            }
        }

        if (!$error && $records) {
            // 既存レコードを更新
            $result = $this->firmup_handy_model->editMacaddr($records, 'macaddr');
            if (!$result) {
                $message = '';                    
                $error = true;
            }
        }

        // DEBUG output codeigniter Log
        //log_message('debug', print_r($existing_mac_address, true));
        //log_message('debug', print_r($new_mac_address, true));
        
        if (!$error && count($existing_mac_address) > 0) {
            // 既存レコードを更新
            $result = $this->firmup_handy_model->editMacaddr($existing_mac_address, 'macaddr');
            if (!$result) {
                $message = 'IMEIテーブル更新失敗。';                    
                $error = true;
            }
        }

        if (!$error && count($new_mac_address) > 0) {
            // 新規レコードを追加
            $result = $this->firmup_handy_model->addMacaddr($new_mac_address);
            if (!$result) {
                $message = 'IMEIテーブル追加失敗。';                    
                $error = true;
            }
        }

        if (!$error) {
            //登録成功
            $message = '登録成功しました';
        }

        // 結果表示
        $data['css'] = 'dummy.css';
        $data['menu'] = 'handy_firm';
        $data['success'] = !$error;
        $data['message'] = $message;
        $data['back'] = 'firmup_handy/view_list';
        $this->load->view('message_view', $data);
    }

    /**
     * 登録されたIMEIリストをCSVファイルにエクスポートする。
     *
     * @param int $id ファームアップ用ファイルテーブルのID。(必須)
     */
    public function export($id)
    {
        // ログインチェック
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        // この操作が可能なのは管理者のみ
        if ($session_data['usermode'] != 'admin') {
            $this->permission_error($session_data);
            return;
        }

        // id が存在するかチェック
        $firmup_record = $this->firmup_handy_model->getFirmupfile($id);
        if (!$firmup_record) {
            // 本来これは起こらない(内部エラー)
            $this->internal_error($session_data, 'idが無効です');
            return;
        }

        // idから登録済みIMEIリストを取得(macaddr昇順)
        // 登録がない場合、macaddr_listは falseになるが、id無効の場合と区別できない
        $macaddr_list = $this->firmup_handy_model->getMacaddr_reg($id, 'macaddr', 'asc');
        
        $this->load->helper('download');
        $fp = fopen('php://temp', 'r+b');
        $header = array('#IMEI');    // スペース不可(ダブルクオートが付加される)
        fputcsv($fp, $header);
        if ($macaddr_list) {
            foreach ($macaddr_list as $row) {
                $array = [];    // 連想配列を初期化
                $array['macaddr'] = $row->macaddr;
                fputcsv($fp, $array, ',', '"');
            }
        }
        rewind($fp);
        $data = str_replace(PHP_EOL, "\r\n", stream_get_contents($fp));
        fclose($fp);
        
        force_download('imei_list.csv', mb_convert_encoding($data, 'SJIS-win', 'UTF-8'));
    }

}
