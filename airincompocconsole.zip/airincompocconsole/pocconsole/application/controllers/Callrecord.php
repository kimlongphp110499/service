<?php if (! defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class CallRecord extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('tenant_model', '', true);
        $this->load->model('callrecord_model', '', true);
        $this->load->helper(array('form','url'));
    }

    /**
     * テナント選択画面か設定画面を表示する。
     *
     * @param int $tid テナントのID。0の場合はテナント選択画面を表示。
     * @param string $page ページ番号。
     * @param string $sortkey ソートキー。
     * @param string $order 順序('asc'or'desc')
     */
    public function view_list($tid = false, $page = 0, $sortkey = false, $order = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];

        if ($session_data['usermode'] != 'admin') {
            $tid = $session_data['tenant'];
        }

        if ($tid) {
            // パラメータチェック
            $tenant = $this->tenant_model->get($tid);
            if (!$tenant) {
                $this->permission_error($session_data);
                return;
            }

            // check sortkey/order specified?
            if ($sortkey == false && $order == false) {
                $sortkey == 'id';
                $order == 'desc';
            }

            $data['record_count'] = $this->callrecord_model->get_tenant_num($tid);
            $data['records'] = $this->callrecord_model->get_tenant($tid, $page, $sortkey, $order);
            $data['tenant'] = $tenant;
            $data['page'] = $page;
            $data['sortkey'] = $sortkey;
            $data['order'] = $order;
            $this->load->view('callrecord_list_view', $data);
        } else {
            $data['tenants'] = $this->tenant_model->get_all();
            $this->load->view('callrecord_select_view', $data);
        }
    }

    /**
     * 指定された通話記録を再生する。
     *
     * ffmpegを使用しg729ファイルをwav形式に変換して、変換したファイル名を返す。
     * 本APIはブラウザからXMLHttpRequestでリクエストされることを想定している。
     *
     * @param int $id 通話記録ID。
     */
    public function play_message($tid = false, $id = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            echo 'Error: 許可されない操作です。';
            return;
        }

        if ($session_data['usermode'] != 'admin' && $tid != $session_data['tenant']) {
            echo 'Error: 許可されない操作です。';
            return;
        }

        $filepath = $this->callrecord_model->get_filepath($tid, $id);
        if (!$filepath) {
            echo 'Error: 許可されない操作です。';
            return;
        }

        $infile = ASTERISK_MONITOR_DIR.$filepath.'.wav';
        $outfile = ASTERISK_MONITOR_DIR.$filepath.'.wav';
        //$outfile = AUDIO_OUTPUT_DIR.$filepath.'.wav';

        if (!file_exists($infile) || filesize($infile) == 0) {
            echo 'Error: 音声ファイルがありません。';
            return;
        }

        if (!file_exists($outfile)) {
            $cmd = FFMPEG_CMD.' -i '.ASTERISK_MONITOR_DIR.$filepath.'.g729 '
                .AUDIO_OUTPUT_DIR.$filepath.'.wav';
            log_message('debug', 'cmd= '.$cmd);
            system($cmd, $retval);
            log_message('debug', 'retval= '.$retval);
        } else {
            log_message('debug', 'file exists: '.$filepath);
        }
        //echo base_url().'audio/'.$filepath.'.wav';
        echo base_url('callrecord/get_message_audio/'.$tid.'/'.$filepath);
    }

    /**
     * audioデータを取得する。
     *
     * @param int $tid テナントID。
     * @param string $filepath ファイル名。
     */
    public function get_message_audio($tid, $filepath)
    {
        // wavデータを返す
        $this->output->set_content_type('audio/x-wav');

        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            $this->output->set_status_header(403);
            return;
        }

        if ($session_data['usermode'] != 'admin' && $session_data['tenant'] != $tid) {
            $this->output->set_status_header(403);
            return;
        }

        $tenant = $this->tenant_model->get($tid);
        if (!$tenant) {
            $this->output->set_status_header(403);
            return;
        }

        //$path = AUDIO_OUTPUT_DIR.$filepath.'.wav';
        $path = ASTERISK_MONITOR_DIR.$filepath.'.wav';

        if (!file_exists($path)) {
            $this->output->set_status_header(403);
            return;
        }

        if (isset($_SERVER['HTTP_RANGE'])) {
            preg_match('/bytes=(\d+)-/', $_SERVER['HTTP_RANGE'], $matches);
            $offset = intval($matches[1]);
            $size = filesize($path);
            $this->output->set_status_header(206, 'Partial Content');
            $this->output->set_header('Content-Range: bytes '.$offset.'-'.($size-1).'/'.$size);
            $this->output->set_header('Content-Length: '.($size - $offset));
            $audio = file_get_contents($path, false, null, $offset);
        }
        else {
            $this->output->set_header('Content-Length: '.filesize($path));
            $audio = file_get_contents($path);
        }
        $this->output->set_output($audio);
    }
        
    /**
     * 通話記録をCSVファイルにエクスポートする。
     *
     * @param int $tid テナントID。
     */
    public function export($tid = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        if ($session_data['usermode'] != 'admin' && $tid != $session_data['tenant']) {
            $this->permission_error($session_data);
            return;
        }

        // パラメータチェック
        $records = $this->callrecord_model->get_tenant($tid, -1, 'id', 'asc');
        if (!$records) {
            $this->permission_error($session_data);
            return;
        }
        
        $this->load->helper('download');
        $fp = fopen('php://temp', 'r+b');
        $header = array('#ID', '日時', '発信元', '発信先', '通話時間', '種別');
        fputcsv($fp, $header);
        foreach ($records as $row) {
            $array = [];
            $array['id'] = $row->id;
            $array['date_time'] = date('Y-m-d H:i:s', $row->date_time / 1000);
            $array['send_from'] = $row->send_from;
            $array['send_to'] = !empty($row->send_to) ? $row->send_to : $row->group_name;
            $array['duration'] = $row->duration;
	    if ($row->type == 13) {
	        $array['type'] = '会議室';
            } else if ($row->type == 8) {
                $array['type'] = '同報';
            } else {
                $array['type'] = '個別';
            }
            fputcsv($fp, $array, ',', '"');
        }
        rewind($fp);
        $data = str_replace(PHP_EOL, "\r\n", stream_get_contents($fp));
        fclose($fp);
        
        force_download('callrecords.csv', mb_convert_encoding($data, 'SJIS-win', 'UTF-8'));
    }

    /**
     * パーミッションエラー処理。
     *
     * @param array $session_data セッションデータ。
     */
    private function permission_error($session_data)
    {
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['css'] = 'dummy.css';
        $data['menu'] = 'home';
        $data['success'] = false;
        $data['message'] = '許可されない操作です。';
        $data['back'] = 'home';
        $this->load->view('message_view', $data);
    }
}
