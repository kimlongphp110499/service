<?php if (! defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class VerifyLogin extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('webaccount_model', '', true);
        $this->load->library('pocutil');
    }

    public function index()
    {
        //This method will have the credentials validation
        $this->load->library('form_validation');
        $this->form_validation->set_rules('login_id', 'LoginID', 'trim|required');
        $this->form_validation->set_rules('password', 'Password', 'trim|required|callback_check_database');

        if ($this->form_validation->run() == false) {
            //Field validation failed.  User redirected to login page
            $data = array('css' => 'signin.css');
            //$this->load->view('templates/header', $data);
            $this->load->view('login_view', $data);
            $this->load->view('templates/footer');
        } else {
            //Go to private area
            redirect(base_url('home'), 'refresh');
        }
    }

    public function check_database($password)
    {
        //Field validation succeeded.  Validate against database
        $login_id = $this->input->post('login_id');

        //query the database
        $result = $this->webaccount_model->login($login_id, $password);

        if ($result) {
            $sess_array = array();
            foreach ($result as $row) {
                if ($row->status == 0) {
                    $this->form_validation->set_message('check_database', 'このアカウントは無効です。');
                    return false;
                }
                $token = $this->create_token(8);
                $this->webaccount_model->set_token($row->account_id, $token);
                $this->webaccount_model->set_last_login($row->account_id, time());
                $sess_array = array(
                    'id' => $row->account_id,
                    'username' => $row->username,
                    'tenant' => $row->company_id,
                    'usermode' => $row->type,
                    'token' => $token
                );
                $this->session->set_userdata('logged_in', $sess_array);
            }
            return true;
        } else {
            $this->form_validation->set_message('check_database', 'ログインIDまたはパスワードが違います。');
            return false;
        }
    }

    private function create_token($length)
    {
        static $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJLKMNOPQRSTUVWXYZ0123456789';
        $str = '';
        for ($i = 0; $i < $length; ++$i) {
            $str .= $chars[mt_rand(0, 61)];
        }
        return $str;
    }
}
