<?php if (! defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class WebAccount extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('webaccount_model', '', true);
        $this->load->model('tenant_model', '', true);
        $this->load->helper(array('form','url'));
    }

    /**
     * Webアカウント一覧を表示する。
     *
     * @param string $sortkey ソートキー。
     * @param string $order 順序('asc'or'desc')
     */
    public function view_list($sortkey = false, $order = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['sortkey'] = $sortkey;
        $data['order'] = $order;
        if ($session_data['usermode'] == 'admin') {
            $data['accounts'] = $this->webaccount_model->get_all($sortkey, $order);
        } else {
            $data['accounts'] = $this->webaccount_model->get_tenant($session_data['tenant'], $sortkey, $order);
        }
        
        $this->load->view('webaccount_list_view', $data);
    }

    /**
     * Webアカウント追加画面を表示。
     */
    public function add()
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        if ($session_data['usermode'] != 'admin') {
            $this->permission_error($session_data);
            return;
        }

        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['account'] = false;
        $data['tenants'] = $this->tenant_model->get_all();
        
        $this->load->view('webaccount_new_view', $data);
    }

    /**
     * Webアカウントを追加する。
     */
    public function add_action()
    {
        $this->do_save(false);
    }

    /**
     * Webアカウントの詳細情報を表示する。
     *
     * @param int $id 表示するアカウントのID。
     */
    public function view($id = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        // パラメータチェック
        $account = $this->webaccount_model->get($id);
        if (!$account) {
            $this->permission_error($session_data);
            return;
        }

        if ($session_data['usermode'] != 'admin' && $account->company_id != $session_data['tenant']) {
            $this->permission_error($session_data);
            return;
        }

        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['account'] = $account;
        
        $this->load->view('webaccount_detail_view', $data);
    }

    /**
     * Webアカウントの編集画面を表示する。
     *
     * @param int $id 表示するアカウントのID。
     */
    public function edit($id = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        // パラメータチェック
        $account = $this->webaccount_model->get($id);
        if (!$account) {
            $this->permission_error($session_data);
            return;
        }

        if ($session_data['usermode'] != 'admin' && $account->company_id != $session_data['tenant']) {
            $this->permission_error($session_data);
            return;
        }

        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['account'] = $account;
        
        $this->load->view('webaccount_edit_view', $data);
    }

    /**
     * Webアカウントを編集する。
     *
     * @param int $id 編集するテナントのID。
     */
    public function edit_action($id)
    {
        $this->do_save($id);
    }
    
    /**
     * Webアカウントを削除する。
     *
     * @param int $id 削除するテナントのID。
     */
    public function delete($id)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        // パラメータチェック
        $account = $this->webaccount_model->get($id);
        if (!$account) {
            $this->permission_error($session_data);
            return;
        }

        if ($session_data['usermode'] != 'admin' && $account->company_id != $session_data['tenant']) {
            $this->permission_error($session_data);
            return;
        }

        $message = null;
        $rslt = $this->webaccount_model->delete($id);
        if (!$rslt) {
            $message = 'データベースエラーが発生しました。';
        }

        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['css'] = 'dummy.css';
        $data['success'] = $rslt;
        $data['menu'] = 'webaccount';
        $data['back'] = 'webaccount/view_list';
        $data['message'] = $message;
        $this->load->view('message_view', $data);
    }
    
    /**
     * 追加、編集内容をDBに保存する。
     *
     * @param int $id アカウントのID(編集時)  追加時には falseを渡す
     */
    private function do_save($id = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        $account = $this->webaccount_model->get($id);
        if ($session_data['usermode'] != 'admin') {
            if (!$account || $account->company_id != $session_data['tenant']) {
                $this->permission_error($session_data);
                return;
            }
        }

        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('<div class="bg-danger">', '</div>');

        if (!$id) {
            // 新規作成時のみ
            $this->form_validation->set_rules('login_id', 'ログインID', 'required|callback_check_login_id');
            $this->form_validation->set_rules('password', 'パスワード', 'required|matches[confirm]');
            $this->form_validation->set_rules('confirm', 'パスワード(確認)', 'required');
            $this->form_validation->set_rules('type', 'アカウント種別', 'required');
        }
        else {
            // 編集時のみ
            if (!empty($this->input->post('password'))) {
                // 編集でパスワードが入力された
                $this->form_validation->set_rules('password', 'パスワード', 'matches[confirm]');
                $this->form_validation->set_rules('confirm', 'パスワード(確認)', 'required');
            }
        }

        // 共通
        $this->form_validation->set_rules('username', 'ユーザー名', 'required');
        $this->form_validation->set_rules('status', '状態', 'required');

        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        
        if ($this->form_validation->run() === false) {
            if ($id) {
                $data['account'] = $account;
                $this->load->view('webaccount_edit_view', $data);
            } else {
                $data['account'] = false;
                $data['tenants'] = $this->tenant_model->get_all();
                $this->load->view('webaccount_new_view', $data);
            }
            return;
        }

        $message = null;
        if ($id) {
            // edit existing account
            $rslt = $this->webaccount_model->edit($id, $account->login_id);
            $data['back'] = 'webaccount/view/'.$id;
        } else {
            // create new account
            $rslt = $this->webaccount_model->add();
            $data['back'] = 'webaccount/view_list';
        }
        if (!$rslt) {
            $message = 'データベースエラーが発生しました。';
        }

        $data['css'] = 'dummy.css';
        $data['menu'] = 'webaccount';
        $data['success'] = $rslt;
        $data['message'] = $message;
        $this->load->view('message_view', $data);
    }

    /**
     * アカウントデータをCSVファイルにエクスポートする。
     */
    public function export()
    {
		global $global_web_account_type_names;

        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        // パラメータチェック
        $accounts = null;
        if ($session_data['usermode'] == 'admin') {
            $accounts = $this->webaccount_model->get_all('account_id', 'asc');
        } else {
            $accounts = $this->webaccount_model->get_tenant($session_data['tenant'], 'account_id', 'asc');
        }
        if (!$accounts) {
            $this->permission_error($session_data);
            return;
        }
        
        $this->load->helper('download');
        $fp = fopen('php://temp', 'r+b');
        $header = array('#ID', 'アカウントID', 'アカウント名', '種類', '状態', 'APIキー');
        fputcsv($fp, $header);
        foreach ($accounts as $row) {
            $array = [];
            $array['account_id'] = $row->account_id;
            $array['login_id'] = $row->login_id;
            $array['username'] = $row->username;
			 // now "$row->type" cannot be NULL but for safety
            $array['type'] = $global_web_account_type_names[empty($row->type) ? 'tenant' : $row->type];	// '保守'/'テナント'/'API'
            $array['status'] = $row->status ? '有効' : '無効';
            $array['api_key'] = $row->api_key;
            fputcsv($fp, $array, ',', '"');
        }
        rewind($fp);
        $data = str_replace(PHP_EOL, "\r\n", stream_get_contents($fp));
        fclose($fp);
        
        force_download('webaccounts.csv', mb_convert_encoding($data, 'SJIS-win', 'UTF-8'));
    }

    /**
     * ログインIDが重複してないかの確認。
     *
     * @param string $login_id ログインID。
     * @return boolean 重複している場合はFALSEを返す。
     */
    public function check_login_id($login_id)
    {
        //query the database
        $result = $this->webaccount_model->check_login_id($login_id);

        if ($result) {
            $login_id = $this->input->post('login_id');
            $this->form_validation->set_message('check_login_id', '\''.$this->input->post('login_id').'\'はすでに使用されています。別のIDを指定してください。');
            return false;
        }

        return true;
    }

    /**
     * パーミッションエラー処理。
     *
     * @param array $session_data セッションデータ。
     */
    private function permission_error($session_data)
    {
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['css'] = 'dummy.css';
        $data['menu'] = 'home';
        $data['success'] = false;
        $data['message'] = '許可されない操作です。';
        $data['back'] = 'home';
        $this->load->view('message_view', $data);
    }
}
