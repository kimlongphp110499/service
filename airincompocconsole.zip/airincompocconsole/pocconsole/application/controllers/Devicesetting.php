<?php if (! defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class DeviceSetting extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('tenant_model', '', true);
        $this->load->model('pocaccount_model', '', true);
        $this->load->model('group_model', '', true);
        $this->load->model('device_model', '', true);
        $this->load->model('devicesetting_model', '', true);
        $this->load->helper(array('form','url'));
    }

    /**
     * テナント選択画面か設定画面を表示する。
     *
     * @param int $tid テナントのID。指定がない場合はテナント選択画面を表示。
     */
    public function view($tid = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];

        if ($session_data['usermode'] != 'admin') {
            $tid = $session_data['tenant'];
        }

        if ($tid) {
            // パラメータチェック
            $tenant = $this->tenant_model->get($tid);
            if (!$tenant) {
                $this->permission_error($session_data);
                return;
            }
            $data['spt_config'] = $this->devicesetting_model->get_spt_config($tid);
            $data['ism_config'] = $this->devicesetting_model->get_ism_config($tid);
            $data['tenant'] = $tenant;
            $this->load->view('devicesetting_detail_view', $data);
        } else {
            $data['tenants'] = $this->tenant_model->get_all();
            $this->load->view('devicesetting_select_view', $data);
        }
    }
    
    /**
     * PoCアカウントの編集画面を表示する。
     *
     * @param int $tid テナントID。
     */
    public function edit($tid = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        // ユーザーモードでは異なるテナントの編集を禁止する。
        if ($session_data['usermode'] != 'admin' && $tid != $session_data['tenant']) {
            $this->permission_error($session_data);
            return;
        }

        // パラメータチェック
        $tenant = $this->tenant_model->get($tid);
        if (!$tenant) {
            $this->permission_error($session_data);
            return;
        }

        // ISM-101の発信先リストを作成
        $contact_list = array();
        $accounts = $this->pocaccount_model->get_tenant($tid);
        if ($accounts) {
            foreach ($accounts as $row) {
                $data['name'] = $row->display_name;
                $data['sip_number'] = $row->sip_number;
                $contact_list[] = $data;
            }
        }
        $groups = $this->group_model->get_tenant($tid);
        if ($groups) {
            foreach ($groups as $row) {
                $data['name'] = $row->group_name;
                $data['sip_number'] = $row->sip_number;
                $contact_list[] = $data;
            }
        }

        // prepare view data
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['tenant'] = $tenant;
        $data['devices'] = $this->device_model->get_all();
        $data['contacts'] = $contact_list;
        $data['spt_config'] = $this->devicesetting_model->get_spt_config($tid);
        $data['ism_config'] = $this->devicesetting_model->get_ism_config($tid);
        
        // load views
        $this->load->view('devicesetting_edit_view', $data);
    }

    /**
     * 編集する。
     *
     * @param int $tid テナントのID。
     */
    public function edit_action($tid = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        if ($session_data['usermode'] != 'admin' && $tid != $session_data['tenant']) {
            $this->permission_error($session_data);
            return;
        }

        // パラメータチェック
        $tenant = $this->tenant_model->get($tid);
        if (!$tenant) {
            $this->permission_error($session_data);
            return;
        }

        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('<div class="bg-danger">', '</div>');
        $this->form_validation->set_rules('call1', 'MODE1発信番号', 'integer');
        $this->form_validation->set_rules('call2', 'MODE2発信番号', 'integer');
        $this->form_validation->set_rules('call3', 'MODE3発信番号', 'integer');
        $this->form_validation->set_rules('newvoicemail', '不在伝言再生番号', 'integer');
        $this->form_validation->set_rules('novoicemail', 'ラストコール再生番号', 'integer');

        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['tenant'] = $tenant;
        
        if ($this->form_validation->run() === false) {
            $data['spt_config'] = $this->devicesetting_model->get_spt_config($tid);
            $data['ism_config'] = $this->devicesetting_model->get_ism_config($tid);
            $this->load->view('devicesetting_edit_view', $data);
            return;
        }

        $rslt = $this->devicesetting_model->edit($tid);
        $message = null;
        if (!$rslt) {
            $message = 'データベースエラーが発生しました。';
        }
            
        $data['menu'] = 'devicesetting';
        $data['css'] = 'dummy.css';
        $data['success'] = $rslt;
        $data['back'] = 'devicesetting/view/'.$tid;
        $data['message'] = $message;
        $this->load->view('message_view', $data);
    }

    /**
     * パーミッションエラー処理。
     *
     * @param array $session_data セッションデータ。
     */
    private function permission_error($session_data)
    {
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['css'] = 'dummy.css';
        $data['menu'] = 'home';
        $data['success'] = false;
        $data['message'] = '許可されない操作です。';
        $data['back'] = 'home';
        $this->load->view('message_view', $data);
    }
}
