<?php if (! defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class Tenant extends CI_Controller
{
    
    public function __construct()
    {
        parent::__construct();
        $this->load->model('tenant_model', '', true);
        $this->load->model('pocaccount_model', '', true);
        $this->load->model('group_model', '', true);
        $this->load->model('webaccount_model', '', true);
        $this->load->model('handydevice_model', '', true);
        
        $this->load->helper(array('form','url'));
    }

    /**
     * テナント一覧を表示する。
     *
     * @param string $sortkey ソートキー。
     * @param string $order 順序('asc'or'desc')
     * @param string $search 検索文字
     */
    public function view_list($sortkey = false, $order = false, $search = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        // load view
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];

        if ($data['usermode'] == 'admin') {
            $data['tenants'] = $this->tenant_model->get_all($sortkey, $order, $search);
            $data['sortkey'] = $sortkey;
            $data['order'] = $order;
            $data['search'] = $search;
            $this->load->view('tenant_list_view', $data);
        } else {
            $data['tenant'] = $this->tenant_model->get($session_data['tenant']);
            $this->load->view('tenant_detail_view', $data);
        }
    }

    /**
     * テナント一覧を表示する(絞り込み表示)。
     */
    public function view_list_search()
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        // load view
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];

        if ($data['usermode'] == 'admin') {
            $data['tenants'] = $this->tenant_model->get_all(false, false, $this->input->post('search'));
            $data['sortkey'] = false;
            $data['order'] = false;
            $data['search'] = $this->input->post('search');
            $this->load->view('tenant_list_view', $data);
        } else {
            $data['tenant'] = $this->tenant_model->get($session_data['tenant']);
            $this->load->view('tenant_detail_view', $data);
        }
    }

    /**
     * 新規テナント追加画面を表示。
     */
    public function add()
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        if ($session_data['usermode'] != 'admin') {
            $this->permission_error($session_data);
            return;
        }

        // load view
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $this->load->view('tenant_new_view', $data);
    }

    /**
     * 新規テナントを追加する。
     */
    public function add_action()
    {
        $this->do_save(false);
    }
    
    /**
     * テナントの詳細情報を表示する。
     *
     * @param int $id 表示するテナントのID。
     */
    public function view($id = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        // ユーザーモードでは異なるテナントの閲覧を禁止する。
        if ($session_data['usermode'] != 'admin' && $id != $session_data['tenant']) {
            $this->permission_error($session_data);
            return;
        }

        // パラメータチェック
        $tenant = $this->tenant_model->get($id);
        if (!$tenant) {
            $this->permission_error($session_data);
            return;
        }

        // load view
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['tenant'] = $tenant;
        $this->load->view('tenant_detail_view', $data);
    }

    /**
     * テナント編集画面を表示する。
     *
     * @param int $id 表示するテナントのID。
     */
    public function edit($id = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        // ユーザーモードでは異なるテナントの編集を禁止する。
        if ($session_data['usermode'] != 'admin' && $id != $session_data['tenant']) {
            $this->permission_error($session_data);
            return;
        }

        // パラメータチェック
        $tenant = $this->tenant_model->get($id);
        if (!$tenant) {
            $this->permission_error($session_data);
            return;
        }

        // load view
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['tenant'] = $tenant;
        $data['pocaccounts'] = $this->pocaccount_model->get_tenant($id);
        $this->load->view('tenant_edit_view', $data);
    }

    /**
     * テナントを編集する。
     *
     * @param int $id 編集するテナントのID。
     */
    public function edit_action($id = false)
    {
        $this->do_save($id);
    }
    
    /**
     * テナントを削除する。
     *
     * @param int $id 削除するテナントのID。
     */
    public function delete($id = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        if ($session_data['usermode'] != 'admin') {
            $this->permission_error($session_data);
            return;
        }

        // パラメータチェック
        $tenant = $this->tenant_model->get($id);
        if (!$tenant) {
            $this->permission_error($session_data);
            return;
        }

        $this->group_model->delete_tenant($id);
        $this->pocaccount_model->delete_tenant($id);
        $this->webaccount_model->delete_tenant($id);
        $this->tenant_model->delete($id);

        // 新型ハンディ機用テナント設定を削除
        $this->handydevice_model->delete_tenant_config($id);
        
        $session_data = $this->session->userdata('logged_in');
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['css'] = 'dashboard.css';
        $data['menu'] = 'tenant';
        $data['success'] = true;
        $data['back'] = 'tenant/view_list';
        $data['message'] = 'テナント"'.$tenant->company_name.'"を削除しました。';
        $this->load->view('message_view', $data);
    }

    /**
     * テナントデータをCSVファイルにエクスポートする。
     */
    public function export()
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        if ($session_data['usermode'] != 'admin') {
            $this->permission_error($session_data);
            return;
        }

        // パラメータチェック
        $tenants = $this->tenant_model->get_all('company_id', 'asc');
        if (!$tenants) {
            $this->permission_error($session_data);
            return;
        }
        
        $this->load->helper('download');
        $fp = fopen('php://temp', 'r+b');
        $header = array('#ID', 'お客様コード', '会社名', '会社名カナ', 'SIPコンテキスト', '担当者名', '担当者名カナ', '所属部署', '役職', '郵便番号', '住所', '電話番号', 'E-mail', '営業担当者名', '営業担当者TEL', '営業担当者E-mail', '利用者の業種', '代理店名', '代理店担当者名', '代理店電話番号', '代理店E-mail');
        fputcsv($fp, $header);
        foreach ($tenants as $row) {
            $array = [];
            $array['company_id'] = $row->company_id;
            $array['company_code'] = $row->company_code;
            $array['company_name'] = $row->company_name;
            $array['company_kana'] = $row->company_kana;
            $array['sip_contxt'] = $row->sip_context_name;
            $array['contact_name'] = $row->contact_name;
            $array['contact_kana'] = $row->contact_kana;
            $array['contact_department'] = $row->contact_department;
            $array['contact_title'] = $row->contact_title;
            $array['contact_zip'] = $row->contact_zip;
            $array['contact_address'] = $row->contact_address;
            $array['contact_tel'] = $row->contact_tel;
            $array['contact_email'] = $row->contact_email;
            $array['sales_staff_name'] = $row->sales_staff_name;
            $array['sales_staff_tel'] = $row->sales_staff_tel;
            $array['sales_staff_email'] = $row->sales_staff_email;
            $array['company_industry'] = $row->company_industry;
            $array['contact_email'] = $row->contact_email;
            $array['agent_company'] = $row->agent_company;
            $array['agent_name'] = $row->agent_name;
            $array['agent_tel'] = $row->agent_tel;
            $array['agent_email'] = $row->agent_email;
            fputcsv($fp, $array, ',', '"');
        }
        rewind($fp);
        $data = str_replace(PHP_EOL, "\r\n", stream_get_contents($fp));
        fclose($fp);
        
        force_download('tenants.csv', mb_convert_encoding($data, 'SJIS-win', 'UTF-8'));
    }

    /**
     * CSVファイルからテナントをインポートする。(追加のみ)
     */
    public function import()
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        // テナントアカウントでは不可
        if ($session_data['usermode'] != 'admin') {
            $this->permission_error($session_data);
            return;
        }

        // テナント配列初期化
        $err = false;
        $message = '';
        $tenant_array = [];
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        
        // CSVファイル読み込み
        $config['upload_path'] = './uploads/';
        $config['allowed_types'] = 'csv';
        $config['max_size'] = '100';
        $this->load->library('upload', $config);
        if (!$this->upload->do_upload('import_file')) {
            // "/var/www/html/pocconsole/uploads" フォルダが存在しない?
            $err = true;
            $message = 'csvファイルの読み込みに失敗しました。';
        } else {
            $filepath = $this->upload->data('full_path');
            $file = new SplFileObject($filepath);
            $file->setFlags(SplFileObject::READ_CSV);
            $count = 0;
            $line_num = 1;
            $name_list = array();
            $sip_context_list = array();

            global $global_industry_names;

            $this->load->library('form_validation');
            foreach ($file as $line) {
                // 'line' is array so check first array element != null
                if (empty($line[2])) {
                    $line_num++;
                    continue;
                }
                $tenant = array();
                $str = strtolower($line[0]);
                // # で始まる行はコメント
                if (strpos($str, '#') === 0) {
                    $line_num++;
                    continue;
                }
                // 会社名
                $company_name = mb_convert_encoding($line[2], 'UTF-8', 'SJIS');
                if (empty($company_name)) {
                    $err = true;
                    $message = 'CSVファイルの'.$line_num.'行目にエラーがあります。(会社名が必要)';
                    break;
                }
                if (!$this->tenant_model->is_available_company_name($company_name)) {
                    $err = true;
                    $message = 'CSVファイルの'.$line_num.'行目にエラーがあります。(会社名"'.$company_name.'"がすでに存在します)';
                    break;
                }
                if (in_array($company_name, $name_list, TRUE)) {
                    $err = true;
                    $message = 'CSVファイルの'.$line_num.'行目にエラーがあります。(CSV内の他の会社名と重複)';
                    break;
                }
                array_push($name_list, $company_name);
                $tenant['company_name'] = $company_name;

                // 会社名カナ
                $tenant['company_kana'] = mb_convert_encoding($line[3], 'UTF-8', 'SJIS');

                // SIPコンテキスト
                $sip_context_name = mb_convert_encoding($line[4], 'UTF-8', 'SJIS');
                if (empty($sip_context_name)) {
                    $err = true;
                    $message = 'CSVファイルの'.$line_num.'行目にエラーがあります。(SIPコンテキストが必要)';
                    break;
                }
                if (!$this->tenant_model->is_available_sip_context($sip_context_name)) {
                    $err = true;
                    $message = 'CSVファイルの'.$line_num.'行目にエラーがあります。(SIPコンテキスト"'.$sip_context_name.'"がすでに存在します)';
                    break;
                }
                $tenant['sip_context_name'] = $sip_context_name;

                // 担当者名
                $contact_name = mb_convert_encoding($line[5], 'UTF-8', 'SJIS');
                if (empty($contact_name)) {
                    $err = true;
                    $message = 'CSVファイルの'.$line_num.'行目にエラーがあります。(窓口担当者が必要)';
                    break;
                }
                $tenant['contact_name'] = $contact_name;

                // 担当者名カナ
                $tenant['contact_kana'] = mb_convert_encoding($line[6], 'UTF-8', 'SJIS');

                // 所属部署
                $tenant['contact_department'] = mb_convert_encoding($line[7], 'UTF-8', 'SJIS');

                // 役職
                $tenant['contact_title'] = mb_convert_encoding($line[8], 'UTF-8', 'SJIS');

                // 郵便番号
                $tenant['contact_zip'] = mb_convert_encoding($line[9], 'UTF-8', 'SJIS');

                // 住所
                $tenant['contact_address'] = mb_convert_encoding($line[10], 'UTF-8', 'SJIS');

                // 電話番号
                $tenant['contact_tel'] = mb_convert_encoding($line[11], 'UTF-8', 'SJIS');

                // E-mail
                $contact_email = mb_convert_encoding($line[12], 'UTF-8', 'SJIS');
                if (empty($contact_email)) {
                    $err = true;
                    $message = 'CSVファイルの'.$line_num.'行目にエラーがあります。(E-mailが必要)';
                    break;
                }
                $this->form_validation->set_data(array('email' => $contact_email));
                $this->form_validation->set_rules('email', 'E-mail', 'required|valid_email');
                if ($this->form_validation->run() === false) {
                    $err = true;
                    $message = 'CSVファイルの'.$line_num.'行目にエラーがあります。(E-mail形式が不正)';
                    break;
                }
                $this->form_validation->reset_validation();
                $tenant['contact_email'] = $contact_email;

                // 営業担当者名
                $tenant['sales_staff_name'] = mb_convert_encoding($line[13], 'UTF-8', 'SJIS');

                // 営業担当者TEL
                $tenant['sales_staff_tel'] = mb_convert_encoding($line[14], 'UTF-8', 'SJIS');

                // 営業担当者E-mail
                $tenant['sales_staff_email'] = mb_convert_encoding($line[15], 'UTF-8', 'SJIS');
                if (!empty($tenant['sales_staff_email'])) {
                    $this->form_validation->set_data(array('email' => $tenant['sales_staff_email']));
                    $this->form_validation->set_rules('email', 'E-mail', 'required|valid_email');
                    if ($this->form_validation->run() === false) {
                        $err = true;
                        $message = 'CSVファイルの'.$line_num.'行目にエラーがあります。(営業担当者E-mail形式が不正)';
                        break;
                    }
                }
                $this->form_validation->reset_validation();

                // 利用者の業種
                $company_industry = mb_convert_encoding($line[16], 'UTF-8', 'SJIS');
                $tenant['company_industry'] = $company_industry;

                // 代理店名
                $tenant['agent_company'] = mb_convert_encoding($line[17], 'UTF-8', 'SJIS');

                // 代理店担当者名
                $tenant['agent_name'] = mb_convert_encoding($line[18], 'UTF-8', 'SJIS');

                // 代理店電話番号
                $tenant['agent_tel'] = mb_convert_encoding($line[19], 'UTF-8', 'SJIS');

                // 代理店E-mail
                $tenant['agent_email'] = mb_convert_encoding($line[20], 'UTF-8', 'SJIS');
                if (!empty($tenant['agent_email'])) {
                    $this->form_validation->set_data(array('email' => $tenant['agent_email']));
                    $this->form_validation->set_rules('email', 'E-mail', 'required|valid_email');
                    if ($this->form_validation->run() === false) {
                        $err = true;
                        $message = 'CSVファイルの'.$line_num.'行目にエラーがあります。(代理店E-mail形式が不正)';
                        break;
                    }
                }
                $this->form_validation->reset_validation();

                $tenant_array[] = $tenant;
                $line_num++;
            }
        }

        //
        // インポートチェック終了
        //

        // 1件も読み込まなかったときはエラーとする
        if (!$err && empty($tenant_array)) {
            $err = true;
            $message = 'インポート可能なデータがありません。';
        }

        if (!$err) {
            foreach ($tenant_array as $tenant) {
                $new_id = $this->tenant_model->import($tenant);
                if ($new_id === false) {
                    $err = true;
                    $message = 'DBエラーです。';
                    break;
                }
                $this->handydevice_model->copy_tenant_config($new_id);
            }
        }

        /* 結果通知画面 */
        $data['css'] = 'dashboard.css';
        $data['menu'] = 'tenants';
        $data['success'] = !$err;
        $data['message'] = $err ? $message : 'テナントをインポートしました。';
        $data['back'] = 'tenant/view_list/';
        $this->load->view('message_view', $data);
    }

    /**
     * テナント追加、編集内容をDBに保存する。
     *
     * @param int $id テナントのID。(falseの場合 : 新規追加)
     */
    private function do_save($id)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        if (!$id && $session_data['usermode'] != 'admin') {
            $this->permission_error($session_data);
            return;
        }

        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('<div class="bg-danger">', '</div>');

        $this->form_validation->set_rules('contact_name', '窓口担当者', 'required');
        $this->form_validation->set_rules('contact_zip', '郵便番号', 'alpha_dash');
        $this->form_validation->set_rules('contact_tel', '電話番号', 'alpha_dash');
        $this->form_validation->set_rules('contact_email', 'E-mail', 'required|valid_email');
        $this->form_validation->set_rules('agent_tel', '代理店担当者TEL', 'alpha_dash');
        $this->form_validation->set_rules('agent_email', '代理店担当者E-mail', 'valid_email');
        if ($id) {
			// in case 'Edit'
            //$this->form_validation->set_rules('company_name', '契約企業名', 'required|callback_check_company_name');
            $this->form_validation->set_rules('company_name', '契約企業名', 'required');
            $this->form_validation->set_rules('sip_context_name', 'SIPコンテキスト名', 'required|callback_check_sip_context_name['.$id.']');
            // テナントID(お客様コード)は変更できない
        	//$this->form_validation->set_rules('company_code', 'お客様コード', 'trim|required|min_length[6]|max_length[12]|alpha_numeric|callback_check_company_code');
        } else {
			// in case 'Add'
            //$this->form_validation->set_rules('company_name', '契約企業名', 'required|callback_check_company_name');
            $this->form_validation->set_rules('company_name', '契約企業名', 'required');
            $this->form_validation->set_rules('sip_context_name', 'SIPコンテキスト名', 'required|callback_check_sip_context_name');
            // テナントID(お客様コード)は新規追加時に自動生成される
        	//$this->form_validation->set_rules('company_code', 'お客様コード', 'trim|required|min_length[6]|max_length[12]|alpha_numeric|callback_check_company_code');
        }

        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['tenant'] = false;
        
        if ($this->form_validation->run() === false) {
            if ($id) {
                // in case 'Edit'
                $data['tenant'] = $this->tenant_model->get($id);
                $this->load->view('tenant_edit_view', $data);
            } else {
                // in case 'Add'
                $this->load->view('tenant_new_view', $data);
            }
            return;
        }

        if ($id) {
            // テナント情報更新
            // パラメータチェック
            $tenant = $this->tenant_model->get($id);
            if (!$tenant) {
                $this->permission_error($session_data);
                return;
            }
            $rslt = $this->tenant_model->edit($id);
        } else {
            // テナント新規追加
            // 成功の場合、自動生成されたテナントIDを返す
            $rslt = $this->tenant_model->add();
            if ($rslt) {
                // ここでは rslt = 追加されたテナントID
                $rslt = $this->handydevice_model->copy_tenant_config($rslt);
            }
        }

        $data['success'] = $rslt;
        $data['menu'] = 'tenant';
        $data['css'] = 'dashboard.css';
        $data['back'] = 'tenant/view_list';
        if ($rslt) {
            $data['message'] = 'テナント"'.$this->input->post('company_name').'"を'
                .($id ? '更新' : '追加').'しました。';
        } else {
            $data['message'] = 'データベースエラーです。';
        }
        $this->load->view('message_view', $data);
    }

    /**
     * 会社名の入力チェック。
     *
     * @param string $str 会社名。
     * @return boolean すでに同じ会社名が登録されている場合はFALSEを返す。
     */
    public function check_company_name($str)
    {
        $param = array('company_name' => $str);
        $tenant = $this->tenant_model->get_where($param);
        if ($tenant) {
            $this->form_validation->set_message('check_company_name', '"'.$str.'"はすでに存在します。');
            return false;
        }

        return true;
    }

    /**
     * お客様コードの入力チェック。
     *
     * @param string $str お客様コード。
     * @return boolean すでに同じお客様コードが登録されている場合はFALSEを返す。
     */
    public function check_company_code($str)
    {
        $param = array('company_code' => $str);
        $tenant = $this->tenant_model->get_where($param);
        if ($tenant) {
            $this->form_validation->set_message('check_company_code', '"'.$str.'"はすでに存在します。');
            return false;
        }

        return true;
    }

    /**
     * SIPコンテキスト名の入力チェック。
     *
     * @param string $str コンテキスト名。
     * 
     * @param int $id テナントのID。(オプション。falseの場合 : 新規追加)
     * 編集時は自分のテナントIDのコンテキスト名を除外
     *
     * @return boolean すでに同じコンテキスト名が登録されている場合はFALSEを返す。
     */
    public function check_sip_context_name($str, $id = false)
    {
        if (!$this->tenant_model->is_available_sip_context($str, $id)) {
            $this->form_validation->set_message('check_sip_context_name', '"'.$str.'"はすでに存在します。');
            return false;
        }

        return true;
    }

    /**
     * パーミッションエラー処理。
     *
     * @param array $session_data セッションデータ。
     */
    private function permission_error($session_data)
    {
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['css'] = 'dummy.css';
        $data['menu'] = 'home';
        $data['success'] = false;
        $data['message'] = '許可されない操作です。';
        $data['back'] = 'home';
        $this->load->view('message_view', $data);
    }
}
