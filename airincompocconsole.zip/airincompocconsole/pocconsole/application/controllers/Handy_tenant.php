<?php if (! defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class Handy_tenant extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('tenant_model', '', true);
        $this->load->model('handydevice_model', '', true);
        $this->load->helper(array('form','url'));

		log_message('debug', 'Handy_tenant#__construct() enter:');
    }

    /**
     * テナントアカウント用テナントテンプレートか、保守アカウント用テナントテンプレートを表示
     *
     * @param int $tid テナントのID。指定がないか0の場合は保守アカウント用テナントテンプレートを表示。
     */
    public function view($tid = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];

        if ($session_data['usermode'] != 'admin') {
            $tid = $session_data['tenant'];
        }

        if ($tid) {
            // テナントアカウント用テナントテンプレート
            // パラメータチェック
            $tenant = $this->tenant_model->get($tid);
            if (!$tenant) {
                $this->permission_error($session_data);
				return;
			}
            $data['hdy_config'] = $this->handydevice_model->get_tenant_template($tid);
            $data['config_type'] = 'tenant';
            $data['tenant'] = $tenant;
        } else {
            // 保守アカウント用テナントテンプレート
            $data['hdy_config'] = $this->handydevice_model->get_tenant_template(0);
            $data['config_type'] = 'tenant_admin';
            $data['tenant'] = '(保守)';   // for safety
        }

        $this->load->view('handy_tenant_detail_view', $data);
    }
    
    /**
     * テナントアカウント用テナントテンプレートか、保守アカウント用テナントテンプレートを編集
     *
     * @param int $tid テナントのID。指定がないか0の場合は保守アカウント用テナントテンプレートを編集。
     */
    public function edit($tid = false)
    {
		log_message('debug', 'Handy_tenant#edit() enter:');

        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        
        // ユーザーモードでは異なるテナントの編集を禁止する。
        if ($session_data['usermode'] != 'admin' && $tid != $session_data['tenant']) {
            $this->permission_error($session_data);
            return;
        }

        if ($tid) {
            // テナントアカウント用テナントテンプレートを編集
            // パラメータチェック
            $tenant = $this->tenant_model->get($tid);
            if (!$tenant) {
                $this->permission_error($session_data);
                return;
            }
            $data['hdy_config'] = $this->handydevice_model->get_tenant_template($tid);
            $data['config_type'] = 'tenant';
            $data['tenant'] = $tenant;
        } else {
            // 保守アカウント用テナントテンプレート
            $data['hdy_config'] = $this->handydevice_model->get_tenant_template(0);
            $data['config_type'] = 'tenant_admin';
            $data['tenant'] = '(保守)';   // for safety
        }

        $this->load->view('handy_tenant_detail_edit', $data);
    }

    /**
     * 編集結果をテナントテンプレートに保存
     *
     * @param int $tid テナントのID。指定がないか0の場合は保守アカウント用テンプレートを保存。
     */
    public function edit_action($tid = false)
    {
		log_message('debug', 'Handy_tenant#edit_action() enter:');

        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        if ($session_data['usermode'] != 'admin' && $tid != $session_data['tenant']) {
            $this->permission_error($session_data);
            return;
        }

		if ($tid) {
        	// パラメータチェック
        	$tenant = $this->tenant_model->get($tid);
        	if (!$tenant) {
				$this->permission_error($session_data);
            	return;
        	}
            $data['config_type'] = 'tenant';
            $data['tenant'] = $tenant;
        } else {
            // 保守アカウント用テナントテンプレート
            $data['config_type'] = 'tenant_admin';
            $data['tenant'] = '(保守)';   // for safety
		}

        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('<div class="bg-danger">', '</div>');

        // システム情報
        $this->form_validation->set_rules('App_ver', 'アプリケーションバージョン', 'max_length[128]');
        $this->form_validation->set_rules('App_path', 'アプリケーションパス（URL）', 'valid_url|max_length[256]');
        $this->form_validation->set_rules('Kernel_ver', 'カーネルバージョン', 'max_length[128]');
        $this->form_validation->set_rules('Kernel_path', 'カーネルパス（URL）', 'valid_url|max_length[256]');
        $this->form_validation->set_rules('mod_ver', 'モジュールファームバージョン', 'max_length[128]');
        $this->form_validation->set_rules('mod_path', 'モジュールパス（URL）', 'valid_url|max_length[256]');
        // SIP設定
        $this->form_validation->set_rules('prefix_lte', 'LTE優先度', 'greater_than_equal_to[1]|less_than_equal_to[9]');
        $this->form_validation->set_rules('rtp_discard', 'RTPパケット破棄', 'greater_than_equal_to[0]|less_than_equal_to[10]');
        $this->form_validation->set_rules('rtp_delay', 'RTP delay', 'greater_than_equal_to[0]|less_than_equal_to[5000]');
        $this->form_validation->set_rules('prefix_wifi', 'Wi-Fi優先度', 'greater_than_equal_to[1]|less_than_equal_to[9]');
        // PoCアカウント情報
        $this->form_validation->set_rules('sip_server_domain', 'SIPサーバードメイン（URL）', 'valid_url|max_length[256]');
        $this->form_validation->set_rules('sip_server_port', 'SIPサーバーポート番号', 'greater_than_equal_to[0]|less_than_equal_to[65535]');
        $this->form_validation->set_rules('sip_server_ip_crg', 'SIPサーバーIPアドレス（CRG用）', 'valid_url|max_length[256]');
        $this->form_validation->set_rules('sip_server_port_crg', 'SIPサーバーポート番号（CRG用）', 'greater_than_equal_to[0]|less_than_equal_to[65535]');
        $this->form_validation->set_rules('xmpp_server_host', 'XMPPサーバーホスト名', 'max_length[128]');
        $this->form_validation->set_rules('xmpp_server_port', 'XMPPサーバーポート番号', 'greater_than_equal_to[0]|less_than_equal_to[65535]');
        $this->form_validation->set_rules('xmpp_service', 'XMPPサービス名', 'max_length[128]');
        $this->form_validation->set_rules('xmpp_user_name', 'XMPPユーザー名', 'max_length[128]');
        $this->form_validation->set_rules('xmpp_password', 'XMPPパスワード', 'max_length[128]');
        $this->form_validation->set_rules('unattended_rec_id', '不在伝言再生番号', 'max_length[128]');
        $this->form_validation->set_rules('lastcall_id', 'ラストコール再生番号', 'max_length[128]');
       // Webアカウント情報
       $this->form_validation->set_rules('web_account_login_id', 'WebサーバーログインID', 'max_length[128]');
       $this->form_validation->set_rules('web_account_login_password', 'Webサーバーログインパスワード', 'max_length[128]');
        // Wi-Fi設定
        $this->form_validation->set_rules('pri_wifi_ssid', 'WiFi SSID', 'max_length[128]');
        $this->form_validation->set_rules('pri_wifi_password', 'WiFi Password', 'max_length[128]');
        // GPS設定
        $this->form_validation->set_rules('gps_conf_interval', 'GPS測位間隔時間', 'greater_than_equal_to[0]|less_than_equal_to[60]');
        $this->form_validation->set_rules('gps_server_url', 'GPSデータ送信先URL', 'valid_url|max_length[128]');
        $this->form_validation->set_rules('gps_server_interval', 'GPSデータ送信間隔', 'greater_than_equal_to[0]|less_than_equal_to[3600]');
        $this->form_validation->set_rules('gps_distance', 'GPSデータ送信距離間隔', 'greater_than_equal_to[0]|less_than_equal_to[10000]');
        // 通話設定
        $this->form_validation->set_rules('lte_callback_timer', 'LTE Callback Timer', 'greater_than_equal_to[0]|less_than_equal_to[60]');
        $this->form_validation->set_rules('lte_time_out_timer', 'LTE Time out Timer', 'greater_than_equal_to[0]|less_than_equal_to[3600]');
        $this->form_validation->set_rules('lte_time_out_time_rekey', 'LTE Time out Rekey Time', 'greater_than_equal_to[0]|less_than_equal_to[60]');
        $this->form_validation->set_rules('wifi_callback_timer', 'Wi-Fi Callback Timer', 'greater_than_equal_to[0]|less_than_equal_to[60]');
        $this->form_validation->set_rules('wifi_time_out_timer', 'Wi-Fi Time out Timer', 'greater_than_equal_to[0]|less_than_equal_to[3600]');
        $this->form_validation->set_rules('wifi_time_out_time_rekey', 'Wi-Fi Time out Rekey Time', 'greater_than_equal_to[0]|less_than_equal_to[60]');
        $this->form_validation->set_rules('lte_jitter_buff', 'LTEジッターバッファ', 'greater_than_equal_to[0]|less_than_equal_to[2000]');
        $this->form_validation->set_rules('wifi_jitter_buff', 'Wi-Fiジッターバッファ', 'greater_than_equal_to[0]|less_than_equal_to[2000]');
        // 定型メッセージリスト
        $this->form_validation->set_rules('message_list_m1', 'メッセージ１', 'max_length[128]');
        $this->form_validation->set_rules('message_list_m2', 'メッセージ２', 'max_length[128]');
        $this->form_validation->set_rules('message_list_m3', 'メッセージ３', 'max_length[128]');
        $this->form_validation->set_rules('message_list_m4', 'メッセージ４', 'max_length[128]');
        $this->form_validation->set_rules('message_list_m5', 'メッセージ５', 'max_length[128]');
        $this->form_validation->set_rules('message_list_m6', 'メッセージ６', 'max_length[128]');
        $this->form_validation->set_rules('message_list_m7', 'メッセージ７', 'max_length[128]');
        $this->form_validation->set_rules('message_list_m8', 'メッセージ８', 'max_length[128]');
        $this->form_validation->set_rules('message_list_m9', 'メッセージ９', 'max_length[128]');
        $this->form_validation->set_rules('message_list_m10', 'メッセージ１０', 'max_length[128]');
        $this->form_validation->set_rules('message_list_m11', 'メッセージ１１', 'max_length[128]');
        $this->form_validation->set_rules('message_list_m12', 'メッセージ１２', 'max_length[128]');
        $this->form_validation->set_rules('message_list_m13', 'メッセージ１３', 'max_length[128]');
        $this->form_validation->set_rules('message_list_m14', 'メッセージ１４', 'max_length[128]');
        $this->form_validation->set_rules('message_list_m15', 'メッセージ１５', 'max_length[128]');
        $this->form_validation->set_rules('message_list_m16', 'メッセージ１６', 'max_length[128]');
        $this->form_validation->set_rules('message_list_m17', 'メッセージ１７', 'max_length[128]');
        $this->form_validation->set_rules('message_list_m18', 'メッセージ１８', 'max_length[128]');
        $this->form_validation->set_rules('message_list_m19', 'メッセージ１９', 'max_length[128]');
        $this->form_validation->set_rules('message_list_m20', 'メッセージ２０', 'max_length[128]');
       // 送信設定
       $this->form_validation->set_rules('vox_thresh', 'VOX動作レベル', 'greater_than_equal_to[1]|less_than_equal_to[7]');
       // 各種動作設定
       $this->form_validation->set_rules('speaker_fixed_vol', '固定音量レベル', 'greater_than_equal_to[0]|less_than_equal_to[32]');
       $this->form_validation->set_rules('speaker_max_vol', '最大音量レベル', 'greater_than_equal_to[0]|less_than_equal_to[32]');
       $this->form_validation->set_rules('speaker_min_vol', '最小音量レベル', 'greater_than_equal_to[0]|less_than_equal_to[32]');
       $this->form_validation->set_rules('sekkyaku_voice', '接客ボイス感度', 'greater_than_equal_to[1]|less_than_equal_to[7]');
       $this->form_validation->set_rules('sekkyaku_voice_timer', '接客ボイス保持', 'greater_than_equal_to[1]|less_than_equal_to[5]');
       // 緊急動作設定
       $this->form_validation->set_rules('emergency_alarm_duration', '緊急動作　警報音のみ', 'greater_than_equal_to[0]|less_than_equal_to[60]');
       $this->form_validation->set_rules('emergency_alarm_ptt_duration', '緊急動作　警報音+発報', 'greater_than_equal_to[0]|less_than_equal_to[60]');
       $this->form_validation->set_rules('emergency_silent_ptt_duration', '緊急動作　発報のみ', 'greater_than_equal_to[0]|less_than_equal_to[60]');
       $this->form_validation->set_rules('emergency_live_ptt_duration', '緊急動作　音声送信', 'greater_than_equal_to[0]|less_than_equal_to[60]');
       // 端末システム設定
       $this->form_validation->set_rules('display_lcd_contrast', 'コントラスト', 'greater_than_equal_to[1]|less_than_equal_to[10]');
        //
        // 追加項目のチェックをここに入れる
        //

        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        
		log_message('debug', 'Handy_tenant#edit_action() validation:');

        if ($this->form_validation->run() === false) {
            // 編集前のデータを再ロード
            if ($tid) {
                $data['hdy_config'] = $this->handydevice_model->get_tenant_template($tid);
            } else {
                $data['hdy_config'] = $this->handydevice_model->get_tenant_template(0);
            }
            $this->load->view('handy_tenant_detail_edit', $data);
            return;
        }

        // POST内容とそのほかのデータを集める
        $record = array(
            
            // 管理用情報
            'update_date' => date('Y-m-d H:i:s'),
            'comment' => $this->input->post('comment'),

            // システム情報
            'FW_flag' => $this->input->post('FW_flag'),
            'App_ver' => $this->input->post('App_ver'),
            'App_path' => $this->input->post('App_path'),
            'Kernel_ver' => $this->input->post('Kernel_ver'),
            'Kernel_path' => $this->input->post('Kernel_path'),
            'mod_flag' => $this->input->post('mod_flag'),
            'mod_ver' => $this->input->post('mod_ver'),
            'mod_path' => $this->input->post('mod_path'),
            'sim' => $this->input->post('sim'),

            // システム設定
            'key_info' => $this->input->post('key_info'),

            // SIP設定
            'prefix_lte' => $this->input->post('prefix_lte'),
            'rtp_discard' => $this->input->post('rtp_discard'),
            'rtp_delay' => $this->input->post('rtp_delay'),
            'ping_interval' => $this->input->post('ping_interval'),
            'registar_interval' => $this->input->post('registar_interval'),
            'prefix_wifi' => $this->input->post('prefix_wifi'),
            'register_interval_pri_wifi' => $this->input->post('register_interval_pri_wifi'),
            
            // POCアカウント情報
            'sip_server_domain' => $this->input->post('sip_server_domain'),
            'sip_server_port' => $this->input->post('sip_server_port'),
            'sip_server_ip_crg' => $this->input->post('sip_server_ip_crg'),
            'sip_server_port_crg' => $this->input->post('sip_server_port_crg'),
            'xmpp_server_host' => $this->input->post('xmpp_server_host'),
            'xmpp_server_port' => $this->input->post('xmpp_server_port'),
            'xmpp_service' => $this->input->post('xmpp_service'),
            'xmpp_user_name' => $this->input->post('xmpp_user_name'),
            'xmpp_password' => $this->input->post('xmpp_password'),
            'unattended_rec_id' => $this->input->post('unattended_rec_id'),
            'lastcall_id' => $this->input->post('lastcall_id'),

            // Ｗｅｂアカウント情報
            'web_account_login_id' => $this->input->post('web_account_login_id'),
            'web_account_login_password' => $this->input->post('web_account_login_password'),

            // Wi-Fi設定
            'pri_ap_mode' => $this->input->post('pri_ap_mode'),
            'pri_wifi_nw_mode' => $this->input->post('pri_wifi_nw_mode'),
            'pri_wifi_ssid' => $this->input->post('pri_wifi_ssid'),
            'pri_wifi_password' => $this->input->post('pri_wifi_password'),
            'pri_wifi_transparent' => $this->input->post('pri_wifi_transparent'),

            // GPS設定
            'gps_conf_interval' => $this->input->post('gps_conf_interval'),
            'gps_server_url' => $this->input->post('gps_server_url'),
            'gps_mode' => $this->input->post('gps_mode'),
            'gps_server_interval' => $this->input->post('gps_server_interval'),
            'gps_distance' => $this->input->post('gps_distance'),

            // 通話設定
            'lte_callback_timer' => $this->input->post('lte_callback_timer'),
            'lte_time_out_timer' => $this->input->post('lte_time_out_timer'),
            'lte_time_out_time_rekey' => $this->input->post('lte_time_out_time_rekey'),
            'wifi_callback_timer' => $this->input->post('wifi_callback_timer'),
            'wifi_time_out_timer' => $this->input->post('wifi_time_out_timer'),
            'wifi_time_out_time_rekey' => $this->input->post('wifi_time_out_time_rekey'),
            'lte_jitter_buff' => $this->input->post('lte_jitter_buff'),
            'wifi_jitter_buff' => $this->input->post('wifi_jitter_buff'),

            // 受信通知設定
            'speaker_lte_vib' => $this->input->post('speaker_lte_vib'),
            'speaker_pri_wifi_vib' => $this->input->post('speaker_pri_wifi_vib'),
            'speaker_lte_data' => $this->input->post('speaker_lte_data'),
            'speaker_pri_wifi_data' => $this->input->post('speaker_pri_wifi_data'),

            // マイク設定
            'audio_mic_type' => $this->input->post('audio_mic_type'),

            // 定型メッセージリスト
            'message_list_m1' => $this->input->post('message_list_m1'),
            'message_list_m2' => $this->input->post('message_list_m2'),
            'message_list_m3' => $this->input->post('message_list_m3'),
            'message_list_m4' => $this->input->post('message_list_m4'),
            'message_list_m5' => $this->input->post('message_list_m5'),
            'message_list_m6' => $this->input->post('message_list_m6'),
            'message_list_m7' => $this->input->post('message_list_m7'),
            'message_list_m8' => $this->input->post('message_list_m8'),
            'message_list_m9' => $this->input->post('message_list_m9'),
            'message_list_m10' => $this->input->post('message_list_m10'),
            'message_list_m11' => $this->input->post('message_list_m11'),
            'message_list_m12' => $this->input->post('message_list_m12'),
            'message_list_m13' => $this->input->post('message_list_m13'),
            'message_list_m14' => $this->input->post('message_list_m14'),
            'message_list_m15' => $this->input->post('message_list_m15'),
            'message_list_m16' => $this->input->post('message_list_m16'),
            'message_list_m17' => $this->input->post('message_list_m17'),
            'message_list_m18' => $this->input->post('message_list_m18'),
            'message_list_m19' => $this->input->post('message_list_m19'),
            'message_list_m20' => $this->input->post('message_list_m20'),

            // 履歴設定
            'history_timestamp' => $this->input->post('history_timestamp'),
            'history_call' => $this->input->post('history_call'),
            'history_income' => $this->input->post('history_income'),
            'history_outcome' => $this->input->post('history_outcome'),
            'history_message_in' => $this->input->post('history_message_in'),
            'history_message_out' => $this->input->post('history_message_out'),
         
            // カスタム設定
            'custom1' => $this->input->post('custom1'),
            'custom2' => $this->input->post('custom2'),
            'custom3' => $this->input->post('custom3'),
            'custom4' => $this->input->post('custom4'),
            'custom5' => $this->input->post('custom5'),
            'custom6' => $this->input->post('custom6'),
            'custom7' => $this->input->post('custom7'),
            'custom8' => $this->input->post('custom8'),
            'custom9' => $this->input->post('custom9'),
            'custom10' => $this->input->post('custom10'),
            'custom11' => $this->input->post('custom11'),
            'custom12' => $this->input->post('custom12'),
            'custom13' => $this->input->post('custom13'),
            'custom14' => $this->input->post('custom14'),
            'custom15' => $this->input->post('custom15'),
            'custom16' => $this->input->post('custom16'),
            'custom17' => $this->input->post('custom17'),
            'custom18' => $this->input->post('custom18'),
            'custom19' => $this->input->post('custom19'),
            'custom20' => $this->input->post('custom20'),
            
            // 送信設定
            'audio_intnl_mic_gain' => $this->input->post('audio_intnl_mic_gain'),
            'audio_extnl_mic_gain' => $this->input->post('audio_extnl_mic_gain'),
            'audio_emergency_mic_gain' => $this->input->post('audio_emergency_mic_gain'),
            'key_ptt_hold' => $this->input->post('key_ptt_hold'),
            'audio_earphone_callback' => $this->input->post('audio_earphone_callback'),
            'vox' => $this->input->post('vox'),
            'vox_thresh' => $this->input->post('vox_thresh'),
            'audio_noise_can' => $this->input->post('audio_noise_can'),
            'audio_echo_can' => $this->input->post('audio_echo_can'),
            'time_out_timer' => $this->input->post('time_out_timer'),
            'ptt_call' => $this->input->post('ptt_call'),
            'ptt_group' => $this->input->post('ptt_group'),
            'ptt_conference' => $this->input->post('ptt_conference'),
            'direct_call' => $this->input->post('direct_call'),
            'direct_group' => $this->input->post('direct_group'),
            'tx_block' => $this->input->post('tx_block'),
            'ind_callback_timer' => $this->input->post('ind_callback_timer'),
            'group_callback_timer' => $this->input->post('group_callback_timer'),
            'all_callback_timer' => $this->input->post('all_callback_timer'),
            'individual_call_disable' => $this->input->post('individual_call_disable'),
            'individual_message_disable' => $this->input->post('individual_message_disable'),
            
            // 受信設定
            'audio_alc' => $this->input->post('audio_alc'),
            'audio_bass_reduce' => $this->input->post('audio_bass_reduce'),
            'audio_treble_reduce' => $this->input->post('audio_treble_reduce'),
            'record_mode' => $this->input->post('record_mode'),
            'message_block' => $this->input->post('message_block'),

            // 通知/警告設定
            'speaker_beep_vol' => $this->input->post('speaker_beep_vol'),
            'alarm_bell' => $this->input->post('alarm_bell'),
            'bell_mode' => $this->input->post('bell_mode'),
            'voice_guide' => $this->input->post('voice_guide'),
            'voice_guide_vol' => $this->input->post('voice_guide_vol'),
            'alarm_low_battery' => $this->input->post('alarm_low_battery'),
            'alarm_earphone_broken' => $this->input->post('alarm_earphone_broken'),
            'alarm_ind_call_ok' => $this->input->post('alarm_ind_call_ok'),
            'alarm_ind_call_ng' => $this->input->post('alarm_ind_call_ng'),
            'audio_ptt_beep' => $this->input->post('audio_ptt_beep'),
            'audio_end_beep' => $this->input->post('audio_end_beep'),
            'alarm_connect' => $this->input->post('alarm_connect'),
            'alarm_stop_callback' => $this->input->post('alarm_stop_callback'),

            // 各種動作設定
            'shortcut_key' => $this->input->post('shortcut_key'),
            'speaker_extnl_vol' => $this->input->post('speaker_extnl_vol'),
            'speaker_vol_mode' => $this->input->post('speaker_vol_mode'),
            'speaker_fixed_vol' => $this->input->post('speaker_fixed_vol'),
            'speaker_max_vol' => $this->input->post('speaker_max_vol'),
            'speaker_min_vol' => $this->input->post('speaker_min_vol'),
            'earphone_sekkyaku_mode' => $this->input->post('earphone_sekkyaku_mode'),
            'sekkyaku_voice' => $this->input->post('sekkyaku_voice'),
            'sekkyaku_touch' => $this->input->post('sekkyaku_touch'),
            'sekkyaku_release_timer' => $this->input->post('sekkyaku_release_timer'),
            'sekkyaku_voice_timer' => $this->input->post('sekkyaku_voice_timer'),
            
            //緊急動作設定
            'emergency_receive' => $this->input->post('emergency_receive'),
            'emergency_alarm_duration' => $this->input->post('emergency_alarm_duration'),
            'emergency_alarm_ptt_duration' => $this->input->post('emergency_alarm_ptt_duration'),
            'emergency_silent_ptt_duration' => $this->input->post('emergency_silent_ptt_duration'),
            'emergency_live_ptt_duration' => $this->input->post('emergency_live_ptt_duration'),
            'emergency_intnl_vol' => $this->input->post('emergency_intnl_vol'),
            'emergency_extnl_vol' => $this->input->post('emergency_extnl_vol'),
            'kinkyu_sokuho' => $this->input->post('kinkyu_sokuho'),

            //端末システム設定
            'backlight_timer' => $this->input->post('backlight_timer'),
            'display_lcd_contrast' => $this->input->post('display_lcd_contrast'),
            'battery_save' => $this->input->post('battery_save'),
            'power_off_timer' => $this->input->post('power_off_timer'),
            'audio_codec' => $this->input->post('audio_codec'),
            'set_mode' => $this->input->post('set_mode'),
            'reset_disable' => $this->input->post('reset_disable')
        );            
        
        //log_message('debug', 'Handy_tenant#edit_action() write:');

        // 設定を保存
        if ($tid) {
            $rslt = $this->handydevice_model->edit_tenant_template($tid, $record);
        } else {
            $rslt = $this->handydevice_model->edit_tenant_template(0, $record);
        }
        $message = null;
        if (!$rslt) {
            $message = 'データベースエラーが発生しました。';
        }
            
        $data['menu'] = 'devicesetting';
        $data['css'] = 'dummy.css';
        $data['success'] = $rslt;
        if ($tid) {
        	$data['back'] = 'handy_tenant/view/'.$tid;
        } else {
        	$data['back'] = 'handy_tenant/view/0';
		}
        $data['message'] = $message;
        $this->load->view('message_view', $data);
    }

    /**
     * パーミッションエラー処理。
     *
     * @param array $session_data セッションデータ。
     */
    private function permission_error($session_data)
    {
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['css'] = 'dummy.css';
        $data['menu'] = 'home';
        $data['success'] = false;
        $data['message'] = '許可されない操作です。';
        $data['back'] = 'home';
        $this->load->view('message_view', $data);
    }

    /**
     * 文字列がすべて半角文字かのチェック
     *
     * @param $str 判定する文字列
     */
     public function half_size_characters($str)
    {
        $toEncod = 'UTF-8';
        $encoding = mb_internal_encoding();

        $convertstr = mb_convert_encoding($str, $toEncod, $encoding);
        if (strlen($convertstr) === mb_strlen($convertstr, $toEncod))
        {
            return true;
        }
        else
        {
            $this->form_validation->set_message('half_size_characters', '半角文字のみ使用可能です。');
            return false;
        }
    }
}
