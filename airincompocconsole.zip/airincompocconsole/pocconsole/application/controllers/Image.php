<?php if (! defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class Image extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('tenant_model', '', true);
        $this->load->model('pocaccount_model', '', true);
        $this->load->model('group_model', '', true);
        $this->load->helper(array('form','url'));
    }

    /**
     * 画像一覧を表示する。
     *
     * @param int $tid テナントID。
     */
    public function tile_view($tid = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }
        
        if ($session_data['usermode'] != 'admin') {
            $tid = $session_data['tenant'];
        }

        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];

        if ($tid) {
            // パラメータチェック
            $tenant = $this->tenant_model->get($tid);
            if (!$tenant) {
                $this->permission_error($session_data);
                return;
            }

            $account_list = $this->pocaccount_model->get_tenant($tid);
            $accounts = array();
            if ($account_list) {
                foreach ($account_list as $row) {
                    if ($row->device_id == DEVICE_SPT) {
                        $file_name = $this->get_image_file($row->username);
                        $image['poc_id'] = $row->poc_id;
                        $image['display_name'] = $row->display_name;
                        $image['file_name'] = $file_name;
                        if ($file_name != null) {
                            //$image['image_path'] = 'https://ptt.iforce.ne.jp:3199/spt_api2/image_base/'.$row->username."_s/".$file_name.".jpeg";
                            $image['image_path'] = base_url(
                                'image/get_image/'.$tenant->company_id.'/'.$row->poc_id
                                .'/'.$file_name.'/1'
                            );
                            $image['date'] = date("Y/m/d", $file_name);
                            $image['time'] = date("H:i:s", $file_name);
                        } else {
                            $image['image_path'] = base_url('images/noimage_s.png');
                            $image['date'] = "-----";
                            $image['time'] = "-----";
                        }
                        $accounts[] = $image;
                    }
                }
            }

            $data['accounts'] = $accounts;
            $data['tenant'] = $tenant;
            $this->load->view('image_tile_view', $data);
        } else {
            $data['tenants'] = $this->tenant_model->get_all();
            $this->load->view('image_select_view', $data);
        }
    }

    /**
     * 画像を取得する。
     *
     * 画像データを返す。
     *
     * @param int $tid テナントID。
     */
    public function get_image($tid = false, $pid = false, $iid = false, $thumbnail = false)
    {
        // JPEGデータを返す
        $this->output->set_content_type('image/jpeg');

        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            // error
            return;
        }

        if ($session_data['usermode'] != 'admin' && $session_data['tenant'] != $tid) {
            // error
            return;
        }

        $account = $this->pocaccount_model->get($pid);
        if (!$account) {
            // error
            return;
        }

        $folder = $account->username;
        $path = IMAGE_TRANSFER_DIR.$folder;
        if ($thumbnail) {
            $path .= '_s';
        }
        $path .= '/'.$iid.'.jpg';

        $img = file_get_contents($path);
        if ($img === false) {
            $path = $thumbnail ? '_s' : '';
            $this->output->set_content_type('image/png');
            $img = file_get_contents(IMAGE_TRANSFER_DIR.$path.'.png');
        }

        echo $img;
    }
        

    /**
     * 最新画像を取得する。
     *
     * jsonデータを返す。
     *
     * @param int $tid テナントID。
     */
    public function reload_image($tid = false)
    {
        // JSONデータを返す
        $this->output->set_content_type('application/json');

        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            return;
        }
        
        if ($session_data['usermode'] != 'admin') {
            $tid = $session_data['tenant'];
        }

        // パラメータチェック
        $tenant = $this->tenant_model->get($tid);
        if (!$tenant) {
            return;
        }

        $account_list = $this->pocaccount_model->get_tenant($tid);
        $accounts = array();
        if ($account_list) {
            foreach ($account_list as $row) {
                if ($row->device_id == DEVICE_SPT) {
                    $file_name = $this->get_image_file($row->username);
                    $image['poc_id'] = $row->poc_id;
                    if ($file_name != null) {
                        //$image['image_path'] = 'https://ptt.iforce.ne.jp:3199/spt_api2/image_base/'.$row->username."_s/".$file_name.".jpeg";
                        $image['image_path'] = base_url(
                            'image/get_image/'.$tenant->company_id.'/'.$row->poc_id.'/'
                            .$file_name.'/1'
                        );
                        $image['date'] = date("Y/m/d", $file_name);
                        $image['time'] = date("H:i:s", $file_name);
                    } else {
                        $image['image_path'] = base_url('images/noimage_s.png');
                        $image['date'] = "-----";
                        $image['time'] = "-----";
                    }
                    $accounts[] = $image;
                }
            }
        }

        $this->output->set_output(json_encode($accounts, JSON_UNESCAPED_SLASHES));
    }

    /**
     * 画像詳細を表示する。
     *
     * @param int $tid テナントID。
     * @param int $id PoCアカウントID。
     */
    public function detail($tid = false, $id = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }
        
        if ($session_data['usermode'] != 'admin') {
            $tid = $session_data['tenant'];
        }

        // パラメータチェック
        $tenant = $this->tenant_model->get($tid);
        $account = $this->pocaccount_model->get($id);
        if (!$tenant || !$account) {
            $this->permission_error($session_data);
            return;
        }

        $file_name = $this->get_image_file($account->username, true);
        $image_list = null;
        if ($file_name) {
            foreach ($file_name as $row) {
                $image = array();
                $image['poc_id'] = $account->poc_id;
                $image['display_name'] = $account->display_name;
                $image['file_name'] = $row;
                $image['date'] = date("Y/m/d", $row);
                $image['time'] = date("H:i:s", $row);
                $image_list[] = $image;
            }
        }
        
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['tenant'] = $tenant;
        $data['account'] = $account;
        $data['accounts'] = $this->pocaccount_model->get_tenant($tid);
        $data['groups'] = $this->group_model->get_tenant($tid);
        //$data['image_path'] = 'https://ptt.iforce.ne.jp:3199/spt_api2/image_base/'.$account->username.'/';
        $data['image_path'] = base_url('image/get_image/'.$tenant->company_id.'/'
                                       .$account->poc_id);
        $data['image'] = $image_list;
        $this->load->view('image_detail_view', $data);
    }


    /**
     * 画像をpush配信する。
     *
     * @param int $tid テナントID。
     * @param int $pid PoCアカウントID。
     */
    public function push_image($tid = false, $pid = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }
        
        if ($session_data['usermode'] != 'admin') {
            $tid = $session_data['tenant'];
        }

        $parray = $this->input->post('poc_id[]');
        $garray = $this->input->post('group_id[]');
        $iid = $this->input->post('image_id');

        $account = $this->pocaccount_model->get($pid);
        if (!$account) {
            $this->permission_error($session_data);
            return;
        }

        $top = '';
        for ($i = 0; $i < count($parray); $i++) {
            $acc = $this->pocaccount_model->get($parray[$i]);
            if ($i != 0) {
                $top .= ',';
            }
            $top .= $acc->xmpp_username;
        }

        $tog = '';
        for ($i = 0; $i < count($garray); $i++) {
            $group = $this->group_model->get($garray[$i]);
            if ($i != 0) {
                $tog .= ',';
            }
            $tog .= $group->sip_number;
        }
        log_message('debug', 'top='.$top.' tog='.$tog);

        $error = false;
        $message = null;
        $client = new GuzzleHttp\Client;
        try {
            $response = $client->post(
                'https://'.SPTAPI_SERVER_HOST.SPTAPI_PATH.'/message_image.php',
                ['body' => [
                                                 'company_id' => $tid,
                                                 'top' => $top,
                                                 'tog' => $tog,
                                                 'datetime' => time() * 1000,
                                                 'body' => $account->username.'_'.$iid,
                                                 'type' => '11'
                                                 ]
                                      ]
            );
        } catch (RequestException $e) {
            $error = true;
            $message = '画像の配信に失敗しました。';
            log_message('error', 'Sending push image failed.');
            log_message('error', 'RequestException: request='.$e->getRequest()
                        .' response='.($e->hasResponse() ? $e->getResponse() : ''));
        }
        if ($response->getStatusCode() != 200) {
            $error = true;
            $message = '画像の配信に失敗しました。';
            log_message('error', 'Sending push image failed.');
            log_message('error', 'RequestError: status='.$response->getStatusCode());
        }

        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['css'] = 'dummy.css';
        $data['menu'] = 'pocaccount';
        $data['success'] = !$error;
        $data['message'] = $message;
        $data['back'] = 'image/detail/'.$tid.'/'.$pid;
        $this->load->view('message_view', $data);
    }

    /**
     * アカウントの最新画像のファイル名を取得する。
     *
     * @param string $folder_name アカウントのフォルダ名。
     * @return string ファイル名。
     */
    private function get_image_file($folder_name, $all = false)
    {
        $extension = ".jpg";

        if ($folder_name == null) {
            return null;
        }

        $folder_base_path = IMAGE_TRANSFER_DIR;
        $folder_path = $folder_base_path . $folder_name . "/";
        
        if (is_dir($folder_path) && $handle = opendir($folder_path)) {
            $file_list = array();
            $count = 0;
            
            while (($file = readdir($handle)) !== false) {
                if (filetype($folder_path . $file) == "file") {
                    $file = str_replace($extension, "", $file);
                    $file_list[$count] = $file;
                    $count++;
                }
            }

            if (empty($file_list)) {
                return null;
            }
            
            if (!$all) {
                rsort($file_list);
                return $file_list[0];
            } else {
                sort($file_list);
                return $file_list;
            }
        } else {
            return null;
        }
    }

    /**
     * パーミッションエラー処理。
     *
     * @param array $session_data セッションデータ。
     */
    private function permission_error($session_data)
    {
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['css'] = 'dummy.css';
        $data['menu'] = 'home';
        $data['success'] = false;
        $data['message'] = '許可されない操作です。';
        $data['back'] = 'home';
        $this->load->view('message_view', $data);
    }
}
