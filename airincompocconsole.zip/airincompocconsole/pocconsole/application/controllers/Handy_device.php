<?php if (! defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class Handy_device extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('tenant_model', '', true);
        $this->load->model('handydevice_model', '', true);
        $this->load->helper(array('form','url'));

		log_message('debug', 'Handy_device#__construct() enter:');
    }

    /**
     * テナント用デバイステンプレートか、保守アカウント用デバイステンプレートを表示
     *
     * @param int $tid テナントのID。指定がないか0の場合は保守アカウント用デバイステンプレートを表示。
     */
    public function view($tid = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];

        if ($session_data['usermode'] != 'admin') {
            $tid = $session_data['tenant'];
        }

        if ($tid) {
            // テナント用デバイステンプレート
            // パラメータチェック
            $tenant = $this->tenant_model->get($tid);
            if (!$tenant) {
                $this->permission_error($session_data);
                return;
            }
            $data['hdy_config'] = $this->handydevice_model->get_device_template($tid);
            $data['config_type'] = 'device_tenant';
            $data['tenant'] = $tenant;
        } else {
            // 保守アカウント用デバイステンプレート
            $data['hdy_config'] = $this->handydevice_model->get_device_template(0);
            $data['config_type'] = 'device_admin';
            $data['tenant'] = '(保守)';   // for safety
        }

        $this->load->view('handy_device_detail_view', $data);
    }
    
    /**
     * テナント用デバイステンプレートか、保守アカウント用デバイステンプレートを編集
     *
     * @param int $tid テナントのID。指定がないか0の場合は保守アカウント用デバイステンプレートを編集。
     */
    public function edit($tid = false)
    {
		log_message('debug', 'Handy_device#edit() enter:');

        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        
        // ユーザーモードでは異なるテナントの編集を禁止する。
        if ($session_data['usermode'] != 'admin' && $tid != $session_data['tenant']) {
            $this->permission_error($session_data);
            return;
        }

        if ($tid) {
            // テナント用デバイステンプレートを編集
            // パラメータチェック
            $tenant = $this->tenant_model->get($tid);
            if (!$tenant) {
                $this->permission_error($session_data);
                return;
            }
            $data['hdy_config'] = $this->handydevice_model->get_device_template($tid);
            $data['config_type'] = 'device_tenant';
            $data['tenant'] = $tenant;
        } else {
            // 保守アカウント用デバイステンプレート
            $data['hdy_config'] = $this->handydevice_model->get_device_template(0);
            $data['config_type'] = 'device_admin';
            $data['tenant'] = '(保守)';   // for safety
        }

        $this->load->view('handy_device_detail_edit', $data);
    }

    /**
     * 編集結果をテナント用デバイステンプレートか、保守アカウント用デバイステンプレートに保存
     *
     * @param int $tid テナントのID。指定がないか0の場合は保守アカウント用デバイステンプレートを保存。
     */
    public function edit_action($tid = false)
    {
		log_message('debug', 'Handy_device#edit_action() enter:');

        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        if ($session_data['usermode'] != 'admin' && $tid != $session_data['tenant']) {
            $this->permission_error($session_data);
            return;
        }

		if ($tid) {
        	// パラメータチェック
        	$tenant = $this->tenant_model->get($tid);
        	if (!$tenant) {
				$this->permission_error($session_data);
            	return;
        	}
            $data['config_type'] = 'device_tenant';
            $data['tenant'] = $tenant;
        } else {
            // 保守アカウント用テナントテンプレート
            $data['config_type'] = 'device_admin';
            $data['tenant'] = '(保守)';   // for safety
		}

        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('<div class="bg-danger">', '</div>');

        // PoCアカウント情報
        $this->form_validation->set_rules('disp_name', '表示名', 'max_length[128]');
        $this->form_validation->set_rules('sip_id', 'SIP番号', 'max_length[128]');
        $this->form_validation->set_rules('sip_password', 'SIPパスワード', 'max_length[128]');
        // 送信設定
        $this->form_validation->set_rules('vox_thresh', 'VOX動作レベル', 'greater_than_equal_to[1]|less_than_equal_to[7]');
        // 各種動作設定
        $this->form_validation->set_rules('speaker_fixed_vol', '固定音量レベル', 'greater_than_equal_to[0]|less_than_equal_to[32]');
        $this->form_validation->set_rules('speaker_max_vol', '最大音量レベル', 'greater_than_equal_to[0]|less_than_equal_to[32]');
        $this->form_validation->set_rules('speaker_min_vol', '最小音量レベル', 'greater_than_equal_to[0]|less_than_equal_to[32]');
        $this->form_validation->set_rules('sekkyaku_voice', '接客ボイス感度', 'greater_than_equal_to[1]|less_than_equal_to[7]');
        $this->form_validation->set_rules('sekkyaku_voice_timer', '接客ボイス保持', 'greater_than_equal_to[1]|less_than_equal_to[5]');
        // 緊急動作設定
        $this->form_validation->set_rules('emergency_alarm_duration', '緊急動作　警報音のみ', 'greater_than_equal_to[0]|less_than_equal_to[60]');
        $this->form_validation->set_rules('emergency_alarm_ptt_duration', '緊急動作　警報音+発報', 'greater_than_equal_to[0]|less_than_equal_to[60]');
        $this->form_validation->set_rules('emergency_silent_ptt_duration', '緊急動作　発報のみ', 'greater_than_equal_to[0]|less_than_equal_to[60]');
        $this->form_validation->set_rules('emergency_live_ptt_duration', '緊急動作　音声送信', 'greater_than_equal_to[0]|less_than_equal_to[60]');
        // 端末システム設定
        $this->form_validation->set_rules('display_lcd_contrast', 'コントラスト', 'greater_than_equal_to[1]|less_than_equal_to[10]');

        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        
		log_message('debug', 'Handy_device#edit_action() validation:');

        if ($this->form_validation->run() === false) {
            // 編集前のデータを再ロード
            if ($tid) {
                $data['hdy_config'] = $this->handydevice_model->get_device_template($tid);
            } else {
                $data['hdy_config'] = $this->handydevice_model->get_device_template(0);
            }
            $this->load->view('handy_device_detail_edit', $data);
            return;
        }

        // POST内容とそのほかのデータを集める
        $record = array(

            // 管理用情報
            'update_date' => date('Y-m-d H:i:s'),
            'comment' => $this->input->post('comment'),

            // システム設定
            'clock' => $this->input->post('clock'),
            'pri_wifi' => $this->input->post('pri_wifi'),
            'voice_info' => $this->input->post('voice_info'),

            // POCアカウント情報
            'disp_name' => $this->input->post('disp_name'),
            'sip_id' => $this->input->post('sip_id'),
            'sip_password' => $this->input->post('sip_password'),

            // 受信通知設定
            'speaker_lte_vib' => $this->input->post('speaker_lte_vib'),
            'speaker_pri_wifi_vib' => $this->input->post('speaker_pri_wifi_vib'),
            'speaker_lte_data' => $this->input->post('speaker_lte_data'),
            'speaker_pri_wifi_data' => $this->input->post('speaker_pri_wifi_data'),

            // マイク設定
            'audio_mic_type' => $this->input->post('audio_mic_type'),

            // 送信設定
            'audio_intnl_mic_gain' => $this->input->post('audio_intnl_mic_gain'),
            'audio_extnl_mic_gain' => $this->input->post('audio_extnl_mic_gain'),
            'audio_emergency_mic_gain' => $this->input->post('audio_emergency_mic_gain'),
            'key_ptt_hold' => $this->input->post('key_ptt_hold'),
            'audio_earphone_callback' => $this->input->post('audio_earphone_callback'),
            'vox' => $this->input->post('vox'),
            'vox_thresh' => $this->input->post('vox_thresh'),
            'audio_noise_can' => $this->input->post('audio_noise_can'),
            'audio_echo_can' => $this->input->post('audio_echo_can'),
            'time_out_timer' => $this->input->post('time_out_timer'),
            'ptt_call' => $this->input->post('ptt_call'),
            'ptt_group' => $this->input->post('ptt_group'),
            'ptt_conference' => $this->input->post('ptt_conference'),
            'ptt_individual' => $this->input->post('ptt_individual'),
            'direct_call' => $this->input->post('direct_call'),
            'direct_group' => $this->input->post('direct_group'),
            'direct_individual' => $this->input->post('direct_individual'),
            'tx_block' => $this->input->post('tx_block'),
            'ind_callback_timer' => $this->input->post('ind_callback_timer'),
            'group_callback_timer' => $this->input->post('group_callback_timer'),
            'all_callback_timer' => $this->input->post('all_callback_timer'),
            
            // 受信設定
            'audio_alc' => $this->input->post('audio_alc'),
            'audio_bass_reduce' => $this->input->post('audio_bass_reduce'),
            'audio_treble_reduce' => $this->input->post('audio_treble_reduce'),
            'record_mode' => $this->input->post('record_mode'),
            'message_block' => $this->input->post('message_block'),

            // 通知/警告設定
            'speaker_beep_vol' => $this->input->post('speaker_beep_vol'),
            'alarm_bell' => $this->input->post('alarm_bell'),
            'bell_mode' => $this->input->post('bell_mode'),
            'voice_guide' => $this->input->post('voice_guide'),
            'voice_guide_vol' => $this->input->post('voice_guide_vol'),
            'alarm_low_battery' => $this->input->post('alarm_low_battery'),
            'alarm_earphone_broken' => $this->input->post('alarm_earphone_broken'),
            'alarm_ind_call_ok' => $this->input->post('alarm_ind_call_ok'),
            'alarm_ind_call_ng' => $this->input->post('alarm_ind_call_ng'),
            'audio_ptt_beep' => $this->input->post('audio_ptt_beep'),
            'audio_end_beep' => $this->input->post('audio_end_beep'),
            'alarm_connect' => $this->input->post('alarm_connect'),
            'alarm_stop_callback' => $this->input->post('alarm_stop_callback'),

            // 各種動作設定
            'shortcut_key' => $this->input->post('shortcut_key'),
            'speaker_extnl_vol' => $this->input->post('speaker_extnl_vol'),
            'speaker_vol_mode' => $this->input->post('speaker_vol_mode'),
            'speaker_fixed_vol' => $this->input->post('speaker_fixed_vol'),
            'speaker_max_vol' => $this->input->post('speaker_max_vol'),
            'speaker_min_vol' => $this->input->post('speaker_min_vol'),
            'earphone_sekkyaku_mode' => $this->input->post('earphone_sekkyaku_mode'),
            'sekkyaku_voice' => $this->input->post('sekkyaku_voice'),
            'sekkyaku_touch' => $this->input->post('sekkyaku_touch'),
            'sekkyaku_release_timer' => $this->input->post('sekkyaku_release_timer'),
            'sekkyaku_voice_timer' => $this->input->post('sekkyaku_voice_timer'),
            
            //緊急動作設定
            'emergency_receive' => $this->input->post('emergency_receive'),
            'emergency_alarm_duration' => $this->input->post('emergency_alarm_duration'),
            'emergency_alarm_ptt_duration' => $this->input->post('emergency_alarm_ptt_duration'),
            'emergency_silent_ptt_duration' => $this->input->post('emergency_silent_ptt_duration'),
            'emergency_live_ptt_duration' => $this->input->post('emergency_live_ptt_duration'),
            'emergency_intnl_vol' => $this->input->post('emergency_intnl_vol'),
            'emergency_extnl_vol' => $this->input->post('emergency_extnl_vol'),
            'kinkyu_sokuho' => $this->input->post('kinkyu_sokuho'),

            //端末システム設定
            'backlight_timer' => $this->input->post('backlight_timer'),
            'display_lcd_contrast' => $this->input->post('display_lcd_contrast'),
            'battery_save' => $this->input->post('battery_save'),
            'power_off_timer' => $this->input->post('power_off_timer'),
            'audio_codec' => $this->input->post('audio_codec'),
            'set_mode' => $this->input->post('set_mode'),
            'reset_disable' => $this->input->post('reset_disable')  
        );            
            
		//log_message('debug', 'Handy_device#edit_action() write:');

        // 設定を保存
        if ($tid) {
            $rslt = $this->handydevice_model->edit_device_template($tid, $record);
        } else {
            $rslt = $this->handydevice_model->edit_device_template(0, $record);
        }
        $message = null;
        if (!$rslt) {
            $message = 'データベースエラーが発生しました。';
        }
            
        $data['menu'] = 'devicesetting';
        $data['css'] = 'dummy.css';
        $data['success'] = $rslt;
        if ($tid) {
        	$data['back'] = 'handy_device/view/'.$tid;
        } else {
        	$data['back'] = 'handy_device/view/0';
		}
        $data['message'] = $message;
        $this->load->view('message_view', $data);
    }

    /**
     * パーミッションエラー処理。
     *
     * @param array $session_data セッションデータ。
     */
    private function permission_error($session_data)
    {
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['css'] = 'dummy.css';
        $data['menu'] = 'home';
        $data['success'] = false;
        $data['message'] = '許可されない操作です。';
        $data['back'] = 'home';
        $this->load->view('message_view', $data);
    }
}
