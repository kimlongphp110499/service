<?php if (! defined('BASEPATH')) {
    exit('No direct script access allowed');
}

//
// use constant in global context
//

// sip.conf definiton for AWS
const sip_conf_template_aws = <<<'EOD'
[general]
maxexpiry=86400
defaultexpiry=3600
context=default
udpbindaddr=0.0.0.0:5060
transport=udp,ws,wss
disallow=all
;allow=ulaw
;allow=alaw
;allow=g729
;allow=g722
;allow=g723
;allow=g726
allow=speex,speex16,speex32
;allow=gsm
language=ja
externip=52.196.218.153
localnet=10.0.0.0/8
localnet=172.16.0.0/12
localnet=192.168.0.0/16
realm=sns-sip.iforce.ne.jp
pedantic=no
allowguest=no
keepalive=60
qualifyfreq=60
ignoreregexpire=yes

; Jitter buffer
jbenable=yes
jbforce=yes
jbmaxsize=200
jbresyncthreshold=1000
jbimpl=fixed

EOD;
    
// sip.conf definiton for KCPS2
const sip_conf_template_kcps2 = <<<'EOD'
[general]
maxexpirey=3600
defaultexpirey=3600
context=default
udpbindaddr=0.0.0.0:5060
transport=udp,ws,wss
disallow=all
allow=ulaw
allow=alaw
allow=g729
;allow=g722
;allow=g723
;allow=g726
allow=speex,speex16,speex32
;allow=gsm
language=ja
externip=27.93.149.218
localnet=10.0.0.0/8
localnet=192.168.0.0/16
;localnet=198.18.174.130/27
realm=sns-sip.iforce.ne.jp
pedantic=no
allowguest=no
keepalive=60
qualifyfreq=60
ignoreregexpire=yes

; Jitter buffer
jbenable=yes
jbforce=yes
jbmaxsize=200
jbresyncthreshold=1000
jbimpl=fixed

EOD;
        
    
// sip.conf definiton for IIJ GIO
const sip_conf_template_iijgio = <<<'EOD'
[general]
maxexpirey=3600
defaultexpirey=3600
context=default
udpbindaddr=0.0.0.0:5060
transport=udp,ws,wss
disallow=all
allow=ulaw
allow=alaw
allow=g729
;allow=g722
;allow=g723
;allow=g726
;allow=speex
;allow=gsm
language=ja
externip=150.31.253.17
localnet=10.203.0.0/20
realm=sns-sip.iforce.ne.jp
pedantic=no
allowguest=no
keepalive=60

EOD;
            
// sip.conf definiton for AZURE
const sip_conf_template_azure = <<<'EOD'
[general]
maxexpirey=3600
defaultexpirey=3600
context=default
udpbindaddr=0.0.0.0:5060
transport=udp,ws,wss
disallow=all
allow=ulaw
allow=alaw
allow=g729
;allow=g722
;allow=g723
;allow=g726
;allow=speex
;allow=gsm
language=ja
externip=centos.japanwest.cloudapp.azure.com
localnet=10.0.2.4/24
realm=sns-sip.iforce.ne.jp
pedantic=no
allowguest=no
keepalive=60

EOD;
    
// sip.conf definiton common part
const sip_conf_template_common = <<<'EOD'

; Session-Timer
session-timers=originate
session-expires=120
session-minse=60
session-refresher=uas

;
; TLS Settings
;
;tlsenable=yes
;tlsbindaddr=0.0.0.0
;tlscertfile=/etc/asterisk/keys/asterisk.pem
;tlscafile=/etc/asterisk/keys/ca.crt
;tlsdontverifyserver=yes
;tlscipher=ALL
;tlsclientmethod=tlsv1

;
; MESSAGE Settings
;
accept_outofcall_message=yes
outofcall_message_context=messages ;"messages" is context name.
auth_message_requests=yes

; Template for SPT application
;
[dev_spt](!)
type=friend
canreinvite=no
host=dynamic
dtmfmode=rfc2833
callgroup=1
pickupgroup=1
qualify=no
nat=force_rport,comedia
insecure=invite,port
disallow=all
allow=speex,speex16,speex32
allow=ulaw
;allow=g729

; Template for ISM-101
;
[dev_ism](!)
insecure=invite
type=friend
host=dynamic
qualify=no
disallow=all
allow=g729
allow=ulaw
nat=force_rport,comedia

; Template for IP-Phone
;
[dev_ipp](!)
insecure=invite
type=friend
host=dynamic
qualify=no
disallow=all
allow=speex,speex16,speex32
allow=ulaw
;allow=g729
nat=force_rport,comedia

EOD;


class PocAccount extends CI_Controller
{
    private $enc_key = 'SC9MjPrX&x$aWQ5/~wyyyA!eUoPJ&EBy';

    public function __construct()
    {
        parent::__construct();
        $this->load->model('pocaccount_model', '', true);
        $this->load->model('tenant_model', '', true);
        $this->load->model('group_model', '', true);
        $this->load->model('device_model', '', true);
        $this->load->model('handydevice_model', '', true);
        $this->load->helper('file');
        $this->load->helper(array('form','url'));
        $this->load->driver('cache', array('adapter' => 'apc', 'backup' => 'file'));
    }

    /**
     * テナント選択画面かテナントのPoCアカウント一覧を表示する。
     *
     * @param int $tid テナントのID。0の場合はテナント選択画面を表示。
     * @param string $sortkey ソートキー。
     * @param string $order 順序('asc'or'desc')
     */
    public function view_list($tid = false, $sortkey = false, $order = false)
    {
		//$this->output->enable_profiler(true);
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];

        if ($data['usermode'] != 'admin') {
            $tid = $session_data['tenant'];
        }

        // load page
        if ($tid) {
            // パラメータチェック
            $tenant = $this->tenant_model->get($tid);
            if (!$tenant) {
                $this->permission_error($session_data);
                return;
            }

            $data['tenant'] = $tenant;
            $data['accounts'] = $this->pocaccount_model->get_tenant($tid, $sortkey, $order);
            $data['sortkey'] = $sortkey;
            $data['order'] = $order;
            $this->load->view('pocaccount_list_view', $data);
        } else {
            $data['tenants'] = $this->tenant_model->get_all();
            $this->load->view('pocaccount_select_view', $data);
        }
    }

    /**
     * PoCアカウントの追加画面を表示する。
     *
     * @param int $tid テナントID。
     */
    public function add_batch($tid = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        if ($session_data['usermode'] != 'admin') {
            $this->permission_error($session_data);
            return;
        }

        // パラメータチェック
        $tenant = $this->tenant_model->get($tid);
        if (!$tenant) {
            $this->permission_error($session_data);
            return;
        }

        // load view
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['tenant'] = $tenant;
        $data['devices'] = $this->device_model->get_all();
        $this->load->view('pocaccount_add_batch_view', $data);
    }

    /**
     * アカウントを追加する。
     *
     * @param int $tid テナントID。
     */
    public function add_batch_action($tid = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        if ($session_data['usermode'] != 'admin') {
            $this->permission_error($session_data);
            return;
        }

        // パラメータチェック
        $tenant = $this->tenant_model->get($tid);
        if (!$tenant) {
            $this->permission_error($session_data);
            return;
        }

        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('<div class="bg-danger">', '</div>');

        //$this->form_validation->set_rules('hdy_num', '新型ハンディ機アカウント数', 'required|is_natural');
        //$this->form_validation->set_rules('hdy_pref', '新型ハンディ機プレフィックス', 'alpha|max_length[8]');
        //$this->form_validation->set_rules('spt_num', 'SPTアカウント数', 'required|is_natural');
        //$this->form_validation->set_rules('spt_pref', 'SPTプレフィックス', 'alpha|max_length[8]');
        //$this->form_validation->set_rules('ism_num', 'ISMアカウント数', 'required|is_natural');
        //$this->form_validation->set_rules('ism_pref', 'ISMプレフィックス', 'alpha|max_length[8]');
        //$this->form_validation->set_rules('ipp_num', 'IPPアカウント数', 'required|is_natural');
        //$this->form_validation->set_rules('ipp_pref', 'IPPプレフィックス', 'alpha|max_length[8]');

        $this->form_validation->set_rules('device_type', 'デバイス種類', 'required|is_natural|greater_than[0]');  // for safety
        $this->form_validation->set_rules('account_num', '新規アカウント数', 'required|is_natural|greater_than[0]|less_than[99]');
        $this->form_validation->set_rules('prefix', 'プレフィックス', 'required|alpha|min_length[4]|max_length[8]');

        // prepare view data
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['tenant'] = $this->tenant_model->get($tid);
        $data['devices'] = $this->device_model->get_all();
        
        if ($this->form_validation->run() === false) {
            $this->load->view('pocaccount_add_batch_view', $data);
            return;
        }

        $error = false;
        $pw_str = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        /* 名前の重複をチェック */
        $last_ids = $this->tenant_model->get_last_device_ids($tid);

        // followings not used
        //$spt_num = $this->input->post('spt_num');
        //$ism_num = $this->input->post('ism_num');
        //$ipp_num = $this->input->post('ipp_num');
        //$hdy_num = $this->input->post('hdy_num');
        //$spt_pref = $this->input->post('spt_pref');
        //$ism_pref = $this->input->post('ism_pref');
        //$ipp_pref = $this->input->post('ipp_pref');
        //$hdy_pref = $this->input->post('hdy_pref');
        $spt_num = 0;
        $ism_num = 0;
        $ipp_num = 0;
        $hdy_num = 0;
        $spt_pref= '';
        $ism_pref= '';
        $ipp_pref= '';
        $hdy_pref= '';

        $device_type = $this->input->post('device_type');
        $account_num = $this->input->post('account_num');
        $prefix = $this->input->post('prefix');
        
        // アカウント数チェック
        $cur_num = $this->pocaccount_model->count_tenant($tid, $device_type);
        if ($cur_num + $account_num > 999) {
             $error = true;
             $message = '作成できるアカウント数を超えています。';
        }

        // setup account numbers and prefix
        switch ($device_type) {
        case DEVICE_SPT:    // = 1
            $spt_num = $account_num;
            $spt_pref = $prefix;
            break;
        case DEVICE_ISM:    // = 2
            $ism_num = $account_num;
            $ism_pref = $prefix;
            break;
        case DEVICE_IPP:    // = 3
            $ipp_num = $account_num;
            $ipp_pref = $prefix;
            break;
        case DEVICE_HDY:    // = 4
            $hdy_num = $account_num;
            $hdy_pref = $prefix;
            break;
        default:
            $error = true;
            $message = '内部エラー(無効なデバイス種別 '.$device_type.' が指定されました)';
            break;
        }

        $pref = $hdy_pref;
        $last_id = $last_ids->hdy_last_id + 1;
        $hdy_array = [];
        for ($i = 0; !$error && $i < $hdy_num; $i++) {
            $name = $pref.sprintf("%04d", $last_id + $i);
            if (!$this->pocaccount_model->is_available_id($name)) {
                $error = true;
                $message = 'アカウントID"'.$name.'"がすでに存在します。';
                break;
            }
            $account['username'] = $name;
            //$account['password'] = substr(str_shuffle(str_repeat($pw_str, 8)), 0, 8);
            $account['password'] = $name; // 開発用
            $account['device'] = DEVICE_HDY;
            $hdy_array[] = $account;
        }

        $pref = $spt_pref;
        $last_id = $last_ids->spt_last_id + 1;
        $spt_array = [];
        for ($i = 0; !$error && $i < $spt_num; $i++) {
            $name = $pref.sprintf("%04d", $last_id + $i);
            if (!$this->pocaccount_model->is_available_id($name)) {
                $error = true;
                $message = 'アカウントID"'.$name.'"がすでに存在します。';
                break;
            }
            $account['username'] = $name;
            //$account['password'] = substr(str_shuffle(str_repeat($pw_str, 8)), 0, 8);
            $account['password'] = $name; // 開発用
            $account['device'] = DEVICE_SPT;
            $spt_array[] = $account;
        }

        $pref = $ism_pref;
        $last_id = $last_ids->ism_last_id + 1;
        $ism_array = [];
        for ($i = 0; !$error && $i < $ism_num; $i++) {
            $name = $pref.sprintf("%04d", $last_id + $i);
            if (!$this->pocaccount_model->is_available_id($name)) {
                $error = true;
                $message = 'アカウントID"'.$name.'"がすでに存在します。';
                break;
            }
            $account['username'] = $name;
            $account['password'] = substr(str_shuffle(str_repeat($pw_str, 8)), 0, 8);
            $account['device'] = DEVICE_ISM;
            $ism_array[] = $account;
        }

        $pref = $ipp_pref;
        $last_id = $last_ids->ipp_last_id + 1;
        $ipp_array = [];
        for ($i = 0; !$error && $i < $ipp_num; $i++) {
            $name = $pref.sprintf("%04d", $last_id + $i);
            if (!$this->pocaccount_model->is_available_id($name)) {
                $error = true;
                $message = 'アカウントID"'.$name.'"がすでに存在します。';
                break;
            }
            $account['username'] = $name;
            $account['password'] = substr(str_shuffle(str_repeat($pw_str, 8)), 0, 8);
            $account['device'] = DEVICE_IPP;
            $ipp_array[] = $account;
        }

        /* アップロードファイルをチェック */
        if (!$error && count($ism_array) > 0) {
            $config['upload_path'] = './uploads/';
            $config['allowed_types'] = 'csv';
            $config['max_size'] = '1024 * 10';
            $this->load->library('upload', $config);
            if (!$this->upload->do_upload('ism_file')) {
                $error = true;
                $message = 'csvファイルの読み込みに失敗しました。';
            } else {
                $filepath = $this->upload->data('full_path');
                $file = new SplFileObject($filepath);
                $file->setFlags(SplFileObject::READ_CSV);
                $count = 0;
                $line_num = 1;
                foreach ($file as $line) {
                    $str = strtolower($line[0]);
                    if (!is_null($str)) {
                        if (strpos($str, '#') === 0) {
                            $line_num++;
                            continue;
                        }
                        // 前後の空白を削除
                        $str = trim($str);
                        if (!$this->check_mac_address($str)) {
                            $error = true;
                            $message = 'CSVファイルの'.$line_num.'行目にエラーがあります。';
                            break;
                        }
                        if (!$this->pocaccount_model->is_available_macaddr($str)) {
                            $error = true;
                            $message = 'MACアドレス"'.$str.'"はすでに存在します。';
                            break;
                        }
                        $ism_array[$count]['mac_address'] = $str;
                        if (++$count >= count($ism_array)) {
                            break;
                        }
                    }
                    $line_num++;
                }
            }
        }

        if (!$error) {
            /* DBを更新 */
            $this->db->trans_start();
            $new_last_hdy_id = $last_ids->hdy_last_id;
            $new_last_spt_id = $last_ids->spt_last_id;
            $new_last_ism_id = $last_ids->ism_last_id;
            $new_last_ipp_id = $last_ids->ipp_last_id;
            if (count($hdy_array) > 0) {
                $new_last_hdy_id = $this->pocaccount_model->add_batch($tid, $hdy_array, DEVICE_HDY, $last_ids->hdy_last_id + 1);
            }
            if (count($spt_array) > 0) {
                $new_last_spt_id = $this->pocaccount_model->add_batch($tid, $spt_array, DEVICE_SPT, $last_ids->spt_last_id + 1);
            }
            if (count($ism_array) > 0) {
                $new_last_ism_id = $this->pocaccount_model->add_batch($tid, $ism_array, DEVICE_ISM, $last_ids->ism_last_id + 1);
            }
            if (count($ipp_array) > 0) {
                $new_last_ipp_id = $this->pocaccount_model->add_batch($tid, $ipp_array, DEVICE_IPP, $last_ids->ipp_last_id + 1);
            }
            $this->tenant_model->
                update_last_ids(
                    $tid,
                    $new_last_hdy_id,
                    $new_last_spt_id,
                    $new_last_ism_id,
                    $new_last_ipp_id
                );
            $this->db->trans_complete();

            if ($this->db->trans_status() === false) {
                $error = true;
                $message = 'データベースエラーが発生しました。';
                log_message('error', 'Database Error!!');
            }
        }

        if (!$error) {
            $accounts =array_merge($hdy_array, $spt_array, $ism_array, $ipp_array);
            $data['accounts'] = $accounts;

			//
			// create hdy_config database record for PoC account templete here...
			//

            // csvダウンロード用にキャッシュする
            $cid = substr(str_shuffle(str_repeat($pw_str, 8)), 0, 8);
            $this->cache->save($cid, $accounts, 300);
            $data['cacheid'] = $cid;

            /* ISM設定ファイルの書き出し */
            if (count($ism_array) > 0) {
                foreach ($ism_array as $row) {
                    $pid = $row['poc_id'];
                    $account = $this->pocaccount_model->get($pid);
                    $conf = $this->pocaccount_model->get_ism_conf($pid);
                    if ($conf) {
                        $ism_data = $this->generate_ism_conf_data($account, $conf);
                        //$filename = sprintf('%03d%03d%03d%03d',
                        //					(($account->ip_address >> 24) & 0xff),
                        //					(($account->ip_address >> 16) & 0xff),
                        //					(($account->ip_address >>  8) & 0xff),
                        //					(($account->ip_address      ) & 0xff));
                        $ma = explode(':', strtoupper($account->mac_address));
                        $filename = sprintf(
                            '%s%s%s%s%s%s',
                            $ma[0],
                            $ma[1],
                            $ma[2],
                            $ma[3],
                            $ma[4],
                            $ma[5]
                        );
                        //if (!write_file('/var/lib/tftpboot/'.$filename, $ism_data, 'wt')) {
                        if (!write_file('/var/www/html/ism-101/config/'.$filename, $ism_data, 'wt')) {
                            $error = true;
                            $message = '車載機'.$account->username.'の設定ファイル更新に失敗しました。';
                            break;
                        }
                    }
                }
            }
        }

        if (!$error) {
            /* OpenFireにXMPPユーザー登録 */
            if (count($spt_array) > 0) {
                $client = new GuzzleHttp\Client;
                foreach ($spt_array as $row) {
                    try {
                        $response = $client->post(
                            'http://'.XMPP_SERVER_HOST.XMPP_API_PATH.'users',
                            ['auth' => [XMPP_ADMIN_USER, XMPP_ADMIN_PASS],
                                                   'json' => ['username' => $row['xmpp_username'],
                                                              'password' => $row['xmpp_password']],
                                                   'headers' => ['Accept' => 'application/json'],
                                                   ]
                        );
                    } catch (RequestException $e) {
                        $error = true;
                        $message = 'XMPPユーザーの登録に失敗しました。';
                        log_message('error', 'Registering XMPP user '.$row['xmpp_username'].' failed.');
                        log_message('error', 'RequestException: request='.$e->getRequest()
                                    .' response='.($e->hasResponse() ? $e->getResponse() : ''));
                        break;
                    }
                    if ($response->getStatusCode() != 201) {
                        $error = true;
                        $message = 'XMPPユーザーの登録に失敗しました。';
                        log_message('error', 'Registering XMPP user '.$row['xmpp_username'].' failed.');
                        log_message('error', 'RequestError: status='.$response->getStatusCode());
                        break;
                    }
                }
            }
            
            $this->load->view('pocaccount_add_result_view', $data);
        } else {
            $data['css'] = 'dummy.css';
            $data['menu'] = 'pocaccount';
            $data['success'] = false;
            $data['message'] = $message;
            $data['back'] = 'pocaccount/view_list/'.$tid;
            $this->load->view('message_view', $data);
        }
    }

    /**
     * IPアドレスファイルの入力チェック。
     *
     * @param string $str ファイル名。
     * @return boolean エラーの場合はFALSEを返す。
     */
    public function check_ipaddr_file($str)
    {
        if ($this->input->post('ism_num') > 0 && strlen($str) == 0) {
            $this->form_validation->set_message('check_ipaddr_file', 'ファイルが選択されていません。');
            return false;
        }
        return true;
    }

    /**
     * PoCアカウントの詳細情報を表示する。
     *
     * @param int $tid テナントID。
     * @param int $id 表示するアカウントのID。
     */
    public function view($tid = false, $id = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        // ユーザーモードでは異なるテナントの閲覧を禁止する。
        if ($session_data['usermode'] != 'admin' && $tid != $session_data['tenant']) {
            $this->permission_error($session_data);
            return;
        }

        // パラメータチェック
        $tenant = $this->tenant_model->get($tid);
        $account = $this->pocaccount_model->get($id);
        if (!$tenant || !$account) {
            $this->permission_error($session_data);
            return;
        }

        // prepare view data
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['tenant'] = $tenant;
        $data['devices'] = $this->device_model->get_all();
        $data['account'] = $account;
        if ($account->device_id == DEVICE_ISM) {
            $data['calls'] = $this->pocaccount_model->get_ism_call_display_name($id);
        }
        
        // load views
        $this->load->view('pocaccount_detail_view', $data);
    }

    /**
     * 新型ハンディ用PoCアカウントの詳細情報を表示する。
     *
     * @param int $tid テナントID。 (required)
     * @param int $id 表示する新型ハンディのアカウントのID。 (required)
     */
     public function handy_view($tid, $id)
     {
         $session_data = $this->session->userdata('logged_in');
         if (!$session_data) {
             //If no session, redirect to login page
             redirect('login', 'refresh');
             return;
         }
 
         // ユーザーモードでは異なるテナントの閲覧を禁止する。
         if ($session_data['usermode'] != 'admin' && $tid != $session_data['tenant']) {
             $this->permission_error($session_data);
             return;
         }
 
         // パラメータチェック
         $tenant = $this->tenant_model->get($tid);
         $account = $this->pocaccount_model->get($id);
         if (!$tenant || !$account) {
             $this->permission_error($session_data);
             return;
         }
 
         // 新型ハンディ機?
         if ($account->device_id != DEVICE_HDY) {
            log_message('debug', 'handy_view: this is not handy account. ID='.$id);
            $this->permission_error($session_data);
            return;
         }
         else {
            // POCアカウントから hdy_config_id を取得
            log_message('debug', 'handy_view: this is handy account. hdy_config_id='.$account->hdy_config_id);
        }

         // prepare view data
         $data['username'] = $session_data['username'];
         $data['usermode'] = $session_data['usermode'];

         // handydevice_model must be loded in constructor
        $data['hdy_config'] = $this->handydevice_model->get_device_config($tid, $account->hdy_config_id);
        $data['config_type'] = 'device';
        $data['tenant'] = $tenant;
        $data['account'] = $account;

        $this->load->view('handy_device_detail_view', $data);
     }

     /**
     * アカウントを削除する。
     *
     * @param int $tid テナントID。
     * @param int $id 削除するアカウントのID。
     */
    public function delete($tid = false, $id = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        if ($session_data['usermode'] != 'admin') {
            $this->permission_error($session_data);
            return;
        }

        // パラメータチェック
        $account = $this->pocaccount_model->get($id);
        if (!$account) {
            $this->permission_error($session_data);
            return;
        }

        $rslt = $this->do_delete($account);

        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['css'] = 'dummy.css';
        $data['menu'] = 'pocaccount';
        $data['success'] = $rslt;
        $data['back'] = 'pocaccount/view_list/'.$tid;
        $this->load->view('message_view', $data);
    }


    /**
     * アカウントを全削除する。
     *
     * @param int $tid テナントID。
     */
    public function delete_all($tid = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        if ($session_data['usermode'] != 'admin') {
            $this->permission_error($session_data);
            return;
        }

        // パラメータチェック
        $tenant = $this->tenant_model->get($tid);
        if (!$tenant) {
            $this->permission_error($session_data);
            return;
        }

        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];

        $accounts = $this->pocaccount_model->get_tenant($tid);
        if (!$accounts) {
            $data['css'] = 'dummy.css';
            $data['menu'] = 'pocaccount';
            $data['success'] = false;
            $data['message'] = 'アカウントがありません。';
            $data['back'] = 'pocaccount/view_list/'.$tid;
            $this->load->view('message_view', $data);
            return;
        }

        $error = false;
        $message = null;
        foreach ($accounts as $row) {
            if (!$this->do_delete($row)) {
                $error = true;
                $message = 'DBエラーが発生しました。';
                break;
            }
        }

        if (!$error) {
            // 全削除の場合はテナントのデバイスごと最終IDをリセットする
            $this->tenant_model->update_last_ids(
                $tid,
                0,  // hdy
                0,  // spt
                0,  // ism
                0  // ipp
            );        
        }

        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['css'] = 'dummy.css';
        $data['menu'] = 'pocaccount';
        $data['success'] = !$error;
        $data['message'] = $message;
        $data['back'] = 'pocaccount/view_list/'.$tid;
        $this->load->view('message_view', $data);
    }

    /**
     * アカウントを削除する。
     *
     * @param object $account PoCアカウント
     * @return boolean 成功の場合はTRUEを返す。
     */
    private function do_delete($account)
    {
        $error = false;

        if ($account->device_id == DEVICE_SPT) {
            // OpenFireからXMPPユーザーを削除
            // XMPPユーザー削除に失敗してもログに残すだけでエラーとはしない
            try {
                $client = new GuzzleHttp\Client;
                $str = $account->xmpp_username;
                $str = substr($str, 0, strpos($str, '@'));
                $response = $client->delete(
                    'http://'.XMPP_SERVER_HOST.XMPP_API_PATH.'users/'.$str,
                    ['auth' => [XMPP_ADMIN_USER, XMPP_ADMIN_PASS]
                                             ]
                );
                if ($response->getStatusCode() == 500) {
                    log_message('error', 'ERROR: Deleting XMPP user '.$account->xmpp_username.' failed.');
                    log_message('error', 'ERROR: User not exist??? status='.$response->getStatusCode());
                    //just log but ignore this error
                    //$error = true;
                }
                else if ($response->getStatusCode() == 403) {
                    log_message('error', 'ERROR: Deleting XMPP user '.$account->xmpp_username.' failed.');
                    log_message('error', 'ERROR: REST API not enabled??? status='.$response->getStatusCode());
                    //just log but ignore this error
                    //$error = true;
                }
                else if ($response->getStatusCode() != 200) {
                    log_message('error', 'ERROR: Deleting XMPP user '.$account->xmpp_username.' failed.');
                    log_message('error', 'ERROR: RequestError: status='.$response->getStatusCode());
                    $error = true;
                }
                // otherwise OK

            } catch (GuzzleHttp\Exception\RequestException $e) {
                log_message('error', 'ERROR: Deleting XMPP user '.$account->xmpp_username.' failed.');
                log_message('error', 'ERROR: RequestException: request='.$e->getRequest()
                            .' response='.($e->hasResponse() ? $e->getResponse() : ''));
                //$error = true;
            }
        }

        /* 新型ハンディ機用コンフィグIDを取得後、DB更新 */
        $config_ids = $this->pocaccount_model->get_config_ids($account->poc_id);
        if ($this->pocaccount_model->delete($account->poc_id)) {
            // POCアカウント削除成功
            // 新型ハンディ機用コンフィグが存在する場合、これも削除
            if (!empty($config_ids) && $config_ids->hdy_config_id) {
                $this->handydevice_model->delete_device_config(0, $config_ids->hdy_config_id);
            }
        }
        else {
            $error = true;
        }

        return !$error;
    }

    /**
     * PoCアカウントの編集画面を表示する。
     *
     * @param int $tid テナントID。
     * @param int $id 表示するアカウントのID。
     */
    public function edit($tid = false, $id = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        // ユーザーモードでは異なるテナントの閲覧を禁止する。
        if ($session_data['usermode'] != 'admin' && $tid != $session_data['tenant']) {
            $this->permission_error($session_data);
            return;
        }

        // パラメータチェック
        $tenant = $this->tenant_model->get($tid);
        $account = $this->pocaccount_model->get($id);
        if (!$tenant || !$account) {
            $this->permission_error($session_data);
            return;
        }

        // ISM-101の発信先リストを作成
        $accounts = $this->pocaccount_model->get_tenant($tid);
        foreach ($accounts as $row) {
            $data['name'] = $row->display_name;
            $data['sip_number'] = $row->sip_number;
            $contact_list[] = $data;
        }
        $groups = $this->group_model->get_tenant($tid);
        if ($groups) {
            foreach ($groups as $row) {
                $data['name'] = $row->group_name;
                $data['sip_number'] = $row->sip_number;
                $contact_list[] = $data;
            }
        }

        // prepare view data
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['tenant'] = $tenant;
        $data['devices'] = $this->device_model->get_all();
        $data['contacts'] = $contact_list;
        $data['account'] = $account;
        
        // load views
        $this->load->view('pocaccount_edit_view', $data);
    }

    /**
     * 独自フォームバリデーション : アカウント名(username)のチェック
     * 
     * @param int $username チェックするアカウント名。(全テナントで一意、最初が英字大文字または小文字)
     * 
     * @return int チェック結果 (true = OK)
     */
    public function username_check($username)
    {
        $top = substr($username, 0, 1);  // 先頭から1文字
        if (!ctype_alpha($top)) {

            $this->form_validation->set_message('username_check', '先頭が英字ではありません。');
            return false;

        }

        if (!$this->pocaccount_model->is_available_id($username)) {

            $this->form_validation->set_message('username_check', 'アカウント名が重複。');
            return false;

        }

        return true;    // チェックOK
    }

    /**
     * 独自フォームバリデーション : アカウント表示名の重複チェック
     * 
     * @param int $display_name チェックする表示名。(テナント内で一意)
     * @param int $tid テナントID。
     * 
     * @return int チェック結果 (true = OK)
     */
    public function display_check($display_name, $tid)
    {
        if (!$this->pocaccount_model->is_available_in_tenant($tid, $display_name)) {

            $this->form_validation->set_message('display_check', '表示名がテナント内の既存のアカウント名と重複');
            return false;

        }

        if (!$this->group_model->is_available_in_tenant($tid, $display_name)) {

            $this->form_validation->set_message('display_check', '表示名がテナント内の既存のグループ名と重複');
            return false;

        }

        return true;    // チェックOK
    }

    /**
     * 独自フォームバリデーション : SIP番号(sip_number)のチェック
     * 
     * @param int $sip_number チェックするSIP番号。(全テナントで一意)
     * 
     * @return int チェック結果 (true = OK)
     */
    public function sip_number_check($sip_number)
    {
        if (!$this->pocaccount_model->is_available_sip_number($sip_number)) {

            $this->form_validation->set_message('sip_number_check', 'SIP番号が重複。');
            return false;

        }

        return true;    // チェックOK
    }

    /**
     * アカウントを編集する。
     *
     * @param int $id 編集するアカウントのID。
     */
    public function edit_action($tid = false, $id = false)
    {
        $message = '';
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        // ユーザーモードでは異なるテナントの編集を禁止する。
        if ($session_data['usermode'] != 'admin' && $tid != $session_data['tenant']) {
            $this->permission_error($session_data);
            return;
        }

        // パラメータチェック
        $tenant = $this->tenant_model->get($tid);
        $account = $this->pocaccount_model->get($id);
        if (!$tenant || !$account) {
            $this->permission_error($session_data);
            return;
        }

        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('<div class="bg-danger">', '</div>');
        
        if ($this->input->post('username') != $account->username) {
            // ユーザー名が変更された場合
            $this->form_validation->set_rules('username', 'アカウント名', 'required|trim|alpha_numeric|min_length[4]|max_length[16]|callback_username_check');
        }

        if ($this->input->post('display_name') != $account->display_name) {
            // 表示名が変更された場合
            // 7文字以上50文字以下の文字列
            //$this->form_validation->set_rules('display_name', '表示名', 'required|trim|alpha_numeric|min_length[8]|max_length[128]|callback_display_check['.$tid.']');
            $this->form_validation->set_rules('display_name', '表示名', 'required|trim|min_length[7]|max_length[50]|callback_display_check['.$tid.']');
        }

		if (!empty($this->input->post('password'))) {
            // パスワードが入力された
			$this->form_validation->set_rules('password', 'パスワード', 'matches[confirm]');
			$this->form_validation->set_rules('confirm', 'パスワード', 'required');
        }
        
        if ($this->input->post('sip_number') != $account->sip_number) {
            // SIP番号が変更された場合
            $this->form_validation->set_rules('sip_number', 'SIP番号', 'required|trim|integer|exact_length[10]|callback_sip_number_check');
        }

        $this->form_validation->set_rules('device_id', '使用機種', 'required');
        $this->form_validation->set_rules('sip_port', 'SIPサーバーポート番号', 'is_natural_no_zero');
        $this->form_validation->set_rules('use_srtp', '音声データ暗号化', 'required');
        $this->form_validation->set_rules('status', '状態', 'required');
        if ($account->device_id == DEVICE_ISM) {
            $this->form_validation->set_rules('mac_address', 'MACアドレス', 'callback_check_mac_address');
            $this->form_validation->set_rules('call1', 'MODE1発信番号', 'integer');
            $this->form_validation->set_rules('call2', 'MODE2発信番号', 'integer');
            $this->form_validation->set_rules('call3', 'MODE3発信番号', 'integer');
            //$this->form_validation->set_rules('geomode', 'GPS測位モード', 'required');
            $this->form_validation->set_rules('newvoicemail', '不在伝言再生番号', 'integer');
            $this->form_validation->set_rules('novoicemail', 'ラストコール再生番号', 'integer');
        }
        if ($account->device_id == DEVICE_HDY) {
            $this->form_validation->set_rules('imei', 'IMEI', 'callback_check_imei');
        }

        $session_data = $this->session->userdata('logged_in');
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        
        if ($this->form_validation->run() === false) {
            $data['tenant'] = $this->tenant_model->get($tid);
            $data['devices'] = $this->device_model->get_all();
            $data['account'] = $this->pocaccount_model->get($id);
            $this->load->view('pocaccount_edit_view', $data);
            return;
        }

        /* DB更新 */
        $err = false;
        $rslt = $this->pocaccount_model->edit($id, $account->device_id);
        if (!$rslt) {
            $err = true;
            $message = 'データベースエラーが発生しました。';
            log_message('error', 'Database Error!!');
        }

        /* ISM設定ファイルを更新 */
        if (!$err && $account->device_id == DEVICE_ISM) {
            $conf = $this->pocaccount_model->get_ism_conf($id);
            if ($conf) {
                $ism_data = $this->generate_ism_conf_data($account, $conf);
                $ma = explode(':', strtoupper($this->input->post('mac_address')));
                $filename = sprintf(
                    '%s%s%s%s%s%s',
                    $ma[0],
                    $ma[1],
                    $ma[2],
                    $ma[3],
                    $ma[4],
                    $ma[5]
                );
                //if (!write_file('/var/lib/tftpboot/'.$filename, $ism_data, 'wt')) {
                if (!write_file('/var/www/html/ism-101/config/'.$filename, $ism_data, 'wt')) {
                    $err = true;
                    $message = '車載機'.$account->username.'の設定ファイル更新に失敗しました。';
                }
            }
        }

        $data['menu'] = 'pocaccount';
        $data['css'] = 'dummy.css';
        $data['success'] = $err ? false : true;
        if ($err) {
            $data['message'] = $message;
        }
        $data['back'] = 'pocaccount/view_list/'.$tid;
        $this->load->view('message_view', $data);
    }

    /**
     * 新型ハンディ用PoCアカウントの編集画面を表示する。
     *
     * @param int $tid テナントID。 (required)
     * @param int $id 表示する新型ハンディのアカウントのID。 (required)
     */
     public function handy_edit($tid, $id)
     {
         $session_data = $this->session->userdata('logged_in');
         if (!$session_data) {
             //If no session, redirect to login page
             redirect('login', 'refresh');
             return;
         }
 
         // ユーザーモードでは異なるテナントの閲覧を禁止する。
         if ($session_data['usermode'] != 'admin' && $tid != $session_data['tenant']) {
             $this->permission_error($session_data);
             return;
         }
 
         // パラメータチェック
         $tenant = $this->tenant_model->get($tid);
         $account = $this->pocaccount_model->get($id);
         if (!$tenant || !$account) {
             $this->permission_error($session_data);
             return;
         }
 
         // 新型ハンディ機?
         if ($account->device_id != DEVICE_HDY) {
            log_message('debug', 'handy_edit: this is not handy account. ID='.$id);
            $this->permission_error($session_data);
            return;
         }
         else {
            // POCアカウントから hdy_config_id を取得
            log_message('debug', 'handy_edit: this is handy account. hdy_config_id='.$account->hdy_config_id);
        }
         
          // prepare view data
         $data['username'] = $session_data['username'];
         $data['usermode'] = $session_data['usermode'];

        // handydevice_model must be loded in constructor
        $data['hdy_config'] = $this->handydevice_model->get_device_config($tid, $account->hdy_config_id);
        $data['config_type'] = 'device';
        $data['tenant'] = $tenant;
        $data['account'] = $account;
         
         // load edit views
         $this->load->view('handy_device_detail_edit', $data);
     }
 
     /**
      * 新型ハンディ用PoCアカウント別コンフィグデータを編集する。
      *
     * @param int $tid テナントID。 (required)
     * @param int $id 表示する新型ハンディのアカウントのID。 (required)
      */
     public function handy_edit_action($tid, $id)
     {
        $message = '';
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        // ユーザーモードでは異なるテナントの編集を禁止する。
        if ($session_data['usermode'] != 'admin' && $tid != $session_data['tenant']) {
            $this->permission_error($session_data);
            return;
        }

        // パラメータチェック
        $tenant = $this->tenant_model->get($tid);
        $account = $this->pocaccount_model->get($id);
        if (!$tenant || !$account) {
            $this->permission_error($session_data);
            return;
        }

        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('<div class="bg-danger">', '</div>');

        // PoCアカウント情報
        $this->form_validation->set_rules('disp_name', '表示名', 'max_length[128]');
        $this->form_validation->set_rules('sip_id', 'SIP番号', 'max_length[128]');
        $this->form_validation->set_rules('sip_password', 'SIPパスワード', 'max_length[128]');
        // 送信設定
        $this->form_validation->set_rules('vox_thresh', 'VOX動作レベル', 'greater_than_equal_to[1]|less_than_equal_to[7]');
        // 各種動作設定
        $this->form_validation->set_rules('speaker_fixed_vol', '固定音量レベル', 'greater_than_equal_to[0]|less_than_equal_to[32]');
        $this->form_validation->set_rules('speaker_max_vol', '最大音量レベル', 'greater_than_equal_to[0]|less_than_equal_to[32]');
        $this->form_validation->set_rules('speaker_min_vol', '最小音量レベル', 'greater_than_equal_to[0]|less_than_equal_to[32]');
        $this->form_validation->set_rules('sekkyaku_voice', '接客ボイス感度', 'greater_than_equal_to[1]|less_than_equal_to[7]');
        $this->form_validation->set_rules('sekkyaku_voice_timer', '接客ボイス保持', 'greater_than_equal_to[1]|less_than_equal_to[5]');
        // 緊急動作設定
        $this->form_validation->set_rules('emergency_alarm_duration', '緊急動作　警報音のみ', 'greater_than_equal_to[0]|less_than_equal_to[60]');
        $this->form_validation->set_rules('emergency_alarm_ptt_duration', '緊急動作　警報音+発報', 'greater_than_equal_to[0]|less_than_equal_to[60]');
        $this->form_validation->set_rules('emergency_silent_ptt_duration', '緊急動作　発報のみ', 'greater_than_equal_to[0]|less_than_equal_to[60]');
        $this->form_validation->set_rules('emergency_live_ptt_duration', '緊急動作　音声送信', 'greater_than_equal_to[0]|less_than_equal_to[60]');
        // 端末システム設定
        $this->form_validation->set_rules('display_lcd_contrast', 'コントラスト', 'greater_than_equal_to[1]|less_than_equal_to[10]');

        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        
        log_message('debug', 'Handy_device#edit_action() validation:');

        if ($this->form_validation->run() === false) {
            // 編集前のデータを再ロード
            $data['hdy_config'] = $this->handydevice_model->get_device_config($tid, $account->hdy_config_id);
            $data['config_type'] = 'device';
            $data['tenant'] = $tenant;
            $data['account'] = $account;
                
            // load edit views
            $this->load->view('handy_device_detail_edit', $data);
            return;
        }

        // POST内容とそのほかのデータを集める
        $record = array(

            // 管理用情報
            'update_date' => date('Y-m-d H:i:s'),
            'comment' => $this->input->post('comment'),

            // システム設定
            'clock' => $this->input->post('clock'),
            'pri_wifi' => $this->input->post('pri_wifi'),
            'voice_info' => $this->input->post('voice_info'),

            // POCアカウント情報
            'disp_name' => $this->input->post('disp_name'),
            'sip_id' => $this->input->post('sip_id'),
            'sip_password' => $this->input->post('sip_password'),

            // 受信通知設定
            'speaker_lte_vib' => $this->input->post('speaker_lte_vib'),
            'speaker_pri_wifi_vib' => $this->input->post('speaker_pri_wifi_vib'),
            'speaker_lte_data' => $this->input->post('speaker_lte_data'),
            'speaker_pri_wifi_data' => $this->input->post('speaker_pri_wifi_data'),

            // マイク設定
            'audio_mic_type' => $this->input->post('audio_mic_type'),

            // 送信設定
            'audio_intnl_mic_gain' => $this->input->post('audio_intnl_mic_gain'),
            'audio_extnl_mic_gain' => $this->input->post('audio_extnl_mic_gain'),
            'audio_emergency_mic_gain' => $this->input->post('audio_emergency_mic_gain'),
            'key_ptt_hold' => $this->input->post('key_ptt_hold'),
            'audio_earphone_callback' => $this->input->post('audio_earphone_callback'),
            'vox' => $this->input->post('vox'),
            'vox_thresh' => $this->input->post('vox_thresh'),
            'audio_noise_can' => $this->input->post('audio_noise_can'),
            'audio_echo_can' => $this->input->post('audio_echo_can'),
            'time_out_timer' => $this->input->post('time_out_timer'),
            'ptt_call' => $this->input->post('ptt_call'),
            'ptt_group' => $this->input->post('ptt_group'),
            'ptt_conference' => $this->input->post('ptt_conference'),
            'ptt_individual' => $this->input->post('ptt_individual'),
            'direct_call' => $this->input->post('direct_call'),
            'direct_group' => $this->input->post('direct_group'),
            'direct_individual' => $this->input->post('direct_individual'),
            'tx_block' => $this->input->post('tx_block'),
            'ind_callback_timer' => $this->input->post('ind_callback_timer'),
            'group_callback_timer' => $this->input->post('group_callback_timer'),
            'all_callback_timer' => $this->input->post('all_callback_timer'),
            
            // 受信設定
            'audio_alc' => $this->input->post('audio_alc'),
            'audio_bass_reduce' => $this->input->post('audio_bass_reduce'),
            'audio_treble_reduce' => $this->input->post('audio_treble_reduce'),
            'record_mode' => $this->input->post('record_mode'),
            'message_block' => $this->input->post('message_block'),

            // 通知/警告設定
            'speaker_beep_vol' => $this->input->post('speaker_beep_vol'),
            'alarm_bell' => $this->input->post('alarm_bell'),
            'bell_mode' => $this->input->post('bell_mode'),
            'voice_guide' => $this->input->post('voice_guide'),
            'voice_guide_vol' => $this->input->post('voice_guide_vol'),
            'alarm_low_battery' => $this->input->post('alarm_low_battery'),
            'alarm_earphone_broken' => $this->input->post('alarm_earphone_broken'),
            'alarm_ind_call_ok' => $this->input->post('alarm_ind_call_ok'),
            'alarm_ind_call_ng' => $this->input->post('alarm_ind_call_ng'),
            'audio_ptt_beep' => $this->input->post('audio_ptt_beep'),
            'audio_end_beep' => $this->input->post('audio_end_beep'),
            'alarm_connect' => $this->input->post('alarm_connect'),
            'alarm_stop_callback' => $this->input->post('alarm_stop_callback'),

            // 各種動作設定
            'shortcut_key' => $this->input->post('shortcut_key'),
            'speaker_extnl_vol' => $this->input->post('speaker_extnl_vol'),
            'speaker_vol_mode' => $this->input->post('speaker_vol_mode'),
            'speaker_fixed_vol' => $this->input->post('speaker_fixed_vol'),
            'speaker_max_vol' => $this->input->post('speaker_max_vol'),
            'speaker_min_vol' => $this->input->post('speaker_min_vol'),
            'earphone_sekkyaku_mode' => $this->input->post('earphone_sekkyaku_mode'),
            'sekkyaku_voice' => $this->input->post('sekkyaku_voice'),
            'sekkyaku_touch' => $this->input->post('sekkyaku_touch'),
            'sekkyaku_release_timer' => $this->input->post('sekkyaku_release_timer'),
            'sekkyaku_voice_timer' => $this->input->post('sekkyaku_voice_timer'),
            
            //緊急動作設定
            'emergency_receive' => $this->input->post('emergency_receive'),
            'emergency_alarm_duration' => $this->input->post('emergency_alarm_duration'),
            'emergency_alarm_ptt_duration' => $this->input->post('emergency_alarm_ptt_duration'),
            'emergency_silent_ptt_duration' => $this->input->post('emergency_silent_ptt_duration'),
            'emergency_live_ptt_duration' => $this->input->post('emergency_live_ptt_duration'),
            'emergency_intnl_vol' => $this->input->post('emergency_intnl_vol'),
            'emergency_extnl_vol' => $this->input->post('emergency_extnl_vol'),
            'kinkyu_sokuho' => $this->input->post('kinkyu_sokuho'),

            //端末システム設定
            'backlight_timer' => $this->input->post('backlight_timer'),
            'display_lcd_contrast' => $this->input->post('display_lcd_contrast'),
            'battery_save' => $this->input->post('battery_save'),
            'power_off_timer' => $this->input->post('power_off_timer'),
            'audio_codec' => $this->input->post('audio_codec'),
            'set_mode' => $this->input->post('set_mode'),
            'reset_disable' => $this->input->post('reset_disable')
            
        );            

        //log_message('debug', 'Handy_device#edit_action() write:');
         
        // 設定を保存
        $rslt = $this->handydevice_model->edit_device_config($tid, $account->hdy_config_id, $record);
        $message = null;
        if (!$rslt) {
            $message = 'データベースエラーが発生しました。';
        }
            
        $data['menu'] = 'pocaccount';
        $data['css'] = 'dummy.css';
        $data['success'] = $rslt;
        $data['back'] = 'pocaccount/handy_view/'.$tid.'/'.$id;
        $data['message'] = $message;
        
        $this->load->view('message_view', $data);
    }

     /**
     * 正しいMACアドレスかチェックする。
     * xx:xx:xx:xx:xx:xx
     * xx はそれぞれ16進数2桁
     * 
     * このコードは load->library('form_validation') を行っていない場合にも呼び出されることに注意
     */
    public function check_mac_address($str)
    {
        if (!$str || strlen($str) != 17) {
            if (isset($this->form_validation)) {
                $this->form_validation->set_message('check_mac_address', '不正なMACアドレス');
            }
            return false;
        }

        $ma = explode(':', $str);
        if (!$ma || count($ma) != 6) {
            if (isset($this->form_validation)) {
                $this->form_validation->set_message('check_mac_address', '不正なMACアドレス');
            }
            return false;
        }

        foreach ($ma as $hex) {
            if (strlen($hex) != 2 || !ctype_xdigit($hex)) {
                    if (isset($this->form_validation)) {
                        $this->form_validation->set_message('check_mac_address', '不正なMACアドレス');
                    }
                    return false;
            }
        }

        return true;
    }

     /**
     * 正しいIMEIかチェックする。
     * 
     * このコードは load->library('form_validation') を行っていない場合にも呼び出されることに注意
     */
    public function check_imei($str)
    {
        if (!empty($str) && (strlen($str) != 14 && strlen($str) != 15)) {
            if (isset($this->form_validation)) {
                $this->form_validation->set_message('check_imei', '不正なIMEI');
            }
            return false;
        }

        if (!preg_match("/^[0-9]*$/", $str)) {
            if (isset($this->form_validation)) {
                $this->form_validation->set_message('check_imei', '不正なIMEI');
            }
            return false;
        }

        return true;
    }

    /**
     * 新規に作成されたアカウントのCSVファイルをダウンロードする。
     *
     * データがキャッシュに残されていない場合はエラーとなる。
     * apacheユーザーが application/cache フォルダに読み書き可能になっていること
     *
     * @param int $tid テナントID。
     * @param string $cacheid キャッシュID。
     */
    public function download_csv($tid = false, $cacheid = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        if ($session_data['usermode'] != 'admin') {
            $this->permission_error($session_data);
            return;
        }

        $this->load->helper('download');
        $accounts = $this->cache->get($cacheid);

        if ($accounts != null) {
            $fp = fopen('php://temp', 'r+b');
            $header = array('#username', 'password', 'device_name', 'sip_number', 'sip_password');
            fputcsv($fp, $header);
            foreach ($accounts as $row) {
                // 必要なフィールドのみ抜き出す
                $device = $this->device_model->get($row['device']);
                $temp = array($row['username'], $row['password'], $device->device_name, $row['sip_number'], $row['sip_password']);
                fputcsv($fp, $temp, ',', '"');
            }
            rewind($fp);
            $data = str_replace(PHP_EOL, "\r\n", stream_get_contents($fp));
            fclose($fp);
            
            force_download('accounts.csv', mb_convert_encoding($data, 'SJIS-win', 'UTF-8'));
        } 
        else {
            $data['username'] = $session_data['username'];
            $data['usermode'] = $session_data['usermode'];
            $data['css'] = 'dummy.css';
            $data['menu'] = 'pocaccount';
            $data['success'] = false;
            $data['message'] = '時間切れです。';
            $data['back'] = 'pocaccount/view_list/'.$tid;
            $this->load->view('message_view', $data);
        }
    }

    /**
     * 新規に作成されたアカウントのsip.confデータをダウンロードする。
     *
     * データがキャッシュに残されていない場合はエラーとなる。
     * 
     * 注: この関数は実際には使用されない(デバッグ用)
     *
     * @param int $tid テナントID。
     * @param string $cacheid キャッシュID。
     */
    public function download_sipconf($tid = false, $cacheid = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        if ($session_data['usermode'] != 'admin') {
            $this->permission_error($session_data);
            return;
        }

        $this->load->helper('download');
        $accounts = $this->cache->get($cacheid);

        if ($accounts != null) {
            $data = ";%POCCONF_CREATED_DATA_START%\n\n";
            foreach ($accounts as $row) {
                $data .= "; ".$row['username']."\r\n"
                    . "[".$row['sip_number']."]";
                if ($row['device'] == DEVICE_SPT) {
                    $data .= "(spt)\n";
                } elseif ($row['device'] == DEVICE_ISM) {
                    $data .= "(car)\n";
                } else {
                    $data .= "(ipp)\n";
                }
                $data .= "username=".$row['sip_number']."\n"
                    . "secret=".$row['sip_password']."\n"
                    . "mailbox=".$row['sip_number']."\n\n";
            }
            $data .= ";%POCCONF_CREATED_DATA_END%\n";
            
            force_download('sip.conf', $data);
        } else {
            $data['username'] = $session_data['username'];
            $data['usermode'] = $session_data['usermode'];
            $data['css'] = 'dummy.css';
            $data['menu'] = 'pocaccount';
            $data['success'] = false;
            $data['message'] = '時間切れです。';
            $data['back'] = 'pocaccount/view_list/'.$tid;
            $this->load->view('message_view', $data);
        }
    }

    /**
     * SIPサーバーにSIPアカウントとConfBridge電話番号を登録する。
     *
     * データベースに登録されている内容で /etc/asterisk/sip.conf と /etc/asterisk/extensions.conf を書き換える。
     * Asteriskにsip.confとextensions.confを再ロードさせる。
     * 
     * @param int $is_group : グループから呼ばれたかどうか
     */
    public function update_sipconf($is_group = 0)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        if ($session_data['usermode'] != 'admin') {
            $this->permission_error($session_data);
            return;
        }

        $err = false;
        $message = '';

        /* sip.confデータを作成 */
        /* アカウントが一つも存在しない場合、$sip_accounts は falseになる */
        $sip_accounts = $this->pocaccount_model->get_all();
        $sip_conf_data = $this->generate_sip_conf_data($sip_accounts);

        /* ConfBridge用データを作成 */
        /* グループが一つも存在しない場合、$all_groups は falseになる */
        $all_groups = $this->group_model->get_all();
        $conf_bridge_data = $this->generate_conf_bridge_data($all_groups);

        /* ファイルへの書き出し */
        if (!write_file('/mnt/pocdata/pocconf/sip.conf', $sip_conf_data, 'wt')) {
            $err = true;
            $message = 'sip.confの更新に失敗しました。サーバーの設定を確認ししてください。';
        }
        else if (!write_file('/mnt/pocdata/pocconf/confbridge_numbers', $conf_bridge_data, 'wt')) {
            $err = true;
            $message = 'confbridge_numbersの更新に失敗しました。サーバーの設定を確認ししてください。';
        }        
        else {
            /* SIPサーバーにsip.confの更新を依頼する */
            //$connection = ssh2_connect(DEFAULT_SIP_SERVER_DOMAIN, 22);
            //ssh2_auth_password($connection, 'iforce', 'Fi8-gnz.kk2012');
            //$stream = ssh2_exec($connection, '/home/iforce/bin/update_sipconf.sh');
            //if ($stream === false) {
            //    $err = true;
            //    $message = 'SIPサーバーの更新に失敗しました。サーバーの設定を確認してください';
            //} else {
            //    $message = 'sip.confを更新しました。';
            //}
            system('/var/www/html/pocconsole/bin/update_sipconf.sh', $retval);
            log_message('debug', 'retval='.$retval);
            if ($retval === false) {
                $err = true;
                $message = 'SIPサーバーの更新に失敗しました。サーバーの設定を確認してください';
            } else {
                $message = 'sip.confを更新しました。';
            }
        }

        /* 結果通知画面 */
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['css'] = 'dashboard.css';
        if ($is_group) {
            // this is from group_select_view.php
            $data['menu'] = 'group';
            $data['back'] = 'group/view_list/';
        }
        else {
            // this is from pocaccount_select_view.php
            $data['menu'] = 'pocaccount';
            $data['back'] = 'pocaccount/view_list/';
        }
        $data['success'] = !$err;
        $data['message'] = $message;
        $this->load->view('message_view', $data);
    }

    /**
     * テナント内アカウントを全削除後、CSVファイルからアカウントをインポートする。
     *
     * @param int $tid テナントID。(0は不可)
     */
    public function import($tid = false)
    {
        global $global_account_status_names;    // 無効=0 または 有効=1
        
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        // テナントアカウントでは不可
        //if ($session_data['usermode'] != 'admin' && $tid != $session_data['tenant']) {
        if ($session_data['usermode'] != 'admin') {
            $this->permission_error($session_data);
            return;
        }

        // テナントアカウントチェック(tid == 0 はここではじかれる)
        $tenant = $this->tenant_model->get($tid);
        if (!$tenant) {
            $this->permission_error($session_data);
            return;
        }

        // アカウント配列初期化
        $err = false;
        $message = '';
        $hdy_array = [];
        $spt_array = [];
        $ism_array = [];
        $ipp_array = [];        
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        
        // CSVファイル読み込み
        $config['upload_path'] = './uploads/';
        $config['allowed_types'] = 'csv';
        $config['max_size'] = 1024 * 10;
        $this->load->library('upload', $config);
        if (!$this->upload->do_upload('import_file')) {
            // "/var/www/html/pocconsole/uploads" フォルダが存在しない?
            $err = true;
            $message = 'csvファイルの読み込みに失敗しました。';
        } else {
            $filepath = $this->upload->data('full_path');
            $file = new SplFileObject($filepath);
            $file->setFlags(SplFileObject::READ_CSV);
            $count = 0;
            $line_num = 1;
            $username_list = array();
            $display_name_list = array();
            $macaddress_list = array();
            $imei_list = array();

            foreach ($file as $line) {
                // 'line' is array so check first array element != null
                if (!empty($line[1])) {
                    $account = array();
                    $str = strtolower($line[0]);
                    // # で始まる行はコメント
                    if (strpos($str, '#') === 0) {
                        $line_num++;
                        continue;
                    }

                    // we have 8 items in one row - last is 6
                    if (empty($line[8])) {
                        // 9 つのアイテムがそろっていないか、9つめが空文字列(有効または無効が必要)
                        $err = true;
                        $message = 'CSVファイルの'.$line_num.'行目にエラーがあります。(項目数が足りない)';
                        break;
                    }

                    // 「アカウント名」「表示名」「使用機種」「SIP番号」「IMEI」「状態」
                    $username = $line[1];
                    // 英数文字?
                    if (empty($username) || !preg_match("/^[a-zA-Z0-9]+$/", $username)) {
                        $err = true;
                        $message = 'CSVファイルの'.$line_num.'行目にエラーがあります。(無効なアカウント名)';
                        break;
                    }
                    // アカウント名の重複をチェック
                    // 現在のテナントに同じIDがあっても(このあと削除するので)気にしない
                    if (!$this->pocaccount_model->is_available_id($username, $tid)) {
                        $err = true;
                        $message = 'アカウントID"'.$username.'"がすでに存在します。';
                        break;
                    }

                    // すでに読み込んだCSV内のアカウント名との重複チェック
                    if (in_array($username, $username_list, TRUE)) {
                        $err = true;
                        $message = 'CSVファイルの'.$line_num.'行目にエラーがあります。(CSV内の他のアカウント名と重複)';
                        break;
                    }

                    array_push($username_list, $username);   // add array element
                    $account['username'] = $username;

                    $password = $line[2];
                    $account['password'] = $password;
        
                    // 表示名は7文字以上50文字以下の文字列
                    $display_name = mb_convert_encoding($line[3], 'UTF-8', 'SJIS');
                    //$length = strlen($display_name);  // return number of bytes
                    //if (empty($display_name) || !preg_match("/^[a-zA-Z0-9]+$/", $display_name) || $length < 8 || 128 < $length) {
                    //    $err = true;
                    //    $message = 'CSVファイルの'.$line_num.'行目にエラーがあります。(無効な表示名)';
                    //    break;
                    //}
                    $length = mb_strlen($display_name);  // return number of characters counted by internal encoding (UTF-8)
                    if (empty($display_name)) {
                        // 表示名が空ならアカウント名とする
                        $account['display_name'] = $account['username'];
                    } else {
                        if ($length < 7 || 50 < $length) {
                            $err = true;
                            $message = 'CSVファイルの'.$line_num.'行目にエラーがあります。(無効な表示名)';
                            break;
                        }

                        if (!$this->group_model->is_available_in_tenant($tid, $display_name)) {
                            $err = true;
                            $message = 'CSVファイルの'.$line_num.'行目にエラーがあります。(表示名が既存のグループ名と重複)';
                            break;
                        }

                        // すでに読み込んだCSV内の表示名との重複チェック
                        if (in_array($display_name, $display_name_list, TRUE)) {
                            $err = true;
                            $message = 'CSVファイルの'.$line_num.'行目にエラーがあります。(CSV内の他の表示名と重複)';
                            break;
                        }

                        $account['display_name'] = $display_name;
                        array_push($display_name_list, $display_name);   // add array element
                    }
                                        
                    // 使用機種をチェック
                    if (!empty($line[4])) {
                        $device_name = mb_convert_encoding($line[4], 'UTF-8', 'SJIS');
                        $device_row = $this->device_model->get_device($device_name);    // データベース中のdevice行
                        if (empty($device_row)) {
                            // 有効なデバイス名ではない (エンコーディングエラーも含む)
                            $err = true;
                            $message = 'CSVファイルの'.$line_num.'行目にエラーがあります。(無効な使用機種)';
                            break;                            
                        }
                        // otherwise valid device
                        $account['device'] = $device_row->device_id;
                    }
                    else {
                        // 有効なデバイス名ではない (エンコーディングエラーも含む)
                        $err = true;
                        $message = 'CSVファイルの'.$line_num.'行目にエラーがあります。(無効な使用機種)';
                        break;
                    }
                    
                    // SIP番号は利用せず id == 1 から再度割り当てる
                    // SIP番号をチェック
                    // $sip_number = $line[4];
                    // if (empty($sip_number) || !preg_match("/^[0-9]+$/", $sip_number)) {
                    //     $err = true;
                    //     $message = 'CSVファイルの'.$line_num.'行目にエラーがあります。(無効なSIP番号)';
                    //     break;
                    // }
                    // // SIP番号の重複をチェック
                    // if (!$this->pocaccount_model->is_available_sip_number($sip_number)) {
                    //     $err = true;
                    //     $message = 'SIP番号"'.$sip_number.'"がすでに存在します。';
                    //     break;
                    // }
                    // $account['sip_number'] = $sip_number;
                    
                    // IMEIを取得
                    $account['imei'] = '';  // とりあえず空文字列をセット
                    $imei = trim($line[6]);
                    if (empty($imei)) { $imei = ''; }

                    // 有効/無効
                    $status = '0';
                    if (!empty($line[8])) {
                        $status_name = mb_convert_encoding($line[8], 'UTF-8', 'SJIS');
                        if (in_array($status_name, $global_account_status_names, TRUE)) { 
                            // valid parameter
                            $status = array_search($status_name, $global_account_status_names, TRUE);   // 0 or 1
                        }
                        else {
                            // '無効' or '有効’ ではない (エンコーディングエラーも含む)
                            $err = true;
                            $message = 'CSVファイルの'.$line_num.'行目にエラーがあります。(有効/無効以外が指定されました)';
                            break;
                        }
                    }
                    else {
                        // '無効' or '有効’ のフィールドがない
                        $err = true;
                        $message = 'CSVファイルの'.$line_num.'行目にエラーがあります。(有効/無効の指定がありません)';
                        break;
                    }
                    $account['status'] = $status;   // 0 or 1

                    // その他のデフォルト値を設定(もしあれば)
                    
                    // デバイス別処理
                    if ($account['device'] == DEVICE_HDY) {
                        // 有効なIMEIかチェック
                        // 'form_validation' を load していないことに注意
                        if (!$this->check_imei($imei)) {
                            $err = true;
                            $message = 'CSVファイルの'.$line_num.'行目にエラーがあります。(有効なIMEI指定ではありません)';
                            break;
                        }
                        // 重複するIMEIがあるかチェック
                        // 現在のテナントに同じmacアドレスがあっても(このあと削除するので)気にしない
                        if (!empty($imei) && !$this->pocaccount_model->is_available_imei($imei, $tid)) {
                            $err = true;
                            $message = 'CSVファイルの'.$line_num.'行目にエラーがあります。(IMEI '.$imei.' が重複しています)';
                            break;
                        }
                        // すでに読み込んだCSV内のmacアドレスとの重複チェック
                        if (!empty($imei) && in_array($imei, $imei_list, TRUE)) {
                            $err = true;
                            $message = 'CSVファイルの'.$line_num.'行目にエラーがあります。(IMEI '.$imei.' がCSV内の他のIMEIと重複)';
                            break;
                        }

                        // 有効なIMEI 
                        array_push($imei_list, $imei);   // add array element
                        $account['imei'] = $imei;
                        $hdy_array[] = $account;
                    }
                    else if ($account['device'] == DEVICE_SPT) {
                        $spt_array[] = $account;
                    }
                    else if ($account['device'] == DEVICE_ISM) {
                        // ISMは mac_addrが必要
                        if (empty($mac_address)) {
                            $err = true;
                            $message = 'CSVファイルの'.$line_num.'行目にエラーがあります。(ISMは macアドレス指定が必要です)';
                            break;
                        }
                        // 有効なmacアドレスかチェック
                        // 'form_validation' を load していないことに注意
                        if (!$this->check_mac_address($mac_address)) {
                            $err = true;
                            $message = 'CSVファイルの'.$line_num.'行目にエラーがあります。(有効なmacアドレス指定ではありません)';
                            break;
                        }
                        // 重複するmacアドレスがあるかチェック
                        // 現在のテナントに同じmacアドレスがあっても(このあと削除するので)気にしない
                        if (!$this->pocaccount_model->is_available_macaddr($mac_address, $tid)) {
                            $err = true;
                            $message = 'CSVファイルの'.$line_num.'行目にエラーがあります。(MACアドレス'.$mac_address.'が重複しています)';
                            break;
                        }
                        // すでに読み込んだCSV内のmacアドレスとの重複チェック
                        if (in_array($mac_address, $macaddress_list, TRUE)) {
                            $err = true;
                            $message = 'CSVファイルの'.$line_num.'行目にエラーがあります。(MACアドレス'.$mac_address.'がCSV内の他のMACアドレスと重複)';
                            break;
                        }

                        // 有効な macアドレス
                        array_push($macaddress_list, $mac_address);   // add array element
                        $account['mac_address'] = $mac_address;
                        $ism_array[] = $account;
                    }
                    else if ($account['device'] == DEVICE_IPP) {
                        $ipp_array[] = $account;
                    }
                }
                $line_num++;
            }

            // アカウント数上限のチェック
            if (!$err && count($hdy_array) > 999) {
                $err = true;
                $message = '作成できるアカウント数を超えています(DJCP100)';
            }
            if (!$err && count($spt_array) > 999) {
                $err = true;
                $message = '作成できるアカウント数を超えています(Air-InCom.)';
            }
            if (!$err && count($ism_array) > 999) {
                $err = true;
                $message = '作成できるアカウント数を超えています。';
            }
            if (!$err && count($ipp_array) > 999) {
                $err = true;
                $message = '作成できるアカウント数を超えています(IPフォン)';
            }
        }

        //
        // インポートチェック終了
        //

        // 1件も読み込まなかったときはエラーとする
        if (!$err && empty($hdy_array) && empty($spt_array) && empty($ism_array)) {
            $err = true;
            $message = 'インポート可能なデータがありません。';
        }

        if (!$err) {
            $accounts = $this->pocaccount_model->get_tenant($tid);
            if ($accounts) {
                // 既存のPOCアカウントが一つ以上存在
                // テナント内POCアカウント全削除
                // 忘れずにそれぞれの機種の last_id を更新すること
                foreach ($accounts as $row) {
                    if (!$this->do_delete($row)) {
                        $err = true;
                        $message = 'DBエラーが発生しました。';
                        break;
                    }
                }
            }
        }

        if (!$err) {
            // テナント内アカウント追加
            // POCアカウントを全削除しているため、どの機種も ID == 1 から始まる
            $this->db->trans_start();
            if (count($hdy_array) > 0) {
                $this->pocaccount_model->add_batch($tid, $hdy_array, DEVICE_HDY, 1);
            }
            if (count($spt_array) > 0) {
                $this->pocaccount_model->add_batch($tid, $spt_array, DEVICE_SPT, 1);
            }
            if (count($ism_array) > 0) {
                $this->pocaccount_model->add_batch($tid, $ism_array, DEVICE_ISM, 1);
            }
            if (count($ipp_array) > 0) {
                $this->pocaccount_model->add_batch($tid, $ipp_array, DEVICE_IPP, 1);
            }

            // 最終IDはそれぞれのアカウント数になる
            $this->tenant_model->
                update_last_ids(
                    $tid,
                    count($hdy_array),
                    count($spt_array),
                    count($ism_array),
                    count($ipp_array)
                );
            $this->db->trans_complete();

            if ($this->db->trans_status() === false) {
                $err = true;
                $message = 'データベースエラーが発生しました。';
                log_message('error', 'Database Error!!');
            }
        }

        if (!$err) {
            $pw_str = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
            $accounts =array_merge($hdy_array, $spt_array, $ism_array, $ipp_array);
            $data['accounts'] = $accounts;

            // csvダウンロード用にキャッシュする
            $cid = substr(str_shuffle(str_repeat($pw_str, 8)), 0, 8);
            $this->cache->save($cid, $accounts, 300);
            $data['cacheid'] = $cid;

            /* ISM設定ファイルの書き出し */
            if (count($ism_array) > 0) {
                foreach ($ism_array as $row) {
                    $pid = $row['poc_id'];
                    $account = $this->pocaccount_model->get($pid);
                    $conf = $this->pocaccount_model->get_ism_conf($pid);
                    if ($conf) {
                        $ism_data = $this->generate_ism_conf_data($account, $conf);
                        //$filename = sprintf('%03d%03d%03d%03d',
                        //					(($account->ip_address >> 24) & 0xff),
                        //					(($account->ip_address >> 16) & 0xff),
                        //					(($account->ip_address >>  8) & 0xff),
                        //					(($account->ip_address      ) & 0xff));
                        $ma = explode(':', strtoupper($account->mac_address));
                        $filename = sprintf(
                            '%s%s%s%s%s%s',
                            $ma[0],
                            $ma[1],
                            $ma[2],
                            $ma[3],
                            $ma[4],
                            $ma[5]
                        );
                        //if (!write_file('/var/lib/tftpboot/'.$filename, $ism_data, 'wt')) {
                        if (!write_file('/var/www/html/ism-101/config/'.$filename, $ism_data, 'wt')) {
                            $err = true;
                            $message = '車載機'.$account->username.'の設定ファイル更新に失敗しました。';
                            break;
                        }
                    }
                }
            }
        }

        if (!$err) {
            /* OpenFireにXMPPユーザー登録 */
            if (count($spt_array) > 0) {
                $client = new GuzzleHttp\Client;
                foreach ($spt_array as $row) {
                    try {
                        $response = $client->post(
                            'http://'.XMPP_SERVER_HOST.XMPP_API_PATH.'users',
                            ['auth' => [XMPP_ADMIN_USER, XMPP_ADMIN_PASS],
                                                   'json' => ['username' => $row['xmpp_username'],
                                                              'password' => $row['xmpp_password']],
                                                   'headers' => ['Accept' => 'application/json'],
                                                   ]
                        );
                    } catch (RequestException $e) {
                        $err = true;
                        $message = 'XMPPユーザーの登録に失敗しました。';
                        log_message('error', 'Registering XMPP user '.$row['xmpp_username'].' failed.');
                        log_message('error', 'RequestException: request='.$e->getRequest()
                                    .' response='.($e->hasResponse() ? $e->getResponse() : ''));
                        break;
                    }
                    if ($response->getStatusCode() != 201) {
                        $err = true;
                        $message = 'XMPPユーザーの登録に失敗しました。';
                        log_message('error', 'Registering XMPP user '.$row['xmpp_username'].' failed.');
                        log_message('error', 'RequestError: status='.$response->getStatusCode());
                        break;
                    }
                }
            }
        }

        if (!$err) {
            //$this->load->view('pocaccount_add_result_view', $data);
            $message = 'CSVインポート成功しました。[SIP更新]を行ってください。';
        }
            
        /* 結果通知画面 */
        //$data['username'] = $session_data['username'];
        //$data['usermode'] = $session_data['usermode'];
        $data['css'] = 'dashboard.css';
        $data['menu'] = 'pocaccount';
        $data['success'] = !$err;
        $data['message'] = $message;
        $data['back'] = $err ? 'pocaccount/view_list/'.$tid : 'pocaccount/view_list/0#update_sip';
        $this->load->view('message_view', $data);
    }

    /**
     * アカウントデータをCSVファイルにエクスポートする。
     *
     * @param int $tid テナントID。
     */
    public function export($tid = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        if ($session_data['usermode'] != 'admin' && $tid != $session_data['tenant']) {
            $this->permission_error($session_data);
            return;
        }

        // パラメータチェック
        $accounts = $this->pocaccount_model->get_tenant($tid, 'poc_id', 'asc');
        if (!$accounts) {
            $this->permission_error($session_data);
            return;
        }
        
        $this->load->helper('download');
        $fp = fopen('php://temp', 'r+b');
        $header = array('#ID', 'アカウント名', 'パスワード', '表示名', '使用機種', 'SIP番号', 'IMEI','アプリバージョン','状態');
        fputcsv($fp, $header);
        foreach ($accounts as $row) {
            $array = [];
            $array['poc_id'] = $row->poc_id;
            $array['username'] = $row->username;
            $array['password'] = openssl_decrypt($row->enc_password, 'AES-128-ECB', $this->enc_key);
            $array['display_name'] = $row->display_name;
            $array['device_name'] = $row->device_name;
            $array['sip_number'] = $row->sip_number;
            $array['imei'] = !$row->imei ? '' : $row->imei;
            $array['app_version'] = !$row->app_version ? '' : $row->app_version;
            $array['status'] = $row->status ? '有効' : '無効';
            fputcsv($fp, $array, ',', '"');
        }
        rewind($fp);
        $data = str_replace(PHP_EOL, "\r\n", stream_get_contents($fp));
        fclose($fp);
        
        force_download('pocaccounts.csv', mb_convert_encoding($data, 'SJIS-win', 'UTF-8'));
    }

    /**
     * sip.confに書き出すデータを生成する。
     *
     * @param array &$accounts アカウントデータの配列への参照。
     * @retrun string sip.confデータ。
     */
    private function generate_sip_conf_data(&$sip_accounts)
    {
        $write_data = "; This file is generated by PoC Config system. !!! DO NOT EDIT manually !!!\n"
            . "; Generated data: " . date('Y-m-d H:i:s') . "\n\n";

        $template_name = SIP_CONF_TEMPLATE; // defined in config/my_defines.php

        $write_data .= constant($template_name);    // return constant value of name specified.
        $write_data .= sip_conf_template_common;
        
        if ($sip_accounts) {
            // 1つ以上POCアカウントが存在

            foreach ($sip_accounts as $row) {

                if ($row->status != 0 && !empty($row->sip_number)) {
                    $write_data .= "; ".$row->username."\n"
                        ."[".$row->sip_number."]";
                    if ($row->device_id == DEVICE_SPT) {
                        $write_data .= "(dev_spt)\n";
                    } elseif ($row->device_id == DEVICE_ISM) {
                        $write_data .= "(dev_ism)\n";
                    } else {
                        // IP Phone and NEW Handy
                        $write_data .= "(dev_ipp)\n";
                    }
                    $write_data .= "username=".$row->sip_number."\n"
                        . "secret=".$row->sip_password."\n"
                        . "mailbox=".$row->sip_number."\n";
                    if ($row->company_id == 2) {
                        //$write_data .= "context=product\n";
                        $write_data .= "context=develop\n";
                    } else {
                        $write_data .= "context=product\n";
                    }
                    if ($row->use_srtp) {
                        $write_data .= "transport=tls\n"
                            . "encryption=yes\n";
                    }
                    $write_data .= "\n";
                }
            }
        }

        $write_data .= "; End of generated data\n";

        return $write_data;
    }

    /**
     * confbridge_numbers ファイルに書き出すデータを生成する。
     *
     * @param array &$groups グループデータの配列への参照。(falseの場合グループが存在しない)
     * @retrun string confbridge_numbersデータ。
     */
    private function generate_conf_bridge_data(&$groups)
    {
        $write_data = "; This file is generated by PoC Config system. !!! DO NOT EDIT manually !!!\n"
            . "; Generated data: " . date('Y-m-d H:i:s') . "\n\n"
            . "[confbridge_numbers]\n\n";

        $format = "exten => %s,1,Wait(1)\n"
            . "same => n,Answer()\n"
            . "same => n,spt_add_conference_log(\${EXTEN},111111111)\n"
            . "same => n,ConfBridge(%d)\n"
            . "same => n,Hangup\n\n";

        $room_number = 1;
        
        if (!empty($groups)) {
            foreach ($groups as $row) {
                if ($row->status != 0 && !empty($row->conf_sip_number)) {
                    // 有効なグループ
                    $write_data .= sprintf($format, $row->conf_sip_number, $room_number);
                    $room_number += 1;
                }
            }
        }

        if ($room_number == 1) {
           // no enabled group
           $write_data .= ";\n; no groups.\n;\n";
        }

        $write_data .= "; End of generated data\n";

        return $write_data;
    }

    /**
     * 車載機設定ファイルに書き出すデータを生成する。
     *
     * @param array &$account Pocアカウントデータへの参照。
     * @param array &$conf ISM設定の配列への参照。
     * @retrun string 設定データ。
     */
    private function generate_ism_conf_data(&$account, &$conf)
    {
        $write_data = "{\n"
            . "\t\"version\" : \"1\",\n"
            . "\t\"ptt\" : \"".$account->sip_server_domain."\",\n"
            . "\t\"SIP_NUM\" : \"".$account->sip_number."\",\n"
            . "\t\"SIP_PW\" : \"".$account->sip_password."\",\n"
            . "\t\"call1\" : \"".(empty($conf->call1)?"":"e.g. ".$conf->call1)."\",\n"
            . "\t\"call2\" : \"".(empty($conf->call2)?"":"e.g. ".$conf->call2)."\",\n"
            . "\t\"call3\" : \"".(empty($conf->call3)?"":"e.g. ".$conf->call3)."\",\n"
            . "\t\"prefix\" : \"5\",\n"
            //. "\t\"delaytime\" : \"1000\",\n"
            . "\t\"geointerval\" : \"".$conf->geointerval."\",\n"
            . "\t\"geodistance\" : \"".$conf->geodistance."\",\n"
            //. "\t\"callbacktimer\" : \"".$conf->callbacktimer."\",\n"
            . "\t\"NewVoiceMail\": \"".$conf->newvoicemail."\",\n"
            . "\t\"NoVoiceMail\": \"".$conf->novoicemail."\",\n"
            //. "\t\"Mic\": \"".$conf->mic."\",\n"
            //. "\t\"Speaker\": \"".$conf->speaker."\",\n"
            //. "\t\"GPS_Mode\":\"".$conf->geomode."\",\n"
            . "\t\"GPS_URL\":\"".$conf->gpsurl."\",\n"
            //. "\t\"FW_Update\" : \"".($conf->fw_update ? "1" : "0")."\",\n"
            // FW更新は常に有効とする
            . "\t\"FW_Update\" : \"1\",\n"
            . "\t\"firmware\" : [\n"
            . "\t\t{\n"
            . "\t\t\t\"model\" : \"Application\",\n"
            . "\t\t\t\"version\" : \"".$conf->appversion."\",\n"
            . "\t\t\t\"url\" : \"".$conf->apppath."\"\n"
            . "\t\t},\n"
            . "\t\t{\n"
            . "\t\t\t\"model\" : \"Kernel\",\n"
            . "\t\t\t\"version\" : \"".$conf->kernelversion."\",\n"
            . "\t\t\t\"url\" : \"".$conf->kernelpath."\"\n"
            . "\t\t},\n"
            . "\t]\n"
            . "}\n";

        return $write_data;
    }

    /**
     * パーミッションエラー処理。
     *
     * @param array $session_data セッションデータ。
     */
    private function permission_error($session_data)
    {
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['css'] = 'dummy.css';
        $data['menu'] = 'home';
        $data['success'] = false;
        $data['message'] = '許可されない操作です。';
        $data['back'] = 'home';
        $this->load->view('message_view', $data);
    }
}
