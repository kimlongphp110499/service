<?php if (! defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class GeoLocation extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('geolocation_model', '', true);
        $this->load->model('pocaccount_model', '', true);
        $this->load->model('tenant_model', '', true);
        $this->load->helper(array('form','url'));
    }

    public function view($tid = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }
        
        if ($session_data['usermode'] != 'admin') {
            $tid = $session_data['tenant'];
        }

        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['token'] = $session_data['token'];
        $data['tenant'] = $this->tenant_model->get($tid);
        $this->load->view('geolocation_view', $data);
    }

    /**
     * 位置履歴のCSVファイルをダウンロードする。
     *
     * @param int $tid テナントID。
     */
    public function download_csv($tid = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        if ($session_data['usermode'] != 'admin' && $tid != $session_data['tenant']) {
            $this->permission_error($session_data);
            return;
        }

        // パラメータチェック
        $geologs = $this->geolocation_model->get_tenant($tid);
        if (!$geologs) {
            $this->permission_error($session_data);
            return;
        }
        
        $this->load->helper('download');
        $fp = fopen('php://temp', 'r+b');
        $header = array('日時', 'アカウント名', '表示名', '経度', '緯度');
        fputcsv($fp, $header);
        foreach ($geologs as $row) {
            $array = [];
            $array['datetime'] = $row->datetime;
            $array['username'] = $row->username;
            $array['display_name'] = $row->display_name;
            $array['longitude'] = $row->longitude;
            $array['latitude'] = $row->latitude;
            fputcsv($fp, $array, ',', '"');
        }
        rewind($fp);
        $data = str_replace(PHP_EOL, "\r\n", stream_get_contents($fp));
        fclose($fp);
        
        force_download('geolocation_log.csv', mb_convert_encoding($data, 'SJIS-win', 'UTF-8'));
    }

    /**
     * スタッフの現在位置の配列を返す。
     * @param int $tenant_id テナントID。
     */
    public function getStaffLocations($tenant_id)
    {
        $this->output->set_content_type('application/json');

        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            $this->output->set_status_header(403);
            $this->output->set_output(json_encode(array('message' => 'permission error')));
            return;
        }

        $locations = $this->pocaccount_model->getStaffLocations($tenant_id);

        $this->output->set_output(json_encode($locations));
    }

    /**
     * パーミッションエラー処理。
     *
     * @param array $session_data セッションデータ。
     */
    private function permission_error($session_data)
    {
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['css'] = 'dummy.css';
        $data['menu'] = 'home';
        $data['success'] = false;
        $data['message'] = '許可されない操作です。';
        $data['back'] = 'home';
        $this->load->view('message_view', $data);
    }
}
