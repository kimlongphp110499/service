<?php if (! defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class Group extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('group_model', '', true);
        $this->load->model('tenant_model', '', true);
        $this->load->model('pocaccount_model', '', true);
        $this->load->helper(array('form','url'));
        $this->load->driver('cache', array('adapter' => 'apc', 'backup' => 'file'));
    }

    /**
     * テナント選択画面かテナントのグループ一覧を表示する。
     *
     * @param int $tid テナントのID。0の場合はテナント選択画面を表示。
     * @param string $sortkey ソートキー。
     * @param string $order 順序('asc'or'desc')
     */
    public function view_list($tid = false, $sortkey = false, $order = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        
        if ($session_data['usermode'] != 'admin') {
            $tid = $session_data['tenant'];
        }
        
        if ($tid) {
            // パラメータチェック
            $tenant = $this->tenant_model->get($tid);
            if (!$tenant) {
                $this->permission_error($session_data);
                return;
            }

            $data['tenant'] = $tenant;
            $data['accounts'] = $this->group_model->get_tenant($tid, $sortkey, $order);
            $data['sortkey'] = $sortkey;
            $data['order'] = $order;
            $this->load->view('group_list_view', $data);
        } else {
            $data['tenants'] = $this->tenant_model->get_all();
            $this->load->view('group_select_view', $data);
        }
    }

    /**
     * グループの詳細情報を表示する。
     *
     * @param int $tid テナントID。
     * @param int $id 表示するグループのID。
     * @param string $sortkey ソートキー。
     * @param string $order 順序('asc'or'desc')
     */
    public function view($tid = false, $id = false, $sortkey = false, $order = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        if ($session_data['usermode'] != 'admin' && $tid != $session_data['tenant']) {
            $this->permission_error($session_data);
            return;
        }

        // パラメータチェック
        $tenant = $this->tenant_model->get($tid);
        $group = $this->group_model->get($id);
        if (!$tenant || !$group) {
            $this->permission_error($session_data);
            return;
        }

        // prepare view data
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['tenant'] = $tenant;
        $data['group'] = $group;
        $data['sortkey'] = $sortkey;
        $data['order'] = $order;
        $data['members'] = $this->group_model->get_members($id, $sortkey, $order);
        
        // load views
        $this->load->view('group_detail_view', $data);
    }

    /**
     * グループを削除する。
     *
     * @param int $tid テナントのID。
     * @param int $id 削除するグループのID。
     */
    public function delete($tid = false, $id = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        if ($session_data['usermode'] != 'admin') {
            $this->permission_error($session_data);
            return;
        }

        // パラメータチェック
        $tenant = $this->tenant_model->get($tid);
        $group = $this->group_model->get($id);
        if (!$tenant || !$group) {
            $this->permission_error($session_data);
            return;
        }

        $message = 'グループ削除しました。グループメニューから[SIP更新]を行ってください。';
        $rslt = $this->group_model->delete($id);
        if (!$rslt) {
            $message = 'データベースエラーが発生しました。';
        }

        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['css'] = 'dummy.css';
        $data['menu'] = 'group';
        $data['success'] = $rslt;
        $data['message'] = $message;
        $data['back'] = 'group/view_list/'.$tid;
        $this->load->view('message_view', $data);
    }

    /**
     * グループの編集画面を表示する。
     *
     * @param int $tid テナントID。
     * @param int $id 表示するグループのID。
     */
    public function edit($tid = false, $id = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        if ($session_data['usermode'] != 'admin' && $tid != $session_data['tenant']) {
            $this->permission_error($session_data);
            return;
        }

        // パラメータチェック
        $tenant = $this->tenant_model->get($tid);
        $group = $this->group_model->get($id);
        if (!$tenant || !$group) {
            $this->permission_error($session_data);
            return;
        }

        // prepare view data
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['tenant'] = $tenant;
        $data['group'] = $group;
        
        // load views
        $this->load->view('group_edit_view', $data);
    }

    /**
     * グループを編集する。
     *
     * @param int $tid テナントのID。
     * @param int $id 編集するグループのID。
     */
    public function edit_action($tid, $id)
    {
        $this->do_save($tid, $id);
    }
    
    /**
     * グループメンバー編集画面。
     *
     * @param int $tid テナントのID。
     * @param int $id グループのID。
     * @param string $sortkey ソートキー。
     * @param string $order 順序('asc'or'desc')
     */
    public function plan($tid = false, $id = false, $sortkey = false, $order = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        if ($session_data['usermode'] != 'admin' && $tid != $session_data['tenant']) {
            $this->permission_error($session_data);
            return;
        }

        // パラメータチェック
        $tenant = $this->tenant_model->get($tid);
        $group = $this->group_model->get($id);
        if (!$tenant || !$group) {
            $this->permission_error($session_data);
            return;
        }

        // prepare view data
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['tenant'] = $tenant;
        $data['group'] = $group;
        $data['sortkey'] = $sortkey;
        $data['order'] = $order;
        $data['group_members'] = $this->group_model->get_member_ids($id);
        $data['accounts'] = $this->pocaccount_model->get_tenant($tid, $sortkey, $order);
        
        // load views
        $this->load->view('group_plan_view', $data);
    }

    /**
     * グループメンバー編集を実行
     *
     * @param int $tid テナントのID。
     * @param int $id グループのID。
     */
    public function plan_post_action($tid = false, $id = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        if ($session_data['usermode'] != 'admin' && $tid != $session_data['tenant']) {
            $this->permission_error($session_data);
            return;
        }

        // パラメータチェック
        $tenant = $this->tenant_model->get($tid);
        $group = $this->group_model->get($id);
        if (!$tenant || !$group) {
            $this->permission_error($session_data);
            return;
        }

        $message = null;
        $array_poc_id = $this->input->post('poc_id[]');
        $rslt = $this->group_model->plan($id, $array_poc_id);
        if (!$rslt) {
            $message = 'データベースエラーが発生しました。';
        }
        
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['css'] = 'dummy.css';
        $data['menu'] = 'group';
        $data['tenant'] = $tenant;
        $data['success'] = $rslt;
        $data['message'] = $message;
        $data['back'] = 'group/view_list/'.$tid;
        $this->load->view('message_view', $data);
    }
    
    /**
     * グループデータをCSVファイルにエクスポートする。
     *
     * @param int $tid テナントID。
     */
    public function export($tid = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        if ($session_data['usermode'] != 'admin' && $tid != $session_data['tenant']) {
            $this->permission_error($session_data);
            return;
        }

        // パラメータチェック
        $groups = $this->group_model->get_tenant($tid, 'group_id', 'asc');
        if (!$groups) {
            $this->permission_error($session_data);
            return;
        }
        
        $this->load->helper('download');
        $fp = fopen('php://temp', 'r+b');
        $header = array('#ID', 'グループ名', 'グループSIP番号','会議室SIP番号', '状態');
        fputcsv($fp, $header);
        foreach ($groups as $row) {
            $array = [];
            $array['group_id'] = $row->group_id;
            $array['group_name'] = $row->group_name;
            $array['sip_number'] = $row->sip_number;
            $array['conf_sip_number'] = $row->conf_sip_number;
            $array['status'] = $row->status ? '有効' : '無効';
            fputcsv($fp, $array, ',', '"');
        }
        rewind($fp);
        $data = str_replace(PHP_EOL, "\r\n", stream_get_contents($fp));
        fclose($fp);
        
        force_download('groups.csv', mb_convert_encoding($data, 'SJIS-win', 'UTF-8'));
    }

    /**
     * テナント内グループ全削除後、CSVファイルからグループをインポートする。
     *
     * @param int $tid テナントID。(0は不可)
     */
    public function import($tid = false)
    {
        global $global_account_status_names;    // 無効=0 または 有効=1
        
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        // テナントアカウントでは不可
        //if ($session_data['usermode'] != 'admin' && $tid != $session_data['tenant']) {
        if ($session_data['usermode'] != 'admin') {
            $this->permission_error($session_data);
            return;
        }

        // テナントアカウントチェック(tid == 0 はここではじかれる)
        $tenant = $this->tenant_model->get($tid);
        if (!$tenant) {
            $this->permission_error($session_data);
            return;
        }

        // グループ配列初期化
        $err = false;
        $message = '';
        $group_array = [];        
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        
        // CSVファイル読み込み
        $config['upload_path'] = './uploads/';
        $config['allowed_types'] = 'csv';
        $config['max_size'] = '10 * 1024';    // 10MB
        $this->load->library('upload', $config);
        if (!$this->upload->do_upload('import_group')) {
            $err = true;
            $message = 'csvファイルの読み込みに失敗しました。';
        } else {
            $filepath = $this->upload->data('full_path');
            $file = new SplFileObject($filepath);
            $file->setFlags(SplFileObject::READ_CSV);
            $line_num = 1;
            $group_list = array();  //重複チェック用
            foreach ($file as $line) {
                // 'line' is array so check first array element != null
                if (!empty($line[1])) {
                    $account = array();
                    $str = strtolower($line[0]);
                    // # で始まる行はコメント
                    if (strpos($str, '#') === 0) {
                        $line_num++;
                        continue;
                    }

                    // we have 5 items in one row - last is 4
                    if (empty($line[4])) {
                        // 5 つのアイテムがそろっていないか、4つめが空文字列(有効または無効が必要)
                        $err = true;
                        $message = 'CSVファイルの'.$line_num.'行目にエラーがあります。(項目数が足りない)';
                        break;
                    }

                    // 「グループ名」「グループSIP番号」「会議室SIP番号」「状態」

                    if (empty($line[1])) {
                        // グループ名が必要
                        $err = true;
                        $message = 'CSVファイルの'.$line_num.'行目にエラーがあります。(グループ名が必要)';
                        break;
                    }

                    // グループ名は7文字以上50文字以下の文字列
                    $group_name = mb_convert_encoding($line[1], 'UTF-8', 'SJIS');
                    //$length = strlen($group_name);  // return number of bytes
                    //if (empty($group_name) || !preg_match("/^[a-zA-Z0-9]+$/", $group_name) || $length < 8 || 128 < $length) {
                    //    $err = true;
                    //    $message = 'CSVファイルの'.$line_num.'行目にエラーがあります。(無効なグループ名)';
                    //    break;
                    //}
                    $length = mb_strlen($group_name);  // return number of characters counted by internal encoding (UTF-8)
                    if (empty($group_name) || $length < 7 || 50 < $length) {
                        $err = true;
                        $message = 'CSVファイルの'.$line_num.'行目にエラーがあります。(無効なグループ名)';
                        break;
                    }

                    // テナント内の既存POCアカウント表示名と重複していないかチェック
                    if (!$this->pocaccount_model->is_available_in_tenant($tid, $group_name)) {
                        $err = true;
                        $message = 'CSVファイルの'.$line_num.'行目にエラーがあります。(グループ名が既存のアカウント名と重複)';
                        break;
                    }

                    // テナント内の既存のグループは全削除になるのでチェック不要
                    //if (!$this->group_model->is_available_in_tenant($tid, $group_name)) {
                    //    $err = true;
                    //    $message = 'CSVファイルの'.$line_num.'行目にエラーがあります。(グループ名が既存のグループ名と重複)';
                    //    break;
                    //}

                    // すでに読み込んだCSV内のグループ名との重複チェック
                    if (in_array($group_name, $group_list, TRUE)) {
                        $err = true;
                        $message = 'CSVファイルの'.$line_num.'行目にエラーがあります。(CSV内の他のグループ名と重複)';
                        break;
                    }

                    $account['group_name'] = $group_name;
                    array_push($group_list, $group_name);   // add array element
                    
                    // グループSIP番号/会議室SIP番号は利用せず id == 1 から再度割り当てる
                    // $sip_number = $line[2];
                    // if (empty($sip_number) || !preg_match("/^[0-9]+$/", $sip_number)) {
                    //     $err = true;
                    //     $message = 'CSVファイルの'.$line_num.'行目にエラーがあります。(無効なSIP番号)';
                    //     break;
                    // }
                    // // SIP番号の重複をチェック
                    // if (!$this->pocaccount_model->is_available_sip_number($sip_number)) {
                    //     $err = true;
                    //     $message = 'SIP番号"'.$sip_number.'"がすでに存在します。';
                    //     break;
                    // }
                    // $account['sip_number'] = $sip_number;                    

                    // 有効/無効
                    $status = '0';
                    if (!empty($line[4])) {
                        $status_name = mb_convert_encoding($line[4], 'UTF-8', 'SJIS');
                        if (in_array($status_name, $global_account_status_names, TRUE)) { 
                            // valid parameter
                            $status = array_search($status_name, $global_account_status_names, TRUE);   // 0 or 1
                        }
                        else {
                            // '無効' or '有効’ ではない (エンコーディングエラーも含む)
                            $err = true;
                            $message = 'CSVファイルの'.$line_num.'行目にエラーがあります。(有効/無効以外が指定されました)';
                            break;
                        }
                    }
                    else {
                        // '無効' or '有効’ のフィールドがない
                        $err = true;
                        $message = 'CSVファイルの'.$line_num.'行目にエラーがあります。(有効/無効の指定がありません)';
                        break;
                    }
                    $account['status'] = $status;   // 0 or 1

                    // その他のデフォルト値を設定(もしあれば)

                    // グループアカウントを追加
                    $group_array[] = $account;

                }
                $line_num++;
            }

            // インポートグループ数上限のチェック
            // 既存グループは全削除することを想定
            if (!$err && count($group_array) > MAX_GROUPS_IN_TENANT) {
                $err = true;
                $message = 'インポートするグループ数がテナント上限の '.MAX_GROUPS_IN_TENANT.' を超えています';
            }
        }

        //
        // インポートチェック終了
        //
        if (!$err && empty($group_array)) {
            $err = true;
            $message = 'インポート可能なデータがありません。';
        }

        if (!$err) {
            // テナント内グループ全削除
            // tenants テーブルの　group_last_id　を後で忘れずに更新する。
            if (!$this->group_model->delete_tenant($tid)) {
                $err = true;
                $message = 'DBエラーが発生しました。';
            }
        }

        if (!$err) {
            // テナント内グループ追加
            $this->db->trans_start();
            if (count($group_array) > 0) {
                // グループアカウントをすべて削除したため、ID == 1 から始める
                // グループ名重複チェック済
                $this->group_model->add_batch($tid, $group_array, 1);
            }            
            // インポートしたグループ数を最後のgroup_idとして設定
            $this->tenant_model->update_last_group_id($tid, count($group_array));
            $this->db->trans_complete();
            
            if ($this->db->trans_status() === false) {
                $err = true;
                $message = 'データベースエラーが発生しました。';
                log_message('error', 'Database Error!!');
            }
        }

        if (!$err) {
            //$this->load->view('pocaccount_add_result_view', $data);
            $message = 'CSVインポート成功しました。';
        }
            
        /* 結果通知画面 */
        //$data['username'] = $session_data['username'];
        //$data['usermode'] = $session_data['usermode'];
        $data['css'] = 'dummy.css';
        $data['menu'] = 'group';
        $data['tenant'] = $tenant;
        $data['success'] = !$err;
        $data['message'] = $message;
        $data['back'] = 'group/view_list/'.$tid;
        $this->load->view('message_view', $data);
    }

     /**
     * 独自フォームバリデーション : グループ名の重複チェック
     * 
     * @param int $group_name 追加するグループ名。     *
     * @param int $tid テナントID。
     * 
     * @return int チェック結果 (true = OK)
     */
    public function group_check($group_name, $tid)
    {
        if (!$this->pocaccount_model->is_available_in_tenant($tid, $group_name)) {

            $this->form_validation->set_message('group_check', 'グループ名がテナント内の既存のアカウント名と重複');
            return false;

        }

        if (!$this->group_model->is_available_in_tenant($tid, $group_name)) {

            $this->form_validation->set_message('group_check', 'グループ名がテナント内の既存のグループ名と重複');
            return false;

        }

        return true;    // チェックOK
    }

     /**
     * 独自フォームバリデーション : グループ数のチェック
     * 
     * @param int $num_groups 追加するグループ数。     *
     * @param int $tid テナントID。
     * 
     * @return int チェック結果 (true = OK)
     */
    public function num_group_check($num_groups, $tid)
    {
        // ここでは $tid 必ず有効なものであること
        // 無効な $tid が渡されると、単に既存のグループ数=0 が返される
        $groups_in_tenant = $this->group_model->number_of_groups($tid);

        if ($num_groups + $groups_in_tenant > MAX_GROUPS_IN_TENANT) {

            $this->form_validation->set_message('num_group_check', 'グループ数がテナント上限の '.MAX_GROUPS_IN_TENANT.'を超えます。');
            return false;

        }

        return true;
    }

    /**
     * グループの編集。
     *
     * @param int $tid テナントのID。
     * @param int $id グループのID。
     */
    private function do_save($tid = false, $id = false)
    {
        $status_change = false;
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        if ($session_data['usermode'] != 'admin' && $tid != $session_data['tenant']) {
            $this->permission_error($session_data);
            return;
        }

        // パラメータチェック
        $tenant = $this->tenant_model->get($tid);
        $group = $this->group_model->get($id);
        if (!$tenant || !$group) {
            $this->permission_error($session_data);
            return;
        }

        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('<div class="bg-danger">', '</div>');
        if ($group->group_name != $this->input->post('group_name')) {
            // グループ名を変更した場合
            // グループ名は7文字以上50文字以下の文字列
            //$this->form_validation->set_rules('group_name', 'グループ名', 'required|trim|alpha_numeric|min_length[8]|max_length[128]|callback_group_check['.$tid.']');
            $this->form_validation->set_rules('group_name', 'グループ名', 'required|trim|min_length[7]|max_length[50]|callback_group_check['.$tid.']');
        }

        $this->form_validation->set_rules('status', '状態', 'required');
        if ($group->status != $this->input->post('status')) {
            // 状態を変更した場合
            $status_change = true;
        }

        $session_data = $this->session->userdata('logged_in');
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['tenant'] = $tenant;
        
        if ($this->form_validation->run() === false) {
            $data['group'] = $group;
            $this->load->view('group_edit_view', $data);
            return;
        }

        $message = null;
        $rslt = $this->group_model->edit($id);
        if (!$rslt) {
            $message = 'データベースエラーが発生しました。';
        }
        else if ($status_change) {
            $this->update_sipconf();
        }

        $data['menu'] = 'group';
        $data['css'] = 'dummy.css';
        $data['success'] = $rslt;
        $data['message'] = $message;
        $data['back'] = 'group/view_list/'.$tid;
        $this->load->view('message_view', $data);
    }

    /**
     * グループの追加画面を表示する。
     *
     * @param int $tid テナントID。
     */
    public function add_batch($tid = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        if ($session_data['usermode'] != 'admin') {
            $this->permission_error($session_data);
            return;
        }

        // パラメータチェック
        $tenant = $this->tenant_model->get($tid);
        if (!$tenant) {
            $this->permission_error($session_data);
            return;
        }

        // prepare view data
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['tenant'] = $tenant;
        
        // load views
        $this->load->view('group_add_batch_view', $data);
    }

     /**
     * グループを追加する。
     *
     * @param int $tid テナントID。
     */
    public function add_batch_action($tid)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        if ($session_data['usermode'] != 'admin') {
            $this->permission_error($session_data);
            return;
        }

        // パラメータチェック
        $tenant = $this->tenant_model->get($tid);
        if (!$tenant) {
            $this->permission_error($session_data);
            return;
        }

        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('<div class="bg-danger">', '</div>');
        $this->form_validation->set_rules('group_num', 'グループ数', 'required|is_natural_no_zero|callback_num_group_check['.$tid.']');

        // prepare view data
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['tenant'] = $tenant;
        
        if ($this->form_validation->run() === false) {
            $data['menu'] = 'group';
            $data['css'] = 'dashboard.css';
            $this->load->view('group_add_batch_view', $data);
            return;
        }

        $requested_groups = $this->input->post('group_num');
        $last_id = $this->tenant_model->get_last_group_id($tid);
        $index = $last_id + 1;  // この番号からトライする
        $array = [];
    
        for ($i = 0; $i < $requested_groups; $index++) {
            // 初期グループ名を"グループxxx"に変更
            $group['group_name'] = sprintf('グループ%04d', $index);
            //$group['group_name'] = sprintf('GROUP%03d', $index);

            //
            // 初期グループ名がテナント内の既存アカウント表示名/グループ名とぶつからないかチェック
            // 例えば、既存グループを"グループXXX"という名前に変更してあると、ぶつかる場合がある
            //
            if (!$this->pocaccount_model->is_available_in_tenant($tid, $group['group_name'])) {
                // グループ名がテナント内の既存のアカウント名と重複
                // $index を進めて再トライ
                continue;
            }                
            if (!$this->group_model->is_available_in_tenant($tid, $group['group_name'])) {
                // グループ名がテナント内の既存のグループ名と重複
                // $index を進めて再トライ
                continue;
            }                

            // ぶつからない
            $array[] = $group;
            $i++;
        }

        /* DBを更新 */
        $new_last_id = $this->group_model->add_batch($tid, $array, $last_id + 1);
        if ($new_last_id > 0) {
            //$this->tenant_model->update_last_group_id($tid, $last_id + count($array));
            $this->tenant_model->update_last_group_id($tid, $new_last_id);    // 最後に使用した番号を保存
        } else {
            $data['css'] = 'dummy.css';
            $data['menu'] = 'group';
            $data['success'] = false;
            $data['message'] = 'データベースエラーが発生しました。';
            $data['back'] = 'group/view_list/'.$tid;
            $this->load->view('message_view', $data);
            return;
        }
            
        $data['groups'] = $array;

        // csvダウンロード用にキャッシュする
        $pw_str = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $cid = substr(str_shuffle(str_repeat($pw_str, 8)), 0, 8);
        $this->cache->save($cid, $array, 300);
        $data['cacheid'] = $cid;

        $this->load->view('group_add_result_view', $data);
    }

    /**
     * パーミッションエラー処理。
     *
     * @param array $session_data セッションデータ。
     */
    private function permission_error($session_data)
    {
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['css'] = 'dummy.css';
        $data['menu'] = 'home';
        $data['success'] = false;
        $data['message'] = '許可されない操作です。';
        $data['back'] = 'home';
        $this->load->view('message_view', $data);
    }

    /**
     * SIPサーバーにConfBridge電話番号を登録する。
     *
     * データベースに登録されている内容で /etc/asterisk/sip.conf と /etc/asterisk/extensions.conf を書き換える。
     * Asteriskにsip.confとextensions.confを再ロードさせる。
     */
    private function update_sipconf()
    {
        $err = false;
        $message = '';

        /* ConfBridge用データを作成 */
        /* グループが一つも存在しない場合、$all_groups は falseになる */
        $all_groups = $this->group_model->get_all();
        $conf_bridge_data = $this->generate_conf_bridge_data($all_groups);

        /* ファイルへの書き出し */
        if (!write_file('/mnt/pocdata/pocconf/confbridge_numbers', $conf_bridge_data, 'wt')) {
            $err = true;
            $message = 'confbridge_numbersの更新に失敗しました。サーバーの設定を確認ししてください。';
        }        
        else {
            system('/var/www/html/pocconsole/bin/update_sipconf.sh', $retval);
            log_message('debug', 'retval='.$retval);
            if ($retval === false) {
                $err = true;
                $message = 'SIPサーバーの更新に失敗しました。サーバーの設定を確認してください';
            } else {
                $message = 'sip.confを更新しました。';
            }
        }

        return $err;
    }

    /**
     * confbridge_numbers ファイルに書き出すデータを生成する。
     *
     * @param array &$groups グループデータの配列への参照。(falseの場合グループが存在しない)
     * @retrun string confbridge_numbersデータ。
     */
    private function generate_conf_bridge_data(&$groups)
    {
        $write_data = "; This file is generated by PoC Config system. !!! DO NOT EDIT manually !!!\n"
            . "; Generated data: " . date('Y-m-d H:i:s') . "\n\n"
            . "[confbridge_numbers]\n\n";

        $format = "exten => %s,1,Wait(1)\n"
            . "same => n,Answer()\n"
            . "same => n,spt_add_conference_log(\${EXTEN},111111111)\n"
            . "same => n,ConfBridge(%d)\n"
            . "same => n,Hangup\n\n";

        $room_number = 1;
        
        if (!empty($groups)) {
            foreach ($groups as $row) {
                if ($row->status != 0 && !empty($row->conf_sip_number)) {
                    // 有効なグループ
                    $write_data .= sprintf($format, $row->conf_sip_number, $room_number);
                    $room_number += 1;
                }
            }
        }

        if ($room_number == 1) {
           // no enabled group
           $write_data .= ";\n; no groups.\n;\n";
        }

        $write_data .= "; End of generated data\n";

        return $write_data;
    }
}
