<?php if (! defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class SptMap extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('geolocation_model', '', true);
        $this->load->model('pocaccount_model', '', true);
        $this->load->model('tenant_model', '', true);
        $this->load->helper(array('form','url'));
    }

    public function view($token)
    {
        $account = $this->pocaccount_model->get_from_token($token);
        if (!$account) {
            $data['message'] = 'ユーザー認証エラー';
            $this->load->view('templates/spt_error', $data);
            return;
        }
        $data['tenant'] = $this->tenant_model->get($account->company_id);
        $data['token'] = $token;
        $data['ini_lon'] = $account->longitude;
        $data['ini_lat'] = $account->latitude;
        $this->load->view('sptmap_view', $data);
    }

    /**
     * スタッフの現在位置の配列を返す。
     * @param int $tenant_id テナントID。
     */
    public function getStaffLocations($token)
    {
        $this->output->set_content_type('application/json');

        $account = $this->pocaccount_model->get_from_token($token);
        if (!$account) {
            $this->output->set_status_header(403);
            return;
        }

        $locations = $this->pocaccount_model->getStaffLocations($account->company_id);

        $this->output->set_output(json_encode($locations));
    }
}
