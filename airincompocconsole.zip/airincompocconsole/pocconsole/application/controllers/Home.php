<?php if (! defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class Home extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('tenant_model', '', true);
        $this->load->model('webaccount_model', '', true);
        $this->load->model('callrecord_model', '', true);
        $this->load->model('image_model', '', true);
        $this->load->helper(array('form', 'url'));
    }

	public function getSessionData()
	{
        return $this->session->userdata('logged_in');
	}

    /**
     * ホーム画面を表示する。
     */
    public function index()
    {
		//$this->output->enable_profiler(true);
        //$session_data = $this->session->userdata('logged_in');
        $session_data = $this->getSessionData();
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
        }

        $date = new DateTime(date('Y-m-d', time()));
        $today = $date->format('U');
        $date = $date->sub(new DateInterval('P7D'));
        $week = $date->format('U');
        
        $call_list = array();
        if ($session_data['usermode'] == 'admin') {
            $tenants = $this->tenant_model->get_all();
            foreach ($tenants as $row) {
                $call_data['company_name'] = $row->company_name;
                $call_data['call_today_num'] =
                    $this->callrecord_model->get_call_num_from_date($row->company_id, $today);
                $call_data['call_weekly_num'] =
                    $this->callrecord_model->get_call_num_from_date($row->company_id, $week);
                $call_data['file_today_size'] =
                    $this->callrecord_model->get_file_size_from_date($row->company_id, $today);
                $call_data['file_weekly_size'] =
                    $this->callrecord_model->get_file_size_from_date($row->company_id, $week);
                $call_data['file_total_size'] =
                    $this->callrecord_model->get_file_size_from_date($row->company_id) +
                    $this->image_model->get_file_size($row->company_id);
                $call_list[] = $call_data;
            }
        } else {
            $tid = $session_data['tenant'];
            $call_data['call_today_num'] =
                $this->callrecord_model->get_call_num_from_date($tid, $today);
            $call_data['call_weekly_num'] =
                $this->callrecord_model->get_call_num_from_date($tid, $week);
            $call_data['file_today_size'] =
                $this->callrecord_model->get_file_size_from_date($tid, $today);
            $call_data['file_weekly_size'] =
                $this->callrecord_model->get_file_size_from_date($tid, $week);
            $call_data['call_total_num'] =
                $this->callrecord_model->get_call_num_from_date($tid);
            $call_data['file_total_size'] =
                $this->callrecord_model->get_file_size_from_date($tid) +
                $this->image_model->get_file_size($tid);
            $call_list[] = $call_data;
        }

        // load view
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['call_list'] = $call_list;

        $this->load->view('home_view', $data);
    }

    /**
     * ログアウトする。
     */
    public function logout()
    {
        $session_data = $this->session->userdata('logged_in');
        if ($session_data) {
            $this->webaccount_model->set_token($session_data['id'], null);
            $this->session->unset_userdata('logged_in');
            session_destroy();
        }
        
        redirect('login', 'refresh');
    }
}
