<?php if (! defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class Dialplan extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('tenant_model', '', true);
        $this->load->model('group_model', '', true);
        $this->load->model('pocaccount_model', '', true);
        $this->load->helper(array('form','url'));
    }

    /**
     * 回線計画を表示する。
     *
     * @param int $tid テナントのID, 0 の場合はテナント選択画面(保守アカウント用)
     */
    public function view($tid = false)
    {
		//$this->output->enable_profiler(true);
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];

        if ($data['usermode'] != 'admin') {
            $tid = $session_data['tenant'];
        }

        if ($tid) {
            // テナント用回線計画表示

            // パラメータチェック
            $tenant = $this->tenant_model->get($tid);
            if (!$tenant) {
                $this->permission_error($session_data);
                return;
            }

            $data['tenant'] = $tenant;
            $data['emergency_sip_normal_name'] = $this->pocaccount_model->get_account_sip($tenant->emergency_sip_normal);
            $data['emergency_sip_monitor_name'] = $this->pocaccount_model->get_account_sip($tenant->emergency_sip_monitor);
            $data['emergency_sip_group_name'] = $this->group_model->get_group_sip($tenant->emergency_sip_group);

            $this->load->view('dialplan_view', $data);
        } else {
            // テナント選択画面
            $data['tenants'] = $this->tenant_model->get_all();
            $this->load->view('dialplan_select_view', $data);
        }
    }


    /**
     * 回線計画の編集画面を表示する。
     *
     * @param int $tid テナントID。
     */
    public function edit($tid = false)
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        // ユーザーモードでは異なるテナントの閲覧を禁止する。
        if ($session_data['usermode'] != 'admin' && $tid != $session_data['tenant']) {
            $this->permission_error($session_data);
            return;
        }

        // パラメータチェック
        $tenant = $this->tenant_model->get($tid);
        if (!$tenant) {
            $this->permission_error($session_data);
            return;
        }

        // prepare view data
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['tenant'] = $tenant;

        // 有効なアカウント一覧とグループ一覧を取得
        $data['accounts'] = $this->pocaccount_model->get_tenant_accounts($tid);
        $data['groups'] = $this->group_model->get_tenant_groups($tid);
        
        // load views
        $this->load->view('dialplan_edit_view', $data);
    }

    /**
     * 回線計画を編集する。
     *
     * @param int $id 編集する回線計画のID。
     */
    public function edit_action($tid = false)
    {
        $message = '';
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        // ユーザーモードでは異なるテナントの編集を禁止する。
        if ($session_data['usermode'] != 'admin' && $tid != $session_data['tenant']) {
            $this->permission_error($session_data);
            return;
        }

        // パラメータチェック
        $tenant = $this->tenant_model->get($tid);
        if (!$tenant) {
            $this->permission_error($session_data);
            return;
        }

        // this is debug code
        $sip_normal = $this->input->post('emergency_sip_normal');
        $sip_monitor = $this->input->post('emergency_sip_monitor');
        $sip_group = $this->input->post('emergency_sip_group');

        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('<div class="bg-danger">', '</div>');

        $this->form_validation->set_rules('emergency_sip_normal', 'ノーマル用アカウントSIP番号', 'trim|alpha_numeric');
        $this->form_validation->set_rules('emergency_sip_monitor', 'モニター用アカウントSIP番号', 'trim|alpha_numeric');
        $this->form_validation->set_rules('emergency_sip_group', 'グループ用グループSIP番号', 'trim|alpha_numeric');

        $session_data = $this->session->userdata('logged_in');
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        
        if ($this->form_validation->run() === false) {
            // バリデーションエラー
            $data['tenant'] = $this->tenant_model->get($tid);
            $data['accounts'] = $this->pocaccount_model->get_tenant_accounts($tid);
            $data['groups'] = $this->group_model->get_tenant_groups($tid);
            
            $this->load->view('dialplan_edit_view', $data);
            return;
        }

        // build update records
        $emergency = array(
            'emergency_sip_normal' => $this->input->post('emergency_sip_normal'),
            'emergency_sip_monitor' => $this->input->post('emergency_sip_monitor'),
            'emergency_sip_group' => $this->input->post('emergency_sip_group'),
        );


        /* DB更新 */
        $err = false;
        $rslt = $this->tenant_model->edit_emergency($tid, $emergency);
        if (!$rslt) {
            $err = true;
            $message = 'データベースエラーが発生しました。';
            log_message('error', 'Database Error!!');
        }

        $data['menu'] = 'dialplan';
        $data['css'] = 'dummy.css';
        $data['success'] = $err ? false : true;
        if ($err) {
            $data['message'] = $message;
        }
        $data['back'] = 'dialplan/view/'.$tid;
        $this->load->view('message_view', $data);
    }


    /**
     * パーミッションエラー処理。
     *
     * @param array $session_data セッションデータ。
     */
    private function permission_error($session_data)
    {
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['css'] = 'dummy.css';
        $data['menu'] = 'home';
        $data['success'] = false;
        $data['message'] = '許可されない操作です。';
        $data['back'] = 'home';
        $this->load->view('message_view', $data);
    }
}
