<?php if (! defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class Log extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('tenant_model', '', true);
        $this->load->model('callrecord_model', '', true);
        $this->load->helper(array('form','url'));
    }

    public function index()
    {
        $session_data = $this->session->userdata('logged_in');
        if (!$session_data) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }
        
        $date = new DateTime(date('Y-m-d', time()));
        $today = $date->format('U');
        $date = $date->sub(new DateInterval('P7D'));
        $week = $date->format('U');
        
        $call_list = array();
        if ($session_data['usermode'] == 'admin') {
            $tenants = $this->tenant_model->get_all();
            foreach ($tenants as $row) {
                $call_data['company_name'] = $row->company_name;
                $call_data['call_today_num'] =
                    $this->callrecord_model->get_call_num_from_date($row->company_id, $today);
                $call_data['call_weekly_num'] =
                    $this->callrecord_model->get_call_num_from_date($row->company_id, $week);
                $call_list[] = $call_data;
            }
        }

        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['css'] = 'dummy.css';
        $data['menu'] = 'log';
        $data['call_list'] = $call_list;
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidemenu', $data);
        $this->load->view('log_view', $data);
        $this->load->view('templates/footer', $data);
    }
}
