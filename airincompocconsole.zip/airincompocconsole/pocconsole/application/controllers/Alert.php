<?php if (! defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class Alert extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->helper(array('form','url'));
    }

    public function view_list()
    {
        if (!$this->session->userdata('logged_in')) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        $session_data = $this->session->userdata('logged_in');
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['css'] = 'dummy.css';
        $data['menu'] = 'alert';
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidemenu', $data);
        $this->load->view('alert_list_view', $data);
        $this->load->view('templates/footer', $data);
    }

    public function handle($id)
    {
        if (!$this->session->userdata('logged_in')) {
            //If no session, redirect to login page
            redirect('login', 'refresh');
            return;
        }

        $this->load->library('calendar');

        $session_data = $this->session->userdata('logged_in');
        $data['username'] = $session_data['username'];
        $data['usermode'] = $session_data['usermode'];
        $data['css'] = 'dummy.css';
        $data['menu'] = 'alert';
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidemenu', $data);
        $this->load->view('alert_handle_view', $data);
        $this->load->view('templates/footer', $data);
    }
}
