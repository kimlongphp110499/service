<?php

defined('BASEPATH') OR exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
//require APPPATH . '/libraries/REST_Controller.php';

/**
 * Callrecord TEST controller class used for test record playback
 */
class Callrecord_test extends CI_Controller {

    function __construct()
    {
        // Construct the parent class
        parent::__construct();

        $this->load->helper(array('form','url'));        
    }

    /**
     * 指定された通話記録を再生する。
     *
     * ffmpegを使用しg729ファイルをwav形式に変換して、変換したファイルのURLを返す。
     * 本APIはブラウザからXMLHttpRequestでリクエストされることを想定している。
     *
     * @param $filepath 2001002002-7001002001-20171206-115721-in のようなファイルパス
     */
    public function play_record($filepath)
    {
        //$filepath = $this->callrecord_model->get_filepath($tid, $id);
        if (!$filepath) {
            $message = 'Error: ファイル名が指定されていません。';
            //$this->callrecord_error($message);
            echo $message;  /// this will print inside audio_play modal
            return;
        }

        $infile = ASTERISK_MONITOR_DIR.$filepath.'.g729';
        $outfile = AUDIO_OUTPUT_DIR.$filepath.'.wav';

        if (!file_exists($infile) || filesize($infile) == 0) {
            $message = 'Error: g729 音声ファイルがないか 0バイトです。\n' . $infile;
            //$this->callrecord_error($message);
            echo $message;  /// this will print inside audio_play modal
            return;
        }

        if (!file_exists($outfile)) {
            $cmd = FFMPEG_CMD.' -i '.ASTERISK_MONITOR_DIR.$filepath.'.g729 '
                .AUDIO_OUTPUT_DIR.$filepath.'.wav';
            log_message('debug', 'cmd= '.$cmd);
            system($cmd, $retval);
            log_message('debug', 'retval= '.$retval);
        } else {
            log_message('debug', 'file exists: '.$filepath);
        }
        //echo base_url().'audio/'.$filepath.'.wav';
        echo base_url('callrecord_test/get_message_audio/'.$filepath);
    }

    public function get_message_audio($filepath)
    {
        if (!$filepath) {
            log_message('debug', 'get_message_audio: no filepath.');
            return;
        }

        // wavデータを返す
        $this->output->set_content_type('audio/x-wav');

        $path = AUDIO_OUTPUT_DIR.$filepath.'.wav';

        if (!file_exists($path)) {
            log_message('debug', 'get_message_audio: file not found.');
            return;
        }

        $audio = file_get_contents($path);

        echo $audio;
    }

    // エラー表示
    private function callrecord_error($message)
    {
        $data['username'] = 'test';
        $data['usermode'] = 'admin';
        $data['css'] = 'dummy.css';
        $data['menu'] = 'callrecord';
        $data['success'] = false;
        $data['message'] = $message;
        $data['back'] = 'callrecord_test';
        $this->load->view('message_view', $data);
    }    

    public function index()
    {
        $default_value = array(
        //	'apikey'	    => '517ac7236969b9745aed84d4addf65d5',
        //	'tenant_id'	    => 'iforceapi',
        //	'tenant_pass'	=> 'PASSWORD',
        //	'id'			=> 'HANDY001',
        //	'pass'			=> 'HANDY001',
        );

        // add API unique setting
        $default_value += array(
            'request_url' => base_url('callrecord_test'),
            'filename' => '2001002002-7001002001-20171206-115721-in',
        );

        // check get parameter and if exist, use it.
        $filename = $this->input->get('filename');
        if (isset($filename)) {
            $default_value['filename'] = $filename;
        }

        // prepare object
        $test['default_value'] = (object)$default_value;
        
        // load TEST screen
        $this->load->view('callrecord_test_view', $test);
    }
}
