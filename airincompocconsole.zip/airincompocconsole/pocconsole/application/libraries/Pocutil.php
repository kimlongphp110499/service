<?php if (! defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class PocUtil
{

    /**
     * ユーザーモードを返す。
     *
     * @param level Webアカウントに設定されている特権レベル。
     * @return 管理者モードのときは'admin'を、テナントモードのときは'tenant'
     * を返す。
     */
    public function get_user_mode($level)
    {
        if ($level < 10) {
            return 'admin';
        } else {
            return 'tenant';
        }
    }
}
