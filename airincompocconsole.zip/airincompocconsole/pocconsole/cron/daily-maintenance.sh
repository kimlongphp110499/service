#!/bin/sh

cd /var/www/html/pocconsole/cron

# DBバックアップ
backupdir=/root/db_backup
period="-7 days"
newname=`date '+%Y-%m-%d'`.sql
oldname=`date -d "$period" '+%Y-%m-%d'`.sql

mysqldump --defaults-extra-file=my.cnf -u root pocconf > $backupdir/$newname
rm -f $backupdir/$oldname

# DBから31日以上古い通話履歴を削除
mysql --defaults-extra-file=my.cnf -u root pocconf < delete.sql

# 90日以上古い通話音声を削除
find /mnt/pocdata/records/ -mtime +90 | xargs rm -f

