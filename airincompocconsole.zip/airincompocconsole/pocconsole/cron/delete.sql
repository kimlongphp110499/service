DELETE FROM message_all WHERE FROM_UNIXTIME(date_time / 1000) < (NOW() - INTERVAL 31 DAY);
DELETE FROM voice_message WHERE datetime < (NOW() - INTERVAL 31 DAY);
DELETE FROM geolocation_log WHERE datetime < (NOW() - INTERVAL 31 DAY);

