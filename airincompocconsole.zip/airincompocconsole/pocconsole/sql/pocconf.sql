-- phpMyAdmin SQL Dump
-- version 4.0.10.12
-- http://www.phpmyadmin.net
--
-- ホスト: localhost
-- 生成日時: 2016 年 9 月 07 日 19:56
-- サーバのバージョン: 5.1.73
-- PHP のバージョン: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- データベース: `pocconf`
--

SET FOREIGN_KEY_CHECKS=0;

-- --------------------------------------------------------

--
-- テーブルの構造 `devices`
--

DROP TABLE IF EXISTS `devices`;
CREATE TABLE `devices` (
  `device_id` smallint(6) NOT NULL AUTO_INCREMENT COMMENT 'デバイスID',
  `device_name` varchar(20) NOT NULL COMMENT 'デバイス名',
  `model` varchar(20) DEFAULT NULL COMMENT '型番',
  PRIMARY KEY (`device_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='デバイスマスタ';

-- --------------------------------------------------------

--
-- テーブルの構造 `geolocation_log`
--

DROP TABLE IF EXISTS `geolocation_log`;
CREATE TABLE `geolocation_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `poc_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `longitude` text NOT NULL,
  `latitude` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='位置情報履歴';

-- --------------------------------------------------------

--
-- テーブルの構造 `group_members`
--

DROP TABLE IF EXISTS `group_members`;
CREATE TABLE `group_members` (
  `group_id` int(11) NOT NULL COMMENT 'グループID',
  `poc_id` int(11) NOT NULL COMMENT 'PoCアカウントID',
  KEY `groupplans_FK1` (`poc_id`),
  KEY `groupplans_FK2` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='グループプラン';

-- --------------------------------------------------------

--
-- テーブルの構造 `groups`
--

DROP TABLE IF EXISTS `groups`;
CREATE TABLE `groups` (
  `group_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'グループID',
  `sip_number` varchar(10) NOT NULL COMMENT 'グループSIP番号',
  `conf_sip_number` varchar(10) NOT NULL COMMENT '会議室SIP番号',
  `group_name` varchar(50) NOT NULL COMMENT 'グループ名',
  `status` int(11) NOT NULL COMMENT '状態',
  `company_id` int(11) NOT NULL COMMENT '企業ID',
  `register_date` datetime NOT NULL COMMENT '登録日',
  `update_date` datetime NOT NULL,
  PRIMARY KEY (`group_id`,`sip_number`),
  KEY `groups_FK1` (`company_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='グループマスタ';

-- --------------------------------------------------------

--
-- テーブルの構造 `ism_configs`
--

DROP TABLE IF EXISTS `ism_configs`;
CREATE TABLE `ism_configs` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '設定ID',
  `type` enum('system','tenant','specific') NOT NULL DEFAULT 'system' COMMENT '設定種別',
  `call1` varchar(16) DEFAULT NULL COMMENT 'MODE1発信先番号',
  `call2` varchar(16) DEFAULT NULL COMMENT 'MODE2発信先番号',
  `call3` varchar(16) DEFAULT NULL COMMENT 'MODE3発信先番号',
  `geomode` int(11) NOT NULL DEFAULT '0',
  `geointerval` int(11) DEFAULT NULL COMMENT 'GPS測位間隔時間',
  `geodistance` int(11) DEFAULT NULL COMMENT 'GPS測位間隔距離',
  `callbacktimer` int(11) DEFAULT NULL COMMENT 'コールバックタイマー',
  `newvoicemail` varchar(16) DEFAULT NULL COMMENT '不在伝言再生番号',
  `novoicemail` varchar(16) DEFAULT NULL COMMENT 'ラストコール再生番号',
  `mic` int(11) DEFAULT NULL COMMENT 'マイク音量',
  `speaker` int(11) DEFAULT NULL COMMENT 'スピーカー音量',
  `gpsurl` varchar(100) DEFAULT NULL COMMENT 'GPSデータ送信先URL',
  `fw_update` tinyint(1) NOT NULL DEFAULT '0',
  `appversion` varchar(16) DEFAULT NULL COMMENT 'アプリバージョン',
  `apppath` varchar(100) DEFAULT NULL COMMENT 'アプリパス',
  `kernelversion` varchar(16) DEFAULT NULL COMMENT 'カーネルバージョン',
  `kernelpath` varchar(100) DEFAULT NULL COMMENT 'カーネルパス',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='ISM-101設定';

-- --------------------------------------------------------

--
-- テーブルの構造 `message_all`
--

DROP TABLE IF EXISTS `message_all`;
CREATE TABLE `message_all` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) DEFAULT NULL,
  `send_from` varchar(50) DEFAULT NULL,
  `send_to` varchar(50) DEFAULT NULL,
  `date_time` bigint(14) DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  `body` text,
  `filepath` varchar(50) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `to_detail` text,
  PRIMARY KEY (`id`),
  KEY `master_id` (`company_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `pocaccounts`
--

DROP TABLE IF EXISTS `pocaccounts`;
CREATE TABLE `pocaccounts` (
  `poc_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'PoCアカウントID',
  `username` varchar(16) NOT NULL COMMENT 'PoCアカウント名',
  `display_name` varchar(50) DEFAULT NULL COMMENT 'PoCアカウント表示名',
  `password` varchar(100) DEFAULT NULL COMMENT 'パスワード	 SPTアプリでのみ使用',
  `device_id` smallint(6) NOT NULL COMMENT '使用機種',
  `sip_server_domain` varchar(32) NOT NULL,
  `sip_port` int(11) NOT NULL,
  `sip_number` varchar(10) NOT NULL COMMENT 'SIP番号',
  `sip_password` varchar(16) NOT NULL,
  `ip_address` varchar(15) NOT NULL COMMENT 'IPアドレス',
  `mac_address` varchar(17) NOT NULL,
  `app_version` varchar(20) NOT NULL,
  `use_srtp` tinyint(1) NOT NULL DEFAULT '0',
  `hdy_config_id` int(11) NOT NULL,
  `ism_config_id` int(11) NOT NULL,
  `spt_config_id` int(11) NOT NULL,
  `status` int(11) NOT NULL COMMENT '状態',
  `company_id` int(11) NOT NULL COMMENT '企業ID',
  `longitude` text,
  `latitude` text,
  `geo_location` geometry DEFAULT NULL,
  `register_date` datetime NOT NULL COMMENT '登録日',
  `update_date` datetime NOT NULL,
  PRIMARY KEY (`poc_id`,`username`,`sip_number`),
  KEY `pocaccounts_FK1` (`device_id`),
  KEY `pocaccounts_FK2` (`company_id`),
  KEY `pocaccounts_FK3` (`ism_config_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='PoCアカウント';

-- --------------------------------------------------------

--
-- テーブルの構造 `spt_configs`
--

DROP TABLE IF EXISTS `spt_configs`;
CREATE TABLE `spt_configs` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `type` enum('system','tenant','specific') NOT NULL DEFAULT 'system',
  `token` varchar(10) NOT NULL,
  `gps_interval` int(11) DEFAULT NULL COMMENT 'GPSデータ送信間隔',
  `bluetooth_address` varchar(17) DEFAULT NULL,
  `bluetooth_interval` int(11) DEFAULT NULL COMMENT 'BT間隔',
  `bluetooth_rssi_threshold` int(11) DEFAULT NULL COMMENT 'BT RSSI閾値',
  `xmpp_server_domain` varchar(50) DEFAULT NULL COMMENT 'XMPPサーバーホスト名',
  `xmpp_service_name` varchar(50) DEFAULT NULL COMMENT 'XMPPサーバー名',
  `xmpp_port` int(11) DEFAULT NULL COMMENT 'XMPPポート番号',
  `xmpp_username` varchar(50) NOT NULL,
  `xmpp_password` varchar(32) NOT NULL,
  `send_image_interval` int(11) DEFAULT NULL COMMENT '画像送信間隔',
  `send_image_quality` int(11) DEFAULT NULL COMMENT '画像品質',
  `image_folder` varchar(16) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='SPT設定';

-- --------------------------------------------------------

--
-- テーブルの構造 `tenants`
--

DROP TABLE IF EXISTS `tenants`;
CREATE TABLE `tenants` (
  `company_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '企業ID',
  `sip_context_name` varchar(16) NOT NULL,
  `company_code` varchar(32) NOT NULL COMMENT 'お客様コード',
  `company_name` varchar(50) NOT NULL COMMENT '企業名',
  `company_kana` varchar(50) DEFAULT NULL COMMENT '企業名カナ',
  `contact_name` varchar(20) NOT NULL COMMENT '担当者名',
  `contact_kana` varchar(20) DEFAULT NULL COMMENT '担当者カナ',
  `contact_department` varchar(50) DEFAULT NULL COMMENT '所属部署',
  `contact_title` varchar(20) DEFAULT NULL COMMENT '役職',
  `contact_zip` varchar(8) DEFAULT NULL COMMENT '郵便番号',
  `contact_address` varchar(100) DEFAULT NULL COMMENT '住所',
  `contact_tel` varchar(15) DEFAULT NULL COMMENT '電話番号',
  `contact_email` varchar(50) NOT NULL COMMENT 'E-mail',
  `sales_staff_name` varchar(128) DEFAULT NULL COMMENT 'JKCの営業担当者名',
  `sales_staff_tel` varchar(16) DEFAULT NULL COMMENT 'JKCの営業担当者TEL',
  `sales_staff_email` varchar(128) DEFAULT NULL COMMENT 'JKCの営業担当者E-mail',
  `company_industry` varchar(48) DEFAULT NULL COMMENT '利用者の業種',
  `agent_company` varchar(50) DEFAULT NULL COMMENT '担当代理店名',
  `agent_name` varchar(20) DEFAULT NULL COMMENT '代理店担当者名',
  `agent_tel` varchar(15) DEFAULT NULL COMMENT '代理店電話番号',
  `agent_email` varchar(50) DEFAULT NULL COMMENT '代理店E-mail',
  `spt_config_id` int(11) NOT NULL,
  `ism_config_id` int(11) NOT NULL,
  `hdy_last_id` int(11) NOT NULL DEFAULT '0',
  `spt_last_id` int(11) NOT NULL DEFAULT '0',
  `ism_last_id` int(11) NOT NULL DEFAULT '0',
  `ipp_last_id` int(11) NOT NULL DEFAULT '0',
  `group_last_id` int(11) NOT NULL DEFAULT '0',
  `emergency_sip_normal` varchar(10) DEFAULT '' COMMENT '緊急SIP番号ノーマル',
  `emergency_sip_monitor` varchar(10) DEFAULT '' COMMENT '緊急SIP番号モニター',
  `emergency_sip_group` varchar(10) DEFAULT '' COMMENT '緊急SIP番号グループ',
  `register_date` datetime NOT NULL COMMENT '登録日',
  `update_date` datetime NOT NULL COMMENT '更新日',
  PRIMARY KEY (`company_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='契約企業マスタ';

-- --------------------------------------------------------

--
-- テーブルの構造 `voice_message`
--

DROP TABLE IF EXISTS `voice_message`;
CREATE TABLE `voice_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sip_number` varchar(20) NOT NULL,
  `datetime` datetime NOT NULL,
  `filename` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='不在メッセージテーブル';

-- --------------------------------------------------------

--
-- テーブルの構造 `webaccounts`
--

DROP TABLE IF EXISTS `webaccounts`;
CREATE TABLE `webaccounts` (
  `account_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'アカウントID',
  `login_id` varchar(16) NOT NULL,
  `username` varchar(16) NOT NULL COMMENT 'ユーザー名',
  `password` varchar(100) NOT NULL COMMENT 'パスワード',
  `type` enum('admin','tenant', 'tenant_api') NOT NULL DEFAULT 'tenant' COMMENT '特権レベル',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '状態',
  `company_id` int(11) NOT NULL COMMENT '企業ID',
  `token` varchar(10) DEFAULT NULL,
  `api_key` varchar(32) DEFAULT NULL COMMENT '128bit API KEY',
  `digest_hash` varchar(32) DEFAULT NULL COMMENT '128bit Digest Key hash',
  `register_date` datetime NOT NULL COMMENT '登録日',
  `update_date` datetime NOT NULL COMMENT '更新日',
  `last_login` datetime NOT NULL,
  PRIMARY KEY (`account_id`,`username`),
  KEY `webaccounts_FK1` (`company_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Webアカウント';

--
-- ダンプしたテーブルの制約
--

SET FOREIGN_KEY_CHECKS=1;

--
-- テーブルの制約 `groups`
--
ALTER TABLE `groups`
  ADD CONSTRAINT `groups_FK1` FOREIGN KEY (`company_id`) REFERENCES `tenants` (`company_id`);

--
-- テーブルの制約 `group_members`
--
ALTER TABLE `group_members`
  ADD CONSTRAINT `groupplans_FK1` FOREIGN KEY (`poc_id`) REFERENCES `pocaccounts` (`poc_id`),
  ADD CONSTRAINT `groupplans_FK2` FOREIGN KEY (`group_id`) REFERENCES `groups` (`group_id`);

--
-- テーブルの制約 `pocaccounts`
--
ALTER TABLE `pocaccounts`
  ADD CONSTRAINT `pocaccounts_FK1` FOREIGN KEY (`device_id`) REFERENCES `devices` (`device_id`),
  ADD CONSTRAINT `pocaccounts_FK2` FOREIGN KEY (`company_id`) REFERENCES `tenants` (`company_id`),
  ADD CONSTRAINT `pocaccounts_FK3` FOREIGN KEY (`ism_config_id`) REFERENCES `ism_configs` (`id`);

--
-- テーブルの制約 `webaccounts`
--
ALTER TABLE `webaccounts`
  ADD CONSTRAINT `webaccounts_FK1` FOREIGN KEY (`company_id`) REFERENCES `tenants` (`company_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
