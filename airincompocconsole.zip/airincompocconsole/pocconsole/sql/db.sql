-- テーブルの構造 `tenants`
CREATE TABLE IF NOT EXISTS `tenants` (
  `id` int(11) unsigned zerofill NOT NULL AUTO_INCREMENT COMMENT '契約企業ID',
  `code` varchar(32) NOT NULL COMMENT 'お客様コード',
  `name` varchar(255) NOT NULL COMMENT '契約企業名',
  `kana` varchar(255) DEFAULT NULL COMMENT '契約企業名(カナ)',
  `zip` varchar(8) DEFAULT NULL COMMENT '郵便番号',
  `address` varchar(255) DEFAULT NULL COMMENT '住所',
  `contact_name` varchar(128) DEFAULT NULL COMMENT '責任者名',
  `contact_kana` varchar(128) DEFAULT NULL COMMENT '責任者名(カナ)',
  `department_name` varchar(255) DEFAULT NULL COMMENT '部署名',
  `contact_tel` varchar(16) DEFAULT NULL COMMENT '電話番号',
  `contact_email` varchar(128) DEFAULT NULL COMMENT 'E-mail',
  `start_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '契約開始日',
  `end_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '契約終了日',
  `agent` varchar(255) NOT NULL COMMENT '代理店企業名',
  `agent_tel` varchar(16) DEFAULT NULL COMMENT '代理店電話番号',
  `agent_email` varchar(128) DEFAULT NULL COMMENT '代理店E-mail',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='契約企業' AUTO_INCREMENT=1;
