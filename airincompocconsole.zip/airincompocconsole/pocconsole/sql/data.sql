--
-- テーブルのデータのダンプ `tenants`
--

INSERT INTO `tenants` (sip_context_name,company_code,company_name,contact_name,contact_email,spt_config_id,ism_config_id,register_date,update_date) values ('system',0,'システム','','',0,0,0,0);

--
-- テーブルのデータのダンプ `webaccounts`
--

INSERT INTO `webaccounts` (`login_id`, `username`, `password`, `type`, `status`, `company_id`, `register_date`,`update_date`,`last_login`) VALUES ('admin', 'システム管理者', MD5('iforce8880'), 'admin', 1, 1, 0, 0, 0);

--
-- テーブルのデータのダンプ `spt_configs`
--

INSERT INTO `spt_configs` (`type`, `token`, `gps_interval`, `xmpp_server_domain`, `xmpp_service_name`, `xmpp_port`, `xmpp_username`, `xmpp_password`, `send_image_interval`, `send_image_quality`, `image_folder`) VALUES ('system', '', 60000, 'xmpp2.iforce.ne.jp', 'xmpp.iforce.ne.jp', 5222,'','', 10000, 50, '');

--
-- テーブルのデータのダンプ `ism_configs`
--

INSERT INTO `ism_configs` (`type`, `geointerval`, `geodistance`, `callbacktimer`, `newvoicemail`, `novoicemail`, `mic`, `speaker`, `gpsurl`, `appversion`, `apppath`, `kernelversion`, `kernelpath`) VALUES
('system', 60, 100, 30, '103', '104', 14, 14, 'http://prov1-ptt.iforce.ne.jp:1337/Geolocation/post', '001000040', 'http://config.ism.iforce.ne.jp/ism-101/fw/IP-T10_Application_v1.00.40.bin', '001005002', 'http://config.ism.iforce.ne.jp/ism-101/fw/Kernel001005002.bin');

--
-- テーブルのデータのダンプ `devices`
--

INSERT INTO `devices` (`device_name`, `model`) VALUES
('SPTアプリ', NULL),
('ISM-101', 'ISM-101'),
('IPフォン', NULL),
('新型ハンディ機', NULL);
