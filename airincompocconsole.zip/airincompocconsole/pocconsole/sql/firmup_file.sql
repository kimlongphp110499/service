-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 2018 年 3 朁E12 日 06:15
-- サーバのバージョン： 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pocconf`
--

-- --------------------------------------------------------

--
-- テーブルの構造 `firmup_file`
--

CREATE TABLE `firmup_file` (
  `id` int(11) NOT NULL COMMENT 'Index',
  `company_id` int(11) NOT NULL COMMENT 'テナント番号',
  `firm_name` varchar(128) NOT NULL COMMENT 'ファームウエアファイル名',
  `device_name` varchar(32) NOT NULL COMMENT '機種名',
  `firm_version` varchar(128) DEFAULT NULL COMMENT '登録中バージョン',
  `flag` tinyint(1) NOT NULL COMMENT '有効フラグ',
  `register_date` datetime DEFAULT NULL COMMENT '登録日',
  `validity_from` datetime DEFAULT NULL COMMENT '有効期限FROM',
  `validity_to` datetime DEFAULT NULL COMMENT '有効期限TO'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ファームアップ用ファイル登録テーブル';


--
-- Indexes for table `firmup_file`
--
ALTER TABLE `firmup_file`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `firmup_file_FK1` (`company_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `firmup_file`
--
ALTER TABLE `firmup_file`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Index';
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
