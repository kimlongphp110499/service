-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 2018 年 3 朁E08 日 10:46
-- サーバのバージョン： 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pocconf`
--

-- --------------------------------------------------------

--
-- テーブルの構造 `firmup_macaddr`
--

CREATE TABLE `firmup_macaddr` (
  `id` int(11) NOT NULL COMMENT 'Index',
  `macaddr` varchar(12) NOT NULL COMMENT 'MACアドレス',
  `firmup_file_id` int(11) NOT NULL COMMENT 'ファームアップファイルテーブルのIndex',
  `last_connect` datetime DEFAULT NULL COMMENT 'API接続日時',
  `last_update` datetime DEFAULT NULL COMMENT 'ファームウエア更新日時',
  `firm_version` varchar(128) NOT NULL COMMENT '現在のバージョン文字列'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='MACアドレステーブル';

--
-- Indexes for dumped tables
--

--
-- Indexes for table `firmup_macaddr`
--
ALTER TABLE `firmup_macaddr`
  ADD PRIMARY KEY (`id`,`macaddr`) USING BTREE,
  ADD KEY `firmup_macaddr_FK1` (`firmup_file_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `firmup_macaddr`
--
ALTER TABLE `firmup_macaddr`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Index';
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
