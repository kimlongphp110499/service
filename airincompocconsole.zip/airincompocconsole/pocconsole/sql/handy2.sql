--
-- テーブルの構造 `hdy_configs`
--


DROP TABLE IF EXISTS `hdy_configs`;
CREATE TABLE `hdy_configs` (
  --  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
    `id` int(11) NOT NULL COMMENT 'ID',

-- 種類  factory : 工場出荷時設定(adminアカウントのみ操作可能), singleton
--       tenant_admin : 新規テナント用初期設定(adminアカウントのみ操作可能), singleton      
--       device_admin : 新規デバイス用初期設定(adminアカウントのみ操作可能), singleton
--       tenant : テナント設定(テナントアカウントのみ操作可能、テナント作成時にtenant_adminをコピー), x tenant数
--       device_tenant : デバイス設定のテナント用テンプレート(テナントアカウントのみ操作可能、テナント作成時にdevice_adminをコピー), x tenant数
--       device : 個別デバイス設定(adminアカウントとテナントアカウントが操作可能, PoCアカウント作成時にdevice_tenantをコピー), x 新型ハンディのPoCアカウント数
--      
  `type` enum('factory','tenant_admin','device_admin','tenant','device_tenant','device') NOT NULL DEFAULT 'device',

-- tenantsテーブルのインデックス値(または0 : factory or tenant_admin or device_admin時)
-- 0 の場合もあるので外部キーにはしない
	`company_id` int(11) NOT NULL DEFAULT '0' COMMENT 'tenantテーブルのインデックス値',

-- 更新日は自動設定
--	`last_update`	datetime	 NOT NULL COMMENT '更新日',
  update_date	datetime	 NOT NULL COMMENT '更新日',

-- 最終APIログイン
  last_login	datetime	NOT NULL COMMENT '最終APIログイン',

-- コメント
	`comment` varchar(384) DEFAULT NULL COMMENT 'コメント',

-- システム情報
FW_flag	tinyint(1)	NOT NULL DEFAULT '0' COMMENT 'ファーム更新設定（自動ファームウェアアップデートフラグ設定）',
App_ver	varchar(128)	DEFAULT NULL COMMENT 'アプリケーションバージョン',
App_path	varchar(256)	DEFAULT NULL COMMENT 'アプリケーションパス',
Kernel_ver	varchar(128)	DEFAULT NULL COMMENT 'カーネルバージョン',
Kernel_path	varchar(256)	DEFAULT NULL COMMENT 'カーネルパス',
mod_flag	tinyint(1)	NOT NULL DEFAULT '0' COMMENT 'モジュールファーム更新設定（自動ファームウェアアップデート）',
mod_ver	varchar(128)	DEFAULT NULL COMMENT 'モジュールファームバージョン',
mod_path	varchar(256)	DEFAULT NULL COMMENT 'モジュールファームパス',
sim	tinyint(1)	DEFAULT '0' COMMENT 'SIMカード種別',

-- システム設定
battery_save	tinyint(1)	NOT NULL DEFAULT '0' COMMENT 'Battery Saver設定',
mode_req_timer	int(11)	NOT NULL DEFAULT '0' COMMENT 'Mode Reset Timer設定',
clock	tinyint(1)	NOT NULL DEFAULT '1' COMMENT 'Clock設定',
pri_wifi	tinyint(1)	NOT NULL DEFAULT '0' COMMENT 'Private Wi-Fi ON/OFF',
voice_info	tinyint(1)	NOT NULL DEFAULT '0' COMMENT '音声案内設定',
key_info	tinyint(1)	NOT NULL DEFAULT '1' COMMENT '暗号鍵情報',

-- SIP設定
prefix_lte	tinyint(1)	NOT NULL DEFAULT '5' COMMENT 'Prefix（LTE）',
rtp_discard	tinyint(1)	NOT NULL DEFAULT '0' COMMENT 'RTP discard',
rtp_delay	int(11)	NOT NULL DEFAULT '1000' COMMENT 'RTP delay',
ping_interval	int(11)	NOT NULL DEFAULT '60' COMMENT 'PING interval',
registar_interval	int(11)	NOT NULL DEFAULT '3600' COMMENT 'REGISTER interval',
prefix_wifi	tinyint(1)	NOT NULL DEFAULT '5' COMMENT 'Prefix（WiFi）',
register_interval_pri_wifi	int(11)	NOT NULL DEFAULT '3600' COMMENT 'REGISTER interval （WiFi）',

-- POCアカウント情報
disp_name	varchar(384)	DEFAULT NULL COMMENT '表示名',
sip_id	varchar(128)	DEFAULT NULL COMMENT 'SIP番号',
sip_password	varchar(128)	DEFAULT NULL COMMENT 'SIPパスワード',
sip_server_domain	varchar(256)	DEFAULT NULL COMMENT 'SIPサーバードメイン',
sip_server_port	int(11)	DEFAULT NULL COMMENT 'SIPサーバーポート番号',
xmpp_server_host	varchar(128)	DEFAULT NULL COMMENT 'XMPPサーバーホスト名',
xmpp_server_port	int(11)	DEFAULT NULL COMMENT 'XMPPポート番号',
xmpp_service	varchar(128)	DEFAULT NULL COMMENT 'XMPPサービス',
xmpp_user_name	varchar(128)	DEFAULT NULL COMMENT 'XMPPユーザー名',
xmpp_password	varchar(128)	DEFAULT NULL COMMENT 'XMPPパスワード',
-- voice_encryption	tinyint(1)	NOT NULL DEFAULT '0',
terminal_name	varchar(128)	DEFAULT NULL COMMENT '使用機種',
user_login_id	varchar(128)	NOT NULL COMMENT 'PoCアカウントID',
user_login_password	varchar(128)	DEFAULT NULL COMMENT 'PoCアカウントパスワード',
unattended_rec_id	varchar(128)	DEFAULT NULL COMMENT '不在伝言再生番号',
lastcall_id	varchar(128)	DEFAULT NULL COMMENT 'ラストコール再生番号',

-- テナント情報
company_name	varchar(384)	DEFAULT NULL COMMENT '会社名',

-- Ｗｅｂアカウント情報
web_account_login_id	varchar(128)	DEFAULT NULL COMMENT 'ログインID',
web_account_login_password	varchar(128)	DEFAULT NULL COMMENT 'パスワード',

-- Wi-Fi設定
pri_ap_mode	tinyint(1)	NOT NULL DEFAULT '0' COMMENT 'WiFi Mode',
pri_wifi_nw_mode	tinyint(1)	NOT NULL DEFAULT '2' COMMENT 'WiFi ネットワークモード',
pri_wifi_ssid	varchar(128)	DEFAULT NULL COMMENT 'WiFi SSID',
pri_wifi_password	varchar(128)	DEFAULT NULL COMMENT 'WiFi Password',
pri_wifi_transparent	tinyint(1)	NOT NULL DEFAULT '0' COMMENT 'テザリングの許可フラグ',

-- GPS設定
gps_conf_interval	int(11)	NOT NULL DEFAULT '1' COMMENT 'GPS測位間隔時間',
gps_server_url	varchar(100)	DEFAULT NULL COMMENT 'GPSデータ送信先URL',
gps_mode	tinyint(1)	NOT NULL DEFAULT '0' COMMENT '位置測位方式',
gps_server_interval	int(11)	NOT NULL DEFAULT '60' COMMENT 'GPSデータ送信間隔',
gps_distance	int(11)	NOT NULL DEFAULT '100' COMMENT 'GPSデータ送信距離間隔',

-- 通話設定
lte_callback_timer	int(11)	NOT NULL DEFAULT '30' COMMENT 'Callback Timer（LTE）',
lte_time_out_timer	int(11)	NOT NULL DEFAULT '300' COMMENT 'Time-out-Timer設定（LTE）',
lte_time_out_time_rekey	int(11)	NOT NULL DEFAULT '0' COMMENT 'Time-out-Time Rekey Time(LTE)',
wifi_callback_timer	int(11)	NOT NULL DEFAULT '30' COMMENT 'Callback Timer（WiFi）',
wifi_time_out_timer	int(11)	NOT NULL DEFAULT '60' COMMENT 'Time-out-Timer設定（WiFi）',
wifi_time_out_time_rekey	int(11)	NOT NULL DEFAULT '0' COMMENT 'Time-out-Time Rekey Time(WiFi)',
lte_jitter_buf	int(11)	NOT NULL DEFAULT '100' COMMENT 'ジッター・バッファー設定（パケット揺らぎ抑制）LTE',
wifi_jitter_buf	int(11)	NOT NULL DEFAULT '100' COMMENT 'ジッター・バッファー設定（パケット揺らぎ抑制）Wi-Fi',
handsfree_mode tinyint(1) NOT NULL DEFAULT '0' COMMENT 'ハンズフリーモード',
handsfree_timeout_timer int(11) NOT NULL DEFAULT '300' COMMENT 'Time-out-Timer設定(ハンズフリーモード時)',

-- 画像品質設定
-- picture_interval	int(11)	NOT NULL DEFAULT '60' COMMENT '画像送信間隔',
-- picture_quality	int(11)	NOT NULL DEFAULT '100' COMMENT '画像品質',

-- 通話音設定
silent_alarm	tinyint(1)	NOT NULL DEFAULT '0' COMMENT 'Silent Alarm設定',
lte_alarm_connect	tinyint(1)	NOT NULL DEFAULT '1' COMMENT '接続通知音（LTE）',
pri_wifi_alarm_connect	tinyint(1)	NOT NULL DEFAULT '1' COMMENT '接続通知音（WiFi）',
lte_alarm_connect_mode	tinyint(1)	NOT NULL DEFAULT '1' COMMENT '接続通知音可否設定（LTE）',
pri_wifi_alarm_connect_mode	tinyint(1)	NOT NULL DEFAULT '1' COMMENT '接続通知音可否設定（WiFi）',
lte_alarm_connect_fail_type	tinyint(1)	NOT NULL DEFAULT '2' COMMENT '失敗通知音種別（LTE）',
pri_wifi_alarm_connect_fail_type	tinyint(1)	NOT NULL DEFAULT '2' COMMENT '失敗通知音種別（WiFi）',
lte_alarm_connect_fail_mode	tinyint(1)	NOT NULL DEFAULT '1' COMMENT '失敗通知音可否設定（LTE）',
pri_wifi_alarm_connect_fail_mode	tinyint(1)	NOT NULL DEFAULT '1' COMMENT '失敗通知音可否設定（WiFi）',
lte_ind_call_start	tinyint(1)	NOT NULL DEFAULT '1' COMMENT '音声送信開始通知音種別（Individual Call）',
lte_group_call_start	tinyint(1)	NOT NULL DEFAULT '1' COMMENT '音声送信開始通知音種別（Group Call）',
lte_all_call_start	tinyint(1)	NOT NULL DEFAULT '1' COMMENT '音声送信開始通知音種別（All Call）',
lte_telephone_call_start	tinyint(1)	NOT NULL DEFAULT '1' COMMENT '音声送信開始通知音種別（Telephone Call）',
pri_wifi_ind_call_start	tinyint(1)	NOT NULL DEFAULT '1' COMMENT '音声送信開始通知音種別（Wi-Fi Individual Call）',
pri_wifi_group_call_start	tinyint(1)	NOT NULL DEFAULT '1' COMMENT '音声送信開始通知音種別（WiFi Group Call）',
pri_wifi_all_call_start	tinyint(1)	NOT NULL DEFAULT '1' COMMENT '音声送信開始通知音種別（WiFi All Call）',
lte_ind_call_end	tinyint(1)	NOT NULL DEFAULT '1' COMMENT '音声送信終了通知音種別（Individual Call）',
lte_group_call_end	tinyint(1)	NOT NULL DEFAULT '1' COMMENT '音声送信終了通知音種別（Group Call）',
lte_all_call_end	tinyint(1)	NOT NULL DEFAULT '1' COMMENT '音声送信終了通知音種別（All Call）',
lte_telephone_call_end	tinyint(1)	NOT NULL DEFAULT '1' COMMENT '音声送信終了通知音種別（Telephone Call）',
pri_wifi_ind_call_end	tinyint(1)	NOT NULL DEFAULT '1' COMMENT '音声送信終了通知音種別（WiFi Individual Call）',
pri_wifi_group_call_end	tinyint(1)	NOT NULL DEFAULT '1' COMMENT '音声送信終了通知音種別（WiFi Group Call）',
pri_wifi_all_call_end	tinyint(1)	NOT NULL DEFAULT '1' COMMENT '音声送信終了通知音種別（WiFi All Call）',
lte_ind_income_type	tinyint(1)	NOT NULL DEFAULT '1' COMMENT '音声受信通知音種別（Individual Call）',
lte_group_income_type	tinyint(1)	NOT NULL DEFAULT '1' COMMENT '音声受信通知音種別（Group Call）',
lte_all_call_income_type	tinyint(1)	NOT NULL DEFAULT '1' COMMENT '音声受信通知音種別（All Call）',
lte_telephone_income_type	tinyint(1)	NOT NULL DEFAULT '1' COMMENT '音声受信通知音種別（Telephone Call）',
lte_message_income_type	tinyint(1)	NOT NULL DEFAULT '1' COMMENT '音声受信通知音種別（Status/Message Call）',
lte_emergency_income_type	tinyint(1)	NOT NULL DEFAULT '1' COMMENT '音声受信通知音種別（Emergency Response）',
pri_wifi_ind_income_type	tinyint(1)	NOT NULL DEFAULT '1' COMMENT '音声受信通知音種別（WiFi Individual Call）',
pri_wifi_income_type	tinyint(1)	NOT NULL DEFAULT '1' COMMENT '音声受信通知音種別（WiFi Group Call）',
pri_wifi_all_call_income_type	tinyint(1)	NOT NULL DEFAULT '1' COMMENT '音声受信通知音種別（WiFi All Call）',
pri_wifi_emergency_income_type	tinyint(1)	NOT NULL DEFAULT '1' COMMENT '音声受信通知音種別（WiFi Emergency Response）',
continuous_call_mode	tinyint(1)	NOT NULL DEFAULT '0' COMMENT '音声受信通知音種別（連続呼出時のAlert Tone可否設定）',
lte_ind_income_end_type	tinyint(1)	NOT NULL DEFAULT '1' COMMENT '音声受信終了通知音種別（Individual Call）',
lte_group_income_end_type	tinyint(1)	NOT NULL DEFAULT '1' COMMENT '音声受信終了通知音種別（Group Call）',
lte_all_call_income_end_type	tinyint(1)	NOT NULL DEFAULT '1' COMMENT '音声受信終了通知音種別（All Call）',
lte_telephone_call_income_end_type	tinyint(1)	NOT NULL DEFAULT '1' COMMENT '音声受信終了通知音種別（Telephone Call）',
pri_wifi_ind_income_end_type	tinyint(1)	NOT NULL DEFAULT '1' COMMENT '音声受信終了通知音種別（WiFi Individual Call）',
pri_wifi_group_income_end_type	tinyint(1)	NOT NULL DEFAULT '1' COMMENT '音声受信終了通知音種別（WiFi Group Call）',
pri_wifi_all_call_income_end_type	tinyint(1)	NOT NULL DEFAULT '1' COMMENT '音声受信終了通知音種別（WiFi All Call）',
lte_ind_income_alermtime	tinyint(1)	NOT NULL DEFAULT '3' COMMENT '音声受信通知音回数設定（Individual Call）',
lte_group_income_alermtime	tinyint(1)	NOT NULL DEFAULT '3' COMMENT '音声受信通知音回数設定（Group Call）',
lte_all_call_income_alermtime	tinyint(1)	NOT NULL DEFAULT '3' COMMENT '音声受信通知音回数設定（All Call）',
lte_telephone_call_income_alermtime	tinyint(1)	NOT NULL DEFAULT '3' COMMENT '音声受信通知音回数設定（Telephone Call）',
lte_message_income_alermtime	tinyint(1)	NOT NULL DEFAULT '3' COMMENT '音声受信通知音回数設定（Status/Message Call）',
lte_emergency_income_alermtime	tinyint(1)	NOT NULL DEFAULT '3' COMMENT '音声受信通知音回数設定（Emergency Response）',
pri_wifi_ind_income_alermtime	tinyint(1)	NOT NULL DEFAULT '3' COMMENT '音声受信通知音回数設定（WiFi Individual Call）',
pri_wifi_group_income_alermtime	tinyint(1)	NOT NULL DEFAULT '3' COMMENT '音声受信通知音回数設定（WiFi Group Call）',
pri_wifi_all_call_income_alermtime	tinyint(1)	NOT NULL DEFAULT '3' COMMENT '音声受信通知音回数設定（WiFi All Call）',
pri_wifi_emergency_income_alermtime	tinyint(1)	NOT NULL DEFAULT '3' COMMENT '音声受信通知音回数設定（WiFi Emergency Response）',
lte_out_service_type	tinyint(1)	NOT NULL DEFAULT '3' COMMENT '通信圏内/圏外通知音種別（LTE）',
pri_wifi_out_service_type	tinyint(1)	NOT NULL DEFAULT '5' COMMENT '通信圏内/圏外通知音種別（WiFi）',

-- スピーカー音量設定
speaker_min_vol	tinyint(1)	NOT NULL DEFAULT '0' COMMENT 'スピーカー最小音量',
speaker_max_vol	tinyint(1)	NOT NULL DEFAULT '31' COMMENT 'スピーカー最大音量',
speaker_tone_vol	tinyint(1)	NOT NULL DEFAULT '10' COMMENT 'スピーカートーン音量',
speaker_tone_offset	tinyint(1)	NOT NULL DEFAULT '0' COMMENT 'スピーカートーン音量オフセット',
speaker_lte_vib	tinyint(1)	NOT NULL DEFAULT '0' COMMENT '音声受信通知動作(LTE)',
speaker_pri_wifi_vib	tinyint(1)	NOT NULL DEFAULT '0' COMMENT '音声受信通知動作(WiFi)',
speaker_lte_income	tinyint(1)	NOT NULL DEFAULT '10' COMMENT '音声受信通知音量(LTE)',
speaker_pri_wifi_income	tinyint(1)	NOT NULL DEFAULT '10' COMMENT '音声受信通知音量(WiFi)',
speaker_alerm_vol	tinyint(1)	NOT NULL DEFAULT '10' COMMENT 'アラーム音量',
speaker_lte_data	tinyint(1)	NOT NULL DEFAULT '0' COMMENT 'データ受信通知動作(LTE)',
speaker_pri_wifi_data	tinyint(1)	NOT NULL DEFAULT '0' COMMENT 'データ受信通知動作(WiFi)',

-- オーディオ設定
audio_mic_type	tinyint(1)	NOT NULL DEFAULT '0' COMMENT 'マイク種別',
audio_mic_gain	tinyint(1)	NOT NULL DEFAULT '0' COMMENT 'マイクゲイン',
audio_speaker_att	tinyint(1)	NOT NULL DEFAULT '0' COMMENT 'Speaker Attenuation',
audio_gain_rx	tinyint(1)	NOT NULL DEFAULT '0' COMMENT 'Auto Gain Control (RX Audio Response)',
audio_gain_tx	tinyint(1)	NOT NULL DEFAULT '1' COMMENT 'Auto Gain Control (TX Audio Response)',
audio_key_op	tinyint(1)	NOT NULL DEFAULT '1' COMMENT 'キー操作音可否',
audio_echo_can	tinyint(1)	NOT NULL DEFAULT '1' COMMENT 'エコーキャンセラー',
audio_noise_can	tinyint(1)	NOT NULL DEFAULT '1' COMMENT 'ノイズキャンセラー',

-- キー設定
key_lock	tinyint(1)	NOT NULL DEFAULT '0' COMMENT 'キーロック設定',
key_lock_front	tinyint(1)	NOT NULL DEFAULT '1' COMMENT 'キーロック対象設定(Front Key)',
key_lock_topside	tinyint(1)	NOT NULL DEFAULT '1' COMMENT 'キーロック対象設定(Top/Side Key)',
key_lock_volume	tinyint(1)	NOT NULL DEFAULT '1' COMMENT 'キーロック対象設定(Volume)',
key_lock_ptt	tinyint(1)	NOT NULL DEFAULT '1' COMMENT 'キーロック対象設定(PTT Key)',
key_lock_mic	tinyint(1)	NOT NULL DEFAULT '1' COMMENT 'キーロック対象設定(Mic Key)',
auto_key_lock_timer	tinyint(1)	NOT NULL DEFAULT '0' COMMENT 'Auto Key Lock Timer',
key_tone_vol	tinyint(1)	NOT NULL DEFAULT '10' COMMENT 'キー操作音量設定',
backlight_mode	tinyint(1)	NOT NULL DEFAULT '1' COMMENT 'バックライト設定',
backlight_timer	tinyint(1)	NOT NULL DEFAULT '5' COMMENT 'バックライトタイマー設定',
key_p1_sp	tinyint(1)	NOT NULL DEFAULT '23' COMMENT 'P1キー設定情報（ShortPressKey)',
key_p1_df	tinyint(1)	DEFAULT NULL COMMENT 'P1キー設定情報（DoubleFunctionKey)',
key_p1_lp	tinyint(1)	NOT NULL DEFAULT '22' COMMENT 'P1キー設定情報（LongPressKey)',
key_p2_sp	tinyint(1)	NOT NULL DEFAULT '24' COMMENT 'P2キー設定情報（ShortPressKey)',
key_p2_df	tinyint(1)	DEFAULT NULL COMMENT 'P2キー設定情報（DoubleFunctionKey)',
key_p2_lp	tinyint(1)	DEFAULT NULL COMMENT 'P2キー設定情報（LongPressKey)',
key_p3_sp	tinyint(1)	DEFAULT NULL COMMENT 'P3キー設定情報（ShortPressKey)',
key_p3_df	tinyint(1)	DEFAULT NULL COMMENT 'P3キー設定情報（DoubleFunctionKey)',
key_p3_lp	tinyint(1)	DEFAULT NULL COMMENT 'P3キー設定情報（LongPressKey)',
key_p4_sp	tinyint(1)	DEFAULT NULL COMMENT 'P4キー設定情報（ShortPressKey)',
key_p4_df	tinyint(1)	DEFAULT NULL COMMENT 'P4キー設定情報（DoubleFunctionKey)',
key_p4_lp	tinyint(1)	DEFAULT NULL COMMENT 'P4キー設定情報（LongPressKey)',
key_s1_sp	tinyint(1)	NOT NULL DEFAULT '19' COMMENT 'S1キー設定情報（ShortPressKey)',
key_s1_df	tinyint(1)	DEFAULT NULL COMMENT 'S1キー設定情報（DoubleFunctionKey)',
key_s1_lp	tinyint(1)	DEFAULT NULL COMMENT 'S1キー設定情報（LongPressKey)',
key_s2_sp	tinyint(1)	NOT NULL DEFAULT '4' COMMENT 'S2キー設定情報（ShortPressKey)',
key_s2_df	tinyint(1)	DEFAULT NULL COMMENT 'S2キー設定情報（DoubleFunctionKey)',
key_s2_lp	tinyint(1)	DEFAULT NULL COMMENT 'S2キー設定情報（LongPressKey)',
key_u1_sp	tinyint(1)	NOT NULL DEFAULT '7' COMMENT 'U1キー設定情報（ShortPressKey)',
key_u1_df	tinyint(1)	DEFAULT NULL COMMENT 'U1キー設定情報（DoubleFunctionKey)',
key_u1_lp	tinyint(1)	NOT NULL DEFAULT '8' COMMENT 'U1キー設定情報（LongPressKey)',
key_d1_sp	tinyint(1)	NOT NULL DEFAULT '5' COMMENT 'D1キー設定情報（ShortPressKey)',
key_d1_df	tinyint(1)	DEFAULT NULL COMMENT 'D1キー設定情報（DoubleFunctionKey)',
key_d1_lp	tinyint(1)	NOT NULL DEFAULT '6' COMMENT 'D1キー設定情報（LongPressKey)',
key_aux_sp	tinyint(1)	DEFAULT NULL COMMENT 'AUXキー設定情報（ShortPressKey)',
key_aux_df	tinyint(1)	DEFAULT NULL COMMENT 'AUXキー設定情報（DoubleFunctionKey)',
key_aux_lp	tinyint(1)	NOT NULL DEFAULT '2' COMMENT 'AUXキー設定情報（LongPressKey)',

-- ディスプレイ設定
display_pwon_text	varchar(384)	DEFAULT NULL COMMENT 'Power-on Text設定',
display_pwon_mode	tinyint(1)	NOT NULL DEFAULT '1' COMMENT 'Power-on Mode No.設定',
display_screen_logo_url	tinyint(1)	NOT NULL DEFAULT '0' COMMENT 'Custom Start-up Screen設定',
display_battery_flag	tinyint(1)	NOT NULL DEFAULT '1' COMMENT 'Battery Indicator　/　Warning　設定',
display_battery_warning	tinyint(1)	NOT NULL DEFAULT '1' COMMENT 'Battery Warning Tone設定',
display_message_mode	tinyint(1)	NOT NULL DEFAULT '1' COMMENT 'Status/Message表示動作設定',
display_income_mode	tinyint(1)	NOT NULL DEFAULT '1' COMMENT 'Caller No. Display設定',
display_keylock_icon	tinyint(1)	NOT NULL DEFAULT '1' COMMENT 'Key Lock Icon設定',
display_alert_led_mode	tinyint(1)	NOT NULL DEFAULT '0' COMMENT 'Selective Call Alert LED可否設定',
display_lcd_contrast	tinyint(1)	NOT NULL DEFAULT '10' COMMENT 'LCDコントラスト',

-- 定型メッセージリスト
message_list_m1	varchar(384)	DEFAULT NULL COMMENT 'メッセージ１',
message_list_m2	varchar(384)	DEFAULT NULL COMMENT 'メッセージ２',
message_list_m3	varchar(384)	DEFAULT NULL COMMENT 'メッセージ３',
message_list_m4	varchar(384)	DEFAULT NULL COMMENT 'メッセージ４',
message_list_m5	varchar(384)	DEFAULT NULL COMMENT 'メッセージ５',
message_list_m6	varchar(384)	DEFAULT NULL COMMENT 'メッセージ６',
message_list_m7	varchar(384)	DEFAULT NULL COMMENT 'メッセージ７',
message_list_m8	varchar(384)	DEFAULT NULL COMMENT 'メッセージ８',
message_list_m9	varchar(384)	DEFAULT NULL COMMENT 'メッセージ９',
message_list_m10	varchar(384)	DEFAULT NULL COMMENT 'メッセージ１０',
message_list_m11	varchar(384)	DEFAULT NULL COMMENT 'メッセージ１１',
message_list_m12	varchar(384)	DEFAULT NULL COMMENT 'メッセージ１２',
message_list_m13	varchar(384)	DEFAULT NULL COMMENT 'メッセージ１３',
message_list_m14	varchar(384)	DEFAULT NULL COMMENT 'メッセージ１４',
message_list_m15	varchar(384)	DEFAULT NULL COMMENT 'メッセージ１５',
message_list_m16	varchar(384)	DEFAULT NULL COMMENT 'メッセージ１６',
message_list_m17	varchar(384)	DEFAULT NULL COMMENT 'メッセージ１７',
message_list_m18	varchar(384)	DEFAULT NULL COMMENT 'メッセージ１８',
message_list_m19	varchar(384)	DEFAULT NULL COMMENT 'メッセージ１９',
message_list_m20	varchar(384)	DEFAULT NULL COMMENT 'メッセージ２０',

-- ステータスホールド設定
status_hold_mode	tinyint(1)	NOT NULL DEFAULT '0' COMMENT 'Status Hold動作設定',

-- エマージェンシー設定
emergency_mode_number	tinyint(1)	NOT NULL DEFAULT '2' COMMENT 'Emergency Mode No. ',
emergency_cycle	int(11)	NOT NULL DEFAULT '-1' COMMENT 'Emergency Cycle',
emergency_t1_duration	int(11)	NOT NULL DEFAULT '5' COMMENT 'Duration of Locator Tone1',
emergency_transmit_duration	int(11)	NOT NULL DEFAULT '20' COMMENT 'Transmit Duration',
emergency_t2_duration	int(11)	NOT NULL DEFAULT '5' COMMENT 'Duration of Locator Tone 2',
emergency_recieve_duration	int(11)	NOT NULL DEFAULT '40' COMMENT 'Receive Duration',
emergency_locator_tone	tinyint(1)	NOT NULL DEFAULT '2' COMMENT 'Locator Tone',
emergency_mode_type	tinyint(1)	NOT NULL DEFAULT '0' COMMENT 'Emergency Mode Type',
emergency_led	tinyint(1)	NOT NULL DEFAULT '0' COMMENT 'Emergency LED',
emergency_display	tinyint(1)	NOT NULL DEFAULT '0' COMMENT 'Emergency Display',
emergency_text	varchar(16)	DEFAULT NULL COMMENT 'Emergency Text',
emergency_key_delay_time	varchar(16)	NOT NULL DEFAULT '1.0' COMMENT 'Emergency-key Delay Time',
emergency_mic_sense	tinyint(1)	NOT NULL DEFAULT '4' COMMENT 'Emergency Mic Sense',
emergency_bg_transmit	tinyint(1)	NOT NULL DEFAULT '0' COMMENT 'Background Transmission',
emergency_lone_interval	int(11)	NOT NULL DEFAULT '10' COMMENT 'Lone Worker Interval',
emergency_lone_duration	int(11)	NOT NULL DEFAULT '10' COMMENT 'Duration of Lone Worker Tone',
emergency_man_flag	tinyint(1)	NOT NULL DEFAULT '0' COMMENT 'Man-down Detection',
emergency_man_delay_time	int(11)	NOT NULL DEFAULT '10' COMMENT 'Man-down Delay Time',
emergency_man_pre_alert	int(11)	NOT NULL DEFAULT '5' COMMENT 'Man-down Pre-alert',
emergency_man_angle	int(11)	NOT NULL DEFAULT '60' COMMENT 'Man-down Angle',
emergency_stationary_flag	tinyint(1)	NOT NULL DEFAULT '0' COMMENT 'Stationary Detection',
emergency_stationary_delay_time	int(11)	NOT NULL DEFAULT '120' COMMENT 'Stationary Delay Time',
emergency_stationary_pre_alert	int(11)	NOT NULL DEFAULT '10' COMMENT 'Stationary Pre-alert',
emergency_motion_flag	tinyint(1)	NOT NULL DEFAULT '0' COMMENT 'Motion Detection',
emergency_motion_delay_time	int(11)	NOT NULL DEFAULT '10' COMMENT 'Motion Delay Time',
emergency_motion_pre_alert	int(11)	NOT NULL DEFAULT '5' COMMENT 'Motion Pre-alert',
emergency_remote_flag	tinyint(1)	NOT NULL DEFAULT '0' COMMENT 'Remote Monitor機能可否設定',

-- 履歴設定
history_timestamp	tinyint(1)	NOT NULL DEFAULT '0' COMMENT '時刻情報付加設定',
history_call	tinyint(1)	NOT NULL DEFAULT '1' COMMENT '発着信履歴情報',
history_income	tinyint(1)	NOT NULL DEFAULT '1' COMMENT '着信履歴',
history_outcome	tinyint(1)	NOT NULL DEFAULT '1' COMMENT '発信履歴',
history_message_in	tinyint(1)	NOT NULL DEFAULT '1' COMMENT 'メッセージ着信履歴',
history_message_out	tinyint(1)	NOT NULL DEFAULT '1' COMMENT 'メッセージ送信履歴',
history_call_list	varchar(256)	DEFAULT NULL COMMENT '発着信履歴　リスト',
history_income_list	varchar(256)	DEFAULT NULL COMMENT '着信履歴　リスト',
history_outcome_list	varchar(256)	DEFAULT NULL COMMENT '発信履歴　リスト',
history_message_in_list	varchar(256)	DEFAULT NULL COMMENT 'メッセージ着信履歴　リスト',
history_message_out_list	varchar(256)	DEFAULT NULL COMMENT 'メッセージ送信履歴　リスト',

-- カスタム設定
custom1	tinyint(1)	DEFAULT NULL COMMENT 'カスタム１',
custom2	tinyint(1)	DEFAULT NULL COMMENT 'カスタム２',
custom3	tinyint(1)	DEFAULT NULL COMMENT 'カスタム３',
custom4	tinyint(1)	DEFAULT NULL COMMENT 'カスタム４',
custom5	tinyint(1)	DEFAULT NULL COMMENT 'カスタム５',
custom6	tinyint(1)	DEFAULT NULL COMMENT 'カスタム６',
custom7	tinyint(1)	DEFAULT NULL COMMENT 'カスタム７',
custom8	tinyint(1)	DEFAULT NULL COMMENT 'カスタム８',
custom9	tinyint(1)	DEFAULT NULL COMMENT 'カスタム９',
custom10	tinyint(1)	DEFAULT NULL COMMENT 'カスタム１０',
custom11	tinyint(1)	DEFAULT NULL COMMENT 'カスタム１１',
custom12	tinyint(1)	DEFAULT NULL COMMENT 'カスタム１２',
custom13	tinyint(1)	DEFAULT NULL COMMENT 'カスタム１３',
custom14	tinyint(1)	DEFAULT NULL COMMENT 'カスタム１４',
custom15	tinyint(1)	DEFAULT NULL COMMENT 'カスタム１５',
custom16	tinyint(1)	DEFAULT NULL COMMENT 'カスタム１６',
custom17	tinyint(1)	DEFAULT NULL COMMENT 'カスタム１７',
custom18	tinyint(1)	DEFAULT NULL COMMENT 'カスタム１８',
custom19	tinyint(1)	DEFAULT NULL COMMENT 'カスタム１９',
custom20	tinyint(1)	DEFAULT NULL COMMENT 'カスタム２０'


--  PRIMARY KEY (`id`)

) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='新型ハンディ端末設定2';

--
-- テーブルのデータのダンプ `hdy_configs`
--

INSERT INTO `hdy_configs` (`id`, `type`, `company_id`, `update_date`, `last_login`, `comment`, `FW_flag`, `App_ver`, `App_path`, `Kernel_ver`, `Kernel_path`, `mod_flag`, `mod_ver`, `mod_path`, `sim`, `battery_save`, `mode_req_timer`, `clock`, `pri_wifi`, `voice_info`, `key_info`, `prefix_lte`, `rtp_discard`, `rtp_delay`, `ping_interval`, `registar_interval`, `prefix_wifi`, `register_interval_pri_wifi`, `disp_name`, `sip_id`, `sip_password`, `sip_server_domain`, `sip_server_port`, `xmpp_server_host`, `xmpp_server_port`, `xmpp_service`, `xmpp_user_name`, `xmpp_password`, `terminal_name`, `user_login_id`, `user_login_password`, `unattended_rec_id`, `lastcall_id`, `company_name`, `web_account_login_id`, `web_account_login_password`, `pri_ap_mode`, `pri_wifi_nw_mode`, `pri_wifi_ssid`, `pri_wifi_password`, `pri_wifi_transparent`, `gps_conf_interval`, `gps_server_url`, `gps_mode`, `gps_server_interval`, `gps_distance`, `lte_callback_timer`, `lte_time_out_timer`, `lte_time_out_time_rekey`, `wifi_callback_timer`, `wifi_time_out_timer`, `wifi_time_out_time_rekey`, `lte_jitter_buf`, `wifi_jitter_buf`, 'handsfree_mode', 'handsfree_timeout_timer',`silent_alarm`, `lte_alarm_connect`, `pri_wifi_alarm_connect`, `lte_alarm_connect_mode`, `pri_wifi_alarm_connect_mode`, `lte_alarm_connect_fail_type`, `pri_wifi_alarm_connect_fail_type`, `lte_alarm_connect_fail_mode`, `pri_wifi_alarm_connect_fail_mode`, `lte_ind_call_start`, `lte_group_call_start`, `lte_all_call_start`, `lte_telephone_call_start`, `pri_wifi_ind_call_start`, `pri_wifi_group_call_start`, `pri_wifi_all_call_start`, `lte_ind_call_end`, `lte_group_call_end`, `lte_all_call_end`, `lte_telephone_call_end`, `pri_wifi_ind_call_end`, `pri_wifi_group_call_end`, `pri_wifi_all_call_end`, `lte_ind_income_type`, `lte_group_income_type`, `lte_all_call_income_type`, `lte_telephone_income_type`, `lte_message_income_type`, `lte_emergency_income_type`, `pri_wifi_ind_income_type`, `pri_wifi_income_type`, `pri_wifi_all_call_income_type`, `pri_wifi_emergency_income_type`, `continuous_call_mode`, `lte_ind_income_end_type`, `lte_group_income_end_type`, `lte_all_call_income_end_type`, `lte_telephone_call_income_end_type`, `pri_wifi_ind_income_end_type`, `pri_wifi_group_income_end_type`, `pri_wifi_all_call_income_end_type`, `lte_ind_income_alermtime`, `lte_group_income_alermtime`, `lte_all_call_income_alermtime`, `lte_telephone_call_income_alermtime`, `lte_message_income_alermtime`, `lte_emergency_income_alermtime`, `pri_wifi_ind_income_alermtime`, `pri_wifi_group_income_alermtime`, `pri_wifi_all_call_income_alermtime`, `pri_wifi_emergency_income_alermtime`, `lte_out_service_type`, `pri_wifi_out_service_type`, `speaker_min_vol`, `speaker_max_vol`, `speaker_tone_vol`, `speaker_tone_offset`, `speaker_lte_vib`, `speaker_pri_wifi_vib`, `speaker_lte_income`, `speaker_pri_wifi_income`, `speaker_alerm_vol`, `speaker_lte_data`, `speaker_pri_wifi_data`, `audio_mic_type`, `audio_mic_gain`, `audio_speaker_att`, `audio_gain_rx`, `audio_gain_tx`, `audio_key_op`, `audio_echo_can`, `audio_noise_can`, `key_lock`, `key_lock_front`, `key_lock_topside`, `key_lock_volume`, `key_lock_ptt`, `key_lock_mic`, `auto_key_lock_timer`, `key_tone_vol`, `backlight_mode`, `backlight_timer`, `key_p1_sp`, `key_p1_df`, `key_p1_lp`, `key_p2_sp`, `key_p2_df`, `key_p2_lp`, `key_p3_sp`, `key_p3_df`, `key_p3_lp`, `key_p4_sp`, `key_p4_df`, `key_p4_lp`, `key_s1_sp`, `key_s1_df`, `key_s1_lp`, `key_s2_sp`, `key_s2_df`, `key_s2_lp`, `key_u1_sp`, `key_u1_df`, `key_u1_lp`, `key_d1_sp`, `key_d1_df`, `key_d1_lp`, `key_aux_sp`, `key_aux_df`, `key_aux_lp`, `display_pwon_text`, `display_pwon_mode`, `display_screen_logo_url`, `display_battery_flag`, `display_battery_warning`, `display_message_mode`, `display_income_mode`, `display_keylock_icon`, `display_alert_led_mode`, `display_lcd_contrast`, `message_list_m1`, `message_list_m2`, `message_list_m3`, `message_list_m4`, `message_list_m5`, `message_list_m6`, `message_list_m7`, `message_list_m8`, `message_list_m9`, `message_list_m10`, `message_list_m11`, `message_list_m12`, `message_list_m13`, `message_list_m14`, `message_list_m15`, `message_list_m16`, `message_list_m17`, `message_list_m18`, `message_list_m19`, `message_list_m20`, `status_hold_mode`, `emergency_mode_number`, `emergency_cycle`, `emergency_t1_duration`, `emergency_transmit_duration`, `emergency_t2_duration`, `emergency_recieve_duration`, `emergency_locator_tone`, `emergency_mode_type`, `emergency_led`, `emergency_display`, `emergency_text`, `emergency_key_delay_time`, `emergency_mic_sense`, `emergency_bg_transmit`, `emergency_lone_interval`, `emergency_lone_duration`, `emergency_man_flag`, `emergency_man_delay_time`, `emergency_man_pre_alert`, `emergency_man_angle`, `emergency_stationary_flag`, `emergency_stationary_delay_time`, `emergency_stationary_pre_alert`, `emergency_motion_flag`, `emergency_motion_delay_time`, `emergency_motion_pre_alert`, `emergency_remote_flag`, `history_timestamp`, `history_call`, `history_income`, `history_outcome`, `history_message_in`, `history_message_out`, `history_call_list`, `history_income_list`, `history_outcome_list`, `history_message_in_list`, `history_message_out_list`, `custom1`, `custom2`, `custom3`, `custom4`, `custom5`, `custom6`, `custom7`, `custom8`, `custom9`, `custom10`, `custom11`, `custom12`, `custom13`, `custom14`, `custom15`, `custom16`, `custom17`, `custom18`, `custom19`, `custom20`) VALUES
(1, 'factory', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 1, 0, 0, 1, 5, 0, 1000, 60, 3600, 5, 3600, NULL, NULL, NULL, NULL, 5060, NULL, 5222, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, 0, 2, NULL, NULL, 0, 1, NULL, 0, 60, 100, 30, 300, 0, 30, 60, 0, 100, 100, 0, 300, 0, 1, 1, 1, 1, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 5, 0, 31, 10, 0, 0, 0, 10, 10, 10, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 10, 1, 5, 23, 1, 22, 24, 1, 1, 1, 1, 1, 1, 1, 1, 19, 1, 1, 4, 1, 1, 7, 1, 8, 5, 1, 6, 1, 1, 2, NULL, 1, 0, 1, 1, 1, 1, 1, 0, 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 2, -1, 5, 20, 5, 40, -2, 0, 0, 0, NULL, '1.0', 4, 0, 10, 10, 0, 10, 5, 60, 0, 120, 10, 0, 10, 5, 0, 0, 1, 1, 1, 1, 1, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0'),
(2, 'tenant_admin', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 1, 0, 0, 1, 5, 0, 1000, 60, 3600, 5, 3600, NULL, NULL, NULL, NULL, 5060, NULL, 5222, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, 0, 2, NULL, NULL, 0, 1, NULL, 0, 60, 100, 30, 300, 0, 30, 60, 0, 100, 100, 0, 300, 0, 1, 1, 1, 1, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 5, 0, 31, 10, 0, 0, 0, 10, 10, 10, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 10, 1, 5, 23, 1, 22, 24, 1, 1, 1, 1, 1, 1, 1, 1, 19, 1, 1, 4, 1, 1, 7, 1, 8, 5, 1, 6, 1, 1, 2, NULL, 1, 0, 1, 1, 1, 1, 1, 0, 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 2, -1, 5, 20, 5, 40, -2, 0, 0, 0, NULL, '1.0', 4, 0, 10, 10, 0, 10, 5, 60, 0, 120, 10, 0, 10, 5, 0, 0, 1, 1, 1, 1, 1, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0'),
(3, 'device_admin', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 1, 0, 0, 1, 5, 0, 1000, 60, 3600, 5, 3600, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, 0, 2, NULL, NULL, 0, 1, NULL, 0, 60, 100, 30, 300, 0, 30, 60, 0, 100, 100, 0, 300, 0, 1, 1, 1, 1, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 5, 0, 31, 10, 0, 0, 0, 10, 10, 10, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 10, 1, 5, 23, NULL, 22, 24, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 19, NULL, NULL, 4, NULL, NULL, 7, NULL, 8, 5, NULL, 6, NULL, NULL, 2, NULL, 1, 0, 1, 1, 1, 1, 1, 0, 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 2, -1, 5, 20, 5, 40, 2, 0, 0, 0, NULL, '', 4, 0, 10, 10, 0, 10, 5, 60, 0, 120, 10, 0, 10, 5, 0, 0, 1, 1, 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(4, 'tenant', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 1, 0, 0, 1, 5, 0, 1000, 60, 3600, 5, 3600, NULL, NULL, NULL, NULL, 5060, NULL, 5222, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, 0, 2, NULL, NULL, 0, 1, NULL, 0, 60, 100, 30, 300, 0, 30, 60, 0, 100, 100, 0, 300, 0, 1, 1, 1, 1, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 5, 0, 31, 10, 0, 0, 0, 10, 10, 10, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 10, 1, 5, 23, 1, 22, 24, 1, 1, 1, 1, 1, 1, 1, 1, 19, 1, 1, 4, 1, 1, 7, 1, 8, 5, 1, 6, 1, 1, 2, NULL, 1, 0, 1, 1, 1, 1, 1, 0, 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 2, -1, 5, 20, 5, 40, -2, 0, 0, 0, NULL, '1.0', 4, 0, 10, 10, 0, 10, 5, 60, 0, 120, 10, 0, 10, 5, 0, 0, 1, 1, 1, 1, 1, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0'),
(5, 'device', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 1, 0, 0, 1, 5, 0, 1000, 60, 3600, 5, 3600, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, 0, 2, NULL, NULL, 0, 1, NULL, 0, 60, 100, 30, 300, 0, 30, 60, 0, 100, 100, 0, 300, 0, 1, 1, 1, 1, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 5, 0, 31, 10, 0, 0, 0, 10, 10, 10, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 10, 1, 5, 23, NULL, 22, 24, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 19, NULL, NULL, 4, NULL, NULL, 7, NULL, 8, 5, NULL, 6, NULL, NULL, 2, NULL, 1, 0, 1, 1, 1, 1, 1, 0, 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 2, -1, 5, 20, 5, 40, 2, 0, 0, 0, NULL, '', 4, 0, 10, 10, 0, 10, 5, 60, 0, 120, 10, 0, 10, 5, 0, 0, 1, 1, 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `hdy_configs`
--
ALTER TABLE `hdy_configs`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `hdy_configs`
--
ALTER TABLE `hdy_configs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID', AUTO_INCREMENT=2;COMMIT;
